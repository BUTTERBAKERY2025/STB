const fs = require('fs');

// List of files to fix
const files = [
  'client/src/pages/geo-tracking.tsx',
  'client/src/components/financial/ChartOfAccountsManager.tsx',
  'client/src/components/financial/JournalEntryManager.tsx',
  'client/src/components/financial/ProjectFinancialCenter.tsx',
];

files.forEach(file => {
  if (!fs.existsSync(file)) {
    console.log(`File not found: ${file}`);
    return;
  }

  let content = fs.readFileSync(file, 'utf8');
  
  // Replace empty value="" with value="none" or value="all"
  content = content.replace(/<SelectItem value="">/g, '<SelectItem value="none">');
  
  // Special case for geo-tracking & financial reports, replace "all types" with value="all"
  content = content.replace('<SelectItem value="none">جميع الأنواع</SelectItem>', '<SelectItem value="all">جميع الأنواع</SelectItem>');
  content = content.replace('<SelectItem value="none">كل المشاريع</SelectItem>', '<SelectItem value="all">كل المشاريع</SelectItem>');
  
  // Fix radius input - set empty string when null
  content = content.replace(/value=\{locationForm\.radius\}/g, 'value={locationForm.radius || ""}');
  content = content.replace(/onChange=\{\(e\) => setLocationForm\(\{\.\.\.locationForm, radius: parseInt\(e\.target\.value\)\}\)\}/g, 
                          'onChange={(e) => setLocationForm({...locationForm, radius: e.target.value ? parseInt(e.target.value) : null})}');
  
  // Write the fixed content back to the file
  fs.writeFileSync(file, content);
  console.log(`Fixed: ${file}`);
});
