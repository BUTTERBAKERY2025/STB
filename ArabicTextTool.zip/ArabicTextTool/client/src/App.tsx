import { Route, Switch } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

// صفحات النظام
import Dashboard from "./pages/dashboard";
import Projects from "./pages/projects-new";
import DailyReports from "./pages/daily-reports";
import Finances from "./pages/finances";
import FinancialReports from "./pages/financial-reports";
import Equipment from "./pages/equipment";
import Chat from "./pages/chat";
import Documents from "./pages/documents";
import Settings from "./pages/settings";
import RiskPrediction from "./pages/risk-prediction";
import GeoTracking from "./pages/geo-tracking";
import OcrProcessing from "./pages/ocr-processing";
import PaymentRequestGenerator from "./pages/إصدار_مستخلص";
import ProjectProfitability from "./pages/دراسة_المشروع";
import AIAnalytics from "./pages/ai-analytics";
import Workforce from "./pages/workforce";
import Accounts from "./pages/الحسابات";
import FinancialCenter from "./pages/المركز-المالي";
import FinancialSystem from "./pages/financial-system";
import Reports from "./pages/reports";
import NotFound from "./pages/not-found";
import AuthPage from "./pages/auth-page";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Toaster />
        <Switch>
          {/* صفحة تسجيل الدخول */}
          <Route path="/auth">
            <AuthPage />
          </Route>
          
          {/* لوحة التحكم الرئيسية */}
          <Route path="/">
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          </Route>
          
          {/* صفحة المشاريع */}
          <Route path="/projects">
            <ProtectedRoute>
              <Projects />
            </ProtectedRoute>
          </Route>
          
          {/* تفاصيل مشروع محدد */}
          <Route path="/projects/:id">
            {(params) => (
              <ProtectedRoute>
                <Projects />
              </ProtectedRoute>
            )}
          </Route>
          
          {/* التقارير اليومية */}
          <Route path="/daily-reports">
            <ProtectedRoute>
              <DailyReports />
            </ProtectedRoute>
          </Route>
          
          {/* المالية */}
          <Route path="/finances">
            <ProtectedRoute>
              <Finances />
            </ProtectedRoute>
          </Route>
          
          {/* المعدات */}
          <Route path="/equipment">
            <ProtectedRoute>
              <Equipment />
            </ProtectedRoute>
          </Route>
          
          {/* القوى العاملة */}
          <Route path="/workforce">
            <ProtectedRoute>
              <Workforce />
            </ProtectedRoute>
          </Route>
          
          {/* المحادثات */}
          <Route path="/chat">
            <ProtectedRoute>
              <Chat />
            </ProtectedRoute>
          </Route>
          
          {/* المستندات */}
          <Route path="/documents">
            <ProtectedRoute>
              <Documents />
            </ProtectedRoute>
          </Route>
          
          {/* التنبؤ بالمخاطر */}
          <Route path="/risk-prediction">
            <ProtectedRoute>
              <RiskPrediction />
            </ProtectedRoute>
          </Route>
          
          {/* التتبع الجغرافي */}
          <Route path="/geo-tracking">
            <ProtectedRoute>
              <GeoTracking />
            </ProtectedRoute>
          </Route>
          
          {/* معالجة النصوص */}
          <Route path="/ocr-processing">
            <ProtectedRoute>
              <OcrProcessing />
            </ProtectedRoute>
          </Route>
          
          {/* إصدار مستخلص */}
          <Route path="/payment-requests">
            <ProtectedRoute>
              <PaymentRequestGenerator />
            </ProtectedRoute>
          </Route>
          
          {/* دراسة المشروع */}
          <Route path="/project-profitability">
            <ProtectedRoute>
              <ProjectProfitability />
            </ProtectedRoute>
          </Route>
          
          {/* تحليلات الذكاء الاصطناعي */}
          <Route path="/ai-analytics">
            <ProtectedRoute>
              <AIAnalytics />
            </ProtectedRoute>
          </Route>
          
          {/* الحسابات */}
          <Route path="/accounts">
            <ProtectedRoute>
              <Accounts />
            </ProtectedRoute>
          </Route>
          
          {/* المركز المالي */}
          <Route path="/financial-center">
            <ProtectedRoute>
              <FinancialCenter />
            </ProtectedRoute>
          </Route>
          
          {/* النظام المالي */}
          <Route path="/financial-system">
            <ProtectedRoute>
              <FinancialSystem />
            </ProtectedRoute>
          </Route>
          
          {/* التقارير */}
          <Route path="/reports">
            <ProtectedRoute>
              <Reports />
            </ProtectedRoute>
          </Route>
          
          {/* التقارير المالية */}
          <Route path="/financial-reports">
            <ProtectedRoute>
              <FinancialReports />
            </ProtectedRoute>
          </Route>
          
          {/* الإعدادات */}
          <Route path="/settings">
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          </Route>
          
          {/* صفحة غير موجودة */}
          <Route path="/:rest*">
            <NotFound />
          </Route>
        </Switch>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;