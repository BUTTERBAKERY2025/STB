import React from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  Legend,
  LineChart,
  Line
} from 'recharts';
import { Badge } from '@/components/ui/badge';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';

interface PaymentRequest {
  id: number;
  projectId: number;
  requestNumber: string;
  title: string;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  totalAmount: number;
  previousPaymentsAmount: number;
  currentPaymentAmount: number;
  totalCompletionPercentage: number;
  notes: string | null;
  approvedBy: number | null;
  approvalDate: string | null;
  paymentDate: string | null;
  issueDate: string;
  createdBy: number;
  createdAt: string;
}

interface Project {
  id: number;
  name: string;
  budget: number;
  startDate: Date;
  endDate: Date;
  status: string;
  progress: number;
}

interface ProjectFinancialInsightsProps {
  project: Project;
  paymentRequests: PaymentRequest[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#a855f7', '#ec4899'];

const ProjectFinancialInsights: React.FC<ProjectFinancialInsightsProps> = ({ 
  project, 
  paymentRequests 
}) => {
  // حساب إجمالي المدفوعات
  const totalPaid = paymentRequests.reduce((sum, pr) => {
    // نحسب فقط المستخلصات المدفوعة أو المعتمدة
    if (pr.status === 'paid' || pr.status === 'approved') {
      return sum + pr.currentPaymentAmount;
    }
    return sum;
  }, 0);
  
  // حساب إجمالي المعتمد وقيد الدفع
  const totalApproved = paymentRequests.reduce((sum, pr) => {
    if (pr.status === 'approved' && pr.status !== 'paid') {
      return sum + pr.currentPaymentAmount;
    }
    return sum;
  }, 0);
  
  // حساب إجمالي المستخلصات قيد المراجعة
  const totalPending = paymentRequests.reduce((sum, pr) => {
    if (pr.status === 'under_review' || pr.status === 'waiting_approval') {
      return sum + pr.currentPaymentAmount;
    }
    return sum;
  }, 0);
  
  // حساب المبلغ المتبقي
  const remainingBudget = project.budget - totalPaid - totalApproved - totalPending;
  
  // بيانات مصروفات المشروع حسب الشهر
  const paymentsByMonth = paymentRequests.reduce((acc: Record<string, number>, pr) => {
    const month = new Date(pr.issueDate).toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' });
    acc[month] = (acc[month] || 0) + pr.currentPaymentAmount;
    return acc;
  }, {});
  
  const monthlyData = Object.entries(paymentsByMonth).map(([month, amount]) => ({
    month,
    amount: amount
  }));
  
  // بيانات نسب الإنجاز عبر الزمن
  const progressData = paymentRequests
    .sort((a, b) => new Date(a.issueDate).getTime() - new Date(b.issueDate).getTime())
    .map(pr => ({
      date: new Date(pr.issueDate).toLocaleDateString('ar-SA', { month: 'short', year: 'numeric' }),
      progress: pr.totalCompletionPercentage
    }));
  
  // بيانات توزيع المستخلصات حسب الحالة
  const statusCounts = paymentRequests.reduce((acc: Record<string, number>, pr) => {
    acc[pr.status] = (acc[pr.status] || 0) + 1;
    return acc;
  }, {});
  
  const statusData = Object.entries(statusCounts).map(([status, count]) => ({
    status: getStatusTranslation(status),
    count: count
  }));
  
  // بيانات توزيع الميزانية
  const budgetData = [
    { name: 'مدفوع', value: totalPaid },
    { name: 'معتمد', value: totalApproved },
    { name: 'قيد المراجعة', value: totalPending },
    { name: 'متبقي', value: remainingBudget > 0 ? remainingBudget : 0 }
  ];
  
  // حساب متوسط قيمة المستخلص
  const averagePaymentAmount = paymentRequests.length > 0
    ? paymentRequests.reduce((sum, pr) => sum + pr.currentPaymentAmount, 0) / paymentRequests.length
    : 0;
  
  // حالة تنفيذ المشروع (متأخر، في الوقت المحدد، مبكر)
  const projectStatus = getProjectTimeStatus(project);
  
  // حساب نسبة الإنجاز مقارنة بنسبة الوقت المنقضي
  const elapsedTimePercentage = calculateElapsedTimePercentage(project);
  const progressBalance = project.progress - elapsedTimePercentage;
  
  return (
    <div className="space-y-6">
      <Tabs defaultValue="summary" className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="summary">ملخص المشروع</TabsTrigger>
          <TabsTrigger value="charts">رسوم بيانية</TabsTrigger>
          <TabsTrigger value="payments">المستخلصات</TabsTrigger>
        </TabsList>
        
        {/* قسم ملخص المشروع */}
        <TabsContent value="summary">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">نظرة عامة على المشروع</CardTitle>
                <CardDescription>ملخص الحالة المالية للمشروع</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">اسم المشروع</p>
                      <p className="font-medium">{project.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">الميزانية</p>
                      <p className="font-medium">{project.budget.toLocaleString()} ر.س</p>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <p className="text-sm text-muted-foreground">نسبة الإنجاز</p>
                      <p className="text-sm font-medium">{project.progress}%</p>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <p className="text-sm text-muted-foreground">نسبة المنصرف من الميزانية</p>
                      <p className="text-sm font-medium">{Math.round((totalPaid / project.budget) * 100)}%</p>
                    </div>
                    <Progress value={(totalPaid / project.budget) * 100} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">المدفوع</p>
                      <p className="font-medium text-green-600">{totalPaid.toLocaleString()} ر.س</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">المعتمد (غير مدفوع)</p>
                      <p className="font-medium text-blue-600">{totalApproved.toLocaleString()} ر.س</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">قيد المراجعة</p>
                      <p className="font-medium text-amber-600">{totalPending.toLocaleString()} ر.س</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">المتبقي من الميزانية</p>
                      <p className="font-medium">{remainingBudget.toLocaleString()} ر.س</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">مؤشرات الأداء</CardTitle>
                <CardDescription>تحليل أداء المشروع</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <p className="text-sm">حالة الجدول الزمني</p>
                    <Badge className={
                      projectStatus === 'ahead' ? 'bg-green-600' : 
                      projectStatus === 'on-track' ? 'bg-blue-600' : 
                      'bg-red-600'
                    }>
                      {projectStatus === 'ahead' ? 'متقدم عن الجدول الزمني' : 
                       projectStatus === 'on-track' ? 'في الموعد المحدد' : 
                       'متأخر عن الجدول الزمني'}
                    </Badge>
                  </div>
                  
                  <div>
                    <p className="text-sm mb-1">نسبة الإنجاز مقارنة بالوقت المنقضي</p>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs">الإنجاز</span>
                      <span className="text-xs">{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2 mb-1" />
                    
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs">الوقت المنقضي</span>
                      <span className="text-xs">{elapsedTimePercentage}%</span>
                    </div>
                    <Progress value={elapsedTimePercentage} className="h-2" />
                    
                    <div className="mt-2">
                      <p className="text-sm">
                        المشروع {
                          progressBalance > 10 ? 'متقدم بشكل ملحوظ' :
                          progressBalance > 0 ? 'متقدم قليلاً' :
                          progressBalance > -10 ? 'متزامن تقريباً' :
                          'متأخر'
                        } ({Math.abs(progressBalance)}% {progressBalance >= 0 ? 'متقدم' : 'متأخر'})
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">متوسط قيمة المستخلص</p>
                      <p className="font-medium">{averagePaymentAmount.toLocaleString()} ر.س</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">عدد المستخلصات</p>
                      <p className="font-medium">{paymentRequests.length}</p>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">المستخلصات حسب الحالة</p>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(statusCounts).map(([status, count]) => (
                        <div key={status} className="flex justify-between items-center">
                          <span className="text-xs">{getStatusTranslation(status)}</span>
                          <Badge variant="outline">{count}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* قسم الرسوم البيانية */}
        <TabsContent value="charts">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">توزيع الميزانية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={budgetData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={90}
                        paddingAngle={2}
                        dataKey="value"
                        nameKey="name"
                        label={({ name, percent }: any) => 
                          `${name}: ${(percent * 100).toFixed(0)}%`
                        }
                        labelLine={false}
                      >
                        {budgetData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: any) => `${value.toLocaleString()} ر.س`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">المستخلصات الشهرية</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value: any) => `${value.toLocaleString()} ر.س`} />
                      <Bar dataKey="amount" fill="#6366f1" name="المبلغ" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">تطور نسبة الإنجاز</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={progressData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[0, 100]} />
                      <Tooltip formatter={(value: any) => `${value}%`} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="progress" 
                        stroke="#10b981" 
                        name="نسبة الإنجاز" 
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">المستخلصات حسب الحالة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={statusData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="status" type="category" />
                      <Tooltip />
                      <Bar dataKey="count" fill="#7c3aed" name="عدد المستخلصات" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* قسم تفاصيل المستخلصات */}
        <TabsContent value="payments">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">سجل المستخلصات</CardTitle>
              <CardDescription>تفاصيل جميع المستخلصات المالية للمشروع</CardDescription>
            </CardHeader>
            <CardContent>
              {paymentRequests.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">لا توجد مستخلصات مالية لهذا المشروع</p>
              ) : (
                <div className="space-y-4">
                  {paymentRequests
                    .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
                    .map(request => (
                      <div key={request.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-medium">{request.title}</h4>
                            <p className="text-sm text-muted-foreground">رقم: {request.requestNumber}</p>
                          </div>
                          <Badge className={getStatusBadgeColor(request.status)}>
                            {getStatusTranslation(request.status)}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-2">
                          <div>
                            <p className="text-sm text-muted-foreground">تاريخ الإصدار</p>
                            <p className="text-sm">{new Date(request.issueDate).toLocaleDateString('ar-SA')}</p>
                          </div>
                          
                          <div>
                            <p className="text-sm text-muted-foreground">الفترة</p>
                            <p className="text-sm">
                              {new Date(request.startDate).toLocaleDateString('ar-SA')} إلى {new Date(request.endDate).toLocaleDateString('ar-SA')}
                            </p>
                          </div>
                          
                          <div>
                            <p className="text-sm text-muted-foreground">نسبة الإنجاز</p>
                            <p className="text-sm">{request.totalCompletionPercentage}%</p>
                          </div>
                          
                          <div>
                            <p className="text-sm text-muted-foreground">قيمة المستخلص</p>
                            <p className="text-sm font-medium">{request.currentPaymentAmount.toLocaleString()} ر.س</p>
                          </div>
                        </div>
                        
                        {request.paymentDate && (
                          <div className="mt-2 text-sm text-green-600">
                            تم الدفع بتاريخ: {new Date(request.paymentDate).toLocaleDateString('ar-SA')}
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// وظائف مساعدة

// ترجمة حالة المستخلص
function getStatusTranslation(status: string): string {
  switch (status) {
    case 'draft': return 'مسودة';
    case 'under_review': return 'قيد المراجعة';
    case 'waiting_approval': return 'بانتظار الاعتماد';
    case 'approved': return 'معتمد';
    case 'paid': return 'مدفوع';
    case 'rejected': return 'مرفوض';
    case 'archived': return 'مؤرشف';
    default: return status;
  }
}

// لون شارة الحالة
function getStatusBadgeColor(status: string): string {
  switch (status) {
    case 'draft': return 'bg-gray-500';
    case 'under_review': return 'bg-amber-500';
    case 'waiting_approval': return 'bg-orange-500';
    case 'approved': return 'bg-blue-500';
    case 'paid': return 'bg-green-500';
    case 'rejected': return 'bg-red-500';
    case 'archived': return 'bg-purple-500';
    default: return '';
  }
}

// حساب حالة الجدول الزمني للمشروع
function getProjectTimeStatus(project: Project): 'ahead' | 'on-track' | 'behind' {
  const elapsedTimePercentage = calculateElapsedTimePercentage(project);
  
  // قارن نسبة الإنجاز مع نسبة الوقت المنقضي
  if (project.progress > elapsedTimePercentage + 10) {
    return 'ahead';
  } else if (project.progress < elapsedTimePercentage - 10) {
    return 'behind';
  } else {
    return 'on-track';
  }
}

// حساب نسبة الوقت المنقضي من المشروع
function calculateElapsedTimePercentage(project: Project): number {
  const now = new Date();
  const startDate = new Date(project.startDate);
  const endDate = new Date(project.endDate);
  
  const totalDuration = endDate.getTime() - startDate.getTime();
  const elapsedDuration = now.getTime() - startDate.getTime();
  
  // إذا لم يبدأ المشروع بعد
  if (elapsedDuration < 0) return 0;
  
  // إذا انتهى المشروع
  if (elapsedDuration > totalDuration) return 100;
  
  // حساب النسبة المئوية
  return Math.round((elapsedDuration / totalDuration) * 100);
}

export default ProjectFinancialInsights;