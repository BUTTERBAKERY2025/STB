import React from 'react';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableFooter, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Save, Download, Printer, FileText } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { Card, CardContent } from '@/components/ui/card';

interface Project {
  id: number;
  name: string;
  status: string;
}

interface PaymentRequestItem {
  id: number;
  paymentRequestId: number;
  itemName: string;
  itemDescription: string | null;
  unit: string;
  unitPrice: number;
  plannedQuantity: number;
  completedQuantity: number;
  completionPercentage: number;
  previousPaymentPercentage: number;
  currentPaymentAmount: number;
  notes: string | null;
}

interface PaymentRequest {
  id: number;
  projectId: number;
  requestNumber: string;
  title: string;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  totalAmount: number;
  previousPaymentsAmount: number;
  currentPaymentAmount: number;
  totalCompletionPercentage: number;
  notes: string | null;
  approvedBy: number | null;
  approvalDate: string | null;
  paymentDate: string | null;
  issueDate: string;
  createdBy: number;
  createdAt: string;
  attachments: string[];
}

interface User {
  id: number;
  username: string;
  fullName: string;
  role: string;
}

interface PaymentRequestToPdfTemplateProps {
  paymentRequest: PaymentRequest;
  paymentRequestItems: PaymentRequestItem[];
  project: Project;
  company?: {
    name: string;
    logo?: string;
    address?: string;
    phone?: string;
    email?: string;
    website?: string;
    taxId?: string;
  };
  createdByUser?: User;
  approvedByUser?: User;
}

const PaymentRequestToPdfTemplate: React.FC<PaymentRequestToPdfTemplateProps> = ({
  paymentRequest,
  paymentRequestItems,
  project,
  createdByUser,
  approvedByUser,
  company
}) => {
  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    return format(new Date(dateString), 'dd MMMM yyyy', { locale: arSA });
  };

  // تحويل الأرقام إلى الكلمات العربية
  const convertNumberToArabicWords = (number: number) => {
    const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة', 'عشرة'];
    const teens = ['', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
    const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
    const thousands = ['', 'ألف', 'ألفان', 'آلاف', 'آلاف', 'آلاف', 'آلاف', 'آلاف', 'آلاف', 'آلاف', 'آلاف'];
    
    if (number === 0) return 'صفر';
    
    let words = '';
    
    // تجزئة الرقم
    const integerPart = Math.floor(number);
    const decimalPart = Math.round((number - integerPart) * 100);
    
    // معالجة الجزء الصحيح
    if (integerPart < 11) {
      words = units[integerPart];
    } else if (integerPart < 20) {
      words = teens[integerPart - 10];
    } else if (integerPart < 100) {
      const unit = integerPart % 10;
      const ten = Math.floor(integerPart / 10);
      if (unit === 0) {
        words = tens[ten];
      } else {
        words = units[unit] + ' و' + tens[ten];
      }
    } else if (integerPart < 1000) {
      const hundred = Math.floor(integerPart / 100);
      const remainder = integerPart % 100;
      
      words = hundreds[hundred];
      
      if (remainder > 0) {
        words += ' و' + convertNumberToArabicWords(remainder);
      }
    } else if (integerPart < 10000) {
      const thousand = Math.floor(integerPart / 1000);
      const remainder = integerPart % 1000;
      
      if (thousand === 1) {
        words = 'ألف';
      } else if (thousand === 2) {
        words = 'ألفان';
      } else if (thousand >= 3 && thousand <= 10) {
        words = units[thousand] + ' ' + thousands[3];
      } else {
        words = convertNumberToArabicWords(thousand) + ' ' + 'ألف';
      }
      
      if (remainder > 0) {
        words += ' و' + convertNumberToArabicWords(remainder);
      }
    } else {
      return number.toLocaleString('ar-SA'); // للأرقام الكبيرة نعود للصيغة الرقمية
    }
    
    // إضافة الكسور
    if (decimalPart > 0) {
      words += ' و' + convertNumberToArabicWords(decimalPart) + ' هللة';
    }
    
    return words + ' ريال سعودي';
  };

  // حساب المجاميع
  const totals = {
    plannedAmount: paymentRequestItems && paymentRequestItems.length > 0 ? paymentRequestItems.reduce((sum: number, item) => sum + (item.unitPrice * item.plannedQuantity), 0) : 0,
    completedAmount: paymentRequestItems && paymentRequestItems.length > 0 ? paymentRequestItems.reduce((sum: number, item) => sum + (item.unitPrice * item.completedQuantity * item.completionPercentage / 100), 0) : 0,
    currentPayment: paymentRequestItems && paymentRequestItems.length > 0 ? paymentRequestItems.reduce((sum: number, item) => sum + item.currentPaymentAmount, 0) : 0
  };

  // تصدير إلى PDF
  const exportToPdf = async () => {
    const element = document.getElementById('payment-request-pdf-template');
    if (!element) return;
    
    try {
      // التعامل البسيط - إنشاء PDF مباشرة
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      // إضافة عنوان
      pdf.setFont("Helvetica", "bold");
      pdf.setFontSize(18);
      pdf.text(`مستخلص مالي: ${paymentRequest.requestNumber}`, 105, 20, { align: 'center' });
      
      // إضافة معلومات المشروع
      pdf.setFontSize(12);
      pdf.text(`اسم المشروع: ${project.name}`, 190, 40, { align: 'right' });
      pdf.text(`حالة المستخلص: ${paymentRequest.status}`, 190, 48, { align: 'right' });
      pdf.text(`تاريخ المستخلص: ${new Date(paymentRequest.issueDate).toLocaleDateString('ar-SA')}`, 190, 56, { align: 'right' });
      pdf.text(`المبلغ الإجمالي: ${paymentRequest.totalAmount.toLocaleString()} ريال`, 190, 64, { align: 'right' });
      
      // إضافة جدول البنود (مبسط)
      let yPos = 80;
      pdf.line(20, yPos, 190, yPos);
      yPos += 8;
      pdf.text("البند", 175, yPos);
      pdf.text("الكمية", 125, yPos);
      pdf.text("السعر", 90, yPos);
      pdf.text("المبلغ المستحق", 40, yPos);
      yPos += 8;
      pdf.line(20, yPos, 190, yPos);
      yPos += 10;
      
      // إضافة البنود
      if (paymentRequestItems && paymentRequestItems.length > 0) {
        paymentRequestItems.forEach((item: PaymentRequestItem, index: number) => {
          pdf.text(item.itemName, 175, yPos, { align: 'right', maxWidth: 70 });
          pdf.text(item.completedQuantity.toString(), 125, yPos, { align: 'center' });
          pdf.text(item.unitPrice.toLocaleString(), 90, yPos, { align: 'center' });
          pdf.text(item.currentPaymentAmount.toLocaleString(), 40, yPos, { align: 'center' });
          yPos += 10;
          
          // التحقق من تجاوز الصفحة
          if (yPos > 260) {
            pdf.addPage();
            yPos = 30;
          }
        });
      } else {
        pdf.text("لا توجد بنود مضافة", 105, yPos, { align: 'center' });
        yPos += 10;
      }
      
      // إضافة الإجمالي
      yPos += 5;
      pdf.line(20, yPos, 190, yPos);
      yPos += 10;
      pdf.setFont("Helvetica", "bold");
      pdf.text("الإجمالي:", 175, yPos);
      const totalAmount = paymentRequestItems && paymentRequestItems.length > 0 ? paymentRequestItems.reduce((sum: number, item: PaymentRequestItem) => sum + item.currentPaymentAmount, 0) : 0;
      pdf.text(totalAmount.toLocaleString() + " ريال", 40, yPos, { align: 'center' });
      
      // إضافة التوقيعات
      yPos += 30;
      pdf.text("إعداد:", 170, yPos);
      pdf.text("اعتماد:", 100, yPos);
      pdf.text("ختم الشركة:", 30, yPos);
      
      pdf.save(`مستخلص_${paymentRequest.requestNumber}_${project.name}.pdf`);
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      alert('حدث خطأ أثناء تصدير المستخلص، يرجى المحاولة مرة أخرى.');
    }
  };

  // طباعة المستخلص
  const printPaymentRequest = () => {
    window.print();
  };

  return (
    <div className="space-y-4">
      <div className="print:hidden flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">نموذج المستخلص المالي المتقدم</h2>
        <div className="flex space-x-2 space-x-reverse">
          <Button variant="outline" onClick={exportToPdf}>
            <Download className="ml-2 h-4 w-4" />
            تصدير PDF
          </Button>
          <Button variant="outline" onClick={printPaymentRequest}>
            <Printer className="ml-2 h-4 w-4" />
            طباعة
          </Button>
        </div>
      </div>
      
      <Card className="print:shadow-none">
        <CardContent className="p-6">
          <div id="payment-request-pdf-template" className="bg-white p-6 min-h-[29.7cm]" dir="rtl">
            {/* رأس المستند */}
            <div className="flex justify-between items-start border-b pb-4 mb-6">
              <div className="text-right">
                <h1 className="text-2xl font-bold text-primary mb-1">{company?.name || 'شركة المقاولات'}</h1>
                {company?.address && <p className="text-sm text-gray-600">{company.address}</p>}
                <div className="flex space-x-4 space-x-reverse text-sm text-gray-600 mt-1">
                  {company?.phone && <p>هاتف: {company.phone}</p>}
                  {company?.email && <p>بريد إلكتروني: {company.email}</p>}
                </div>
                {company?.website && <p className="text-sm text-gray-600">الموقع: {company.website}</p>}
              </div>
              <div className="text-left">
                <h2 className="text-xl font-bold mb-2">مستخلص مالي</h2>
                <p className="text-sm text-gray-600">رقم المستخلص: {paymentRequest.requestNumber}</p>
                <p className="text-sm text-gray-600">تاريخ الإصدار: {formatDate(paymentRequest.issueDate)}</p>
                <Badge 
                  className="mt-2"
                  variant={
                    paymentRequest.status === 'paid' ? 'default' : 
                    paymentRequest.status === 'approved' ? 'outline' : 
                    'secondary'
                  }
                >
                  {paymentRequest.status === 'paid' ? 'مدفوع' : 
                   paymentRequest.status === 'approved' ? 'معتمد' : 
                   paymentRequest.status === 'rejected' ? 'مرفوض' : 
                   'قيد المراجعة'}
                </Badge>
              </div>
            </div>
            
            {/* معلومات المشروع والمستخلص */}
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <h3 className="text-lg font-semibold border-b pb-2 mb-2">معلومات المشروع</h3>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">اسم المشروع:</p>
                  <p className="text-sm col-span-2">{project.name}</p>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">حالة المشروع:</p>
                  <p className="text-sm col-span-2">{project.status}</p>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">نوع المستخلص:</p>
                  <p className="text-sm col-span-2">{paymentRequest.type}</p>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">عنوان المستخلص:</p>
                  <p className="text-sm col-span-2">{paymentRequest.title}</p>
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-semibold border-b pb-2 mb-2">معلومات الفترة</h3>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">فترة المستخلص:</p>
                  <p className="text-sm col-span-2">
                    من {formatDate(paymentRequest.startDate)} إلى {formatDate(paymentRequest.endDate)}
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">نسبة الإنجاز الكلية:</p>
                  <p className="text-sm col-span-2">{paymentRequest.totalCompletionPercentage}%</p>
                </div>
                <div className="grid grid-cols-3 gap-1">
                  <p className="text-sm font-medium">المدفوعات السابقة:</p>
                  <p className="text-sm col-span-2">{paymentRequest.previousPaymentsAmount.toLocaleString()} ريال</p>
                </div>
                {paymentRequest.paymentDate && (
                  <div className="grid grid-cols-3 gap-1">
                    <p className="text-sm font-medium">تاريخ الدفع:</p>
                    <p className="text-sm col-span-2">{formatDate(paymentRequest.paymentDate)}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* جدول البنود */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold border-b pb-2 mb-4">بنود المستخلص</h3>
              <Table className="border">
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="w-[50px] text-right">#</TableHead>
                    <TableHead className="text-right">البند</TableHead>
                    <TableHead className="text-right">الوحدة</TableHead>
                    <TableHead className="text-center">السعر</TableHead>
                    <TableHead className="text-center">الكمية المخططة</TableHead>
                    <TableHead className="text-center">الكمية المنفذة</TableHead>
                    <TableHead className="text-center">نسبة الإنجاز</TableHead>
                    <TableHead className="text-center">نسبة الدفع السابق</TableHead>
                    <TableHead className="text-center">المبلغ المستحق</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentRequestItems && paymentRequestItems.length > 0 ? paymentRequestItems.map((item: PaymentRequestItem, index: number) => (
                    <TableRow key={item.id}>
                      <TableCell className="text-right">{index + 1}</TableCell>
                      <TableCell className="text-right">
                        <div className="font-medium">{item.itemName}</div>
                        {item.itemDescription && (
                          <div className="text-xs text-gray-500">{item.itemDescription}</div>
                        )}
                      </TableCell>
                      <TableCell className="text-right">{item.unit}</TableCell>
                      <TableCell className="text-center">{item.unitPrice.toLocaleString()}</TableCell>
                      <TableCell className="text-center">{item.plannedQuantity.toLocaleString()}</TableCell>
                      <TableCell className="text-center">{item.completedQuantity.toLocaleString()}</TableCell>
                      <TableCell className="text-center">{item.completionPercentage}%</TableCell>
                      <TableCell className="text-center">{item.previousPaymentPercentage}%</TableCell>
                      <TableCell className="text-center font-medium">{item.currentPaymentAmount.toLocaleString()}</TableCell>
                    </TableRow>
                  )) : (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-4">
                        لا توجد بنود مضافة بعد
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
                <TableFooter>
                  <TableRow>
                    <TableCell colSpan={4} className="text-right">المجموع</TableCell>
                    <TableCell className="text-center">{totals.plannedAmount.toLocaleString()}</TableCell>
                    <TableCell colSpan={3} className="text-right">إجمالي المبلغ المستحق</TableCell>
                    <TableCell className="text-center font-bold">{totals.currentPayment.toLocaleString()}</TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
            
            {/* المبلغ بالكلمات */}
            <div className="mb-6 border p-3 bg-muted/20 rounded-md">
              <p className="text-sm">
                <span className="font-medium ml-2">المبلغ بالكلمات:</span>
                {convertNumberToArabicWords(totals.currentPayment)}
              </p>
            </div>
            
            {/* ملاحظات */}
            {paymentRequest.notes && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold border-b pb-2 mb-2">ملاحظات</h3>
                <p className="text-sm">{paymentRequest.notes}</p>
              </div>
            )}
            
            {/* التوقيعات */}
            <div className="grid grid-cols-3 gap-6 mt-16">
              <div className="text-center">
                <p className="font-medium mb-8">إعداد</p>
                <p className="mb-2">{createdByUser?.fullName || 'مهندس المشروع'}</p>
                <div className="border-t pt-1 w-32 mx-auto">
                  <p className="text-xs">التوقيع</p>
                </div>
              </div>
              
              {approvedByUser && paymentRequest.approvalDate && (
                <div className="text-center">
                  <p className="font-medium mb-8">اعتماد</p>
                  <p className="mb-2">{approvedByUser.fullName}</p>
                  <div className="border-t pt-1 w-32 mx-auto">
                    <p className="text-xs">التوقيع</p>
                  </div>
                </div>
              )}
              
              <div className="text-center">
                <p className="font-medium mb-8">ختم الشركة</p>
                <div className="border border-dashed border-gray-300 rounded-full w-20 h-20 mx-auto mb-2 flex items-center justify-center">
                  <span className="text-gray-400 text-xs">الختم هنا</span>
                </div>
                <div className="border-t pt-1 w-32 mx-auto">
                  <p className="text-xs">التاريخ: {formatDate(paymentRequest.issueDate)}</p>
                </div>
              </div>
            </div>
            
            {/* رقم تسلسلي وشريط سفلي */}
            <div className="mt-10 border-t pt-4 flex justify-between text-xs text-gray-500">
              <p>مستخلص رقم: {paymentRequest.requestNumber}</p>
              <p>تم إنشاؤه بواسطة نظام إدارة المشاريع</p>
              <p>صفحة 1 من 1</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentRequestToPdfTemplate;