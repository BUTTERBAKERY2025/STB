import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CheckIcon, X, Clock, AlertTriangle, Ban, FileCheck, CreditCard, ArchiveIcon, Info } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface User {
  id: number;
  username: string;
  fullName: string;
  role: string;
  avatar: string | null;
}

export type PaymentRequestStatus = 
  | 'draft' // مسودة
  | 'under_review' // قيد المراجعة
  | 'approved' // معتمد
  | 'paid' // مدفوع
  | 'rejected' // مرفوض
  | 'waiting_approval' // في انتظار الاعتماد
  | 'pending_payment' // في انتظار الدفع
  | 'archived'; // مؤرشف

interface PaymentRequest {
  id: number;
  projectId: number;
  requestNumber: string;
  title: string;
  type: string;
  startDate: string;
  endDate: string;
  status: PaymentRequestStatus;
  totalAmount: number;
  previousPaymentsAmount: number;
  currentPaymentAmount: number;
  totalCompletionPercentage: number;
  notes: string | null;
  approvedBy: number | null;
  approvalDate: string | null;
  paymentDate: string | null;
  issueDate: string;
  createdBy: number;
  createdAt: string;
  attachments: string[];
  statusHistory?: StatusHistoryEntry[];
}

interface StatusHistoryEntry {
  id: number;
  paymentRequestId: number;
  status: PaymentRequestStatus;
  timestamp: string;
  notes: string | null;
  userId: number;
  user?: User;
}

interface PaymentStatusTrackerProps {
  paymentRequest: PaymentRequest;
  currentUser: User;
  canApprove?: boolean;
  canReject?: boolean;
  canPay?: boolean;
  onStatusChange?: (status: PaymentRequestStatus) => void;
}

const statusSteps: { status: PaymentRequestStatus; label: string; icon: React.ReactNode; color: string }[] = [
  {
    status: 'draft',
    label: 'مسودة',
    icon: <FileCheck />,
    color: 'bg-gray-500'
  },
  {
    status: 'under_review',
    label: 'قيد المراجعة',
    icon: <Clock />,
    color: 'bg-amber-500'
  },
  {
    status: 'waiting_approval',
    label: 'بانتظار الاعتماد',
    icon: <AlertTriangle />,
    color: 'bg-orange-500'
  },
  {
    status: 'approved',
    label: 'معتمد',
    icon: <CheckIcon />,
    color: 'bg-blue-500'
  },
  {
    status: 'paid',
    label: 'مدفوع',
    icon: <CreditCard />,
    color: 'bg-green-500'
  }
];

// حالات إضافية غير معروضة في مخطط التقدم الأساسي:
const additionalStatuses: { status: PaymentRequestStatus; label: string; icon: React.ReactNode; color: string }[] = [
  {
    status: 'rejected',
    label: 'مرفوض',
    icon: <Ban />,
    color: 'bg-red-500'
  },
  {
    status: 'archived',
    label: 'مؤرشف',
    icon: <ArchiveIcon />,
    color: 'bg-purple-500'
  },
  {
    status: 'pending_payment',
    label: 'بانتظار الدفع',
    icon: <CreditCard />,
    color: 'bg-indigo-500'
  }
];

// نحصل على جميع الحالات من الأساسية والإضافية
const allStatuses = [...statusSteps, ...additionalStatuses];

// وظيفة للحصول على معلومات الحالة حسب رمز الحالة
const getStatusInfo = (status: PaymentRequestStatus) => {
  return allStatuses.find(s => s.status === status) || {
    status,
    label: status,
    icon: <Info />,
    color: 'bg-gray-500'
  };
};

const PaymentStatusTracker: React.FC<PaymentStatusTrackerProps> = ({
  paymentRequest,
  currentUser,
  canApprove = false,
  canReject = false,
  canPay = false,
  onStatusChange
}) => {
  const [showStatusChangeDialog, setShowStatusChangeDialog] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<PaymentRequestStatus | null>(null);
  const [statusNotes, setStatusNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // الحصول على تاريخ حالات المستخلص - للتبسيط سنستخدم بيانات وهمية لأن نقطة النهاية API غير موجودة
  const { data: statusHistory, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['/api/payment-requests', paymentRequest.id, 'status-history'],
    queryFn: async () => {
      // بشكل طبيعي سنستدعي البيانات من الخادم، لكن للتبسيط سنقوم بإنشاء بيانات تجريبية
      await new Promise(r => setTimeout(r, 500)); // محاكاة التأخير في الشبكة
      
      // تاريخ حالة المستخلص المحاكي
      return [
        {
          id: 1,
          paymentRequestId: paymentRequest.id,
          status: paymentRequest.status,
          timestamp: new Date().toISOString(),
          notes: "تم إنشاء المستخلص",
          userId: 1,
          user: {
            id: 1,
            username: "admin",
            fullName: "مدير النظام",
            role: "مدير"
          }
        }
      ] as StatusHistoryEntry[];
    },
    enabled: !!paymentRequest?.id
  });
  
  // إرسال تغيير الحالة
  const statusMutation = useMutation({
    mutationFn: async ({ id, status, notes }: { id: number, status: PaymentRequestStatus, notes?: string }) => {
      // استخدام apiRequest بشكل صحيح 
      const response = await fetch(`/api/payment-requests/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, notes })
      });
      return await response.json();
    },
    onSuccess: (data) => {
      // نغلق مربع الحوار ونستدعي وظيفة تغيير الحالة للتحديث
      setShowStatusChangeDialog(false);
      setStatusNotes('');
      setSelectedStatus(null);
      setIsSubmitting(false);
      if (onStatusChange) {
        onStatusChange(data.status || selectedStatus);
      }
    },
    onError: () => {
      setIsSubmitting(false);
    }
  });
  
  // فتح مربع حوار تغيير الحالة
  const handleStatusChange = (newStatus: PaymentRequestStatus) => {
    setSelectedStatus(newStatus);
    setShowStatusChangeDialog(true);
  };
  
  // إرسال تغيير الحالة
  const submitStatusChange = () => {
    if (selectedStatus && paymentRequest) {
      setIsSubmitting(true);
      statusMutation.mutate({
        id: paymentRequest.id,
        status: selectedStatus,
        notes: statusNotes || undefined
      });
    }
  };
  
  // حساب مؤشر التقدم
  const getProgressStep = () => {
    const currentStatusIndex = statusSteps.findIndex(s => s.status === paymentRequest.status);
    if (currentStatusIndex === -1) {
      // إذا كانت الحالة الحالية هي "مرفوض" أو غير مدرجة في الخطوات، نستخدم حالة "مسودة" كنقطة بداية
      if (paymentRequest.status === 'rejected') {
        return 1;
      }
      if (paymentRequest.status === 'archived') {
        return 5;
      }
      if (paymentRequest.status === 'pending_payment') {
        return 4;
      }
      return 0;
    }
    return currentStatusIndex + 1;
  };
  
  // الحصول على نسبة التقدم لشريط التقدم
  const getProgressPercentage = () => {
    const progressStep = getProgressStep();
    const totalSteps = statusSteps.length;
    return (progressStep / totalSteps) * 100;
  };
  
  // التحقق من إمكانية تغيير الحالة
  const canChangeStatus = (targetStatus: PaymentRequestStatus) => {
    if (!currentUser) return false;
    
    const currentStatus = paymentRequest.status;
    
    // الانتقال إلى حالة "قيد المراجعة" متاح فقط إذا كانت الحالة الحالية "مسودة"
    if (targetStatus === 'under_review') {
      return currentStatus === 'draft';
    }
    
    // الانتقال إلى حالة "بانتظار الاعتماد" متاح فقط إذا كانت الحالة الحالية "قيد المراجعة"
    if (targetStatus === 'waiting_approval') {
      return currentStatus === 'under_review';
    }
    
    // الانتقال إلى حالة "معتمد" متاح فقط للمستخدمين المصرح لهم بالاعتماد وإذا كانت الحالة الحالية "بانتظار الاعتماد"
    if (targetStatus === 'approved') {
      return canApprove && currentStatus === 'waiting_approval';
    }
    
    // الانتقال إلى حالة "مدفوع" متاح فقط للمستخدمين المصرح لهم بالدفع وإذا كانت الحالة الحالية "معتمد"
    if (targetStatus === 'paid') {
      return canPay && currentStatus === 'approved';
    }
    
    // الانتقال إلى حالة "مرفوض" متاح فقط للمستخدمين المصرح لهم بالرفض وإذا كانت الحالة الحالية "بانتظار الاعتماد"
    if (targetStatus === 'rejected') {
      return canReject && currentStatus === 'waiting_approval';
    }
    
    // الانتقال إلى حالة "بانتظار الدفع" متاح فقط إذا كانت الحالة الحالية "معتمد"
    if (targetStatus === 'pending_payment') {
      return currentStatus === 'approved';
    }
    
    // الانتقال إلى حالة "مؤرشف" متاح فقط إذا كانت الحالة الحالية "مدفوع" أو "مرفوض"
    if (targetStatus === 'archived') {
      return currentStatus === 'paid' || currentStatus === 'rejected';
    }
    
    return false;
  };
  
  // الحصول على خطوات العمل المتاحة
  const getAvailableActions = () => {
    const currentStatus = paymentRequest.status;
    
    const actions: { status: PaymentRequestStatus; label: string }[] = [];
    
    if (currentStatus === 'draft') {
      actions.push({ status: 'under_review', label: 'إرسال للمراجعة' });
    }
    
    if (currentStatus === 'under_review') {
      actions.push({ status: 'waiting_approval', label: 'إرسال للاعتماد' });
    }
    
    if (currentStatus === 'waiting_approval') {
      if (canApprove) {
        actions.push({ status: 'approved', label: 'اعتماد المستخلص' });
      }
      if (canReject) {
        actions.push({ status: 'rejected', label: 'رفض المستخلص' });
      }
    }
    
    if (currentStatus === 'approved') {
      actions.push({ status: 'pending_payment', label: 'تقديم للصرف' });
      if (canPay) {
        actions.push({ status: 'paid', label: 'تأكيد الدفع' });
      }
    }
    
    if (currentStatus === 'pending_payment' && canPay) {
      actions.push({ status: 'paid', label: 'تأكيد الدفع' });
    }
    
    if (currentStatus === 'paid' || currentStatus === 'rejected') {
      actions.push({ status: 'archived', label: 'أرشفة المستخلص' });
    }
    
    return actions;
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const currentStatusInfo = getStatusInfo(paymentRequest.status);
  const progressPercentage = getProgressPercentage();
  const availableActions = getAvailableActions();
  
  return (
    <div className="space-y-6">
      {/* عرض الحالة الحالية */}
      <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center space-x-4 space-x-reverse">
          <Badge className={cn('text-white', currentStatusInfo.color)}>
            {currentStatusInfo.label}
          </Badge>
          <div>
            <p className="text-sm text-gray-500">حالة المستخلص</p>
            <p className="font-medium">{paymentRequest.requestNumber} - {paymentRequest.title}</p>
          </div>
        </div>
        <div className="text-left">
          <p className="text-sm text-gray-500">تاريخ آخر تحديث</p>
          <p className="text-sm">{formatDate(paymentRequest.createdAt)}</p>
        </div>
      </div>
      
      {/* شريط تقدم المستخلص */}
      <div className="space-y-4">
        <Progress value={progressPercentage} className="h-2" />
        
        <div className="flex justify-between">
          {statusSteps.map((step, index) => {
            const isCurrentStep = step.status === paymentRequest.status;
            const isCompletedStep = statusSteps.findIndex(s => s.status === paymentRequest.status) >= index;
            
            return (
              <div key={step.status} className="flex flex-col items-center">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center text-white",
                  isCurrentStep ? step.color : isCompletedStep ? step.color : 'bg-gray-200'
                )}>
                  {step.icon}
                </div>
                <span className={cn(
                  "text-xs mt-2 text-center max-w-[70px]",
                  isCurrentStep ? "font-bold" : ""
                )}>
                  {step.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>
      
      {/* الإجراءات المتاحة */}
      {availableActions.length > 0 && (
        <div className="mt-6">
          <h4 className="text-sm font-medium mb-2">الإجراءات المتاحة</h4>
          <div className="flex flex-wrap gap-2">
            {availableActions.map(action => (
              <Button
                key={action.status}
                onClick={() => handleStatusChange(action.status)}
                variant={action.status === 'rejected' ? 'destructive' : 'default'}
                className={action.status === 'approved' ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                {action.label}
              </Button>
            ))}
          </div>
        </div>
      )}
      
      {/* تاريخ حالات المستخلص */}
      <div className="mt-8">
        <h4 className="font-medium mb-4">سجل تغييرات حالة المستخلص</h4>
        
        {isLoadingHistory ? (
          <div className="text-center p-4">جاري تحميل البيانات...</div>
        ) : statusHistory && statusHistory.length > 0 ? (
          <div className="space-y-4">
            {statusHistory
              .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
              .map((entry, index) => {
                const statusInfo = getStatusInfo(entry.status);
                return (
                  <div key={entry.id || index} className="flex items-start space-x-4 space-x-reverse border-r-2 border-gray-200 pr-4 pb-4">
                    <div className={cn("p-2 rounded-full text-white", statusInfo.color)}>
                      {statusInfo.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">{statusInfo.label}</p>
                          {entry.user && (
                            <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-500">
                              <span>بواسطة:</span>
                              <div className="flex items-center">
                                <Avatar className="h-6 w-6 ml-2">
                                  {entry.user.avatar && <AvatarImage src={entry.user.avatar} alt={entry.user.fullName} />}
                                  <AvatarFallback>{entry.user.fullName.substring(0, 2)}</AvatarFallback>
                                </Avatar>
                                {entry.user.fullName}
                              </div>
                            </div>
                          )}
                        </div>
                        <span className="text-sm text-gray-500">{formatDate(entry.timestamp)}</span>
                      </div>
                      {entry.notes && (
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="link" size="sm" className="px-0">
                              عرض الملاحظات
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent>
                            <p className="text-sm">{entry.notes}</p>
                          </PopoverContent>
                        </Popover>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        ) : (
          <div className="text-center p-4 text-gray-500">
            لا يوجد سجل لتغييرات الحالة
          </div>
        )}
      </div>
      
      {/* مربع حوار تغيير الحالة */}
      <Dialog open={showStatusChangeDialog} onOpenChange={setShowStatusChangeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تغيير حالة المستخلص</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من رغبتك في تغيير حالة المستخلص إلى "{selectedStatus && getStatusInfo(selectedStatus).label}"؟
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="notes">ملاحظات (اختياري)</Label>
              <Textarea
                id="notes"
                placeholder="أضف ملاحظات حول سبب تغيير الحالة"
                value={statusNotes}
                onChange={(e) => setStatusNotes(e.target.value)}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowStatusChangeDialog(false)}
              disabled={isSubmitting}
            >
              إلغاء
            </Button>
            <Button 
              onClick={submitStatusChange}
              disabled={isSubmitting}
              className={selectedStatus === 'rejected' ? 'bg-red-600 hover:bg-red-700' : (
                selectedStatus === 'approved' ? 'bg-green-600 hover:bg-green-700' : ''
              )}
            >
              {isSubmitting ? 'جاري المعالجة...' : 'تأكيد'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PaymentStatusTracker;