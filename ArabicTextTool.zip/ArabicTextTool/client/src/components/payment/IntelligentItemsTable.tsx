import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableFooter, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  PlusCircle, 
  Pencil, 
  Trash2, 
  Save, 
  X,
  Calculator,
  ChevronDown
} from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from '@/components/ui/badge';

interface PaymentRequestItem {
  id: number;
  paymentRequestId: number;
  itemName: string;
  itemDescription: string | null;
  unit: string;
  unitPrice: number;
  plannedQuantity: number;
  completedQuantity: number;
  completionPercentage: number;
  previousPaymentPercentage: number;
  currentPaymentAmount: number;
  notes: string | null;
}

interface DailyReport {
  id: number;
  projectId: number;
  reportDate: string;
  workCompleted: string;
  issues: string | null;
  workersPresent: number;
  equipmentUsed: any;
  weatherConditions: string | null;
  hoursWorked: number;
  submittedBy: number;
  submittedAt: string;
}

interface IntelligentItemsTableProps {
  projectId: number;
  paymentRequestId: number;
  onTotalChange: (totals: { planned: number; completed: number; current: number }) => void;
  initialItems?: PaymentRequestItem[];
  dailyReports?: DailyReport[];
  readOnly?: boolean;
}

type ItemRow = Omit<PaymentRequestItem, 'id'> & { id?: number, isEditing?: boolean, isNew?: boolean };

const defaultRow: ItemRow = {
  paymentRequestId: 0,
  itemName: '',
  itemDescription: '',
  unit: '',
  unitPrice: 0,
  plannedQuantity: 0,
  completedQuantity: 0,
  completionPercentage: 0,
  previousPaymentPercentage: 0,
  currentPaymentAmount: 0,
  notes: ''
};

const IntelligentItemsTable: React.FC<IntelligentItemsTableProps> = ({
  projectId,
  paymentRequestId,
  onTotalChange,
  initialItems = [],
  dailyReports = [],
  readOnly = false
}) => {
  const [rows, setRows] = useState<ItemRow[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newItem, setNewItem] = useState<ItemRow>({ ...defaultRow });
  const [totals, setTotals] = useState({ planned: 0, completed: 0, current: 0 });
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  
  // تحميل البيانات الأولية
  useEffect(() => {
    if (initialItems && initialItems.length > 0) {
      setRows(initialItems.map(item => ({ ...item, isEditing: false })));
      calculateTotals(initialItems);
    } else {
      setRows([]);
      calculateTotals([]);
    }
  }, [initialItems]);
  
  // تعيين معرف المستخلص المالي
  useEffect(() => {
    setNewItem(prev => ({ ...prev, paymentRequestId }));
    setRows(prev => prev.map(row => ({ ...row, paymentRequestId })));
  }, [paymentRequestId]);
  
  // حساب الإجماليات
  const calculateTotals = (items: ItemRow[]) => {
    const planned = items.reduce((sum, item) => sum + (item.unitPrice * item.plannedQuantity), 0);
    const completed = items.reduce((sum, item) => sum + (item.unitPrice * item.completedQuantity * item.completionPercentage / 100), 0);
    const current = items.reduce((sum, item) => sum + item.currentPaymentAmount, 0);
    
    const newTotals = { planned, completed, current };
    setTotals(newTotals);
    onTotalChange(newTotals);
  };
  
  // إضافة صف جديد
  const addRow = () => {
    const newRows = [...rows, { ...newItem, isNew: true, isEditing: true }];
    setRows(newRows);
    calculateTotals(newRows);
    setNewItem({ ...defaultRow, paymentRequestId });
    setShowAddDialog(false);
  };
  
  // تحرير صف
  const startEditing = (index: number) => {
    setRows(rows.map((row, i) => i === index ? { ...row, isEditing: true } : row));
  };
  
  // حفظ التغييرات
  const saveRow = (index: number) => {
    setRows(rows.map((row, i) => i === index ? { ...row, isEditing: false, isNew: false } : row));
    calculateTotals(rows);
  };
  
  // إلغاء التحرير
  const cancelEditing = (index: number) => {
    if (rows[index].isNew) {
      // إذا كان صف جديد، نحذفه
      const newRows = [...rows];
      newRows.splice(index, 1);
      setRows(newRows);
      calculateTotals(newRows);
    } else {
      // إذا كان صف موجود، نعيد القيم الأصلية
      setRows(rows.map((row, i) => 
        i === index ? { ...initialItems?.find(item => item.id === row.id) || row, isEditing: false } : row
      ));
    }
  };
  
  // حذف صف
  const deleteRow = (index: number) => {
    const newRows = [...rows];
    newRows.splice(index, 1);
    setRows(newRows);
    calculateTotals(newRows);
  };
  
  // تحديث قيمة في صف
  const updateRowValue = (index: number, field: keyof ItemRow, value: any) => {
    const updatedRows = [...rows];
    updatedRows[index] = { ...updatedRows[index], [field]: value };
    
    // إذا تم تغيير أي من القيم المؤثرة في الحساب، نعيد حساب المبلغ الحالي
    if (['unitPrice', 'completedQuantity', 'completionPercentage', 'previousPaymentPercentage'].includes(field)) {
      const row = updatedRows[index];
      const calculatedAmount = row.unitPrice * row.completedQuantity * (row.completionPercentage - row.previousPaymentPercentage) / 100;
      updatedRows[index].currentPaymentAmount = calculatedAmount > 0 ? calculatedAmount : 0;
    }
    
    setRows(updatedRows);
  };
  
  // استخراج اقتراحات من تقارير الإنجاز اليومية
  const getSuggestionsFromReports = () => {
    if (!dailyReports || dailyReports.length === 0) return [];
    
    // استخراج عناصر العمل من تفاصيل التقارير
    const workDescriptions = dailyReports.flatMap(report => {
      const sentences = report.workCompleted.split('. ');
      return sentences.filter(s => s.length > 10 && !s.toLowerCase().includes('إجمالي') && !s.toLowerCase().includes('total'));
    });
    
    // تنظيف الاقتراحات وإزالة التكرار
    return Array.from(new Set(workDescriptions)).slice(0, 5);
  };
  
  // اقتراح قيم بناء على تقارير الإنجاز
  const suggestValuesFromReports = () => {
    setSuggestions(getSuggestionsFromReports());
    setShowSuggestions(true);
  };
  
  // استخدام اقتراح
  const useSuggestion = (suggestion: string) => {
    setNewItem(prev => ({
      ...prev,
      itemName: suggestion.split(' ').slice(0, 3).join(' '),
      itemDescription: suggestion
    }));
    setShowSuggestions(false);
  };
  
  // حساب متوسط نسب الإنجاز من تقارير الإنجاز اليومية
  const calculateAverageCompletion = () => {
    if (!dailyReports || dailyReports.length === 0) return 0;
    
    // في مثال حقيقي، قد يكون هناك منطق أكثر تعقيدًا هنا
    // لتقدير نسبة الإنجاز بناءً على عدد التقارير وتكرار الأعمال المذكورة
    const recentReports = dailyReports.slice(-5); // آخر 5 تقارير
    
    // افتراض أن كل تقرير يمثل نسبة 5-10% من المشروع
    const progressPerReport = Math.min(10, Math.max(5, 100 / (dailyReports.length * 2)));
    
    return Math.min(95, recentReports.length * progressPerReport);
  };
  
  // تقدير إنجاز البند الحالي
  const estimateCompletion = () => {
    const estimated = calculateAverageCompletion();
    
    setNewItem(prev => ({
      ...prev,
      completionPercentage: estimated > prev.previousPaymentPercentage ? estimated : prev.previousPaymentPercentage + 5
    }));
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">بنود المستخلص المالي</h3>
        
        {!readOnly && (
          <div className="space-x-2 flex flex-row-reverse">
            <Button onClick={() => setShowAddDialog(true)}>
              <PlusCircle className="ml-2 h-4 w-4" />
              إضافة بند
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  <Calculator className="ml-2 h-4 w-4" />
                  أدوات ذكية
                  <ChevronDown className="mr-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>أدوات مساعدة</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={suggestValuesFromReports}>
                  اقتراح بنود من تقارير الإنجاز
                </DropdownMenuItem>
                <DropdownMenuItem onClick={estimateCompletion}>
                  تقدير نسب الإنجاز آليًا
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
      
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[50px]">#</TableHead>
            <TableHead>البند</TableHead>
            <TableHead>الوحدة</TableHead>
            <TableHead className="text-center">السعر</TableHead>
            <TableHead className="text-center">الكمية المخططة</TableHead>
            <TableHead className="text-center">الكمية المنفذة</TableHead>
            <TableHead className="text-center">نسبة الإنجاز %</TableHead>
            <TableHead className="text-center">نسبة الدفع السابق %</TableHead>
            <TableHead className="text-center">المبلغ المستحق</TableHead>
            {!readOnly && <TableHead className="w-[100px]">إجراءات</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={readOnly ? 9 : 10} className="text-center text-gray-500 py-4">
                لا توجد بنود حتى الآن. قم بإضافة بنود للمستخلص.
              </TableCell>
            </TableRow>
          ) : (
            rows.map((row, index) => (
              <TableRow key={row.id || `new-${index}`} className={row.isNew ? 'bg-primary/5' : ''}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>
                  {row.isEditing ? (
                    <div className="space-y-1">
                      <Input 
                        value={row.itemName} 
                        onChange={e => updateRowValue(index, 'itemName', e.target.value)} 
                        placeholder="اسم البند"
                        className="mb-1"
                      />
                      <Input 
                        value={row.itemDescription || ''} 
                        onChange={e => updateRowValue(index, 'itemDescription', e.target.value)} 
                        placeholder="وصف البند (اختياري)"
                      />
                    </div>
                  ) : (
                    <>
                      <div className="font-medium">{row.itemName}</div>
                      {row.itemDescription && (
                        <div className="text-sm text-gray-500">{row.itemDescription}</div>
                      )}
                    </>
                  )}
                </TableCell>
                <TableCell>
                  {row.isEditing ? (
                    <Input 
                      value={row.unit} 
                      onChange={e => updateRowValue(index, 'unit', e.target.value)} 
                      placeholder="الوحدة"
                    />
                  ) : (
                    row.unit
                  )}
                </TableCell>
                <TableCell className="text-center">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.unitPrice} 
                      onChange={e => updateRowValue(index, 'unitPrice', parseFloat(e.target.value) || 0)} 
                      min="0"
                      className="text-center"
                    />
                  ) : (
                    row.unitPrice.toLocaleString()
                  )}
                </TableCell>
                <TableCell className="text-center">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.plannedQuantity} 
                      onChange={e => updateRowValue(index, 'plannedQuantity', parseFloat(e.target.value) || 0)} 
                      min="0"
                      className="text-center"
                    />
                  ) : (
                    row.plannedQuantity.toLocaleString()
                  )}
                </TableCell>
                <TableCell className="text-center">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.completedQuantity} 
                      onChange={e => updateRowValue(index, 'completedQuantity', parseFloat(e.target.value) || 0)} 
                      min="0"
                      max={row.plannedQuantity}
                      className="text-center"
                    />
                  ) : (
                    row.completedQuantity.toLocaleString()
                  )}
                </TableCell>
                <TableCell className="text-center">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.completionPercentage} 
                      onChange={e => updateRowValue(index, 'completionPercentage', parseFloat(e.target.value) || 0)} 
                      min="0"
                      max="100"
                      className="text-center"
                    />
                  ) : (
                    <Badge variant="default" className={row.completionPercentage >= 90 ? "bg-green-600" : (row.completionPercentage >= 50 ? "bg-amber-600" : "bg-gray-600")}>
                      {row.completionPercentage}%
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-center">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.previousPaymentPercentage} 
                      onChange={e => updateRowValue(index, 'previousPaymentPercentage', parseFloat(e.target.value) || 0)} 
                      min="0"
                      max={row.completionPercentage}
                      className="text-center"
                    />
                  ) : (
                    `${row.previousPaymentPercentage}%`
                  )}
                </TableCell>
                <TableCell className="text-center font-medium">
                  {row.isEditing ? (
                    <Input 
                      type="number" 
                      value={row.currentPaymentAmount} 
                      onChange={e => updateRowValue(index, 'currentPaymentAmount', parseFloat(e.target.value) || 0)} 
                      min="0"
                      className="text-center"
                    />
                  ) : (
                    row.currentPaymentAmount.toLocaleString()
                  )}
                </TableCell>
                {!readOnly && (
                  <TableCell>
                    <div className="flex items-center justify-center space-x-2">
                      {row.isEditing ? (
                        <>
                          <Button variant="ghost" size="icon" onClick={() => saveRow(index)}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => cancelEditing(index)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button variant="ghost" size="icon" onClick={() => startEditing(index)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => deleteRow(index)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
        <TableFooter>
          <TableRow>
            <TableCell colSpan={7} className="text-left">إجمالي المستخلص</TableCell>
            <TableCell className="text-center">المخطط</TableCell>
            <TableCell className="text-center">{totals.planned.toLocaleString()}</TableCell>
            {!readOnly && <TableCell />}
          </TableRow>
          <TableRow>
            <TableCell colSpan={7}></TableCell>
            <TableCell className="text-center">المنفذ</TableCell>
            <TableCell className="text-center">{totals.completed.toLocaleString()}</TableCell>
            {!readOnly && <TableCell />}
          </TableRow>
          <TableRow>
            <TableCell colSpan={7}></TableCell>
            <TableCell className="text-center">المستحق حاليًا</TableCell>
            <TableCell className="text-center font-bold">{totals.current.toLocaleString()}</TableCell>
            {!readOnly && <TableCell />}
          </TableRow>
        </TableFooter>
      </Table>
      
      {/* مربع حوار إضافة بند جديد */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة بند جديد</DialogTitle>
            <DialogDescription>
              أدخل معلومات البند الجديد للمستخلص المالي
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">اسم البند</Label>
              <div className="col-span-3">
                <Input 
                  value={newItem.itemName} 
                  onChange={e => setNewItem({...newItem, itemName: e.target.value})}
                  placeholder="اسم البند"
                />
                
                {/* اقتراحات من تقارير الإنجاز */}
                {showSuggestions && suggestions.length > 0 && (
                  <div className="mt-2 p-2 border rounded-md bg-background">
                    <p className="text-sm font-medium mb-1">اقتراحات من تقارير الإنجاز:</p>
                    <div className="space-y-1">
                      {suggestions.map((suggestion, idx) => (
                        <div 
                          key={idx} 
                          className="p-1 text-sm rounded cursor-pointer hover:bg-gray-100"
                          onClick={() => useSuggestion(suggestion)}
                        >
                          {suggestion}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">الوصف</Label>
              <Input 
                className="col-span-3" 
                value={newItem.itemDescription || ''} 
                onChange={e => setNewItem({...newItem, itemDescription: e.target.value})}
                placeholder="وصف البند (اختياري)"
              />
            </div>
            
            <div className="grid grid-cols-4 items-center gap-4">
              <Label className="text-right">الوحدة</Label>
              <Input 
                className="col-span-3" 
                value={newItem.unit} 
                onChange={e => setNewItem({...newItem, unit: e.target.value})}
                placeholder="الوحدة (مثل: متر، قطعة، يوم عمل)"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">سعر الوحدة</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={newItem.unitPrice} 
                  onChange={e => setNewItem({...newItem, unitPrice: parseFloat(e.target.value) || 0})}
                  min="0"
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">الكمية المخططة</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={newItem.plannedQuantity} 
                  onChange={e => setNewItem({...newItem, plannedQuantity: parseFloat(e.target.value) || 0})}
                  min="0"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">الكمية المنفذة</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={newItem.completedQuantity} 
                  onChange={e => setNewItem({...newItem, completedQuantity: parseFloat(e.target.value) || 0})}
                  min="0"
                  max={newItem.plannedQuantity}
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">نسبة الإنجاز %</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={newItem.completionPercentage} 
                  onChange={e => setNewItem({...newItem, completionPercentage: parseFloat(e.target.value) || 0})}
                  min="0"
                  max="100"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">نسبة الدفع السابق %</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={newItem.previousPaymentPercentage} 
                  onChange={e => setNewItem({...newItem, previousPaymentPercentage: parseFloat(e.target.value) || 0})}
                  min="0"
                  max={newItem.completionPercentage}
                />
              </div>
              
              <div className="grid grid-cols-4 items-center gap-2">
                <Label className="text-right col-span-2">المبلغ المستحق</Label>
                <Input 
                  className="col-span-2" 
                  type="number"
                  value={
                    newItem.currentPaymentAmount || 
                    (newItem.unitPrice * newItem.completedQuantity * 
                      (newItem.completionPercentage - newItem.previousPaymentPercentage) / 100)
                  } 
                  onChange={e => setNewItem({...newItem, currentPaymentAmount: parseFloat(e.target.value) || 0})}
                  min="0"
                />
              </div>
            </div>
          </div>
          
          <DialogFooter className="flex space-x-2 justify-between">
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>إلغاء</Button>
            <div className="space-x-2">
              <Button variant="outline" onClick={suggestValuesFromReports}>
                اقتراح من التقارير
              </Button>
              <Button onClick={addRow}>إضافة البند</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default IntelligentItemsTable;