import React, { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage, 
  FormDescription 
} from '@/components/ui/form';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Textarea 
} from '@/components/ui/textarea';
import { 
  Button 
} from '@/components/ui/button';
import {
  Separator
} from "@/components/ui/separator";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@/components/ui/alert";
import { 
  Calendar as CalendarIcon, 
  MapPin, 
  Building, 
  DollarSign, 
  Info, 
  Users, 
  FileText, 
  HardDrive, 
  Truck,
  User,
  AlertCircle
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useUsers } from '@/lib/data';

import type { Project } from '@shared/schema';

// Create a zod schema for project form
const projectFormSchema = z.object({
  name: z
    .string()
    .min(3, { message: 'اسم المشروع يجب أن يحتوي على الأقل 3 أحرف' })
    .max(100, { message: 'اسم المشروع يجب ألا يتجاوز 100 حرف' }),
  description: z
    .string()
    .min(10, { message: 'الوصف يجب أن يحتوي على الأقل 10 أحرف' })
    .max(1000, { message: 'الوصف يجب ألا يتجاوز 1000 حرف' }),
  clientName: z
    .string()
    .optional(),
  contractNumber: z
    .string()
    .optional(),
  location: z
    .string()
    .min(2, { message: 'موقع المشروع مطلوب' }),
  status: z
    .enum(['planned', 'inProgress', 'delayed', 'completed'], { 
      required_error: 'الرجاء اختيار حالة المشروع' 
    }),
  category: z
    .enum(['electricity', 'water', 'communications', 'roads', 'buildings'], { 
      required_error: 'الرجاء اختيار تصنيف المشروع' 
    }),
  startDate: z
    .date({ required_error: 'تاريخ البداية مطلوب' }),
  endDate: z
    .date({ required_error: 'تاريخ النهاية مطلوب' }),
  duration: z
    .number()
    .min(1, { message: 'المدة يجب أن تكون على الأقل 1 شهر' })
    .max(120, { message: 'المدة يجب ألا تتجاوز 120 شهر' }),
  budget: z
    .number()
    .min(0, { message: 'الميزانية يجب أن تكون على الأقل 0' }),
  progress: z
    .number()
    .min(0, { message: 'نسبة الإنجاز يجب أن تكون بين 0 و 100' })
    .max(100, { message: 'نسبة الإنجاز يجب أن تكون بين 0 و 100' })
    .default(0),
  imageUrl: z
    .string()
    .url({ message: 'يرجى إدخال رابط صحيح للصورة' })
    .optional()
    .or(z.literal('')),
  managerId: z
    .number()
    .optional(),
  notes: z
    .string()
    .max(1000, { message: 'الملاحظات يجب ألا تتجاوز 1000 حرف' })
    .optional(),
}).refine(
  (data) => {
    return new Date(data.endDate) > new Date(data.startDate);
  },
  {
    message: 'تاريخ النهاية يجب أن يكون بعد تاريخ البداية',
    path: ['endDate'],
  }
);

// Infer the type from the schema
type ProjectFormValues = z.infer<typeof projectFormSchema>;

interface ProjectFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: ProjectFormValues) => void;
  initialData?: Project;
  isSubmitting: boolean;
}

const ProjectForm: React.FC<ProjectFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  isSubmitting
}) => {
  const [activeTab, setActiveTab] = useState('basic');
  const { data: users, isLoading: isLoadingUsers } = useUsers();
  
  // Initialize the form with default values or initial data
  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectFormSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          startDate: new Date(initialData.startDate),
          endDate: new Date(initialData.endDate),
        }
      : {
          name: '',
          description: '',
          clientName: '',
          contractNumber: '',
          location: '',
          status: 'planned',
          category: 'buildings',
          startDate: new Date(),
          endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
          duration: 6,
          budget: 0,
          progress: 0,
          imageUrl: '',
          notes: '',
        },
  });

  // Watch the start and end dates to calculate duration
  const startDate = form.watch('startDate');
  const endDate = form.watch('endDate');

  // Calculate duration in months whenever dates change
  useEffect(() => {
    if (startDate && endDate) {
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Only update if end date is after start date
      if (end > start) {
        const diffTime = Math.abs(end.getTime() - start.getTime());
        const diffMonths = Math.ceil(diffTime / (1000 * 60 * 60 * 24 * 30));
        form.setValue('duration', diffMonths);
      }
    }
  }, [startDate, endDate, form]);

  // Helper function to handle form submission
  const handleSubmit = (values: ProjectFormValues) => {
    onSubmit(values);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل المشروع' : 'إضافة مشروع جديد'}</DialogTitle>
          <DialogDescription>
            {initialData 
              ? 'قم بتعديل معلومات المشروع أدناه' 
              : 'أدخل معلومات المشروع الجديد'}
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="basic">معلومات أساسية</TabsTrigger>
            <TabsTrigger value="details">تفاصيل المشروع</TabsTrigger>
            <TabsTrigger value="additional">معلومات إضافية</TabsTrigger>
          </TabsList>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6 py-4">
              {/* Basic Information Tab */}
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>اسم المشروع*</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="أدخل اسم المشروع" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="clientName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>اسم العميل / المالك</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="أدخل اسم العميل" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>وصف المشروع*</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          placeholder="وصف تفصيلي للمشروع" 
                          className="min-h-[120px]"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الموقع*</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                            <Input {...field} className="pr-10" placeholder="موقع المشروع" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="contractNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رقم العقد</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="أدخل رقم العقد" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تصنيف المشروع*</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <div className="flex items-center gap-2">
                                <Building className="h-4 w-4" />
                                <SelectValue placeholder="اختر تصنيف المشروع" />
                              </div>
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="electricity">كهرباء</SelectItem>
                            <SelectItem value="water">مياه</SelectItem>
                            <SelectItem value="communications">اتصالات</SelectItem>
                            <SelectItem value="roads">طرق</SelectItem>
                            <SelectItem value="buildings">مباني</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>حالة المشروع*</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر حالة المشروع" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="planned">مخطط</SelectItem>
                            <SelectItem value="inProgress">قيد التنفيذ</SelectItem>
                            <SelectItem value="delayed">متأخر</SelectItem>
                            <SelectItem value="completed">مكتمل</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    type="button" 
                    variant="default" 
                    onClick={() => setActiveTab('details')}
                  >
                    التالي
                  </Button>
                </div>
              </TabsContent>

              {/* Details Tab */}
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ البداية*</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            value={field.value instanceof Date 
                              ? field.value.toISOString().split('T')[0] 
                              : String(field.value).split('T')[0]} 
                            onChange={e => field.onChange(new Date(e.target.value))} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ النهاية*</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            value={field.value instanceof Date 
                              ? field.value.toISOString().split('T')[0] 
                              : String(field.value).split('T')[0]} 
                            onChange={e => field.onChange(new Date(e.target.value))} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="duration"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>المدة (شهور)*</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1} 
                            {...field} 
                            onChange={e => field.onChange(Number(e.target.value))} 
                            value={field.value}
                          />
                        </FormControl>
                        <FormDescription className="text-xs">
                          المدة محسوبة تلقائياً من تاريخ البداية والنهاية
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>الميزانية*</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
                            <Input 
                              {...field} 
                              className="pr-10" 
                              type="number" 
                              min={0} 
                              placeholder="أدخل ميزانية المشروع" 
                              onChange={e => field.onChange(Number(e.target.value))}
                              value={field.value}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="progress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نسبة الإنجاز (%)</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          type="number" 
                          min={0} 
                          max={100} 
                          placeholder="أدخل نسبة الإنجاز" 
                          onChange={e => field.onChange(Number(e.target.value))}
                          value={field.value}
                        />
                      </FormControl>
                      <div className="w-full bg-gray-200 h-2 rounded-full mt-2">
                        <div 
                          className="bg-primary h-2 rounded-full" 
                          style={{ width: `${field.value || 0}%` }} 
                        />
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Progress based on status alert */}
                {form.watch('status') === 'completed' && form.watch('progress') !== 100 && (
                  <Alert className="bg-amber-50 text-amber-800 border-amber-300">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>ملاحظة</AlertTitle>
                    <AlertDescription>
                      المشروع بحالة "مكتمل" لكن نسبة الإنجاز ليست 100%. هل تريد ضبط نسبة الإنجاز إلى 100%؟
                      <div className="mt-2">
                        <Button 
                          type="button" 
                          variant="outline" 
                          size="sm"
                          onClick={() => form.setValue('progress', 100)}
                        >
                          ضبط إلى 100%
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                )}

                <div className="flex justify-between">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveTab('basic')}
                  >
                    السابق
                  </Button>
                  <Button 
                    type="button" 
                    variant="default" 
                    onClick={() => setActiveTab('additional')}
                  >
                    التالي
                  </Button>
                </div>
              </TabsContent>

              {/* Additional Tab */}
              <TabsContent value="additional" className="space-y-4">
                <FormField
                  control={form.control}
                  name="imageUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>صورة المشروع</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="أدخل رابط صورة المشروع (اختياري)" />
                      </FormControl>
                      <FormDescription className="text-xs">
                        أدخل رابط صورة المشروع (مثال: https://example.com/image.jpg)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="managerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>مدير المشروع</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(Number(value))} 
                        value={field.value?.toString() || undefined}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4" />
                              <SelectValue placeholder="اختر مدير المشروع" />
                            </div>
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {isLoadingUsers ? (
                            <SelectItem value="loading" disabled>جاري تحميل المستخدمين...</SelectItem>
                          ) : users && users.length > 0 ? (
                            users.map(user => (
                              <SelectItem key={user.id} value={user.id.toString()}>
                                {user.fullName || user.username}
                              </SelectItem>
                            ))
                          ) : (
                            <SelectItem value="none" disabled>لا يوجد مستخدمين</SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات إضافية</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          placeholder="أي ملاحظات إضافية عن المشروع" 
                          className="min-h-[120px]"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-between pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setActiveTab('details')}
                  >
                    السابق
                  </Button>
                  <div className="flex gap-2">
                    <Button type="button" variant="outline" onClick={onClose}>
                      إلغاء
                    </Button>
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? 'جاري الحفظ...' : initialData ? 'تحديث المشروع' : 'إضافة المشروع'}
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </form>
          </Form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default ProjectForm;