import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MapPin,
  Plus,
  Trash2,
  PenSquare,
  Eye,
  Search,
  Layers,
  Map,
  ListFilter,
  Info
} from "lucide-react";
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

// Import API hooks
import { useProjectGeoLocations, useCreateGeoLocation, useUpdateGeoLocation, useDeleteGeoLocation } from '@/lib/data';

// Import types
import type { Project, GeoLocation, InsertGeoLocation } from '@shared/schema';

// Mock location data
const mockLocations = [
  {
    id: 1,
    name: 'موقع المشروع الرئيسي',
    latitude: 24.713552,
    longitude: 46.675297,
    projectId: 1,
    description: 'المقر الرئيسي للمشروع ومكاتب الإدارة',
    status: 'active',
    entityType: 'project',
    entityId: 1,
    radius: 500,
    createdAt: new Date(2025, 0, 15),
    updatedAt: new Date(2025, 0, 15)
  },
  {
    id: 2,
    name: 'منطقة العمل - المرحلة 1',
    latitude: 24.714552,
    longitude: 46.677297,
    projectId: 1,
    description: 'منطقة العمل للمرحلة الأولى من المشروع',
    status: 'active',
    entityType: 'site',
    entityId: 1,
    radius: 300,
    createdAt: new Date(2025, 0, 20),
    updatedAt: new Date(2025, 0, 20)
  },
  {
    id: 3,
    name: 'مخزن المواد',
    latitude: 24.715552,
    longitude: 46.676297,
    projectId: 1,
    description: 'مخزن المواد والمعدات الخاصة بالمشروع',
    status: 'active',
    entityType: 'storage',
    entityId: 1,
    radius: 200,
    createdAt: new Date(2025, 1, 5),
    updatedAt: new Date(2025, 1, 5)
  },
  {
    id: 4,
    name: 'محطة المعالجة',
    latitude: 24.716552,
    longitude: 46.678297,
    projectId: 1,
    description: 'محطة معالجة المياه الخاصة بالمشروع',
    status: 'planned',
    entityType: 'facility',
    entityId: 2,
    radius: 250,
    createdAt: new Date(2025, 1, 10),
    updatedAt: new Date(2025, 1, 10)
  }
];

interface ProjectGeoTrackingProps {
  project: Project;
}

const ProjectGeoTracking: React.FC<ProjectGeoTrackingProps> = ({ project }) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('map');
  const [locations, setLocations] = useState<any[]>(mockLocations);
  const [selectedLocation, setSelectedLocation] = useState<any | null>(null);
  const [isAddLocationOpen, setIsAddLocationOpen] = useState(false);
  const [isViewLocationOpen, setIsViewLocationOpen] = useState(false);
  const [isEditLocationOpen, setIsEditLocationOpen] = useState(false);
  const [newLocation, setNewLocation] = useState<any>({
    name: '',
    latitude: 24.774265,
    longitude: 46.738586, // Riyadh coordinates as default
    projectId: project.id,
    description: '',
    status: 'active',
    entityType: 'site',
    radius: 300
  });
  
  // Filter locations based on search term
  const filteredLocations = locations.filter(location => {
    const name = location.name.toLowerCase();
    const description = location.description?.toLowerCase() || '';
    const status = location.status?.toLowerCase() || '';
    const type = location.entityType?.toLowerCase() || '';
    
    return (
      name.includes(searchTerm.toLowerCase()) ||
      description.includes(searchTerm.toLowerCase()) ||
      status.includes(searchTerm.toLowerCase()) ||
      type.includes(searchTerm.toLowerCase())
    );
  });
  
  // Add location
  const handleAddLocation = () => {
    const location = {
      ...newLocation,
      id: locations.length + 1,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastUpdateTime: new Date().toISOString()
    };
    
    setLocations([...locations, location]);
    
    toast({
      title: "تمت إضافة الموقع",
      description: "تمت إضافة الموقع الجديد بنجاح",
    });
    
    setIsAddLocationOpen(false);
    setNewLocation({
      name: '',
      latitude: 24.774265,
      longitude: 46.738586,
      projectId: project.id,
      description: '',
      status: 'active',
      entityType: 'site',
      radius: 300
    });
  };
  
  // Edit location
  const handleEditLocation = () => {
    if (!selectedLocation) return;
    
    const updatedLocations = locations.map(loc =>
      loc.id === selectedLocation.id
        ? { ...selectedLocation, updatedAt: new Date() }
        : loc
    );
    
    setLocations(updatedLocations);
    
    toast({
      title: "تم تحديث الموقع",
      description: "تم تحديث بيانات الموقع بنجاح",
    });
    
    setIsEditLocationOpen(false);
  };
  
  // Delete location
  const handleDeleteLocation = (id: number) => {
    setLocations(locations.filter(loc => loc.id !== id));
    
    toast({
      title: "تم حذف الموقع",
      description: "تم حذف الموقع بنجاح",
    });
    
    if (isViewLocationOpen && selectedLocation?.id === id) {
      setIsViewLocationOpen(false);
      setSelectedLocation(null);
    }
  };
  
  // View location
  const handleViewLocation = (location: any) => {
    setSelectedLocation(location);
    setIsViewLocationOpen(true);
  };
  
  // Edit location dialog
  const handleOpenEditDialog = (location: any) => {
    setSelectedLocation(location);
    setIsEditLocationOpen(true);
  };
  
  // Format date
  const formatDate = (date: Date) => {
    return format(date, 'yyyy/MM/dd', { locale: ar });
  };
  
  // Get entity type text
  const getEntityTypeText = (type: string) => {
    switch (type) {
      case 'project':
        return 'موقع المشروع';
      case 'site':
        return 'موقع عمل';
      case 'storage':
        return 'مخزن';
      case 'facility':
        return 'منشأة';
      case 'equipment':
        return 'معدات';
      default:
        return type;
    }
  };
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">نشط</Badge>;
      case 'planned':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">مخطط</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">غير نشط</Badge>;
      default:
        return null;
    }
  };
  
  // Map component
  const MapComponent = () => {
    return (
      <div className="h-[600px] relative border rounded-md overflow-hidden">
        <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
          <Button
            className="gap-2"
            onClick={() => setIsAddLocationOpen(true)}
          >
            <Plus className="h-4 w-4" />
            <span>إضافة موقع</span>
          </Button>
          <Button
            variant="outline"
            className="gap-2 bg-white"
            onClick={() => setActiveTab('list')}
          >
            <ListFilter className="h-4 w-4" />
            <span>عرض القائمة</span>
          </Button>
        </div>
        
        <div className="absolute bottom-4 right-4 z-10 rounded-md bg-white p-2 shadow-md">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-green-500"></div>
              <span className="text-xs">موقع نشط</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-blue-500"></div>
              <span className="text-xs">موقع مخطط</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-gray-500"></div>
              <span className="text-xs">موقع غير نشط</span>
            </div>
          </div>
        </div>
        
        <div className="h-full w-full bg-[#f5f5f5] flex items-center justify-center">
          <div className="text-center">
            <Map className="h-16 w-16 mx-auto text-muted-foreground/60" />
            <h3 className="text-lg font-medium mt-4">خريطة المشروع</h3>
            <p className="text-muted-foreground max-w-md mt-2">
              في الواجهة الفعلية، سيتم عرض خريطة تفاعلية هنا تعرض جميع المواقع المسجلة للمشروع.
            </p>
            <div className="mt-4">
              <Button
                onClick={() => setIsAddLocationOpen(true)}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                <span>إضافة موقع جديد</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  return (
    <div className="space-y-6">
      <Tabs
        defaultValue="map"
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2 md:w-fit">
          <TabsTrigger value="map" className="flex gap-1">
            <Map className="h-4 w-4 hidden sm:block" />
            <span>الخريطة</span>
          </TabsTrigger>
          <TabsTrigger value="list" className="flex gap-1">
            <Layers className="h-4 w-4 hidden sm:block" />
            <span>قائمة المواقع</span>
          </TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="map" className="m-0">
            <MapComponent />
          </TabsContent>
          
          <TabsContent value="list" className="m-0">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                  <div className="relative w-full sm:w-96">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="البحث في المواقع..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 pr-4"
                    />
                  </div>
                  
                  <div className="w-full sm:w-auto">
                    <Button
                      className="gap-2 w-full sm:w-auto"
                      onClick={() => setIsAddLocationOpen(true)}
                    >
                      <Plus className="h-4 w-4" />
                      <span>إضافة موقع</span>
                    </Button>
                  </div>
                </div>
                
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الاسم</TableHead>
                        <TableHead>النوع</TableHead>
                        <TableHead>الإحداثيات</TableHead>
                        <TableHead>النطاق (م)</TableHead>
                        <TableHead>آخر تحديث</TableHead>
                        <TableHead>الحالة</TableHead>
                        <TableHead>الإجراءات</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredLocations.length > 0 ? (
                        filteredLocations.map((location) => (
                          <TableRow key={location.id}>
                            <TableCell className="font-medium">{location.name}</TableCell>
                            <TableCell>{getEntityTypeText(location.entityType)}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="text-xs">Lat: {location.latitude.toFixed(6)}</span>
                                <span className="text-xs">Lng: {location.longitude.toFixed(6)}</span>
                              </div>
                            </TableCell>
                            <TableCell>{location.radius} م</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="text-xs">{formatDate(location.updatedAt)}</span>
                              </div>
                            </TableCell>
                            <TableCell>{getStatusBadge(location.status)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleViewLocation(location)}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleOpenEditDialog(location)}
                                >
                                  <PenSquare className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="text-red-500"
                                  onClick={() => handleDeleteLocation(location.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="h-24 text-center">
                            لا توجد مواقع مطابقة للبحث
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
                
                {filteredLocations.length === 0 && searchTerm === '' && (
                  <div className="flex flex-col items-center justify-center p-8 mt-6">
                    <MapPin className="h-10 w-10 text-muted mb-2" />
                    <h3 className="text-lg font-semibold">لا توجد مواقع</h3>
                    <p className="text-muted-foreground text-center max-w-md mt-1 mb-4">
                      لم يتم إضافة أي مواقع لهذا المشروع بعد. أضف موقعًا جديدًا للبدء.
                    </p>
                    <Button
                      onClick={() => setIsAddLocationOpen(true)}
                      className="gap-2"
                    >
                      <Plus className="h-4 w-4" />
                      <span>إضافة موقع جديد</span>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
      
      {/* Add Location Dialog */}
      <Dialog open={isAddLocationOpen} onOpenChange={setIsAddLocationOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة موقع جديد</DialogTitle>
            <DialogDescription>
              أضف موقعًا جديدًا للمشروع لتتبعه على الخريطة
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm font-medium">
                اسم الموقع
              </label>
              <Input
                id="name"
                placeholder="اكتب اسم الموقع..."
                value={newLocation.name}
                onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <label htmlFor="latitude" className="text-sm font-medium">
                  خط العرض (Latitude)
                </label>
                <Input
                  id="latitude"
                  type="number"
                  step="0.000001"
                  placeholder="24.774265"
                  value={newLocation.latitude}
                  onChange={(e) => setNewLocation({ ...newLocation, latitude: parseFloat(e.target.value) })}
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="longitude" className="text-sm font-medium">
                  خط الطول (Longitude)
                </label>
                <Input
                  id="longitude"
                  type="number"
                  step="0.000001"
                  placeholder="46.738586"
                  value={newLocation.longitude}
                  onChange={(e) => setNewLocation({ ...newLocation, longitude: parseFloat(e.target.value) })}
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="status" className="text-sm font-medium">
                الحالة
              </label>
              <Select 
                value={newLocation.status}
                onValueChange={(value) => setNewLocation({ ...newLocation, status: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر الحالة..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">نشط</SelectItem>
                  <SelectItem value="planned">مخطط</SelectItem>
                  <SelectItem value="inactive">غير نشط</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="entityType" className="text-sm font-medium">
                نوع الموقع
              </label>
              <Select 
                value={newLocation.entityType}
                onValueChange={(value) => setNewLocation({ ...newLocation, entityType: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع الموقع..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="project">موقع المشروع</SelectItem>
                  <SelectItem value="site">موقع عمل</SelectItem>
                  <SelectItem value="storage">مخزن</SelectItem>
                  <SelectItem value="facility">منشأة</SelectItem>
                  <SelectItem value="equipment">معدات</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">
                  نطاق الموقع (متر)
                </label>
                <span className="text-sm font-medium">{newLocation.radius} م</span>
              </div>
              <Slider
                value={[newLocation.radius]}
                min={50}
                max={1000}
                step={50}
                onValueChange={(value) => setNewLocation({ ...newLocation, radius: value[0] })}
              />
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="description" className="text-sm font-medium">
                الوصف (اختياري)
              </label>
              <Input
                id="description"
                placeholder="أضف وصفًا للموقع..."
                value={newLocation.description}
                onChange={(e) => setNewLocation({ ...newLocation, description: e.target.value })}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddLocationOpen(false)}
            >
              إلغاء
            </Button>
            <Button 
              onClick={handleAddLocation}
              disabled={!newLocation.name || !newLocation.latitude || !newLocation.longitude}
            >
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* View Location Dialog */}
      {selectedLocation && (
        <Dialog open={isViewLocationOpen} onOpenChange={setIsViewLocationOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                تفاصيل الموقع
              </DialogTitle>
            </DialogHeader>
            
            <div className="py-4">
              <div className="flex items-center gap-4 mb-6">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">{selectedLocation.name}</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline">
                      {getEntityTypeText(selectedLocation.entityType)}
                    </Badge>
                    {getStatusBadge(selectedLocation.status)}
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="rounded-md border overflow-hidden p-4">
                  <div className="flex justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">الإحداثيات</p>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-xs text-muted-foreground">خط العرض:</span>
                          <p>{selectedLocation.latitude.toFixed(6)}</p>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground">خط الطول:</span>
                          <p>{selectedLocation.longitude.toFixed(6)}</p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground mb-1">النطاق</p>
                      <p>{selectedLocation.radius} متر</p>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">تاريخ الإنشاء</p>
                    <p>{formatDate(selectedLocation.createdAt)}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">آخر تحديث</p>
                    <p>{formatDate(selectedLocation.updatedAt)}</p>
                  </div>
                </div>
                
                {selectedLocation.description && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">الوصف</p>
                    <p>{selectedLocation.description}</p>
                  </div>
                )}
                
                <div className="pt-4">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="gap-1 flex-1"
                      onClick={() => {
                        setIsViewLocationOpen(false);
                        handleOpenEditDialog(selectedLocation);
                      }}
                    >
                      <PenSquare className="h-4 w-4" />
                      <span>تعديل</span>
                    </Button>
                    <Button
                      variant="destructive"
                      className="gap-1 flex-1"
                      onClick={() => {
                        handleDeleteLocation(selectedLocation.id);
                        setIsViewLocationOpen(false);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>حذف</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
      
      {/* Edit Location Dialog */}
      {selectedLocation && (
        <Dialog open={isEditLocationOpen} onOpenChange={setIsEditLocationOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>تعديل الموقع</DialogTitle>
              <DialogDescription>
                قم بتحديث معلومات الموقع
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-2">
              <div className="grid gap-2">
                <label htmlFor="edit-name" className="text-sm font-medium">
                  اسم الموقع
                </label>
                <Input
                  id="edit-name"
                  placeholder="اكتب اسم الموقع..."
                  value={selectedLocation.name}
                  onChange={(e) => setSelectedLocation({ ...selectedLocation, name: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="edit-latitude" className="text-sm font-medium">
                    خط العرض (Latitude)
                  </label>
                  <Input
                    id="edit-latitude"
                    type="number"
                    step="0.000001"
                    value={selectedLocation.latitude}
                    onChange={(e) => setSelectedLocation({ ...selectedLocation, latitude: parseFloat(e.target.value) })}
                  />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="edit-longitude" className="text-sm font-medium">
                    خط الطول (Longitude)
                  </label>
                  <Input
                    id="edit-longitude"
                    type="number"
                    step="0.000001"
                    value={selectedLocation.longitude}
                    onChange={(e) => setSelectedLocation({ ...selectedLocation, longitude: parseFloat(e.target.value) })}
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <label htmlFor="edit-status" className="text-sm font-medium">
                  الحالة
                </label>
                <Select 
                  value={selectedLocation.status}
                  onValueChange={(value) => setSelectedLocation({ ...selectedLocation, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر الحالة..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">نشط</SelectItem>
                    <SelectItem value="planned">مخطط</SelectItem>
                    <SelectItem value="inactive">غير نشط</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <label htmlFor="edit-entityType" className="text-sm font-medium">
                  نوع الموقع
                </label>
                <Select 
                  value={selectedLocation.entityType}
                  onValueChange={(value) => setSelectedLocation({ ...selectedLocation, entityType: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع الموقع..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="project">موقع المشروع</SelectItem>
                    <SelectItem value="site">موقع عمل</SelectItem>
                    <SelectItem value="storage">مخزن</SelectItem>
                    <SelectItem value="facility">منشأة</SelectItem>
                    <SelectItem value="equipment">معدات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">
                    نطاق الموقع (متر)
                  </label>
                  <span className="text-sm font-medium">{selectedLocation.radius} م</span>
                </div>
                <Slider
                  value={[selectedLocation.radius]}
                  min={50}
                  max={1000}
                  step={50}
                  onValueChange={(value) => setSelectedLocation({ ...selectedLocation, radius: value[0] })}
                />
              </div>
              
              <div className="grid gap-2">
                <label htmlFor="edit-description" className="text-sm font-medium">
                  الوصف (اختياري)
                </label>
                <Input
                  id="edit-description"
                  placeholder="أضف وصفًا للموقع..."
                  value={selectedLocation.description || ''}
                  onChange={(e) => setSelectedLocation({ ...selectedLocation, description: e.target.value })}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditLocationOpen(false)}
              >
                إلغاء
              </Button>
              <Button 
                onClick={handleEditLocation}
                disabled={!selectedLocation.name || !selectedLocation.latitude || !selectedLocation.longitude}
              >
                حفظ التغييرات
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ProjectGeoTracking;