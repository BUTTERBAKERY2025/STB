import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Button 
} from '@/components/ui/button';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipProvider, 
  TooltipTrigger 
} from '@/components/ui/tooltip';
import {
  MapPin,
  Info,
  Eye,
  AlertTriangle
} from 'lucide-react';
import type { Project } from '@shared/schema';

// Since we're using @react-google-maps/api
import { 
  GoogleMap, 
  useLoadScript, 
  MarkerF, 
  InfoWindowF 
} from '@react-google-maps/api';

// Define the props interface
interface ProjectMapProps {
  projects: Project[];
  onViewProject: (projectId: number) => void;
}

// Default map settings
const mapContainerStyle = {
  width: '100%',
  height: '70vh',
};

const defaultCenter = {
  lat: 24.7136, // Default center of Saudi Arabia
  lng: 46.6753,
};

const defaultOptions = {
  disableDefaultUI: true,
  zoomControl: true,
  mapTypeControl: true,
  scrollwheel: true,
  fullscreenControl: true,
};

// Helper to get marker color based on project status
const getMarkerIcon = (status: string) => {
  switch (status) {
    case 'completed':
      return 'http://maps.google.com/mapfiles/ms/icons/green-dot.png';
    case 'inProgress':
      return 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png';
    case 'delayed':
      return 'http://maps.google.com/mapfiles/ms/icons/red-dot.png';
    case 'planned':
      return 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png';
    default:
      return 'http://maps.google.com/mapfiles/ms/icons/purple-dot.png';
  }
};

// Helper to get status badge class
const getStatusBadgeClass = (status: string) => {
  switch (status) {
    case 'completed':
      return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
    case 'inProgress':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
    case 'delayed':
      return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
    case 'planned':
      return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
  }
};

// Helper to get status display text
const getStatusDisplayText = (status: string) => {
  switch (status) {
    case 'completed': return 'مكتمل';
    case 'inProgress': return 'قيد التنفيذ';
    case 'delayed': return 'متأخر';
    case 'planned': return 'مخطط';
    default: return status;
  }
};

// Get category display text
const getCategoryDisplay = (category: string): string => {
  const categories: Record<string, string> = {
    'electricity': 'كهرباء',
    'water': 'مياه',
    'communications': 'اتصالات',
    'roads': 'طرق',
    'buildings': 'مباني',
  };
  return categories[category] || category;
};

// Sample geocoder function (in real app, would use a geocoding service)
const geocodeProject = (project: Project) => {
  // This is a mock function that would normally call a geocoding API
  // For simplicity, we'll just use placeholder coordinates based on the name
  // In a real app, you would use the Google Geocoding API or similar
  
  // If we already have coordinates cached for this location, use them
  const locationCoordinates: Record<string, { lat: number; lng: number }> = {
    'الرياض': { lat: 24.7136, lng: 46.6753 },
    'جدة': { lat: 21.4858, lng: 39.1925 },
    'مكة': { lat: 21.3891, lng: 39.8579 },
    'المدينة': { lat: 24.5247, lng: 39.5692 },
    'الدمام': { lat: 26.4207, lng: 50.0888 },
    'الطائف': { lat: 21.2886, lng: 40.4160 },
    'تبوك': { lat: 28.3998, lng: 36.5715 },
    'أبها': { lat: 18.2164, lng: 42.5053 },
    'بريدة': { lat: 26.3292, lng: 43.7723 },
    'جازان': { lat: 16.8892, lng: 42.5511 },
  };
  
  // Check if we have coordinates for this city
  for (const city in locationCoordinates) {
    if (project.location?.includes(city)) {
      return locationCoordinates[city];
    }
  }
  
  // Default fallback: generate random coordinates near Saudi Arabia
  return {
    lat: 24.7136 + (Math.random() - 0.5) * 3,
    lng: 46.6753 + (Math.random() - 0.5) * 3
  };
};

const ProjectMap: React.FC<ProjectMapProps> = ({ projects, onViewProject }) => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  
  // Load the Google Maps script
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.VITE_GOOGLE_MAPS_API_KEY || "",
    language: "ar",
  });
  
  // Geocode all projects to get their coordinates
  const projectsWithCoordinates = projects.map(project => ({
    ...project,
    coordinates: geocodeProject(project)
  }));
  
  // Handle marker click
  const handleMarkerClick = (project: Project) => {
    setSelectedProject(project);
  };
  
  // Render loading state
  if (loadError) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertTriangle className="h-10 w-10 text-amber-500 mx-auto mb-2" />
          <p className="text-lg font-semibold">خطأ في تحميل الخريطة</p>
          <p className="text-muted-foreground mt-1">
            لا يمكن تحميل خريطة Google. يرجى التحقق من اتصالك بالإنترنت أو مفتاح API.
          </p>
          <div className="mt-4">
            <Button variant="outline">إعادة المحاولة</Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!isLoaded) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
          <p className="text-lg font-semibold">جاري تحميل الخريطة...</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="bg-muted/50 p-3 rounded-md">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Info className="h-4 w-4" />
          <span>انقر على أي علامة على الخريطة لعرض تفاصيل المشروع</span>
        </div>
      </div>
      
      {/* Map legend */}
      <div className="flex flex-wrap gap-3 mb-2">
        <Badge variant="outline" className="gap-1.5">
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
          <span>مكتمل</span>
        </Badge>
        <Badge variant="outline" className="gap-1.5">
          <div className="w-3 h-3 rounded-full bg-blue-500"></div>
          <span>قيد التنفيذ</span>
        </Badge>
        <Badge variant="outline" className="gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <span>متأخر</span>
        </Badge>
        <Badge variant="outline" className="gap-1.5">
          <div className="w-3 h-3 rounded-full bg-amber-500"></div>
          <span>مخطط</span>
        </Badge>
      </div>
      
      {/* Main map */}
      <Card className="overflow-hidden">
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={defaultCenter}
          zoom={6}
          options={defaultOptions}
        >
          {/* Render markers for all projects */}
          {projectsWithCoordinates.map((project) => (
            <MarkerF
              key={project.id}
              position={project.coordinates}
              icon={getMarkerIcon(project.status || '')}
              onClick={() => handleMarkerClick(project)}
            />
          ))}
          
          {/* Show info window for selected project */}
          {selectedProject && (
            <InfoWindowF
              position={projectsWithCoordinates.find(p => p.id === selectedProject.id)?.coordinates || defaultCenter}
              onCloseClick={() => setSelectedProject(null)}
            >
              <div className="info-window p-1" style={{ maxWidth: '300px', textAlign: 'right', direction: 'rtl' }}>
                <h3 className="font-semibold text-base mb-1">{selectedProject.name}</h3>
                
                <div className="flex items-center gap-1 mb-1 text-sm">
                  <MapPin className="h-3.5 w-3.5" />
                  <span>{selectedProject.location}</span>
                </div>
                
                <div className="flex items-center gap-1 mb-1">
                  <Badge className={getStatusBadgeClass(selectedProject.status || '')}>
                    {getStatusDisplayText(selectedProject.status || '')}
                  </Badge>
                </div>
                
                {selectedProject.description && (
                  <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                    {selectedProject.description}
                  </p>
                )}
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-1 h-7 text-xs"
                  onClick={() => onViewProject(selectedProject.id)}
                >
                  <Eye className="h-3.5 w-3.5 ml-1" />
                  <span>عرض المشروع</span>
                </Button>
              </div>
            </InfoWindowF>
          )}
        </GoogleMap>
      </Card>
      
      {/* List of projects */}
      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-lg">المشاريع على الخريطة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {projectsWithCoordinates.map((project) => (
              <div 
                key={project.id} 
                className={`p-3 rounded-md cursor-pointer border-2 transition-all hover:bg-muted/30 ${selectedProject?.id === project.id ? 'border-primary' : 'border-transparent'}`}
                onClick={() => handleMarkerClick(project)}
              >
                <div className="flex items-start justify-between mb-1">
                  <h4 className="font-medium text-sm line-clamp-1">{project.name}</h4>
                  <Badge className={getStatusBadgeClass(project.status || '')}>
                    {getStatusDisplayText(project.status || '')}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground mb-2 flex items-center">
                  <MapPin className="h-3 w-3 ml-1 flex-shrink-0" />
                  <span className="truncate">{project.location}</span>
                </div>
                <div className="flex justify-end">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      onViewProject(project.id);
                    }}
                  >
                    <Eye className="h-3.5 w-3.5 ml-1" />
                    <span>عرض</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProjectMap;