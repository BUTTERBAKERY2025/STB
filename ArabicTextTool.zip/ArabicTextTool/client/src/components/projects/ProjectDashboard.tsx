import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { 
  Button 
} from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableHead,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import {
  LayoutDashboard,
  PlusCircle,
  Calendar,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  AlertTriangle,
  Construction,
  HelpCircle,
  TrendingUp,
  Building,
  DollarSign,
  Users,
  CalendarDays,
  ExternalLink,
  PieChart as PieChartIcon,
  BarChart3,
  BarChart2,
  Activity,
  EyeIcon
} from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';
import type { Project } from '@shared/schema';

interface ProjectDashboardProps {
  projects: Project[];
  recentProjects: Project[];
  onCreateProject: () => void;
  onViewProject: (projectId: number) => void;
  onViewAllProjects: () => void;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];
const RADIAN = Math.PI / 180;

// Custom label for pie chart
const renderCustomizedLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
}: any) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text
      x={x}
      y={y}
      fill="white"
      textAnchor={x > cx ? 'start' : 'end'}
      dominantBaseline="central"
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const ProjectDashboard: React.FC<ProjectDashboardProps> = ({
  projects,
  recentProjects,
  onCreateProject,
  onViewProject,
  onViewAllProjects
}) => {
  // Calculate stats
  const totalProjects = projects.length;
  const activeProjects = projects.filter(p => p.status === 'inProgress').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;
  const delayedProjects = projects.filter(p => p.status === 'delayed').length;
  const plannedProjects = projects.filter(p => p.status === 'planned').length;
  const totalBudget = projects.reduce((sum, p) => sum + p.budget, 0);
  
  // Average completion rate of active projects
  const activeProjectsProgress = projects
    .filter(p => p.status === 'inProgress')
    .reduce((sum, p) => sum + p.progress, 0);
  const avgProgressPercentage = activeProjects > 0 
    ? Math.round(activeProjectsProgress / activeProjects) 
    : 0;

  // For trend calculation (example: 5% increase from previous period)
  const projectsGrowthRate = 5; // Example value, would calculate from real data
  const budgetGrowthRate = 8; // Example value
  const completionRateChange = 2; // Example value

  // Project by category data for charts
  const categoryData = projects.reduce((acc, project) => {
    const category = project.category;
    const existingCategory = acc.find(item => item.name === category);
    
    if (existingCategory) {
      existingCategory.value += 1;
      existingCategory.budget += project.budget;
    } else {
      acc.push({
        name: category,
        value: 1,
        budget: project.budget
      });
    }
    
    return acc;
  }, [] as { name: string; value: number; budget: number }[]);

  // Map category keys to Arabic names
  const categoryMapping: Record<string, string> = {
    'electricity': 'كهرباء',
    'water': 'مياه',
    'communications': 'اتصالات',
    'roads': 'طرق',
    'buildings': 'مباني'
  };

  // Map category data to include Arabic names for charts
  const categoryChartData = categoryData.map(item => ({
    ...item,
    nameAr: categoryMapping[item.name] || item.name
  }));

  // For pie chart - project status distribution
  const statusData = [
    { name: 'قيد التنفيذ', value: activeProjects, color: '#3b82f6' },
    { name: 'مكتمل', value: completedProjects, color: '#22c55e' },
    { name: 'متأخر', value: delayedProjects, color: '#ef4444' },
    { name: 'مخطط', value: plannedProjects, color: '#f59e0b' }
  ].filter(item => item.value > 0);

  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'inProgress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delayed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'planned':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  // Get category display text
  const getCategoryDisplay = (category: string): string => {
    return categoryMapping[category] || category;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">لوحة المعلومات</h1>
        <Button onClick={onCreateProject} className="gap-1">
          <PlusCircle className="h-4 w-4" />
          <span>مشروع جديد</span>
        </Button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي المشاريع</p>
                <div className="flex gap-2 items-baseline mt-1">
                  <p className="text-3xl font-bold">{totalProjects}</p>
                  {projectsGrowthRate > 0 && (
                    <p className="text-sm text-green-600 flex items-center">
                      <ArrowUpRight className="h-3 w-3 ml-0.5" />
                      {projectsGrowthRate}%
                    </p>
                  )}
                </div>
              </div>
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-md">
                <LayoutDashboard className="h-5 w-5 text-blue-700 dark:text-blue-300" />
              </div>
            </div>
            <div className="mt-4 flex justify-between text-sm">
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-blue-500 ml-1"></span>
                <span className="text-muted-foreground">نشط: {activeProjects}</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-green-500 ml-1"></span>
                <span className="text-muted-foreground">مكتمل: {completedProjects}</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-2 h-2 rounded-full bg-amber-500 ml-1"></span>
                <span className="text-muted-foreground">مخطط: {plannedProjects}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي الميزانيات</p>
                <div className="flex gap-2 items-baseline mt-1">
                  <p className="text-3xl font-bold">{formatCurrency(totalBudget)}</p>
                  {budgetGrowthRate > 0 && (
                    <p className="text-sm text-green-600 flex items-center">
                      <ArrowUpRight className="h-3 w-3 ml-0.5" />
                      {budgetGrowthRate}%
                    </p>
                  )}
                </div>
              </div>
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-md">
                <DollarSign className="h-5 w-5 text-green-700 dark:text-green-300" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-xs text-muted-foreground">
                متوسط الميزانية للمشروع الواحد
              </div>
              <div className="text-sm font-semibold">
                {formatCurrency(totalBudget / (totalProjects || 1))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-muted-foreground">متوسط نسبة الإنجاز</p>
                <div className="flex gap-2 items-baseline mt-1">
                  <p className="text-3xl font-bold">{avgProgressPercentage}%</p>
                  {completionRateChange > 0 && (
                    <p className="text-sm text-green-600 flex items-center">
                      <ArrowUpRight className="h-3 w-3 ml-0.5" />
                      {completionRateChange}%
                    </p>
                  )}
                </div>
              </div>
              <div className="p-2 bg-amber-100 dark:bg-amber-900 rounded-md">
                <Activity className="h-5 w-5 text-amber-700 dark:text-amber-300" />
              </div>
            </div>
            <div className="mt-4">
              <Progress value={avgProgressPercentage} className="h-2" />
              <div className="mt-2 text-xs text-muted-foreground">
                المشاريع النشطة: {activeProjects}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-sm text-muted-foreground">المشاريع المتأخرة</p>
                <div className="flex gap-2 items-baseline mt-1">
                  <p className="text-3xl font-bold">{delayedProjects}</p>
                  <p className="text-sm text-muted-foreground">
                    من أصل {totalProjects}
                  </p>
                </div>
              </div>
              <div className="p-2 bg-red-100 dark:bg-red-900 rounded-md">
                <AlertTriangle className="h-5 w-5 text-red-700 dark:text-red-300" />
              </div>
            </div>
            <div className="mt-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">نسبة التأخير</span>
                <span className="text-xs font-medium">
                  {totalProjects ? Math.round((delayedProjects / totalProjects) * 100) : 0}%
                </span>
              </div>
              <Progress 
                value={totalProjects ? (delayedProjects / totalProjects) * 100 : 0} 
                className="h-2 mt-1" 
                indicatorClassName="bg-red-500"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>توزيع المشاريع حسب الحالة</CardTitle>
            <CardDescription>مقارنة بين أنواع المشاريع حسب الحالة</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    label={renderCustomizedLabel}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [value, 'عدد المشاريع']}
                    labelFormatter={(label) => `${label}`}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>توزيع المشاريع حسب التصنيف</CardTitle>
            <CardDescription>تصنيف المشاريع حسب النوع</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="nameAr" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [value, 'عدد المشاريع']}
                    labelFormatter={(label) => `${label}`}
                  />
                  <Bar dataKey="value" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent projects */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>أحدث المشاريع</CardTitle>
            <CardDescription>آخر المشاريع المضافة أو المحدثة</CardDescription>
          </div>
          <Button variant="outline" onClick={onViewAllProjects} className="gap-1">
            <ExternalLink className="h-4 w-4" />
            <span>عرض كل المشاريع</span>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم المشروع</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>التصنيف</TableHead>
                  <TableHead>الإنجاز</TableHead>
                  <TableHead>الميزانية</TableHead>
                  <TableHead>التاريخ</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentProjects.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-4 text-muted-foreground">
                      لا توجد مشاريع حالياً. أضف مشروعًا جديدًا للبدء.
                    </TableCell>
                  </TableRow>
                ) : (
                  recentProjects.map((project) => (
                    <TableRow key={project.id}>
                      <TableCell>
                        <div className="font-medium">{project.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {project.location}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusBadgeClass(project.status)}>
                          {getStatusDisplayText(project.status)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Building className="h-3.5 w-3.5" />
                          <span>{getCategoryDisplay(project.category)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="w-24">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs text-muted-foreground">نسبة الإنجاز</span>
                            <span className="text-xs font-medium">{project.progress}%</span>
                          </div>
                          <Progress value={project.progress} className="h-1" />
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(project.budget)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="text-xs">{formatDate(new Date(project.startDate))}</span>
                          <span className="text-xs text-muted-foreground">إلى</span>
                          <span className="text-xs">{formatDate(new Date(project.endDate))}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => onViewProject(project.id)}
                          className="ml-auto"
                        >
                          <EyeIcon className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProjectDashboard;