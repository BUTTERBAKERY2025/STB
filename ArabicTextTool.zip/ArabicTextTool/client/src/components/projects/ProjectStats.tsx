import React from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import {
  Calculator,
  Calendar,
  CreditCard,
  DollarSign,
  CheckCircle2,
  Clock,
  BarChart2,
  PieChart as PieChartIcon
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

import type { Project } from '@shared/schema';

interface ProjectStatsProps {
  projects: Project[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const ProjectStats: React.FC<ProjectStatsProps> = ({ projects }) => {
  // No projects, show placeholder
  if (projects.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <div className="text-muted-foreground">
            لا توجد مشاريع لعرض الإحصائيات. أضف مشاريع جديدة لرؤية الإحصائيات هنا.
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate stats
  const totalProjects = projects.length;
  const inProgressProjects = projects.filter(p => p.status === 'inProgress').length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;
  const delayedProjects = projects.filter(p => p.status === 'delayed').length;
  const plannedProjects = projects.filter(p => p.status === 'planned').length;
  
  const totalBudget = projects.reduce((sum, project) => sum + project.budget, 0);
  const avgProjectBudget = totalBudget / totalProjects;
  
  // Calculate avg progress of in-progress projects
  const inProgressProjectsProgress = projects
    .filter(p => p.status === 'inProgress')
    .reduce((sum, project) => sum + project.progress, 0);
  const avgProgressPercentage = inProgressProjects > 0 
    ? inProgressProjectsProgress / inProgressProjects 
    : 0;

  // Status data for pie chart
  const statusData = [
    { name: 'قيد التنفيذ', value: inProgressProjects },
    { name: 'مكتمل', value: completedProjects },
    { name: 'متأخر', value: delayedProjects },
    { name: 'مخطط', value: plannedProjects }
  ].filter(item => item.value > 0);

  // Category data for bar chart
  const categoryData = projects.reduce((acc, project) => {
    const category = project.category;
    const existingCategory = acc.find(item => item.name === category);
    
    if (existingCategory) {
      existingCategory.value += 1;
      existingCategory.budget += project.budget;
    } else {
      acc.push({
        name: category,
        value: 1,
        budget: project.budget
      });
    }
    
    return acc;
  }, [] as { name: string; value: number; budget: number }[]);

  // Map category keys to Arabic names
  const categoryMapping: Record<string, string> = {
    'electricity': 'كهرباء',
    'water': 'مياه',
    'communications': 'اتصالات',
    'roads': 'طرق',
    'buildings': 'مباني'
  };

  // Map category data to include Arabic names
  const categoryChartData = categoryData.map(item => ({
    ...item,
    nameAr: categoryMapping[item.name] || item.name
  }));

  // This custom tooltip component will use Arabic
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm text-right">
          <p className="text-sm font-bold">{payload[0].payload.nameAr}</p>
          <p className="text-xs text-muted-foreground">
            عدد المشاريع: {payload[0].value}
          </p>
          <p className="text-xs text-muted-foreground">
            الميزانية: {formatCurrency(payload[0].payload.budget)}
          </p>
        </div>
      );
    }
    return null;
  };

  const PieCustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border rounded shadow-sm text-right">
          <p className="text-sm font-bold">{payload[0].name}</p>
          <p className="text-xs text-muted-foreground">
            عدد المشاريع: {payload[0].value}
          </p>
          <p className="text-xs text-muted-foreground">
            النسبة: {payload[0].percent ? (payload[0].percent * 100).toFixed(1) : 0}%
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي المشاريع</p>
                <p className="text-2xl font-bold">{totalProjects}</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <Calculator className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {`${inProgressProjects} قيد التنفيذ، ${completedProjects} مكتمل`}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">إجمالي الميزانيات</p>
                <p className="text-2xl font-bold">{formatCurrency(totalBudget)}</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {`متوسط ${formatCurrency(avgProjectBudget)} لكل مشروع`}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">نسبة الإنجاز</p>
                <p className="text-2xl font-bold">{avgProgressPercentage.toFixed(1)}%</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <CheckCircle2 className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {`${completedProjects} مشروع مكتمل (100%)`}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">المشاريع المتأخرة</p>
                <p className="text-2xl font-bold">{delayedProjects}</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-full">
                <Clock className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              {`${(delayedProjects / totalProjects * 100).toFixed(1)}% من إجمالي المشاريع`}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="category" className="w-full">
        <div className="flex justify-between items-center mb-3">
          <h2 className="text-lg font-semibold">تحليل المشاريع</h2>
          <TabsList>
            <TabsTrigger value="category" className="flex items-center gap-1">
              <BarChart2 className="h-4 w-4" />
              <span>التصنيفات</span>
            </TabsTrigger>
            <TabsTrigger value="status" className="flex items-center gap-1">
              <PieChartIcon className="h-4 w-4" />
              <span>الحالة</span>
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="category">
          <Card>
            <CardContent className="pt-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryChartData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis 
                      dataKey="nameAr" 
                      type="category" 
                      width={70} 
                      tick={{ fontSize: 12 }} 
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" fill="#0088FE" name="عدد المشاريع" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="status">
          <Card>
            <CardContent className="pt-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                    >
                      {statusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<PieCustomTooltip />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProjectStats;