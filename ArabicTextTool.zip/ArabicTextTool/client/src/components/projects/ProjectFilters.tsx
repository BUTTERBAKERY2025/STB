import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  X, 
  Building, 
  Calendar, 
  Bookmark, 
  ChevronsUpDown 
} from 'lucide-react';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Button 
} from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Badge } from '@/components/ui/badge';

export interface ProjectFiltersState {
  search: string;
  status: string[];
  category: string[];
  date: 'all' | 'thisMonth' | 'lastMonth' | 'thisYear' | 'custom';
  startDate?: string;
  endDate?: string;
  budget: 'all' | 'under100k' | 'under500k' | 'under1m' | 'over1m' | 'custom';
  minBudget?: number;
  maxBudget?: number;
  sortBy: 'newest' | 'oldest' | 'nameAsc' | 'nameDesc' | 'budgetAsc' | 'budgetDesc' | 'progressAsc' | 'progressDesc';
}

interface ProjectFiltersProps {
  filters: ProjectFiltersState;
  onFilterChange: (filters: ProjectFiltersState) => void;
  onReset: () => void;
  filtersActive: boolean;
}

const ProjectFilters: React.FC<ProjectFiltersProps> = ({
  filters,
  onFilterChange,
  onReset,
  filtersActive
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFilterChange({ ...filters, search: e.target.value });
  };

  const handleStatusChange = (status: string) => {
    const updatedStatuses = filters.status.includes(status)
      ? filters.status.filter(s => s !== status)
      : [...filters.status, status];
    
    onFilterChange({ ...filters, status: updatedStatuses });
  };

  const handleCategoryChange = (category: string) => {
    const updatedCategories = filters.category.includes(category)
      ? filters.category.filter(c => c !== category)
      : [...filters.category, category];
    
    onFilterChange({ ...filters, category: updatedCategories });
  };

  const handleDateChange = (date: ProjectFiltersState['date']) => {
    onFilterChange({ ...filters, date });
  };

  const handleBudgetChange = (budget: ProjectFiltersState['budget']) => {
    onFilterChange({ ...filters, budget });
  };

  const handleSortChange = (sortBy: ProjectFiltersState['sortBy']) => {
    onFilterChange({ ...filters, sortBy });
  };

  const clearSearch = () => {
    onFilterChange({ ...filters, search: '' });
  };

  const getActiveFiltersCount = (): number => {
    let count = 0;
    if (filters.search) count++;
    if (filters.status.length > 0) count++;
    if (filters.category.length > 0) count++;
    if (filters.date !== 'all') count++;
    if (filters.budget !== 'all') count++;
    return count;
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-col md:flex-row gap-2">
        <div className="relative flex-grow">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            value={filters.search}
            onChange={handleSearchChange}
            placeholder="البحث عن مشروع..."
            className="pl-3 pr-10"
          />
          {filters.search && (
            <button
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={clearSearch}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        
        <div className="flex gap-2">
          <Select value={filters.sortBy} onValueChange={handleSortChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="الترتيب حسب" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">الأحدث</SelectItem>
              <SelectItem value="oldest">الأقدم</SelectItem>
              <SelectItem value="nameAsc">الاسم (أ-ي)</SelectItem>
              <SelectItem value="nameDesc">الاسم (ي-أ)</SelectItem>
              <SelectItem value="budgetAsc">الميزانية (تصاعدي)</SelectItem>
              <SelectItem value="budgetDesc">الميزانية (تنازلي)</SelectItem>
              <SelectItem value="progressAsc">الإنجاز (تصاعدي)</SelectItem>
              <SelectItem value="progressDesc">الإنجاز (تنازلي)</SelectItem>
            </SelectContent>
          </Select>

          <Popover>
            <PopoverTrigger asChild>
              <Button 
                variant={filtersActive ? "default" : "outline"} 
                className="gap-2"
              >
                <Filter className="h-4 w-4" />
                <span>تصفية</span>
                {getActiveFiltersCount() > 0 && (
                  <Badge variant="secondary" className="h-5 w-5 p-0 flex items-center justify-center">
                    {getActiveFiltersCount()}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-96 p-4" align="end">
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">حالة المشروع</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge 
                      variant={filters.status.includes('planned') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleStatusChange('planned')}
                    >
                      مخطط
                    </Badge>
                    <Badge 
                      variant={filters.status.includes('inProgress') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleStatusChange('inProgress')}
                    >
                      قيد التنفيذ
                    </Badge>
                    <Badge 
                      variant={filters.status.includes('delayed') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleStatusChange('delayed')}
                    >
                      متأخر
                    </Badge>
                    <Badge 
                      variant={filters.status.includes('completed') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleStatusChange('completed')}
                    >
                      مكتمل
                    </Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-2">تصنيف المشروع</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge 
                      variant={filters.category.includes('electricity') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleCategoryChange('electricity')}
                    >
                      كهرباء
                    </Badge>
                    <Badge 
                      variant={filters.category.includes('water') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleCategoryChange('water')}
                    >
                      مياه
                    </Badge>
                    <Badge 
                      variant={filters.category.includes('communications') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleCategoryChange('communications')}
                    >
                      اتصالات
                    </Badge>
                    <Badge 
                      variant={filters.category.includes('roads') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleCategoryChange('roads')}
                    >
                      طرق
                    </Badge>
                    <Badge 
                      variant={filters.category.includes('buildings') ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => handleCategoryChange('buildings')}
                    >
                      مباني
                    </Badge>
                  </div>
                </div>

                <Collapsible
                  open={isExpanded}
                  onOpenChange={setIsExpanded}
                  className="space-y-4"
                >
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-1 p-0">
                      <ChevronsUpDown className="h-4 w-4" />
                      <span>{isExpanded ? 'عرض أقل' : 'خيارات متقدمة'}</span>
                    </Button>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium mb-2">التاريخ</h3>
                      <Select value={filters.date} onValueChange={(v) => handleDateChange(v as any)}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر الفترة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الفترات</SelectItem>
                          <SelectItem value="thisMonth">الشهر الحالي</SelectItem>
                          <SelectItem value="lastMonth">الشهر الماضي</SelectItem>
                          <SelectItem value="thisYear">العام الحالي</SelectItem>
                          <SelectItem value="custom">فترة مخصصة</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      {filters.date === 'custom' && (
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div>
                            <label className="text-xs text-muted-foreground">من تاريخ</label>
                            <Input 
                              type="date" 
                              value={filters.startDate} 
                              onChange={(e) => onFilterChange({ ...filters, startDate: e.target.value })}
                            />
                          </div>
                          <div>
                            <label className="text-xs text-muted-foreground">إلى تاريخ</label>
                            <Input 
                              type="date" 
                              value={filters.endDate} 
                              onChange={(e) => onFilterChange({ ...filters, endDate: e.target.value })}
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    <div>
                      <h3 className="text-sm font-medium mb-2">الميزانية</h3>
                      <Select value={filters.budget} onValueChange={(v) => handleBudgetChange(v as any)}>
                        <SelectTrigger>
                          <SelectValue placeholder="اختر الميزانية" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع الميزانيات</SelectItem>
                          <SelectItem value="under100k">أقل من 100,000</SelectItem>
                          <SelectItem value="under500k">أقل من 500,000</SelectItem>
                          <SelectItem value="under1m">أقل من 1,000,000</SelectItem>
                          <SelectItem value="over1m">أكثر من 1,000,000</SelectItem>
                          <SelectItem value="custom">ميزانية مخصصة</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      {filters.budget === 'custom' && (
                        <div className="grid grid-cols-2 gap-2 mt-2">
                          <div>
                            <label className="text-xs text-muted-foreground">الحد الأدنى</label>
                            <Input 
                              type="number" 
                              value={filters.minBudget} 
                              onChange={(e) => onFilterChange({ ...filters, minBudget: Number(e.target.value) })}
                            />
                          </div>
                          <div>
                            <label className="text-xs text-muted-foreground">الحد الأقصى</label>
                            <Input 
                              type="number" 
                              value={filters.maxBudget} 
                              onChange={(e) => onFilterChange({ ...filters, maxBudget: Number(e.target.value) })}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
                
                <div className="flex justify-end">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={onReset}
                    className="mr-2"
                  >
                    إعادة ضبط
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => {}}
                  >
                    تطبيق
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>
      
      {filtersActive && (
        <div className="flex flex-wrap gap-2 pt-2">
          {filters.status.length > 0 && (
            <div className="flex items-center">
              <Badge variant="secondary" className="gap-1">
                <Bookmark className="h-3 w-3" />
                <span>الحالة: {filters.status.length}</span>
                <button
                  className="ml-1 rounded-full hover:bg-muted"
                  onClick={() => onFilterChange({ ...filters, status: [] })}
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            </div>
          )}
          
          {filters.category.length > 0 && (
            <div className="flex items-center">
              <Badge variant="secondary" className="gap-1">
                <Building className="h-3 w-3" />
                <span>التصنيف: {filters.category.length}</span>
                <button
                  className="ml-1 rounded-full hover:bg-muted"
                  onClick={() => onFilterChange({ ...filters, category: [] })}
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            </div>
          )}
          
          {filters.date !== 'all' && (
            <div className="flex items-center">
              <Badge variant="secondary" className="gap-1">
                <Calendar className="h-3 w-3" />
                <span>
                  {filters.date === 'thisMonth' ? 'الشهر الحالي' : 
                   filters.date === 'lastMonth' ? 'الشهر الماضي' : 
                   filters.date === 'thisYear' ? 'العام الحالي' : 'فترة مخصصة'}
                </span>
                <button
                  className="ml-1 rounded-full hover:bg-muted"
                  onClick={() => onFilterChange({ ...filters, date: 'all' })}
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            </div>
          )}
          
          {filters.budget !== 'all' && (
            <div className="flex items-center">
              <Badge variant="secondary" className="gap-1">
                <span>الميزانية:</span>
                <span>
                  {filters.budget === 'under100k' ? 'أقل من 100ألف' : 
                   filters.budget === 'under500k' ? 'أقل من 500ألف' : 
                   filters.budget === 'under1m' ? 'أقل من مليون' : 
                   filters.budget === 'over1m' ? 'أكثر من مليون' : 'ميزانية مخصصة'}
                </span>
                <button
                  className="ml-1 rounded-full hover:bg-muted"
                  onClick={() => onFilterChange({ ...filters, budget: 'all' })}
                >
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            </div>
          )}
          
          {filtersActive && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 px-2 text-xs"
              onClick={onReset}
            >
              إزالة كل الفلاتر
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default ProjectFilters;