import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { 
  ArrowLeft, 
  FileEdit, 
  Users, 
  Map, 
  FileText,
  Info,
  Workflow,
  Loader2 
} from 'lucide-react';

// Import project tab components
import ProjectSummary from './ProjectSummary';
import ProjectTeamTab from './ProjectTeamTab';
import ProjectGeoTracking from './ProjectGeoTracking';
import ProjectDocumentsTab from './ProjectDocumentsTab';

// Import API hooks
import { useProject, useUpdateProject } from '@/lib/data';

// Import types
import type { Project } from '@shared/schema';

interface ProjectDetailsProps {
  projectId: number;
  onBack: () => void;
  onEdit: (project: Project) => void;
}

const ProjectDetails: React.FC<ProjectDetailsProps> = ({ 
  projectId, 
  onBack,
  onEdit
}) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('summary');
  
  // Fetch project data
  const { 
    data: project, 
    isLoading, 
    error,
    refetch 
  } = useProject(projectId);
  
  const updateProjectMutation = useUpdateProject();
  
  // Track initial loading
  const [firstLoad, setFirstLoad] = useState(true);
  
  useEffect(() => {
    if (project && firstLoad) {
      setFirstLoad(false);
    }
  }, [project, firstLoad]);
  
  // Handle errors
  useEffect(() => {
    if (error) {
      toast({
        title: "خطأ في تحميل بيانات المشروع",
        description: error.message,
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  // Handle project updates
  const handleUpdateProject = async (updatedProject: Partial<Project>) => {
    try {
      await updateProjectMutation.mutateAsync({ 
        id: projectId, 
        project: updatedProject 
      });
      
      toast({
        title: "تم تحديث المشروع",
        description: "تم تحديث بيانات المشروع بنجاح",
      });
      
      refetch();
    } catch (error) {
      toast({
        title: "خطأ في تحديث المشروع",
        description: error instanceof Error ? error.message : "حدث خطأ أثناء تحديث المشروع",
        variant: "destructive",
      });
    }
  };
  
  // Render loading state
  if (isLoading || firstLoad) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <Skeleton className="h-8 w-32" />
          </div>
          <Skeleton className="h-9 w-24" />
        </div>
        
        <Skeleton className="h-10 w-full max-w-md mx-auto rounded-lg" />
        
        <div className="grid grid-cols-1 gap-8">
          <Skeleton className="h-[600px] w-full rounded-lg" />
        </div>
      </div>
    );
  }
  
  // Handle missing project
  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-[50vh] space-y-4">
        <Info className="h-12 w-12 text-muted-foreground" />
        <h2 className="text-xl font-semibold">لم يتم العثور على المشروع</h2>
        <p className="text-muted-foreground">
          المشروع الذي تبحث عنه غير موجود أو تم حذفه.
        </p>
        <Button onClick={onBack}>الرجوع إلى قائمة المشاريع</Button>
      </div>
    );
  }
  
  // Set active tab from URL query parameter
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tabParam = params.get('tab');
    if (tabParam && ['summary', 'team', 'geo', 'documents'].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, []);
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            className="h-9 w-9"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold">{project.name}</h1>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline"
            className="gap-1"
            onClick={() => onEdit(project)}
          >
            <FileEdit className="h-4 w-4" />
            <span>تعديل المشروع</span>
          </Button>
        </div>
      </div>
      
      {/* Navigation Tabs */}
      <Tabs
        defaultValue="summary"
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-4 md:w-fit">
          <TabsTrigger value="summary" className="flex gap-1">
            <Info className="h-4 w-4 hidden sm:block" />
            <span>الملخص</span>
          </TabsTrigger>
          <TabsTrigger value="team" className="flex gap-1">
            <Users className="h-4 w-4 hidden sm:block" />
            <span>فريق العمل</span>
          </TabsTrigger>
          <TabsTrigger value="geo" className="flex gap-1">
            <Map className="h-4 w-4 hidden sm:block" />
            <span>الموقع الجغرافي</span>
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex gap-1">
            <FileText className="h-4 w-4 hidden sm:block" />
            <span>المستندات</span>
          </TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="summary" className="m-0">
            <ProjectSummary project={project} />
          </TabsContent>
          
          <TabsContent value="team" className="m-0">
            <ProjectTeamTab project={project} />
          </TabsContent>
          
          <TabsContent value="geo" className="m-0">
            <ProjectGeoTracking project={project} />
          </TabsContent>
          
          <TabsContent value="documents" className="m-0">
            <ProjectDocumentsTab project={project} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default ProjectDetails;