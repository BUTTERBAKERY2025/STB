import React from 'react';
import { useLocation } from 'wouter';
import { formatDate, getRemainingDays } from '@/lib/utils';
import { useDeadlinesByProject } from '@/lib/data';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  TimerIcon,
  CalendarDays,
  AlertCircle,
  Plus
} from 'lucide-react';
import { Project } from '@shared/schema';

// تعريف نوع البيانات للمواعيد النهائية بناءً على الهيكل المتوقع من API
interface Deadline {
  id: number;
  title: string;
  description: string | null;
  dueDate: string;
  startDate?: string;
  completed: boolean;
  projectId: number;
  priority?: string;
  assignedTo?: number | null;
  status?: string;
}

// Function to determine deadline status
const getDeadlineStatus = (deadline: Deadline) => {
  if (deadline.completed) {
    return { label: 'مكتمل', color: 'bg-green-100 text-green-800', icon: <CheckCircle2 className="h-4 w-4" /> };
  }
  
  const daysRemaining = getRemainingDays(new Date(deadline.dueDate));
  
  if (daysRemaining < 0) {
    return { label: 'متأخر', color: 'bg-red-100 text-red-800', icon: <AlertTriangle className="h-4 w-4" /> };
  }
  
  if (daysRemaining <= 7) {
    return { label: 'وشيك', color: 'bg-amber-100 text-amber-800', icon: <AlertCircle className="h-4 w-4" /> };
  }
  
  return { label: 'قادم', color: 'bg-blue-100 text-blue-800', icon: <CalendarDays className="h-4 w-4" /> };
};

interface ProjectDeadlinesProps {
  project: Project;
  showHeader?: boolean;
  limitItems?: number;
}

const ProjectDeadlines: React.FC<ProjectDeadlinesProps> = ({ 
  project, 
  showHeader = true,
  limitItems
}) => {
  const [_, setLocation] = useLocation();
  const { data: deadlines = [], isLoading } = useDeadlinesByProject(project.id);
  
  // Sort deadlines by due date, with upcoming deadlines first
  const sortedDeadlines = [...deadlines].sort((a, b) => {
    // First sort by completion status
    if (a.completed && !b.completed) return 1;
    if (!a.completed && b.completed) return -1;
    
    // Then sort by due date, earlier dates first
    return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
  });
  
  // Limit deadlines if needed
  const displayDeadlines = limitItems ? sortedDeadlines.slice(0, limitItems) : sortedDeadlines;

  return (
    <Card>
      {showHeader && (
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-lg">المواعيد النهائية</CardTitle>
            <CardDescription>المواعيد المهمة والمراحل المستقبلية للمشروع</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation(`/reports?projectId=${project.id}&tab=deadlines`)}
            >
              عرض الكل
            </Button>
            <Button 
              size="sm"
              onClick={() => setLocation(`/reports?projectId=${project.id}&action=addDeadline`)}
            >
              <Plus className="h-4 w-4 ml-1" />
              موعد جديد
            </Button>
          </div>
        </CardHeader>
      )}
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        ) : displayDeadlines.length > 0 ? (
          <div className="space-y-4">
            {displayDeadlines.map((deadline, index) => {
              const status = getDeadlineStatus(deadline);
              const daysRemaining = getRemainingDays(new Date(deadline.dueDate));
              const isPast = daysRemaining < 0;
              
              // Calculate progress (for visual purposes)
              const startDate = deadline.startDate ? new Date(deadline.startDate) : new Date(project.startDate);
              const dueDate = new Date(deadline.dueDate);
              const today = new Date();
              
              const totalDuration = dueDate.getTime() - startDate.getTime();
              const elapsed = today.getTime() - startDate.getTime();
              
              // Calculate progress as percentage of time elapsed
              const progressPercentage = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));
              
              return (
                <div key={deadline.id} className="group">
                  <div className="rounded-lg border p-4 transition-colors hover:bg-muted/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{deadline.title}</h3>
                          <Badge className={status.color}>
                            <span className="flex items-center gap-1">
                              {status.icon}
                              <span>{status.label}</span>
                            </span>
                          </Badge>
                        </div>
                        
                        <div className="mt-1 text-sm text-muted-foreground">
                          {deadline.description}
                        </div>
                      </div>
                      
                      <div className="flex items-center">
                        {deadline.completed ? (
                          <Badge variant="outline" className="bg-green-50">
                            <CheckCircle2 className="h-3.5 w-3.5 text-green-600 ml-1" />
                            <span>مكتمل</span>
                          </Badge>
                        ) : (
                          <Badge 
                            variant="outline" 
                            className={isPast ? "bg-red-50" : "bg-blue-50"}
                          >
                            <TimerIcon className={`h-3.5 w-3.5 ml-1 ${isPast ? "text-red-600" : "text-blue-600"}`} />
                            <span>
                              {isPast 
                                ? `متأخر بـ ${Math.abs(daysRemaining)} يوم` 
                                : `متبقي ${daysRemaining} يوم`}
                            </span>
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    {!deadline.completed && (
                      <div className="mt-3">
                        <div className="flex justify-between text-xs mb-1">
                          <span>{formatDate(startDate)}</span>
                          <span>{formatDate(dueDate)}</span>
                        </div>
                        <div className={`w-full h-1.5 rounded-full ${isPast ? "bg-red-200" : "bg-blue-200"}`}>
                          <div 
                            className={`h-1.5 rounded-full ${isPast ? "bg-red-500" : "bg-blue-500"}`} 
                            style={{ width: `${progressPercentage}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {index < displayDeadlines.length - 1 && (
                    <Separator className="my-4" />
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>لا توجد مواعيد نهائية مسجلة بعد</p>
          </div>
        )}
      </CardContent>
      
      {!showHeader && limitItems && deadlines.length > limitItems && (
        <CardFooter>
          <Button 
            variant="ghost" 
            className="w-full"
            onClick={() => setLocation(`/reports?projectId=${project.id}&tab=deadlines`)}
          >
            عرض المزيد
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default ProjectDeadlines;