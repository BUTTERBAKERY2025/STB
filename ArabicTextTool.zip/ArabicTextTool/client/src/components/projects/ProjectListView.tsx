import React from 'react';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Button 
} from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  MoreHorizontal, 
  EyeIcon, 
  Edit, 
  Trash2, 
  FileText, 
  Calendar,
  Building,
  MapPin,
  Clock,
  BarChart4,
  Users,
  Link2
} from 'lucide-react';
import { 
  formatDate, 
  formatCurrency 
} from '@/lib/utils';

import type { Project } from '@shared/schema';

interface ProjectListViewProps {
  projects: Project[];
  onEdit: (project: Project) => void;
  onDelete: (projectId: number) => void;
  onViewDetails: (projectId: number) => void;
  onNavigateToTab: (projectId: number, tab: string) => void;
}

const ProjectListView: React.FC<ProjectListViewProps> = ({
  projects,
  onEdit,
  onDelete,
  onViewDetails,
  onNavigateToTab
}) => {
  const sortedProjects = [...projects].sort((a, b) => {
    // Sort by status first (in progress, delayed, planned, completed)
    const statusOrder: Record<string, number> = {
      'inProgress': 0,
      'delayed': 1,
      'planned': 2,
      'completed': 3
    };
    
    const aOrder = statusOrder[a.status] ?? 4;
    const bOrder = statusOrder[b.status] ?? 4;
    
    if (aOrder !== bOrder) {
      return aOrder - bOrder;
    }
    
    // Then sort by start date (newest first)
    return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
  });

  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'inProgress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delayed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'planned':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  // Get category display text
  const getCategoryDisplay = (category: string): string => {
    const categories: Record<string, string> = {
      'electricity': 'كهرباء',
      'water': 'مياه',
      'communications': 'اتصالات',
      'roads': 'طرق',
      'buildings': 'مباني',
    };
    return categories[category] || category;
  };

  return (
    <div className="rounded-md border shadow-sm overflow-hidden">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead className="w-[300px]">اسم المشروع</TableHead>
            <TableHead>الحالة</TableHead>
            <TableHead>التصنيف</TableHead>
            <TableHead>الإنجاز</TableHead>
            <TableHead>المدة</TableHead>
            <TableHead>الميزانية</TableHead>
            <TableHead>بداية المشروع</TableHead>
            <TableHead className="text-left">إجراءات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedProjects.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-6 text-muted-foreground">
                لا توجد مشاريع، قم بإضافة مشروع جديد.
              </TableCell>
            </TableRow>
          ) : (
            sortedProjects.map((project) => (
              <TableRow 
                key={project.id}
                className="hover:bg-muted/30 transition-colors cursor-pointer"
                onClick={() => onViewDetails(project.id)}
              >
                <TableCell className="font-medium">
                  <div>
                    <div className="font-semibold">{project.name}</div>
                    {project.clientName && (
                      <div className="text-sm text-muted-foreground flex items-center">
                        <span>العميل: {project.clientName}</span>
                      </div>
                    )}
                    <div className="text-xs text-muted-foreground flex items-center mt-1">
                      <MapPin className="h-3 w-3 ml-1" />
                      <span className="truncate max-w-[200px]">{project.location}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={getStatusBadgeClass(project.status)}>
                    {getStatusDisplayText(project.status)}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Building className="h-3.5 w-3.5 ml-1" />
                    <span>{getCategoryDisplay(project.category)}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col space-y-1">
                    <div className="text-sm">{project.progress}%</div>
                    <div className="w-24 bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full">
                      <div 
                        className="bg-primary h-1.5 rounded-full" 
                        style={{ width: `${project.progress}%` }} 
                      />
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Clock className="h-3.5 w-3.5 ml-1" />
                    <span>{project.duration} شهر</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="font-semibold tabular-nums">{formatCurrency(project.budget)}</div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Calendar className="h-3.5 w-3.5 ml-1" />
                    <span>{formatDate(new Date(project.startDate))}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex justify-end">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>إجراءات</DropdownMenuLabel>
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          onViewDetails(project.id);
                        }}>
                          <EyeIcon className="h-4 w-4 ml-2" />
                          <span>عرض المشروع</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          onEdit(project);
                        }}>
                          <Edit className="h-4 w-4 ml-2" />
                          <span>تعديل المشروع</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          onNavigateToTab(project.id, 'daily-reports');
                        }}>
                          <FileText className="h-4 w-4 ml-2" />
                          <span>التقارير اليومية</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          onNavigateToTab(project.id, 'finances');
                        }}>
                          <BarChart4 className="h-4 w-4 ml-2" />
                          <span>المالية</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => {
                          e.stopPropagation();
                          onNavigateToTab(project.id, 'team');
                        }}>
                          <Users className="h-4 w-4 ml-2" />
                          <span>فريق العمل</span>
                        </DropdownMenuItem>
                        
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                          onClick={(e) => {
                            e.stopPropagation();
                            onDelete(project.id);
                          }}
                          className="text-red-600 focus:text-red-600 dark:focus:text-red-500"
                        >
                          <Trash2 className="h-4 w-4 ml-2" />
                          <span>حذف المشروع</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default ProjectListView;