import React from 'react';
import { 
  Card, 
  CardContent, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Button 
} from '@/components/ui/button';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Edit, 
  Trash2, 
  EyeIcon, 
  MapPin, 
  Calendar, 
  Clock, 
  Building, 
  Star,
  Link2
} from 'lucide-react';
import { 
  formatDate, 
  formatCurrency 
} from '@/lib/utils';

import type { Project } from '@shared/schema';

interface ProjectCardProps {
  project: Project;
  onEdit: (project: Project) => void;
  onDelete: (projectId: number) => void;
  onViewDetails: (projectId: number) => void;
  isCompact?: boolean;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onEdit,
  onDelete,
  onViewDetails,
  isCompact = false
}) => {
  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'inProgress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delayed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'planned':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  // Get category display text
  const getCategoryDisplay = (category: string): string => {
    const categories: Record<string, string> = {
      'electricity': 'كهرباء',
      'water': 'مياه',
      'communications': 'اتصالات',
      'roads': 'طرق',
      'buildings': 'مباني',
    };
    return categories[category] || category;
  };

  // Rating indicator (calculate based on progress vs timeline)
  const getProjectRating = (project: Project): number => {
    // Simple calculation based on progress and status
    if (project.status === 'completed') return 5;
    if (project.status === 'delayed') return 2;
    
    // For in-progress and planned projects
    return Math.ceil(project.progress / 20);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star 
            key={star} 
            className={`h-3.5 w-3.5 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
          />
        ))}
      </div>
    );
  };

  return (
    <Card className={`overflow-hidden hover:shadow-md transition-all duration-300 hover-card-rise ${isCompact ? 'h-full' : ''}`}>
      <div className="relative h-32 overflow-hidden bg-gradient-to-b from-primary/20 to-primary/5">
        {project.imageUrl && (
          <img 
            src={project.imageUrl} 
            alt={project.name} 
            className="w-full h-full object-cover"
          />
        )}
        <div className="absolute top-2 left-2">
          <Badge className={getStatusBadgeClass(project.status)}>
            {getStatusDisplayText(project.status)}
          </Badge>
        </div>
        <div className="absolute bottom-0 right-0 left-0 bg-black/30 text-white p-2">
          <h3 className="font-bold truncate">{project.name}</h3>
        </div>
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center text-muted-foreground text-sm">
            <MapPin className="h-3.5 w-3.5 ml-1" />
            <span className="truncate max-w-[150px]">{project.location}</span>
          </div>
          <div className="text-xs">
            {renderStars(getProjectRating(project))}
          </div>
        </div>

        {!isCompact && (
          <div className="space-y-3">
            {project.clientName && (
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">العميل:</span>
                <span className="font-semibold truncate max-w-[150px]">{project.clientName}</span>
              </div>
            )}
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">الميزانية:</span>
              <span className="font-semibold">{formatCurrency(project.budget)}</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">التصنيف:</span>
              <span className="flex items-center gap-1">
                <Building className="h-3.5 w-3.5" />
                <span>{getCategoryDisplay(project.category)}</span>
              </span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">المدة:</span>
              <div className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                <span>{project.duration} شهر</span>
              </div>
            </div>
            
            <div className="flex flex-col space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">الإنجاز:</span>
                <span>{project.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full">
                <div 
                  className="bg-primary h-1.5 rounded-full" 
                  style={{ width: `${project.progress}%` }} 
                />
              </div>
            </div>
          </div>
        )}
        
        {isCompact && (
          <div className="space-y-2 mt-2">
            <div className="flex flex-col space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">الإنجاز:</span>
                <span>{project.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full">
                <div 
                  className="bg-primary h-1.5 rounded-full" 
                  style={{ width: `${project.progress}%` }} 
                />
              </div>
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="border-t px-4 py-2 flex justify-between">
        <div className="flex space-x-1 space-x-reverse">
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 p-0" 
            onClick={() => onViewDetails(project.id)}
            title="عرض التفاصيل"
          >
            <EyeIcon className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 p-0" 
            onClick={() => onEdit(project)}
            title="تعديل المشروع"
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/30" 
            onClick={() => onDelete(project.id)}
            title="حذف المشروع"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="h-8 px-2 text-xs"
          onClick={() => onViewDetails(project.id)}
        >
          <Link2 className="h-3.5 w-3.5 ml-1" />
          عرض التفاصيل
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProjectCard;