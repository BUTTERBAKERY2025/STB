import React from 'react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Button 
} from '@/components/ui/button';
import { 
  Grid, 
  List, 
  Columns, 
  KanbanSquare, 
  Map, 
  BarChart3, 
  ChevronDown,
  LayoutDashboard
} from 'lucide-react';

type ViewType = 'dashboard' | 'grid' | 'list' | 'kanban' | 'map' | 'analytics';

interface ProjectViewSelectorProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
  availableViews?: ViewType[];
}

interface ViewOption {
  id: ViewType;
  label: string;
  icon: React.ReactNode;
  description?: string;
}

const ProjectViewSelector: React.FC<ProjectViewSelectorProps> = ({
  activeView,
  onViewChange,
  availableViews = ['dashboard', 'grid', 'list', 'kanban', 'map', 'analytics']
}) => {
  // Define all possible view options
  const allViewOptions: ViewOption[] = [
    {
      id: 'dashboard',
      label: 'لوحة القيادة',
      icon: <LayoutDashboard className="h-4 w-4 ml-2" />,
      description: 'عرض لوحة المعلومات مع إحصائيات وتقارير المشاريع'
    },
    {
      id: 'grid',
      label: 'بطاقات',
      icon: <Grid className="h-4 w-4 ml-2" />,
      description: 'عرض المشاريع كبطاقات في شبكة'
    },
    {
      id: 'list',
      label: 'قائمة',
      icon: <List className="h-4 w-4 ml-2" />,
      description: 'عرض المشاريع كقائمة تفصيلية'
    },
    {
      id: 'kanban',
      label: 'كانبان',
      icon: <KanbanSquare className="h-4 w-4 ml-2" />,
      description: 'عرض المشاريع كلوحة كانبان حسب الحالة'
    },
    {
      id: 'map',
      label: 'خريطة',
      icon: <Map className="h-4 w-4 ml-2" />,
      description: 'عرض المشاريع على الخريطة حسب الموقع'
    },
    {
      id: 'analytics',
      label: 'تحليلات',
      icon: <BarChart3 className="h-4 w-4 ml-2" />,
      description: 'عرض تحليلات وإحصائيات المشاريع'
    }
  ];

  // Filter to only show available views
  const viewOptions = allViewOptions.filter(view => 
    availableViews.includes(view.id)
  );

  // Get active view details
  const activeViewOption = viewOptions.find(view => view.id === activeView) || viewOptions[0];

  return (
    <div className="flex items-center">
      <div className="hidden md:flex">
        {viewOptions.map((view) => (
          <Button
            key={view.id}
            variant={activeView === view.id ? "default" : "ghost"}
            size="sm"
            className="gap-1"
            onClick={() => onViewChange(view.id)}
          >
            {React.cloneElement(view.icon as React.ReactElement, {
              className: "h-4 w-4 ml-1"
            })}
            <span>{view.label}</span>
          </Button>
        ))}
      </div>

      <div className="block md:hidden">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="gap-1">
              {React.cloneElement(activeViewOption.icon as React.ReactElement, {
                className: "h-4 w-4 ml-1"
              })}
              <span>{activeViewOption.label}</span>
              <ChevronDown className="h-4 w-4 mr-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {viewOptions.map((view) => (
              <DropdownMenuItem
                key={view.id}
                onClick={() => onViewChange(view.id)}
                className="gap-2"
              >
                {React.cloneElement(view.icon as React.ReactElement, {
                  className: "h-4 w-4 ml-1"
                })}
                <span>{view.label}</span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default ProjectViewSelector;