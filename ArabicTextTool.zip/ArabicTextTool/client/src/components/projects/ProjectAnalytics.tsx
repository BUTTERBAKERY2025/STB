import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart as BarChartIcon, 
  TrendingUp, 
  AlertCircle, 
  Calendar, 
  DollarSign 
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

import type { Project, Expense, Invoice } from '@shared/schema';

interface ProjectAnalyticsProps {
  project: Project;
  expenses: Expense[];
  invoices: Invoice[];
}

// For pie chart
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const ProjectAnalytics: React.FC<ProjectAnalyticsProps> = ({
  project,
  expenses,
  invoices
}) => {
  // Calculate metrics
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalInvoices = invoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const profitability = totalInvoices - totalExpenses;
  const profitabilityPercentage = project.budget > 0 
    ? Math.round((profitability / project.budget) * 100) 
    : 0;

  // Group expenses by category for pie chart
  const prepareExpensesByCategoryData = () => {
    const categories: Record<string, number> = {};
    
    expenses.forEach(expense => {
      if (categories[expense.category]) {
        categories[expense.category] += expense.amount;
      } else {
        categories[expense.category] = expense.amount;
      }
    });
    
    return Object.keys(categories).map(category => ({
      name: getCategoryDisplayName(category),
      value: categories[category]
    }));
  };

  // Prepare financial comparison data
  const prepareFinancialComparisonData = () => {
    return [
      {
        name: 'الميزانية',
        المبلغ: project.budget,
      },
      {
        name: 'المصروفات',
        المبلغ: totalExpenses,
      },
      {
        name: 'الفواتير',
        المبلغ: totalInvoices,
      },
      {
        name: 'الربحية',
        المبلغ: profitability,
      }
    ];
  };

  // Helper for category display names
  const getCategoryDisplayName = (category: string): string => {
    const categoryMap: Record<string, string> = {
      'materials': 'مواد',
      'labor': 'عمالة',
      'equipment': 'معدات',
      'other': 'أخرى',
      'transportation': 'نقل',
      'consulting': 'استشارات',
    };
    
    return categoryMap[category] || category;
  };

  // Custom tooltip content for the pie chart
  const renderCustomizedLabel = (props: any) => {
    const { cx, cy, midAngle, innerRadius, outerRadius, percent, index, name } = props;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
    const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);
    
    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor="middle" 
        dominantBaseline="central"
        className="text-xs"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  // Risk score calculation (simplified)
  const calculateRiskScore = (): number => {
    // Start with a base score
    let score = 50;
    
    // Project completion vs timeline factor
    const today = new Date();
    const startDate = new Date(project.startDate);
    const endDate = new Date(project.endDate);
    const totalDuration = endDate.getTime() - startDate.getTime();
    const elapsedDuration = today.getTime() - startDate.getTime();
    const expectedProgress = Math.min(100, Math.max(0, (elapsedDuration / totalDuration) * 100));
    
    // If behind schedule (progress is less than expected based on timeline)
    if (project.progress < expectedProgress) {
      score -= Math.min(25, (expectedProgress - project.progress) * 0.5);
    }
    
    // Budget factor
    if (totalExpenses > project.budget * 0.8) {
      score -= 15; // High risk if we've spent more than 80% of budget
    } else if (totalExpenses > project.budget * 0.6) {
      score -= 5; // Medium risk if we've spent more than 60% of budget
    }
    
    // Profitability factor
    if (profitabilityPercentage < 0) {
      score -= 20; // High risk if profitability is negative
    } else if (profitabilityPercentage < 10) {
      score -= 10; // Medium risk if profitability is low
    }
    
    // Clamp score between 0-100
    return Math.min(100, Math.max(0, score));
  };

  const riskScore = calculateRiskScore();
  
  // Determine risk level from score
  const getRiskLevel = (score: number): { label: string; color: string } => {
    if (score < 30) return { label: 'مرتفع', color: 'text-red-500' };
    if (score < 70) return { label: 'متوسط', color: 'text-yellow-500' };
    return { label: 'منخفض', color: 'text-green-500' };
  };
  
  const riskLevel = getRiskLevel(riskScore);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Budget card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الميزانية</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(project.budget)}</div>
            <p className="text-xs text-gray-500 mt-1">
              تم صرف {formatCurrency(totalExpenses)} ({Math.round((totalExpenses/project.budget)*100)}%)
            </p>
          </CardContent>
        </Card>
        
        {/* Profitability card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">الربحية المتوقعة</CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${profitability >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(profitability)}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {profitabilityPercentage}% من قيمة المشروع
            </p>
          </CardContent>
        </Card>
        
        {/* Risk level card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">مستوى المخاطر</CardTitle>
            <AlertCircle className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${riskLevel.color}`}>
              {riskLevel.label}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
              <div 
                className={`h-2.5 rounded-full ${
                  riskScore < 30 ? 'bg-red-500' : 
                  riskScore < 70 ? 'bg-yellow-500' : 'bg-green-500'
                }`} 
                style={{ width: `${riskScore}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              درجة المخاطرة: {riskScore}/100
            </p>
          </CardContent>
        </Card>
        
        {/* Progress vs. Timeline card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">الإنجاز مقابل الجدول</CardTitle>
            <Calendar className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {project.progress}%
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${project.progress}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">
              المدة: {project.duration} شهر
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Financial Comparison Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">مقارنة مالية</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={prepareFinancialComparisonData()}
                margin={{ top: 10, right: 10, left: 10, bottom: 20 }}
                layout="vertical"
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  scale="band" 
                  tickLine={false}
                  axisLine={false}
                  style={{ fontFamily: 'var(--font-sans)' }}
                />
                <Tooltip 
                  formatter={(value: number) => [`${formatCurrency(value)}`, 'المبلغ']} 
                  contentStyle={{ direction: 'rtl', textAlign: 'right' }}
                />
                <Bar dataKey="المبلغ" fill="#8884d8" barSize={30} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        {/* Expenses by Category Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">توزيع المصروفات</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={prepareExpensesByCategoryData()}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomizedLabel}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {prepareExpensesByCategoryData().map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => [`${formatCurrency(value)}`, 'المبلغ']} 
                  contentStyle={{ direction: 'rtl', textAlign: 'right' }}
                />
                <Legend 
                  layout="horizontal" 
                  verticalAlign="bottom" 
                  align="center"
                  formatter={(value) => <span style={{ direction: 'rtl' }}>{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProjectAnalytics;