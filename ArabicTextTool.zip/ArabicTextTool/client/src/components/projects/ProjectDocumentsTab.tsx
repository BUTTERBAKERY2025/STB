import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  FileText, 
  Upload, 
  Download, 
  Search, 
  Eye, 
  Clock, 
  User,
  Calendar,
  FileUp,
  Loader2,
  Trash2,
  FilterX,
  Filter
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

// Import types
import type { Project } from '@shared/schema';

interface ProjectDocumentsTabProps {
  project: Project;
}

// Mock document data
interface Document {
  id: number;
  name: string;
  type: string;
  size: string;
  uploadedBy: string;
  uploadedAt: Date;
  status: 'pending' | 'approved' | 'rejected';
  category: 'contract' | 'report' | 'invoice' | 'plan' | 'other';
}

const documents: Document[] = [
  {
    id: 1,
    name: "عقد المشروع.pdf",
    type: "PDF",
    size: "2.4 MB",
    uploadedBy: "أحمد محمد",
    uploadedAt: new Date(2025, 2, 10),
    status: 'approved',
    category: 'contract'
  },
  {
    id: 2,
    name: "تقرير تقدم الأعمال - مارس 2025.xlsx",
    type: "Excel",
    size: "1.8 MB",
    uploadedBy: "فاطمة علي",
    uploadedAt: new Date(2025, 2, 15),
    status: 'approved',
    category: 'report'
  },
  {
    id: 3,
    name: "مخطط الموقع.dwg",
    type: "AutoCAD",
    size: "5.2 MB",
    uploadedBy: "خالد عبد الله",
    uploadedAt: new Date(2025, 2, 20),
    status: 'approved',
    category: 'plan'
  },
  {
    id: 4,
    name: "فاتورة المواد - دفعة 1.pdf",
    type: "PDF",
    size: "1.1 MB",
    uploadedBy: "عمر فهد",
    uploadedAt: new Date(2025, 2, 25),
    status: 'pending',
    category: 'invoice'
  },
  {
    id: 5,
    name: "جدول الأعمال المتبقية.docx",
    type: "Word",
    size: "950 KB",
    uploadedBy: "أحمد محمد",
    uploadedAt: new Date(2025, 2, 28),
    status: 'pending',
    category: 'other'
  }
];

const ProjectDocumentsTab: React.FC<ProjectDocumentsTabProps> = ({ project }) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [viewDocumentDialogOpen, setViewDocumentDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [filters, setFilters] = useState<{
    status: string[];
    category: string[];
  }>({
    status: [],
    category: []
  });

  // Filter documents
  const filteredDocuments = documents.filter(doc => {
    // Search filter
    const matchesSearch = searchTerm === '' || 
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.uploadedBy.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Status filter
    const matchesStatus = filters.status.length === 0 || 
      filters.status.includes(doc.status);
    
    // Category filter
    const matchesCategory = filters.category.length === 0 || 
      filters.category.includes(doc.category);
    
    return matchesSearch && matchesStatus && matchesCategory;
  });

  // Check if there are active filters
  const hasActiveFilters = filters.status.length > 0 || filters.category.length > 0;

  // Toggle status filter
  const toggleStatusFilter = (status: 'pending' | 'approved' | 'rejected') => {
    setFilters(prev => {
      if (prev.status.includes(status)) {
        return {
          ...prev,
          status: prev.status.filter(s => s !== status)
        };
      } else {
        return {
          ...prev,
          status: [...prev.status, status]
        };
      }
    });
  };

  // Toggle category filter
  const toggleCategoryFilter = (category: 'contract' | 'report' | 'invoice' | 'plan' | 'other') => {
    setFilters(prev => {
      if (prev.category.includes(category)) {
        return {
          ...prev,
          category: prev.category.filter(c => c !== category)
        };
      } else {
        return {
          ...prev,
          category: [...prev.category, category]
        };
      }
    });
  };

  // Reset filters
  const resetFilters = () => {
    setFilters({
      status: [],
      category: []
    });
    setSearchTerm('');
  };

  // Handle upload
  const handleUpload = () => {
    setUploadStatus('uploading');
    setTimeout(() => {
      setUploadStatus('success');
      toast({
        title: "تم رفع المستند",
        description: "تم رفع المستند بنجاح وسيتم مراجعته قريبًا",
      });
      setTimeout(() => {
        setUploadDialogOpen(false);
        setUploadStatus('idle');
      }, 1000);
    }, 2000);
  };

  // View document
  const viewDocument = (document: Document) => {
    setSelectedDocument(document);
    setViewDocumentDialogOpen(true);
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">معتمد</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">مرفوض</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">قيد المراجعة</Badge>;
      default:
        return null;
    }
  };

  // Get category text
  const getCategoryText = (category: string) => {
    switch (category) {
      case 'contract':
        return 'عقد';
      case 'report':
        return 'تقرير';
      case 'invoice':
        return 'فاتورة';
      case 'plan':
        return 'مخطط';
      case 'other':
        return 'أخرى';
      default:
        return category;
    }
  };

  // Get file type icon
  const getFileTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'pdf':
        return <FileText className="h-4 w-4 text-red-500" />;
      case 'excel':
        return <FileText className="h-4 w-4 text-green-500" />;
      case 'word':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'autocad':
        return <FileText className="h-4 w-4 text-yellow-500" />;
      default:
        return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
            <div className="relative w-full sm:w-96">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="البحث في المستندات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-4"
              />
            </div>
            
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10 gap-2">
                    <Filter className="h-4 w-4" />
                    <span>تصفية</span>
                    {hasActiveFilters && (
                      <Badge className="ml-1 h-5 px-1.5 bg-primary">
                        {filters.status.length + filters.category.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="p-2">
                    <p className="text-sm font-medium mb-2">الحالة</p>
                    <div className="flex flex-wrap gap-1">
                      <Badge 
                        variant={filters.status.includes('approved') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleStatusFilter('approved')}
                      >
                        معتمد
                      </Badge>
                      <Badge 
                        variant={filters.status.includes('pending') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleStatusFilter('pending')}
                      >
                        قيد المراجعة
                      </Badge>
                      <Badge 
                        variant={filters.status.includes('rejected') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleStatusFilter('rejected')}
                      >
                        مرفوض
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <div className="p-2">
                    <p className="text-sm font-medium mb-2">النوع</p>
                    <div className="flex flex-wrap gap-1">
                      <Badge 
                        variant={filters.category.includes('contract') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategoryFilter('contract')}
                      >
                        عقد
                      </Badge>
                      <Badge 
                        variant={filters.category.includes('report') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategoryFilter('report')}
                      >
                        تقرير
                      </Badge>
                      <Badge 
                        variant={filters.category.includes('invoice') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategoryFilter('invoice')}
                      >
                        فاتورة
                      </Badge>
                      <Badge 
                        variant={filters.category.includes('plan') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategoryFilter('plan')}
                      >
                        مخطط
                      </Badge>
                      <Badge 
                        variant={filters.category.includes('other') ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => toggleCategoryFilter('other')}
                      >
                        أخرى
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <div className="p-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start gap-2"
                      onClick={resetFilters}
                    >
                      <FilterX className="h-4 w-4" />
                      <span>إعادة ضبط التصفية</span>
                    </Button>
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button
                className="gap-2"
                onClick={() => setUploadDialogOpen(true)}
              >
                <Upload className="h-4 w-4" />
                <span>رفع مستند</span>
              </Button>
            </div>
          </div>
          
          {hasActiveFilters && (
            <div className="bg-muted/40 text-sm p-3 rounded-md flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <span>التصفية مفعّلة. تم عرض {filteredDocuments.length} من أصل {documents.length} مستند.</span>
              </div>
              <Button size="sm" variant="ghost" className="h-7 gap-1" onClick={resetFilters}>
                <FilterX className="h-3.5 w-3.5" />
                <span>إزالة التصفية</span>
              </Button>
            </div>
          )}
          
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المستند</TableHead>
                  <TableHead>النوع</TableHead>
                  <TableHead>التصنيف</TableHead>
                  <TableHead>الحجم</TableHead>
                  <TableHead>تاريخ الرفع</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>الإجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.length > 0 ? (
                  filteredDocuments.map((doc) => (
                    <TableRow key={doc.id}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {getFileTypeIcon(doc.type)}
                          <span>{doc.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{doc.type}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getCategoryText(doc.category)}
                        </Badge>
                      </TableCell>
                      <TableCell>{doc.size}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>
                            {format(doc.uploadedAt, 'yyyy/MM/dd', { locale: ar })}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(doc.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => viewDocument(doc)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              toast({
                                title: "جاري التنزيل",
                                description: `جاري تنزيل ${doc.name}`
                              });
                            }}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      لا توجد مستندات مطابقة للبحث
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      
      {/* Upload Document Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>رفع مستند جديد</DialogTitle>
            <DialogDescription>
              قم برفع المستندات المتعلقة بالمشروع هنا للمراجعة والاعتماد.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-center w-full">
              <label
                htmlFor="dropzone-file"
                className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-muted/40 hover:bg-muted/60"
              >
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <FileUp className="w-8 h-8 mb-3 text-muted-foreground" />
                  <p className="mb-2 text-sm text-muted-foreground">
                    <span className="font-semibold">اضغط للرفع</span> أو اسحب واسقط
                  </p>
                  <p className="text-xs text-muted-foreground">
                    PDF, DOCX, XLSX, JPG (بحد أقصى 10MB)
                  </p>
                </div>
                <input id="dropzone-file" type="file" className="hidden" />
              </label>
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="document-name" className="text-sm font-medium">
                اسم المستند
              </label>
              <Input
                id="document-name"
                placeholder="اكتب اسم المستند..."
              />
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="document-category" className="text-sm font-medium">
                تصنيف المستند
              </label>
              <select
                id="document-category"
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                <option value="contract">عقد</option>
                <option value="report">تقرير</option>
                <option value="invoice">فاتورة</option>
                <option value="plan">مخطط</option>
                <option value="other">أخرى</option>
              </select>
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="document-description" className="text-sm font-medium">
                الوصف (اختياري)
              </label>
              <Input
                id="document-description"
                placeholder="أضف وصفًا مختصرًا للمستند..."
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setUploadDialogOpen(false);
                setUploadStatus('idle');
              }}
              disabled={uploadStatus === 'uploading'}
            >
              إلغاء
            </Button>
            <Button
              onClick={handleUpload}
              disabled={uploadStatus !== 'idle'}
            >
              {uploadStatus === 'uploading' ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  جاري الرفع...
                </>
              ) : uploadStatus === 'success' ? (
                <>
                  تم الرفع بنجاح
                </>
              ) : (
                <>
                  رفع المستند
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* View Document Dialog */}
      <Dialog open={viewDocumentDialogOpen} onOpenChange={setViewDocumentDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              <div className="flex items-center gap-2">
                {selectedDocument && getFileTypeIcon(selectedDocument.type)}
                <span>{selectedDocument?.name}</span>
              </div>
            </DialogTitle>
          </DialogHeader>
          
          <div className="grid gap-4">
            <div className="aspect-video bg-muted flex items-center justify-center rounded-lg">
              <FileText className="h-16 w-16 text-muted-foreground/40" />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">تم الرفع بواسطة:</span>
                    <span>{selectedDocument?.uploadedBy}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">تاريخ الرفع:</span>
                    <span>
                      {selectedDocument?.uploadedAt && format(selectedDocument.uploadedAt, 'yyyy/MM/dd', { locale: ar })}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">الحالة:</span>
                    <span>{selectedDocument && getStatusBadge(selectedDocument.status)}</span>
                  </div>
                </CardContent>
              </Card>
              
              <div className="space-y-4">
                <Button className="w-full gap-2">
                  <Download className="h-4 w-4" />
                  <span>تنزيل المستند</span>
                </Button>
                
                <Button variant="destructive" className="w-full gap-2">
                  <Trash2 className="h-4 w-4" />
                  <span>حذف المستند</span>
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProjectDocumentsTab;