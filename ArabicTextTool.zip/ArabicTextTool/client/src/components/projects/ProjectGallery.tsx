import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Button 
} from '@/components/ui/button';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  ChevronLeft, 
  ChevronRight, 
  Info, 
  Calendar, 
  MapPin,
  DollarSign, 
  Building, 
  Clock,
  Star,
  BarChart3,
  TrendingUp,
  ArrowRight,
  EyeIcon,
  Link2
} from 'lucide-react';
import { formatDate, formatCurrency } from '@/lib/utils';

import type { Project } from '@shared/schema';

interface ProjectGalleryProps {
  projects: Project[];
  onViewProject: (projectId: number) => void;
  title?: string;
  limit?: number;
}

const ProjectGallery: React.FC<ProjectGalleryProps> = ({
  projects,
  onViewProject,
  title = 'المشاريع',
  limit = 3
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const filteredProjects = projects
    // Sort by newest first
    .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
    // Limit to specified number
    .slice(0, limit);
  
  const nextProject = () => {
    setCurrentIndex((prev) => (prev + 1) % filteredProjects.length);
  };
  
  const prevProject = () => {
    setCurrentIndex((prev) => (prev - 1 + filteredProjects.length) % filteredProjects.length);
  };
  
  // If no projects, show placeholder
  if (filteredProjects.length === 0) {
    return (
      <Card className="bg-muted/30">
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">لا توجد مشاريع لعرضها.</p>
        </CardContent>
      </Card>
    );
  }

  const project = filteredProjects[currentIndex];

  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'inProgress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'delayed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'planned':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  // Get category display text
  const getCategoryDisplay = (category: string): string => {
    const categories: Record<string, string> = {
      'electricity': 'كهرباء',
      'water': 'مياه',
      'communications': 'اتصالات',
      'roads': 'طرق',
      'buildings': 'مباني',
    };
    return categories[category] || category;
  };

  // Rating indicator (calculate based on progress vs timeline)
  const getProjectRating = (project: Project): number => {
    // Simple calculation based on progress and status
    if (project.status === 'completed') return 5;
    if (project.status === 'delayed') return 2;
    
    // For in-progress and planned projects
    return Math.ceil(project.progress / 20);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star 
            key={star} 
            className={`h-4 w-4 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xl font-bold">{title}</h2>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={prevProject}
            disabled={filteredProjects.length <= 1}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground">
            {currentIndex + 1} / {filteredProjects.length}
          </span>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={nextProject}
            disabled={filteredProjects.length <= 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card className="overflow-hidden shadow-md">
        <div className="h-48 overflow-hidden relative bg-gradient-to-b from-primary/20 to-primary/5">
          {project.imageUrl ? (
            <img 
              src={project.imageUrl} 
              alt={project.name} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-muted/50">
              <Building className="h-16 w-16 text-muted" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="absolute top-4 left-4">
            <Badge className={getStatusBadgeClass(project.status)}>
              {getStatusDisplayText(project.status)}
            </Badge>
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white">
            <h3 className="text-2xl font-bold mb-1">{project.name}</h3>
            <div className="flex items-center gap-3 text-sm">
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{project.location}</span>
              </div>
              <div className="flex items-center gap-1">
                <Building className="h-4 w-4" />
                <span>{getCategoryDisplay(project.category)}</span>
              </div>
            </div>
          </div>
        </div>
        
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
            <div className="flex flex-col bg-muted/30 p-3 rounded-lg">
              <span className="text-xs text-muted-foreground">الميزانية</span>
              <div className="flex items-center mt-1">
                <DollarSign className="h-4 w-4 text-primary ml-1" />
                <span className="font-semibold">{formatCurrency(project.budget)}</span>
              </div>
            </div>
            
            <div className="flex flex-col bg-muted/30 p-3 rounded-lg">
              <span className="text-xs text-muted-foreground">مدة المشروع</span>
              <div className="flex items-center mt-1">
                <Clock className="h-4 w-4 text-primary ml-1" />
                <span className="font-semibold">{project.duration} شهر</span>
              </div>
            </div>
            
            <div className="flex flex-col bg-muted/30 p-3 rounded-lg">
              <span className="text-xs text-muted-foreground">تاريخ البداية</span>
              <div className="flex items-center mt-1">
                <Calendar className="h-4 w-4 text-primary ml-1" />
                <span className="font-semibold">{formatDate(new Date(project.startDate))}</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-muted-foreground">التقييم</span>
                {renderStars(getProjectRating(project))}
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm text-muted-foreground">نسبة الإنجاز</span>
                <span className="font-semibold">{project.progress}%</span>
              </div>
              <div className="w-full bg-muted h-2 rounded-full">
                <div 
                  className="bg-primary h-2 rounded-full" 
                  style={{ width: `${project.progress}%` }} 
                />
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
              {project.description}
            </p>
          </div>
        </CardContent>
        
        <CardFooter className="border-t p-4 flex justify-between items-center">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <TrendingUp className="h-3.5 w-3.5" />
            <span>تاريخ آخر تحديث: {formatDate(new Date(project.updatedAt || project.createdAt))}</span>
          </div>
          
          <Button
            onClick={() => onViewProject(project.id)}
            className="gap-1"
          >
            <EyeIcon className="h-4 w-4" />
            <span>عرض المشروع</span>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ProjectGallery;