import React from 'react';
import { useLocation } from 'wouter';
import { formatDate, formatTime } from '@/lib/utils';
import { useActivitiesByProject } from '@/lib/data';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Calendar,
  Clock,
  AlertTriangle,
  FileText,
  Users,
  Truck,
  MessageSquare,
  Banknote,
  Receipt,
  FilePlus,
  Edit,
  CheckCircle,
  Activity,
  ArrowUpDown,
  BadgeAlert,
  Package,
  ClipboardList,
  Plus
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Project } from '@shared/schema';

// تعريف نوع بيانات النشاط
interface ProjectActivity {
  id: number;
  userId: number;
  userName: string | null;
  projectId: number;
  timestamp: string;
  type: string;
  description: string;
  details?: any;
}

// Define activity types for icon selection
const getActivityIcon = (type: string) => {
  switch (type) {
    case 'risk':
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    case 'document':
      return <FileText className="h-5 w-5 text-blue-500" />;
    case 'team':
      return <Users className="h-5 w-5 text-indigo-500" />;
    case 'equipment':
      return <Truck className="h-5 w-5 text-green-500" />;
    case 'comment':
      return <MessageSquare className="h-5 w-5 text-purple-500" />;
    case 'expense':
      return <Banknote className="h-5 w-5 text-red-500" />;
    case 'invoice':
      return <Receipt className="h-5 w-5 text-emerald-500" />;
    case 'report':
      return <ClipboardList className="h-5 w-5 text-orange-500" />;
    case 'status':
      return <ArrowUpDown className="h-5 w-5 text-blue-500" />;
    case 'milestone':
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    case 'issue':
      return <BadgeAlert className="h-5 w-5 text-red-500" />;
    case 'material':
      return <Package className="h-5 w-5 text-yellow-500" />;
    default:
      return <Activity className="h-5 w-5 text-gray-500" />;
  }
};

// Get username for display (fallback to "النظام" if not available)
const getUserDisplayName = (userName: string | null) => {
  return userName || "النظام";
};

// Get initial for avatar
const getInitial = (name: string) => {
  return name.charAt(0).toUpperCase();
};

interface ProjectActivitiesProps {
  project: Project;
  showHeader?: boolean;
  limitItems?: number;
}

const ProjectActivities: React.FC<ProjectActivitiesProps> = ({ 
  project, 
  showHeader = true,
  limitItems
}) => {
  const [_, setLocation] = useLocation();
  const { data: activities = [], isLoading } = useActivitiesByProject(project.id);
  
  // Limit activities if needed
  const displayActivities = limitItems ? activities.slice(0, limitItems) : activities;

  return (
    <Card>
      {showHeader && (
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-lg">أنشطة المشروع</CardTitle>
            <CardDescription>آخر التحديثات والنشاطات المتعلقة بالمشروع</CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setLocation(`/reports?projectId=${project.id}&tab=activities`)}
          >
            عرض الكل
          </Button>
        </CardHeader>
      )}
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        ) : displayActivities.length > 0 ? (
          <div className="space-y-6">
            {displayActivities.map((activity, index) => (
              <div key={activity.id || index} className="relative">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                      {getActivityIcon(activity.type)}
                    </div>
                  </div>
                  <div className="flex-grow space-y-1">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback>{getInitial(getUserDisplayName(activity.userName))}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{getUserDisplayName(activity.userName)}</span>
                      <Badge variant="outline" className="text-xs">
                        {activity.type === 'risk' && 'مخاطر'}
                        {activity.type === 'document' && 'مستند'}
                        {activity.type === 'team' && 'فريق'}
                        {activity.type === 'equipment' && 'معدات'}
                        {activity.type === 'comment' && 'تعليق'}
                        {activity.type === 'expense' && 'مصروف'}
                        {activity.type === 'invoice' && 'فاتورة'}
                        {activity.type === 'report' && 'تقرير'}
                        {activity.type === 'status' && 'تحديث حالة'}
                        {activity.type === 'milestone' && 'إنجاز'}
                        {activity.type === 'issue' && 'مشكلة'}
                        {activity.type === 'material' && 'مواد'}
                        {activity.type !== 'risk' &&
                         activity.type !== 'document' &&
                         activity.type !== 'team' &&
                         activity.type !== 'equipment' &&
                         activity.type !== 'comment' &&
                         activity.type !== 'expense' &&
                         activity.type !== 'invoice' &&
                         activity.type !== 'report' &&
                         activity.type !== 'status' &&
                         activity.type !== 'milestone' &&
                         activity.type !== 'issue' &&
                         activity.type !== 'material' && 'نشاط'}
                      </Badge>
                    </div>
                    <p>{activity.description}</p>
                    <div className="flex items-center text-sm text-muted-foreground gap-2">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{formatDate(new Date(activity.timestamp))}</span>
                      <Clock className="h-3.5 w-3.5 mr-2" />
                      <span>{formatTime(new Date(activity.timestamp))}</span>
                    </div>
                  </div>
                </div>
                {index < displayActivities.length - 1 && (
                  <Separator className="my-4" />
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>لا توجد أنشطة مسجلة بعد</p>
          </div>
        )}
      </CardContent>
      
      {!showHeader && limitItems && activities.length > limitItems && (
        <CardFooter>
          <Button 
            variant="ghost" 
            className="w-full"
            onClick={() => setLocation(`/reports?projectId=${project.id}&tab=activities`)}
          >
            عرض المزيد
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};

export default ProjectActivities;