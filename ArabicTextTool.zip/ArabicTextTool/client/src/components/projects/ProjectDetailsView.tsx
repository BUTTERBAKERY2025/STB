import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Button,
  buttonVariants
} from '@/components/ui/button';
import { 
  Badge 
} from '@/components/ui/badge';
import { 
  Separator 
} from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  ChevronLeft, 
  MapPin, 
  Calendar, 
  Clock, 
  Building, 
  FileText, 
  User as UserIcon, 
  CreditCard,
  ClipboardList,
  Receipt,
  BarChart3,
  Users,
  Folder,
  Star,
  ExternalLink,
  Download,
  Printer,
  AlertTriangle,
  Edit3,
  Truck,
} from 'lucide-react';
import { formatDate, formatCurrency } from '@/lib/utils';
import ProjectAnalytics from './ProjectAnalytics';
import ProjectActivities from './ProjectActivities';
import ProjectDeadlines from './ProjectDeadlines';

import type { 
  Project, 
  DailyReport, 
  Expense, 
  Invoice, 
  TeamAssignment, 
  Equipment, 
  Document,
  Deadline,
  ProjectRisk,
  User as UserSchema
} from '@shared/schema';

// Use existing User type from the schema (excluding password for security)
type UserType = Omit<UserSchema, 'password'>;

interface ProjectDetailsViewProps {
  project: Project;
  dailyReports: DailyReport[];
  expenses: Expense[];
  invoices: Invoice[];
  team: TeamAssignment[];
  equipment: Equipment[];
  documents: Document[];
  risks: ProjectRisk[];
  deadlines: Deadline[];
  users: UserType[];
  onBack: () => void;
  onEdit: (project: Project) => void;
}

// Helper to get display status in Arabic
const getStatusDisplay = (status: string): { label: string; color: string } => {
  switch (status) {
    case 'completed':
      return { label: 'مكتمل', color: 'bg-green-100 text-green-800' };
    case 'inProgress':
      return { label: 'قيد التنفيذ', color: 'bg-yellow-100 text-yellow-800' };
    case 'delayed':
      return { label: 'متأخر', color: 'bg-red-100 text-red-800' };
    case 'planned':
      return { label: 'مخطط', color: 'bg-blue-100 text-blue-800' };
    default:
      return { label: status, color: 'bg-gray-100 text-gray-800' };
  }
};

// Rating component
const RatingStars: React.FC<{ rating: number }> = ({ rating }) => {
  return (
    <div className="flex items-center">
      {[1, 2, 3, 4, 5].map(star => (
        <Star 
          key={star} 
          className={`h-5 w-5 ${star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
        />
      ))}
    </div>
  );
};

// Calculate project rating based on financial performance and timeline
const calculateProjectRating = (
  project: Project, 
  expenses: Expense[], 
  invoices: Invoice[]
): number => {
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalInvoices = invoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const profit = totalInvoices - totalExpenses;
  
  // Budget adherence rating (0-1.5 stars)
  const budgetRating = project.budget > 0 
    ? Math.max(0, 1.5 - (Math.max(0, totalExpenses - project.budget) / project.budget) * 1.5)
    : 0;
  
  // Progress vs timeline rating (0-1.5 stars)
  const startDate = new Date(project.startDate);
  const endDate = new Date(project.endDate);
  const now = new Date();
  const totalDuration = endDate.getTime() - startDate.getTime();
  const elapsed = now.getTime() - startDate.getTime();
  const expectedProgress = Math.min(1, Math.max(0, elapsed / totalDuration)) * 100;
  const progressRating = 1.5 * Math.min(1, project.progress / Math.max(1, expectedProgress));
  
  // Profitability rating (0-2 stars)
  const profitabilityRating = project.budget > 0 
    ? Math.min(2, Math.max(0, (profit / project.budget) * 2))
    : 0;
  
  // Calculate total rating (out of 5)
  return Math.min(5, Math.max(0, budgetRating + progressRating + profitabilityRating));
};

const ProjectDetailsView: React.FC<ProjectDetailsViewProps> = ({
  project,
  dailyReports,
  expenses,
  invoices,
  team,
  equipment,
  documents,
  risks,
  deadlines,
  users,
  onBack,
  onEdit
}) => {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('overview');
  const projectRating = calculateProjectRating(project, expenses, invoices);
  const statusDisplay = getStatusDisplay(project.status);

  // Calculate metrics
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalInvoices = invoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const profitability = totalInvoices - totalExpenses;
  
  // Get category display
  const getCategoryDisplay = (category: string): string => {
    const categories: Record<string, string> = {
      'electricity': 'كهرباء',
      'water': 'مياه',
      'communications': 'اتصالات',
      'roads': 'طرق',
      'buildings': 'مباني',
    };
    return categories[category] || category;
  };

  // Get user name
  const getUserName = (userId: number): string => {
    const user = users.find(u => u.id === userId);
    return user ? user.fullName : `مستخدم #${userId}`;
  };

  // Generate project PDF report (simplified implementation)
  const handleExportPDF = () => {
    alert('سيتم تصدير تقرير المشروع كملف PDF...');
    // Implement actual PDF export logic here
  };

  return (
    <div className="space-y-6">
      {/* Back button and header */}
      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          size="sm"
          className="gap-1"
          onClick={onBack}
        >
          <ChevronLeft className="h-4 w-4" />
          <span>العودة للمشاريع</span>
        </Button>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleExportPDF}
            className="gap-1"
          >
            <Download className="h-4 w-4" />
            <span>تصدير PDF</span>
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.print()}
            className="gap-1"
          >
            <Printer className="h-4 w-4" />
            <span>طباعة</span>
          </Button>
          
          <Button 
            size="sm" 
            onClick={() => onEdit(project)}
            className="gap-1"
          >
            <Edit3 className="h-4 w-4" />
            <span>تعديل المشروع</span>
          </Button>
        </div>
      </div>
      
      {/* Project header */}
      <Card className="border-none shadow-none bg-muted/40">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold">{project.name}</h1>
                <Badge className={statusDisplay.color}>{statusDisplay.label}</Badge>
              </div>
              
              <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{project.location}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>{formatDate(new Date(project.startDate))} - {formatDate(new Date(project.endDate))}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  <span>{project.duration} شهر</span>
                </div>
                <div className="flex items-center gap-1">
                  <Building className="h-4 w-4" />
                  <span>{getCategoryDisplay(project.category)}</span>
                </div>
              </div>
              
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {project.description}
              </p>
            </div>
            
            <div className="flex flex-col items-center gap-2">
              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-1">تقييم المشروع</div>
                <RatingStars rating={projectRating} />
              </div>
              
              <div className="flex flex-col items-center bg-card p-3 rounded-lg shadow-sm">
                <span className="text-sm text-muted-foreground">الميزانية</span>
                <span className="text-xl font-bold">{formatCurrency(project.budget)}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">نسبة الإنجاز</span>
              <span className="text-sm font-medium">{project.progress}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full">
              <div 
                className="bg-primary h-2 rounded-full" 
                style={{ width: `${project.progress}%` }}
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Tabs navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent">
          <div className="flex overflow-x-auto hide-scrollbar">
            <TabsTrigger 
              value="overview" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger 
              value="daily-reports" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              التقارير اليومية ({dailyReports.length})
            </TabsTrigger>
            <TabsTrigger 
              value="finances" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              المالية
            </TabsTrigger>
            <TabsTrigger 
              value="team" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              الفريق ({team.length})
            </TabsTrigger>
            <TabsTrigger 
              value="equipment" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              المعدات ({equipment.length})
            </TabsTrigger>
            <TabsTrigger 
              value="documents" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              المستندات ({documents.length})
            </TabsTrigger>
            <TabsTrigger 
              value="analysis" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              التحليل
            </TabsTrigger>
            <TabsTrigger 
              value="risks" 
              className="py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary"
            >
              المخاطر ({risks.length})
            </TabsTrigger>
          </div>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Key metrics */}
            <div className="col-span-2 space-y-6">
              <h2 className="text-xl font-bold mb-4">مؤشرات المشروع</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="py-3">
                    <CardTitle className="text-sm font-medium">المصروفات</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(totalExpenses)}</div>
                    <p className="text-xs text-muted-foreground">
                      {Math.round((totalExpenses / project.budget) * 100)}% من الميزانية
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-3">
                    <CardTitle className="text-sm font-medium">الفواتير</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(totalInvoices)}</div>
                    <p className="text-xs text-muted-foreground">
                      {invoices.length} فاتورة
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-3">
                    <CardTitle className="text-sm font-medium">الربحية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${profitability >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(profitability)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {Math.round((profitability / project.budget) * 100)}% من الميزانية
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-3">
                    <CardTitle className="text-sm font-medium">التقارير اليومية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{dailyReports.length}</div>
                    <p className="text-xs text-muted-foreground">
                      آخر تقرير: {dailyReports.length > 0 ? formatDate(new Date(dailyReports[0].reportDate)) : 'لا يوجد'}
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              {/* المواعيد النهائية - المكون المحسن */}
              <ProjectDeadlines project={project} showHeader={true} limitItems={3} />
              
              {/* Risk indicators */}
              {risks.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">مؤشرات المخاطر</h2>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="gap-1"
                      onClick={() => setActiveTab('risks')}
                    >
                      <ExternalLink className="h-4 w-4" />
                      <span>عرض الكل</span>
                    </Button>
                  </div>
                  
                  <div className="space-y-3">
                    {risks
                      .sort((a, b) => (b.probability * b.impact) - (a.probability * a.impact))
                      .slice(0, 3)
                      .map(risk => (
                        <Card key={risk.id} className="overflow-hidden">
                          <div className={`flex items-center p-3 border-r-4 ${
                            risk.status === 'active' ? 'border-yellow-500' : 
                            risk.status === 'mitigated' ? 'border-green-500' : 'border-red-500'
                          }`}>
                            <div className="flex-grow">
                              <h3 className="font-medium flex items-center">
                                <AlertTriangle className={`h-4 w-4 ml-1 ${
                                  risk.status === 'active' ? 'text-yellow-500' : 
                                  risk.status === 'mitigated' ? 'text-green-500' : 'text-red-500'
                                }`} />
                                {risk.title}
                              </h3>
                              <div className="flex items-center text-sm text-muted-foreground">
                                <span>الاحتمالية: {risk.probability}% • التأثير: {risk.impact}%</span>
                              </div>
                            </div>
                            <Badge variant="outline" className={
                              risk.status === 'active' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' : 
                              risk.status === 'mitigated' ? 'bg-green-100 text-green-800 border-green-200' : 
                              'bg-red-100 text-red-800 border-red-200'
                            }>
                              {risk.status === 'active' ? 'نشط' : 
                               risk.status === 'mitigated' ? 'تم معالجته' : 'حدث'}
                            </Badge>
                          </div>
                        </Card>
                      ))
                    }
                  </div>
                </div>
              )}
              
              {/* الأنشطة الأخيرة - المكون المحسن */}
              <ProjectActivities project={project} showHeader={true} limitItems={5} />
            </div>
            
            {/* Quick actions panel */}
            <div className="space-y-6">
              <h2 className="text-xl font-bold mb-4">إجراءات سريعة</h2>
              
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="outline" 
                  className="h-20 flex flex-col items-center justify-center"
                  onClick={() => setLocation(`/daily-reports?projectId=${project.id}`)}
                >
                  <ClipboardList className="h-6 w-6 mb-1" />
                  <span>تقرير يومي جديد</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="h-20 flex flex-col items-center justify-center"
                  onClick={() => setLocation(`/payment-requests?projectId=${project.id}`)}
                >
                  <Receipt className="h-6 w-6 mb-1" />
                  <span>إصدار مستخلص</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="h-20 flex flex-col items-center justify-center"
                  onClick={() => setLocation(`/finances?projectId=${project.id}&tab=expenses`)}
                >
                  <CreditCard className="h-6 w-6 mb-1" />
                  <span>تسجيل مصروف</span>
                </Button>
                
                <Button 
                  variant="outline" 
                  className="h-20 flex flex-col items-center justify-center"
                  onClick={() => setLocation(`/finances?projectId=${project.id}&tab=invoices`)}
                >
                  <FileText className="h-6 w-6 mb-1" />
                  <span>إصدار فاتورة</span>
                </Button>
              </div>
              
              {/* Project team summary */}
              <div>
                <h3 className="text-lg font-medium mb-3">فريق المشروع</h3>
                {team.length > 0 ? (
                  <div className="space-y-3">
                    {team.slice(0, 5).map(member => {
                      const userName = getUserName(member.userId);
                      return (
                        <div key={member.id} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary ml-2">
                              <UserIcon className="h-4 w-4" />
                            </div>
                            <div>
                              <div className="font-medium text-sm">{userName}</div>
                              <div className="text-xs text-muted-foreground">{member.role}</div>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {new Date(member.joinedAt).toLocaleDateString('ar-SA')}
                          </Badge>
                        </div>
                      );
                    })}
                    
                    {team.length > 5 && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full text-center"
                        onClick={() => setActiveTab('team')}
                      >
                        عرض الكل ({team.length})
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-3 text-muted-foreground">
                    لم يتم تعيين فريق بعد
                  </div>
                )}
              </div>
              
              {/* Recent documents */}
              <div>
                <h3 className="text-lg font-medium mb-3">آخر المستندات</h3>
                {documents.length > 0 ? (
                  <div className="space-y-2">
                    {documents.slice(0, 3).map(doc => (
                      <div key={doc.id} className="flex items-center p-2 rounded-md hover:bg-muted">
                        <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center text-primary ml-2">
                          <FileText className="h-4 w-4" />
                        </div>
                        <div className="flex-grow overflow-hidden">
                          <div className="font-medium text-sm truncate">{doc.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatDate(new Date(doc.uploadedAt))}
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    {documents.length > 3 && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full text-center"
                        onClick={() => setActiveTab('documents')}
                      >
                        عرض الكل ({documents.length})
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-3 text-muted-foreground">
                    لا توجد مستندات مرفقة
                  </div>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Daily Reports Tab */}
        <TabsContent value="daily-reports" className="pt-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">التقارير اليومية</h2>
            <Button
              onClick={() => setLocation(`/daily-reports?projectId=${project.id}`)}
              className="gap-1"
            >
              <ClipboardList className="h-4 w-4" />
              تقرير جديد
            </Button>
          </div>
          
          {dailyReports.length > 0 ? (
            <div className="space-y-4">
              {dailyReports
                .sort((a, b) => new Date(b.reportDate).getTime() - new Date(a.reportDate).getTime())
                .map(report => (
                  <Card key={report.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">
                            تقرير يوم {formatDate(new Date(report.reportDate))}
                          </CardTitle>
                          <CardDescription>
                            بواسطة: {getUserName(report.submittedBy)}
                          </CardDescription>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(report.submittedAt).toLocaleTimeString('ar-SA')}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-medium mb-1">الأعمال المنجزة:</h4>
                          <p className="text-sm">{report.workCompleted}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div>
                            <h4 className="text-sm font-medium mb-1">عدد العمال:</h4>
                            <p className="text-sm">{report.workersPresent} عامل</p>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium mb-1">ساعات العمل:</h4>
                            <p className="text-sm">{report.hoursWorked} ساعة</p>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium mb-1">حالة الطقس:</h4>
                            <p className="text-sm">{report.weatherConditions || 'غير محدد'}</p>
                          </div>
                          
                          <div>
                            <h4 className="text-sm font-medium mb-1">المعدات المستخدمة:</h4>
                            <p className="text-sm">
                              {Array.isArray(report.equipmentUsed) 
                                ? report.equipmentUsed.join(', ') 
                                : 'غير محدد'}
                            </p>
                          </div>
                        </div>
                        
                        {report.issues && (
                          <div>
                            <h4 className="text-sm font-medium mb-1">مشكلات ومعوقات:</h4>
                            <p className="text-sm">{report.issues}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                    <CardFooter className="justify-end pt-0">
                      <Button variant="ghost" size="sm">عرض التفاصيل</Button>
                    </CardFooter>
                  </Card>
                ))
              }
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <ClipboardList className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium">لا توجد تقارير يومية</h3>
              <p className="text-muted-foreground mt-1 mb-4">قم بإنشاء أول تقرير يومي لهذا المشروع</p>
              <Button
                onClick={() => setLocation(`/daily-reports?projectId=${project.id}`)}
              >
                إنشاء تقرير جديد
              </Button>
            </div>
          )}
        </TabsContent>
        
        {/* Finances Tab */}
        <TabsContent value="finances" className="pt-6">
          <div className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">الإدارة المالية</h2>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation(`/finances?projectId=${project.id}&tab=expenses`)}
                  className="gap-1"
                >
                  <CreditCard className="h-4 w-4" />
                  مصروف جديد
                </Button>
                <Button
                  size="sm"
                  onClick={() => setLocation(`/payment-requests?projectId=${project.id}`)}
                  className="gap-1"
                >
                  <Receipt className="h-4 w-4" />
                  إصدار مستخلص
                </Button>
              </div>
            </div>
            
            {/* Financial summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">الميزانية الإجمالية</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(project.budget)}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">إجمالي المصروفات</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(totalExpenses)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {expenses.length} عملية صرف
                  </p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">إجمالي الفواتير</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {formatCurrency(totalInvoices)}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {invoices.length} فاتورة
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {/* Expenses and Invoices */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Expenses table */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">آخر المصروفات</CardTitle>
                    <Button
                      variant="ghost" 
                      size="sm"
                      onClick={() => setLocation(`/finances?projectId=${project.id}&tab=expenses`)}
                    >
                      عرض الكل
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {expenses.length > 0 ? (
                    <div className="relative w-full overflow-auto">
                      <table className="w-full caption-bottom text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="h-10 px-2 text-right font-medium">التاريخ</th>
                            <th className="h-10 px-2 text-right font-medium">الوصف</th>
                            <th className="h-10 px-2 text-right font-medium">المبلغ</th>
                            <th className="h-10 px-2 text-right font-medium">الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                          {expenses
                            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                            .slice(0, 5)
                            .map(expense => (
                              <tr key={expense.id} className="border-b transition-colors hover:bg-muted/50">
                                <td className="p-2 align-middle">{formatDate(new Date(expense.date))}</td>
                                <td className="p-2 align-middle max-w-[180px] truncate">{expense.description}</td>
                                <td className="p-2 align-middle font-medium">{formatCurrency(expense.amount)}</td>
                                <td className="p-2 align-middle">
                                  <Badge variant="outline" className={
                                    expense.status === 'approved' ? 'bg-green-100 text-green-800 border-green-200' : 
                                    expense.status === 'rejected' ? 'bg-red-100 text-red-800 border-red-200' : 
                                    'bg-yellow-100 text-yellow-800 border-yellow-200'
                                  }>
                                    {expense.status === 'approved' ? 'معتمد' : 
                                     expense.status === 'rejected' ? 'مرفوض' : 'معلق'}
                                  </Badge>
                                </td>
                              </tr>
                            ))
                          }
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground">
                      لا توجد مصروفات مسجلة
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Invoices table */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">الفواتير</CardTitle>
                    <Button
                      variant="ghost" 
                      size="sm"
                      onClick={() => setLocation(`/finances?projectId=${project.id}&tab=invoices`)}
                    >
                      عرض الكل
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {invoices.length > 0 ? (
                    <div className="relative w-full overflow-auto">
                      <table className="w-full caption-bottom text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="h-10 px-2 text-right font-medium">التاريخ</th>
                            <th className="h-10 px-2 text-right font-medium">الرقم</th>
                            <th className="h-10 px-2 text-right font-medium">العميل</th>
                            <th className="h-10 px-2 text-right font-medium">المبلغ</th>
                            <th className="h-10 px-2 text-right font-medium">الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoices
                            .sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime())
                            .slice(0, 5)
                            .map(invoice => (
                              <tr key={invoice.id} className="border-b transition-colors hover:bg-muted/50">
                                <td className="p-2 align-middle">{formatDate(new Date(invoice.issueDate))}</td>
                                <td className="p-2 align-middle">{invoice.invoiceNumber}</td>
                                <td className="p-2 align-middle max-w-[120px] truncate">{invoice.clientName}</td>
                                <td className="p-2 align-middle font-medium">{formatCurrency(invoice.amount)}</td>
                                <td className="p-2 align-middle">
                                  <Badge variant="outline" className={
                                    invoice.status === 'paid' ? 'bg-green-100 text-green-800 border-green-200' : 
                                    invoice.status === 'overdue' ? 'bg-red-100 text-red-800 border-red-200' : 
                                    'bg-yellow-100 text-yellow-800 border-yellow-200'
                                  }>
                                    {invoice.status === 'paid' ? 'مدفوع' : 
                                     invoice.status === 'overdue' ? 'متأخر' : 'معلق'}
                                  </Badge>
                                </td>
                              </tr>
                            ))
                          }
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-muted-foreground">
                      لا توجد فواتير مسجلة
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            {/* Payment requests (link to full section) */}
            <div className="flex justify-center">
              <Button
                variant="outline"
                size="lg"
                onClick={() => setLocation(`/payment-requests?projectId=${project.id}`)}
                className="gap-2"
              >
                <Receipt className="h-5 w-5" />
                <span>إدارة المستخلصات المالية</span>
              </Button>
            </div>
          </div>
        </TabsContent>
        
        {/* Team Tab */}
        <TabsContent value="team" className="pt-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">فريق المشروع</h2>
            <Button
              onClick={() => setLocation(`/teams?projectId=${project.id}`)}
              className="gap-1"
            >
              <Users className="h-4 w-4" />
              إضافة عضو
            </Button>
          </div>
          
          {team.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {team.map(member => (
                <Card key={member.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-4 space-x-reverse">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <UserIcon className="h-5 w-5" />
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-medium">{getUserName(member.userId)}</h3>
                        <Badge className="mt-1">{member.role}</Badge>
                        <p className="text-xs text-muted-foreground mt-2">
                          تاريخ الانضمام: {formatDate(new Date(member.joinedAt))}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <Users className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium">لا يوجد أعضاء في الفريق</h3>
              <p className="text-muted-foreground mt-1 mb-4">قم بإضافة أعضاء إلى فريق المشروع</p>
              <Button
                onClick={() => setLocation(`/teams?projectId=${project.id}`)}
              >
                إضافة عضو
              </Button>
            </div>
          )}
        </TabsContent>
        
        {/* Equipment Tab */}
        <TabsContent value="equipment" className="pt-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">المعدات</h2>
            <Button
              onClick={() => setLocation(`/equipment?projectId=${project.id}`)}
              className="gap-1"
            >
              <Truck className="h-4 w-4" />
              إضافة معدة
            </Button>
          </div>
          
          {equipment.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {equipment.map(item => (
                <Card key={item.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-4 space-x-reverse">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                        <Truck className="h-5 w-5" />
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-medium">{item.name}</h3>
                        <p className="text-sm text-muted-foreground">النوع: {item.type}</p>
                        <Badge 
                          className={
                            item.status === 'available' ? 'bg-green-100 text-green-800 mt-2' :
                            item.status === 'in-use' ? 'bg-blue-100 text-blue-800 mt-2' :
                            'bg-yellow-100 text-yellow-800 mt-2'
                          }
                        >
                          {item.status === 'available' ? 'متاح' : 
                           item.status === 'in-use' ? 'قيد الاستخدام' : 
                           'في الصيانة'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <Truck className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium">لا توجد معدات مسجلة</h3>
              <p className="text-muted-foreground mt-1 mb-4">قم بإضافة معدات للمشروع</p>
              <Button
                onClick={() => setLocation(`/equipment?projectId=${project.id}`)}
              >
                إضافة معدة
              </Button>
            </div>
          )}
        </TabsContent>
        
        {/* Documents Tab */}
        <TabsContent value="documents" className="pt-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">المستندات</h2>
            <Button
              onClick={() => setLocation(`/documents?projectId=${project.id}`)}
              className="gap-1"
            >
              <Folder className="h-4 w-4" />
              رفع مستند
            </Button>
          </div>
          
          {documents.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {documents.map(document => (
                <Card key={document.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="p-4">
                      <div className="flex items-center space-x-4 space-x-reverse mb-2">
                        <div className={`h-10 w-10 rounded bg-primary/10 flex items-center justify-center text-primary ${
                          document.fileType === 'pdf' ? 'bg-red-100 text-red-600' :
                          document.fileType === 'doc' || document.fileType === 'docx' ? 'bg-blue-100 text-blue-600' :
                          document.fileType === 'xls' || document.fileType === 'xlsx' ? 'bg-green-100 text-green-600' :
                          document.fileType === 'jpg' || document.fileType === 'png' ? 'bg-purple-100 text-purple-600' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          <FileText className="h-5 w-5" />
                        </div>
                        <div className="flex-grow overflow-hidden">
                          <h3 className="font-medium truncate">{document.name}</h3>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Badge variant="outline" className="ml-2">
                              {document.fileType.toUpperCase()}
                            </Badge>
                            <span>{formatDate(new Date(document.uploadedAt))}</span>
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        التصنيف: {document.category}
                      </p>
                    </div>
                    <div className="bg-muted p-2 flex items-center justify-end space-x-2 space-x-reverse">
                      <Button variant="ghost" size="sm" className="h-8">
                        <Download className="h-4 w-4 ml-1" />
                        <span>تحميل</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <Folder className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium">لا توجد مستندات</h3>
              <p className="text-muted-foreground mt-1 mb-4">قم برفع المستندات الخاصة بالمشروع</p>
              <Button
                onClick={() => setLocation(`/documents?projectId=${project.id}`)}
              >
                رفع مستند
              </Button>
            </div>
          )}
        </TabsContent>
        
        {/* Analysis Tab */}
        <TabsContent value="analysis" className="pt-6">
          <h2 className="text-xl font-bold mb-6">تحليل المشروع</h2>
          <ProjectAnalytics 
            project={project}
            expenses={expenses}
            invoices={invoices}
          />
        </TabsContent>
        
        {/* Risks Tab */}
        <TabsContent value="risks" className="pt-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold">تحليل المخاطر</h2>
            <Button
              onClick={() => setLocation(`/risk-prediction?projectId=${project.id}`)}
              className="gap-1"
            >
              <AlertTriangle className="h-4 w-4" />
              إضافة مخاطرة
            </Button>
          </div>
          
          {risks.length > 0 ? (
            <div className="space-y-4">
              {risks.map(risk => (
                <Card key={risk.id}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center">
                        <AlertTriangle className={`h-5 w-5 ml-2 ${
                          risk.status === 'active' ? 'text-yellow-500' : 
                          risk.status === 'mitigated' ? 'text-green-500' : 'text-red-500'
                        }`} />
                        <CardTitle className="text-lg">{risk.title}</CardTitle>
                      </div>
                      <Badge
                        className={
                          risk.status === 'active' ? 'bg-yellow-100 text-yellow-800' : 
                          risk.status === 'mitigated' ? 'bg-green-100 text-green-800' : 
                          'bg-red-100 text-red-800'
                        }
                      >
                        {risk.status === 'active' ? 'نشط' : 
                         risk.status === 'mitigated' ? 'تم معالجته' : 'حدث'}
                      </Badge>
                    </div>
                    <CardDescription>{risk.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <div className="text-sm font-medium mb-1">درجة الاحتمالية:</div>
                        <div className="flex items-center">
                          <div className="w-full bg-gray-200 h-2 rounded-full ml-2">
                            <div 
                              className="bg-blue-500 h-2 rounded-full" 
                              style={{ width: `${risk.probability}%` }}
                            />
                          </div>
                          <div className="min-w-[40px] text-sm font-medium">{risk.probability}%</div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-sm font-medium mb-1">درجة التأثير:</div>
                        <div className="flex items-center">
                          <div className="w-full bg-gray-200 h-2 rounded-full ml-2">
                            <div 
                              className="bg-red-500 h-2 rounded-full" 
                              style={{ width: `${risk.impact}%` }}
                            />
                          </div>
                          <div className="min-w-[40px] text-sm font-medium">{risk.impact}%</div>
                        </div>
                      </div>
                    </div>
                    
                    {risk.mitigation && (
                      <div className="mt-4" key={`risk-mitigation-${risk.id}`}>
                        <div className="text-sm font-medium mb-1">استراتيجية تخفيف المخاطر:</div>
                        <p className="text-sm">{risk.mitigation}</p>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="text-sm text-muted-foreground">
                      تاريخ الإنشاء: {formatDate(new Date(risk.createdAt))}
                    </div>
                    <Button variant="outline" size="sm">تحديث الحالة</Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 border rounded-lg">
              <AlertTriangle className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium">لا توجد مخاطر مسجلة</h3>
              <p className="text-muted-foreground mt-1 mb-4">قم بإضافة تقييم للمخاطر المحتملة للمشروع</p>
              <Button
                onClick={() => setLocation(`/risk-prediction?projectId=${project.id}`)}
              >
                إضافة تقييم مخاطر
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProjectDetailsView;