import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  CalendarDays, 
  Clock, 
  BarChart4, 
  User, 
  Users, 
  TrendingUp,
  Building2,
  CalendarClock,
  CreditCard,
  AlertCircle,
  Timer,
  Target,
  FileText,
  CheckCircle2
} from "lucide-react";
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

// Import types
import type { Project } from '@shared/schema';

// Helper function to get status badge
const getStatusBadge = (status: string) => {
  switch (status) {
    case 'planned':
      return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">مخطط</Badge>;
    case 'inProgress':
      return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">قيد التنفيذ</Badge>;
    case 'delayed':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">متأخر</Badge>;
    case 'completed':
      return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">مكتمل</Badge>;
    default:
      return null;
  }
};

// Helper function to get category badge
const getCategoryBadge = (category: string) => {
  switch (category) {
    case 'electricity':
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-800 border-yellow-200">كهرباء</Badge>;
    case 'water':
      return <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">مياه</Badge>;
    case 'communications':
      return <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">اتصالات</Badge>;
    case 'roads':
      return <Badge variant="outline" className="bg-orange-50 text-orange-800 border-orange-200">طرق</Badge>;
    case 'buildings':
      return <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">مباني</Badge>;
    default:
      return null;
  }
};

interface ProjectSummaryProps {
  project: Project;
}

// Mock milestone data
const milestones = [
  {
    id: 1,
    name: 'بداية المشروع',
    dueDate: new Date(2025, 0, 15),
    completedDate: new Date(2025, 0, 15),
    status: 'completed'
  },
  {
    id: 2,
    name: 'اكتمال التصاميم',
    dueDate: new Date(2025, 1, 1),
    completedDate: new Date(2025, 1, 5),
    status: 'completed'
  },
  {
    id: 3,
    name: 'اكتمال 50% من العمل',
    dueDate: new Date(2025, 3, 15),
    completedDate: null,
    status: 'inProgress'
  },
  {
    id: 4,
    name: 'تسليم المشروع',
    dueDate: new Date(2025, 6, 30),
    completedDate: null,
    status: 'planned'
  }
];

// Mock team members
const teamMembers = [
  { id: 1, name: 'أحمد محمد', role: 'مدير المشروع', avatar: null },
  { id: 2, name: 'فاطمة علي', role: 'مهندس كهرباء', avatar: null },
  { id: 3, name: 'خالد عبدالله', role: 'مشرف موقع', avatar: null }
];

// Mock risk data
const risks = [
  { id: 1, name: 'تأخر توريد المواد', level: 'high', status: 'active' },
  { id: 2, name: 'نقص العمالة', level: 'medium', status: 'mitigated' },
  { id: 3, name: 'ظروف جوية سيئة', level: 'low', status: 'active' }
];

const ProjectSummary: React.FC<ProjectSummaryProps> = ({ project }) => {
  // Format date
  const formatDate = (date: Date) => {
    return format(date, 'yyyy/MM/dd', { locale: ar });
  };
  
  // Calculate days remaining
  const daysRemaining = () => {
    const today = new Date();
    const endDate = new Date(project.endDate);
    const diffTime = endDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-SA', {
      style: 'currency',
      currency: 'SAR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };
  
  return (
    <div className="space-y-6">
      {/* Project Overview */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-xl">نظرة عامة على المشروع</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-medium">الوصف</h3>
                <p className="text-muted-foreground mt-1">
                  {project.description || 'لا يوجد وصف للمشروع'}
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">اسم العميل</h3>
                  <p>{project.clientName || 'غير محدد'}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">رقم العقد</h3>
                  <p>{project.contractNumber || 'غير محدد'}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">الموقع</h3>
                  <p>{project.location || 'غير محدد'}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">النوع</h3>
                  <p>{getCategoryBadge(project.category!)}</p>
                </div>
              </div>
              
              {project.notes && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">ملاحظات</h3>
                  <p>{project.notes}</p>
                </div>
              )}
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">الحالة</p>
                      <div className="mt-1">{getStatusBadge(project.status!)}</div>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">نسبة الإنجاز</p>
                      <p className="text-2xl font-semibold">{project.progress || 0}%</p>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <Target className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <Progress value={project.progress || 0} className="h-2 mt-2" />
                </CardContent>
              </Card>
              
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">تاريخ البداية</p>
                      <p>{formatDate(new Date(project.startDate))}</p>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <CalendarDays className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">تاريخ النهاية</p>
                      <p>{formatDate(new Date(project.endDate))}</p>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <CalendarClock className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">المدة (يوم)</p>
                      <p className="text-2xl font-semibold">{project.duration || 0}</p>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-primary-50">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">الأيام المتبقية</p>
                      <p className="text-2xl font-semibold">{daysRemaining()}</p>
                    </div>
                    <div className="bg-primary-100 p-2 rounded-full">
                      <Timer className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {project.budget && (
                <Card className="bg-primary-50 col-span-2">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">الميزانية</p>
                        <p className="text-2xl font-semibold">{formatCurrency(project.budget)}</p>
                      </div>
                      <div className="bg-primary-100 p-2 rounded-full">
                        <CreditCard className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Team Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">فريق العمل</CardTitle>
              <Users className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div key={member.id} className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-muted-foreground/10 flex items-center justify-center">
                    <User className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">{member.name}</p>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        {/* Risks Overview */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">المخاطر</CardTitle>
              <AlertCircle className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {risks.map((risk) => (
                <div key={risk.id} className="flex items-center gap-3">
                  <div className={`h-2 w-2 rounded-full ${
                    risk.level === 'high' ? 'bg-red-500' :
                    risk.level === 'medium' ? 'bg-amber-500' : 'bg-green-500'
                  }`} />
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <p className="font-medium">{risk.name}</p>
                      <Badge
                        variant="outline"
                        className={
                          risk.status === 'mitigated'
                            ? 'bg-green-50 text-green-800 border-green-200'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }
                      >
                        {risk.status === 'mitigated' ? 'تم معالجته' : 'نشط'}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {risk.level === 'high' ? 'خطورة عالية' :
                       risk.level === 'medium' ? 'خطورة متوسطة' : 'خطورة منخفضة'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Documents & Milestone Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Documents */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">المستندات الأخيرة</CardTitle>
              <FileText className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 rounded-md border">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-blue-500" />
                  <p>تقرير تقدم المشروع.pdf</p>
                </div>
                <span className="text-xs text-muted-foreground">28 مارس</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md border">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-green-500" />
                  <p>جدول المهام.xlsx</p>
                </div>
                <span className="text-xs text-muted-foreground">25 مارس</span>
              </div>
              <div className="flex justify-between items-center p-3 rounded-md border">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-red-500" />
                  <p>تحليل المخاطر.pdf</p>
                </div>
                <span className="text-xs text-muted-foreground">20 مارس</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Milestones */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg">المراحل الرئيسية</CardTitle>
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {milestones.map((milestone) => (
                <div key={milestone.id} className="flex items-start gap-3">
                  <div className="mt-0.5">
                    <div className={`h-4 w-4 rounded-full flex items-center justify-center ${
                      milestone.status === 'completed' ? 'bg-green-500' :
                      milestone.status === 'inProgress' ? 'bg-amber-500' : 'bg-gray-200'
                    }`}>
                      {milestone.status === 'completed' && (
                        <CheckCircle2 className="h-4 w-4 text-white" />
                      )}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <p className="font-medium">{milestone.name}</p>
                      <Badge
                        variant="outline"
                        className={
                          milestone.status === 'completed'
                            ? 'bg-green-50 text-green-800 border-green-200'
                            : milestone.status === 'inProgress'
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : 'bg-gray-50 text-gray-800 border-gray-200'
                        }
                      >
                        {milestone.status === 'completed' ? 'مكتمل' : 
                         milestone.status === 'inProgress' ? 'قيد التنفيذ' : 'مخطط'}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <CalendarDays className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground">
                        تاريخ الاستحقاق: {formatDate(milestone.dueDate)}
                      </span>
                    </div>
                    {milestone.completedDate && (
                      <div className="flex items-center gap-2 mt-1">
                        <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
                        <span className="text-xs text-muted-foreground">
                          تاريخ الإكمال: {formatDate(milestone.completedDate)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProjectSummary;