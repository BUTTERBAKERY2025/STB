import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  UserPlus, 
  Mail, 
  MoreVertical, 
  Search, 
  AtSign, 
  Phone,
  UserCog,
  User,
  Clock,
  Users
} from "lucide-react";

// Import types
import { Project } from "@shared/schema";

// Mock user data
const mockTeamMembers = [
  {
    id: 1,
    user: {
      id: 1,
      username: 'admin',
      fullName: 'مدير النظام',
      email: 'admin@example.com',
      role: 'مدير',
      avatar: null
    },
    role: 'مدير المشروع',
    joinedAt: new Date(2025, 0, 15),
    status: 'active'
  },
  {
    id: 2,
    user: {
      id: 2,
      username: 'ahmed',
      fullName: 'أحمد محمد',
      email: 'ahmed@example.com',
      role: 'مهندس',
      avatar: null
    },
    role: 'مهندس مدني',
    joinedAt: new Date(2025, 0, 20),
    status: 'active'
  },
  {
    id: 3,
    user: {
      id: 3,
      username: 'fatima',
      fullName: 'فاطمة علي',
      email: 'fatima@example.com',
      role: 'مهندس',
      avatar: null
    },
    role: 'مهندس كهرباء',
    joinedAt: new Date(2025, 1, 5),
    status: 'active'
  },
  {
    id: 4,
    user: {
      id: 4,
      username: 'khalid',
      fullName: 'خالد عبدالله',
      email: 'khalid@example.com',
      role: 'مشرف',
      avatar: null
    },
    role: 'مشرف موقع',
    joinedAt: new Date(2025, 1, 15),
    status: 'active'
  },
  {
    id: 5,
    user: {
      id: 5,
      username: 'omar',
      fullName: 'عمر فهد',
      email: 'omar@example.com',
      role: 'محاسب',
      avatar: null
    },
    role: 'مدير مالي',
    joinedAt: new Date(2025, 2, 1),
    status: 'active'
  }
];

interface ProjectTeamTabProps {
  project: Project;
}

const ProjectTeamTab: React.FC<ProjectTeamTabProps> = ({ project }) => {
  const { toast } = useToast();
  const [teamMembers, setTeamMembers] = useState(mockTeamMembers);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('team');
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<any>(null);
  
  // Filter team members based on search term
  const filteredMembers = teamMembers.filter(member => {
    const fullName = member.user.fullName?.toLowerCase() || '';
    const role = member.role.toLowerCase();
    const username = member.user.username.toLowerCase();
    const email = member.user.email?.toLowerCase() || '';
    
    return (
      fullName.includes(searchTerm.toLowerCase()) ||
      role.includes(searchTerm.toLowerCase()) ||
      username.includes(searchTerm.toLowerCase()) ||
      email.includes(searchTerm.toLowerCase())
    );
  });
  
  // Get avatar for a user
  const getUserAvatar = (user: any) => {
    if (user.avatar) {
      return <AvatarImage src={user.avatar} alt={user.fullName || user.username} />;
    }
    
    const initials = user.fullName 
      ? user.fullName.split(' ').map((n: string) => n[0]).join('').substring(0, 2) 
      : user.username.substring(0, 2);
      
    return <AvatarFallback>{initials}</AvatarFallback>;
  };
  
  // Get status badge color
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">نشط</Badge>;
      case 'pending':
        return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">قيد الانتظار</Badge>;
      case 'inactive':
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">غير نشط</Badge>;
      default:
        return null;
    }
  };
  
  // Format date
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };
  
  // Add team member
  const handleAddMember = () => {
    // In a real application, this would send a request to the server
    toast({
      title: "تمت إضافة عضو جديد",
      description: "تمت إضافة العضو الجديد بنجاح إلى فريق المشروع",
    });
    
    setIsAddMemberOpen(false);
  };
  
  // Remove team member
  const handleRemoveMember = (memberId: number) => {
    setTeamMembers(prev => prev.filter(member => member.id !== memberId));
    
    toast({
      title: "تمت إزالة العضو",
      description: "تمت إزالة العضو من فريق المشروع بنجاح",
    });
  };
  
  // View member details
  const handleViewMember = (member: any) => {
    setSelectedMember(member);
  };
  
  return (
    <div className="space-y-6">
      <Tabs
        defaultValue="team"
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2 md:w-fit">
          <TabsTrigger value="team" className="flex gap-1">
            <Users className="h-4 w-4 hidden sm:block" />
            <span>أعضاء الفريق</span>
          </TabsTrigger>
          <TabsTrigger value="roles" className="flex gap-1">
            <UserCog className="h-4 w-4 hidden sm:block" />
            <span>الأدوار والصلاحيات</span>
          </TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="team" className="m-0">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-6">
                  <div className="relative w-full sm:w-96">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      placeholder="البحث عن أعضاء الفريق..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 pr-4"
                    />
                  </div>
                  
                  <div className="w-full sm:w-auto">
                    <Button
                      className="gap-2 w-full sm:w-auto"
                      onClick={() => setIsAddMemberOpen(true)}
                    >
                      <UserPlus className="h-4 w-4" />
                      <span>إضافة عضو</span>
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredMembers.length > 0 ? (
                    filteredMembers.map((member) => (
                      <Card key={member.id} className="overflow-hidden border">
                        <CardContent className="p-0">
                          <div className="p-4">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-3">
                                <Avatar className="h-10 w-10">
                                  {getUserAvatar(member.user)}
                                </Avatar>
                                <div>
                                  <h3 className="font-semibold">{member.user.fullName || member.user.username}</h3>
                                  <p className="text-sm text-muted-foreground">{member.role}</p>
                                </div>
                              </div>
                              
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-8 w-8">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleViewMember(member)}>
                                    عرض التفاصيل
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    تعديل الدور
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    className="text-red-600"
                                    onClick={() => handleRemoveMember(member.id)}
                                  >
                                    إزالة من الفريق
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            
                            <div className="mt-3 grid grid-cols-1 gap-2">
                              <div className="flex items-center gap-2 text-sm">
                                <AtSign className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">{member.user.email || 'لا يوجد بريد إلكتروني'}</span>
                              </div>
                              <div className="flex items-center gap-2 text-sm">
                                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                                <span className="text-muted-foreground">
                                  تاريخ الانضمام: {formatDate(member.joinedAt)}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-sm pt-1">
                                {getStatusBadge(member.status)}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  ) : (
                    <div className="col-span-full flex flex-col items-center justify-center p-8 bg-muted/30 rounded-lg">
                      <Users className="h-10 w-10 text-muted mb-2" />
                      <h3 className="text-lg font-semibold">لا يوجد أعضاء</h3>
                      <p className="text-muted-foreground text-center max-w-md mt-1 mb-4">
                        {searchTerm 
                          ? 'لا توجد نتائج مطابقة للبحث. جرّب كلمات بحث أخرى.'
                          : 'لم يتم إضافة أعضاء للفريق بعد. أضف أعضاء جدد للبدء.'}
                      </p>
                      
                      <Button onClick={() => setIsAddMemberOpen(true)}>
                        إضافة عضو
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="roles" className="m-0">
            <Card>
              <CardContent className="p-6">
                <div className="space-y-2">
                  <h2 className="text-lg font-semibold mb-4">الأدوار والصلاحيات</h2>
                  
                  <div className="grid gap-6">
                    <div className="rounded-md border p-4">
                      <h3 className="font-medium">مدير المشروع</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        يمتلك صلاحيات كاملة على المشروع بما في ذلك إدارة الفريق والميزانية والجدول الزمني.
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          إدارة الفريق
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          إدارة الميزانية
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          تعديل المشروع
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="rounded-md border p-4">
                      <h3 className="font-medium">مهندس</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        يمتلك صلاحيات للوصول للمستندات الفنية والخرائط والتقارير.
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          المستندات الفنية
                        </Badge>
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          الخرائط
                        </Badge>
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          التقارير
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="rounded-md border p-4">
                      <h3 className="font-medium">مشرف موقع</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        مسؤول عن متابعة العمل في الموقع وإنشاء وتحديث التقارير اليومية.
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">
                          التقارير اليومية
                        </Badge>
                        <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">
                          تتبع الموقع
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="rounded-md border p-4">
                      <h3 className="font-medium">مدير مالي</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        مسؤول عن إدارة الجوانب المالية للمشروع بما في ذلك المستخلصات والفواتير.
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          المستخلصات
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          الفواتير
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          التقارير المالية
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
      
      {/* Add Member Dialog */}
      <Dialog open={isAddMemberOpen} onOpenChange={setIsAddMemberOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة عضو جديد</DialogTitle>
            <DialogDescription>
              أضف عضو جديد إلى فريق المشروع وحدد دوره وصلاحياته
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="grid gap-2">
              <label htmlFor="user" className="text-sm font-medium">
                المستخدم
              </label>
              <select
                id="user"
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                <option value="" disabled selected>اختر مستخدم...</option>
                <option value="6">محمد أحمد</option>
                <option value="7">سارة خالد</option>
                <option value="8">علي محمود</option>
              </select>
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="role" className="text-sm font-medium">
                الدور
              </label>
              <select
                id="role"
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              >
                <option value="" disabled selected>اختر دورا...</option>
                <option value="project_manager">مدير المشروع</option>
                <option value="engineer">مهندس</option>
                <option value="site_supervisor">مشرف موقع</option>
                <option value="financial_manager">مدير مالي</option>
              </select>
            </div>
            
            <div className="grid gap-2">
              <label className="text-sm font-medium">
                الأقسام
              </label>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                  المستندات
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                  التقارير
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                  المالية
                </Badge>
                <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
                  الموقع الجغرافي
                </Badge>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsAddMemberOpen(false)}
            >
              إلغاء
            </Button>
            <Button onClick={handleAddMember}>
              إضافة
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Member Details Dialog */}
      {selectedMember && (
        <Dialog open={!!selectedMember} onOpenChange={() => setSelectedMember(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                تفاصيل عضو الفريق
              </DialogTitle>
            </DialogHeader>
            
            <div className="py-4">
              <div className="flex items-center gap-4 mb-6">
                <Avatar className="h-16 w-16">
                  {getUserAvatar(selectedMember.user)}
                </Avatar>
                <div>
                  <h2 className="text-xl font-semibold">{selectedMember.user.fullName || selectedMember.user.username}</h2>
                  <p className="text-muted-foreground">{selectedMember.role}</p>
                  {getStatusBadge(selectedMember.status)}
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">اسم المستخدم</h3>
                    <p>{selectedMember.user.username}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">البريد الإلكتروني</h3>
                    <p>{selectedMember.user.email || 'غير محدد'}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">تاريخ الانضمام</h3>
                    <p>{formatDate(selectedMember.joinedAt)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">الحالة</h3>
                    <p>{selectedMember.status === 'active' ? 'نشط' : 'غير نشط'}</p>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">الصلاحيات</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedMember.role === 'مدير المشروع' && (
                      <>
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          إدارة الفريق
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          إدارة الميزانية
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-800 border-blue-200">
                          تعديل المشروع
                        </Badge>
                      </>
                    )}
                    {selectedMember.role === 'مهندس مدني' && (
                      <>
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          المستندات الفنية
                        </Badge>
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          الخرائط
                        </Badge>
                        <Badge variant="outline" className="bg-green-50 text-green-800 border-green-200">
                          التقارير
                        </Badge>
                      </>
                    )}
                    {selectedMember.role === 'مشرف موقع' && (
                      <>
                        <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">
                          التقارير اليومية
                        </Badge>
                        <Badge variant="outline" className="bg-amber-50 text-amber-800 border-amber-200">
                          تتبع الموقع
                        </Badge>
                      </>
                    )}
                    {selectedMember.role === 'مدير مالي' && (
                      <>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          المستخلصات
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          الفواتير
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-800 border-purple-200">
                          التقارير المالية
                        </Badge>
                      </>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">الإجراءات</h3>
                  <div className="flex gap-2">
                    <Button variant="outline" className="gap-1">
                      <Mail className="h-4 w-4" />
                      <span>إرسال بريد</span>
                    </Button>
                    <Button variant="outline" className="gap-1">
                      <Phone className="h-4 w-4" />
                      <span>اتصال</span>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default ProjectTeamTab;