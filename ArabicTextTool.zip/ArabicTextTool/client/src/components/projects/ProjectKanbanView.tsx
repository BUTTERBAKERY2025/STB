import React from 'react';
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Button 
} from '@/components/ui/button';
import {
  Plus,
  CheckCircle,
  Clock,
  AlertTriangle,
  Calendar,
  ArrowRight,
  EyeIcon,
  Edit
} from 'lucide-react';

import ProjectCard from './ProjectCard';
import type { Project } from '@shared/schema';

interface ProjectKanbanViewProps {
  projects: Project[];
  onEditProject: (project: Project) => void;
  onViewProject: (projectId: number) => void;
}

const ProjectKanbanView: React.FC<ProjectKanbanViewProps> = ({
  projects,
  onEditProject,
  onViewProject
}) => {
  // Group projects by status
  const plannedProjects = projects.filter(p => p.status === 'planned');
  const inProgressProjects = projects.filter(p => p.status === 'inProgress');
  const delayedProjects = projects.filter(p => p.status === 'delayed');
  const completedProjects = projects.filter(p => p.status === 'completed');

  // Helper to render project cards in a column
  const renderProjectCards = (projectsList: Project[]) => {
    if (projectsList.length === 0) {
      return (
        <div className="flex items-center justify-center h-20 bg-muted/30 rounded-md">
          <p className="text-sm text-muted-foreground">لا توجد مشاريع</p>
        </div>
      );
    }

    return projectsList.map(project => (
      <div key={project.id} className="mb-3">
        <ProjectCard
          project={project}
          onEdit={onEditProject}
          onDelete={() => {}}
          onViewDetails={onViewProject}
          isCompact
        />
      </div>
    ));
  };

  return (
    <div className="overflow-x-auto pb-4">
      <div className="min-w-[1000px] grid grid-cols-4 gap-4">
        {/* Planned Column */}
        <div className="flex flex-col">
          <div className="flex items-center mb-2">
            <div className="h-6 w-6 rounded-full bg-amber-100 flex items-center justify-center ml-2">
              <Calendar className="h-3.5 w-3.5 text-amber-600" />
            </div>
            <h3 className="font-medium">مخطط</h3>
            <div className="flex items-center justify-center bg-muted text-muted-foreground rounded-full text-xs w-6 h-6 mr-2">
              {plannedProjects.length}
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-220px)] p-1 space-y-3">
            {renderProjectCards(plannedProjects)}
          </div>
        </div>

        {/* In Progress Column */}
        <div className="flex flex-col">
          <div className="flex items-center mb-2">
            <div className="h-6 w-6 rounded-full bg-blue-100 flex items-center justify-center ml-2">
              <Clock className="h-3.5 w-3.5 text-blue-600" />
            </div>
            <h3 className="font-medium">قيد التنفيذ</h3>
            <div className="flex items-center justify-center bg-muted text-muted-foreground rounded-full text-xs w-6 h-6 mr-2">
              {inProgressProjects.length}
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-220px)] p-1 space-y-3">
            {renderProjectCards(inProgressProjects)}
          </div>
        </div>

        {/* Delayed Column */}
        <div className="flex flex-col">
          <div className="flex items-center mb-2">
            <div className="h-6 w-6 rounded-full bg-red-100 flex items-center justify-center ml-2">
              <AlertTriangle className="h-3.5 w-3.5 text-red-600" />
            </div>
            <h3 className="font-medium">متأخر</h3>
            <div className="flex items-center justify-center bg-muted text-muted-foreground rounded-full text-xs w-6 h-6 mr-2">
              {delayedProjects.length}
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-220px)] p-1 space-y-3">
            {renderProjectCards(delayedProjects)}
          </div>
        </div>

        {/* Completed Column */}
        <div className="flex flex-col">
          <div className="flex items-center mb-2">
            <div className="h-6 w-6 rounded-full bg-green-100 flex items-center justify-center ml-2">
              <CheckCircle className="h-3.5 w-3.5 text-green-600" />
            </div>
            <h3 className="font-medium">مكتمل</h3>
            <div className="flex items-center justify-center bg-muted text-muted-foreground rounded-full text-xs w-6 h-6 mr-2">
              {completedProjects.length}
            </div>
          </div>
          
          <div className="overflow-y-auto max-h-[calc(100vh-220px)] p-1 space-y-3">
            {renderProjectCards(completedProjects)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectKanbanView;