import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { InsertWorkerAttendance, Worker, insertWorkerAttendanceSchema } from "@shared/schema.new";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { CalendarIcon } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { arSA } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";

// قائمة حالات الحضور
const attendanceStatuses = [
  { value: "present", label: "حاضر" },
  { value: "absent", label: "غائب" },
  { value: "leave", label: "مجاز" },
  { value: "late", label: "متأخر" },
];

interface AttendanceFormProps {
  worker: Worker;
  onSuccess: () => void;
}

export function AttendanceForm({ worker, onSuccess }: AttendanceFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // استعلام قائمة المشاريع
  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // استعلام المستخدم الحالي
  const { data: currentUser } = useQuery({
    queryKey: ["/api/user"],
  });

  // تعديل مخطط التحقق من البيانات
  const formSchema = insertWorkerAttendanceSchema.extend({
    date: z.coerce.date(),
    hoursWorked: z.coerce.number().min(0, "يجب أن تكون ساعات العمل قيمة موجبة").optional(),
  });

  // تهيئة نموذج إدخال البيانات
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      workerId: worker.id,
      projectId: worker.currentProjectId || undefined,
      date: new Date(),
      status: "present",
      hoursWorked: 8,
      notes: "",
      recordedBy: currentUser?.id,
    },
  });

  // إضافة سجل حضور جديد
  const createAttendanceMutation = useMutation({
    mutationFn: async (newAttendance: InsertWorkerAttendance) => {
      const res = await apiRequest("POST", "/api/worker-attendance", newAttendance);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التسجيل بنجاح",
        description: "تم تسجيل الحضور بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/worker-attendance"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workers", worker.id, "attendance"] });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ في التسجيل",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // معالجة تقديم النموذج
  function onSubmit(values: z.infer<typeof formSchema>) {
    if (!values.recordedBy && currentUser?.id) {
      values.recordedBy = currentUser.id;
    }
    
    // تحويل التاريخ إلى تنسيق نصي (ISO 8601)
    const formattedValues = {
      ...values,
      date: values.date ? values.date.toISOString().split('T')[0] : '',
    };
    
    createAttendanceMutation.mutate(formattedValues as InsertWorkerAttendance);
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* التاريخ */}
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>التاريخ</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-right font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "dd/MM/yyyy", { locale: arSA })
                        ) : (
                          <span>اختر تاريخ</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="end">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* المشروع */}
          <FormField
            control={form.control}
            name="projectId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>المشروع</FormLabel>
                <Select
                  onValueChange={(value) => field.onChange(parseInt(value))}
                  defaultValue={field.value?.toString()}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {projects?.map((project: any) => (
                      <SelectItem key={project.id} value={project.id.toString()}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* الحالة */}
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الحالة</FormLabel>
                <Select
                  onValueChange={field.onChange}
                  defaultValue={field.value}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="اختر حالة الحضور" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {attendanceStatuses.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* ساعات العمل */}
          <FormField
            control={form.control}
            name="hoursWorked"
            render={({ field }) => (
              <FormItem>
                <FormLabel>ساعات العمل</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    placeholder="عدد ساعات العمل"
                    {...field}
                    onChange={(e) => {
                      const value = e.target.value === "" ? undefined : parseFloat(e.target.value);
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        {/* ملاحظات */}
        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>ملاحظات</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="أدخل ملاحظات إضافية عن الحضور"
                  className="resize-none h-20"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={onSuccess}
          >
            إلغاء
          </Button>
          <Button
            type="submit"
            disabled={createAttendanceMutation.isPending}
          >
            تسجيل الحضور
          </Button>
        </div>
      </form>
    </Form>
  );
}