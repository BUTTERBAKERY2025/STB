import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Worker } from "@shared/schema.new";
import { format } from "date-fns";
import { arSA } from 'date-fns/locale';
import { BriefcaseBusiness, Calendar, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";

interface WorkerCardProps {
  worker: Worker;
  onEdit: (worker: Worker) => void;
  onViewAttendance: (worker: Worker) => void;
}

// تحويل حالة العامل إلى مكون بادج مع اللون المناسب
function getStatusBadge(status: string) {
  switch (status) {
    case 'active':
      return <Badge variant="secondary">نشط</Badge>;
    case 'leave':
      return <Badge variant="outline">مجاز</Badge>;
    case 'inactive':
      return <Badge variant="destructive">منقطع</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

// تحويل نوع الكفالة إلى مكون بادج مع اللون المناسب
function getSponsorshipBadge(sponsorship: string) {
  switch (sponsorship) {
    case 'company':
      return <Badge variant="secondary">كفالة الشركة</Badge>;
    case 'rental':
      return <Badge variant="outline">عمل بالإيجار</Badge>;
    case 'part_time':
      return <Badge variant="default">تعاقد جزئي</Badge>;
    default:
      return <Badge variant="outline">{sponsorship}</Badge>;
  }
}

export function WorkerCard({ worker, onEdit, onViewAttendance }: WorkerCardProps) {
  // تنسيق التاريخ بطريقة عربية
  const formatDate = (date: string | Date) => {
    return format(new Date(date), 'dd MMMM yyyy', { locale: arSA });
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl">{worker.name}</CardTitle>
            <CardDescription className="mt-1">
              {worker.specialization} - {worker.nationality}
            </CardDescription>
          </div>
          <div className="flex flex-col items-end gap-1">
            {getStatusBadge(worker.status)}
            {getSponsorshipBadge(worker.sponsorshipStatus)}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-0">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2">
              <BriefcaseBusiness className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">{worker.jobCategory}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">تاريخ الالتحاق: {formatDate(worker.joiningDate)}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm">
              {worker.salaryType === 'monthly' ? 'راتب شهري: ' : 'أجرة يومية: '}
              {worker.salaryAmount} ريال
            </span>
          </div>
          
          {worker.currentProjectId && (
            <div className="p-2 bg-primary/10 rounded-md">
              <span className="text-sm font-medium">مشروع حالي:</span>
              <span className="text-sm mr-1">#{worker.currentProjectId}</span>
            </div>
          )}
        </div>
      </CardContent>
      <Separator className="my-3" />
      <CardFooter className="pt-0 flex justify-between">
        <Button variant="outline" size="sm" onClick={() => onViewAttendance(worker)}>
          سجل الحضور
        </Button>
        <Button variant="default" size="sm" onClick={() => onEdit(worker)}>
          تعديل
        </Button>
      </CardFooter>
    </Card>
  );
}