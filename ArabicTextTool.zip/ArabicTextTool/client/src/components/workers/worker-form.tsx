import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { InsertWorker, Worker, insertWorkerSchema } from "@shared/schema.new";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  CalendarIcon, 
  UserRoundPlus, 
  Upload, 
  PlusCircle, 
  Trash2, 
  FileText,
  Camera,
  User,
  Briefcase,
  WalletCards,
  Phone,
  Clock,
  Loader2
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { arSA } from "date-fns/locale";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

// قائمة التخصصات المتاحة
const specializations = [
  { value: "site_engineer", label: "مهندس موقع" },
  { value: "execution_supervisor", label: "مشرف تنفيذ" },
  { value: "project_manager", label: "مدير مشروع" },
  { value: "excavation_worker", label: "عامل حفريات" },
  { value: "electrician", label: "عامل كهرباء" },
  { value: "plumber", label: "سباك" },
  { value: "form_carpenter", label: "نجار قالب" },
  { value: "reinforcement_blacksmith", label: "حداد تسليح" },
  { value: "general_worker", label: "عامل عام أو مساعد" },
  { value: "equipment_driver", label: "سائق معدة أو شاحنة" },
];

// قائمة التصنيفات الوظيفية
const jobCategories = [
  { value: "engineer", label: "مهندس" },
  { value: "supervisor", label: "مشرف" },
  { value: "manager", label: "إداري" },
  { value: "technician", label: "فني" },
  { value: "worker", label: "عامل" },
  { value: "driver", label: "سائق" },
];

// قائمة حالات الكفالة
const sponsorshipStatuses = [
  { value: "company", label: "كفالة الشركة" },
  { value: "rental", label: "عمل بالإيجار" },
  { value: "part_time", label: "تعاقد جزئي" },
];

// قائمة أنواع الراتب
const salaryTypes = [
  { value: "monthly", label: "شهري" },
  { value: "daily", label: "يومي" },
];

// قائمة حالات العامل
const workerStatuses = [
  { value: "active", label: "نشط" },
  { value: "leave", label: "مجاز" },
  { value: "inactive", label: "منقطع" },
];

interface WorkerFormProps {
  worker?: Worker;
  onSuccess: () => void;
}

export function WorkerForm({ worker, onSuccess }: WorkerFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!worker;

  // استعلام قائمة المشاريع
  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  // تعديل مخطط التحقق من البيانات لتضمين القواعد الإضافية
  const formSchema = insertWorkerSchema.extend({
    salaryAmount: z.coerce.number().positive("يجب أن يكون المبلغ قيمة موجبة"),
    identityNumber: z.string().min(8, "يجب أن يكون رقم الهوية 8 أرقام على الأقل"),
    joiningDate: z.coerce.date(),
  });

  // تهيئة نموذج إدخال البيانات
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: isEditing
      ? {
          ...worker,
          joiningDate: new Date(worker.joiningDate),
        }
      : {
          name: "",
          identityNumber: "",
          nationality: "",
          specialization: "",
          jobCategory: "",
          sponsorshipStatus: "company",
          phoneNumber: "",
          email: "",
          salaryType: "monthly",
          salaryAmount: 0,
          status: "active",
          joiningDate: new Date(),
          directManagerId: undefined,
          currentProjectId: undefined,
          notes: "",
        },
  });

  // إنشاء عامل جديد
  const createWorkerMutation = useMutation({
    mutationFn: async (newWorker: InsertWorker) => {
      const res = await apiRequest("POST", "/api/workers", newWorker);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الإنشاء بنجاح",
        description: "تم إضافة العامل بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/workers"] });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ في الإنشاء",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // تعديل بيانات عامل موجود
  const updateWorkerMutation = useMutation({
    mutationFn: async ({ id, ...workerData }: Worker) => {
      const res = await apiRequest("PATCH", `/api/workers/${id}`, workerData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التعديل بنجاح",
        description: "تم تحديث بيانات العامل بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/workers"] });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "خطأ في التعديل",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // معالجة تقديم النموذج
  function onSubmit(values: z.infer<typeof formSchema>) {
    // تحويل التاريخ من Date إلى string قبل الإرسال
    const dateString = format(values.joiningDate, 'yyyy-MM-dd'); // تنسيق التاريخ كنص
    
    // نسخة من القيم مع تنسيق التاريخ كنص
    const formattedValues = {
      ...values,
      joiningDate: dateString
    };
    
    // تسجيل البيانات التي سيتم إرسالها للتشخيص
    console.log("القيم المرسلة:", formattedValues);
    
    if (isEditing && worker) {
      updateWorkerMutation.mutate({ ...formattedValues, id: worker.id });
    } else {
      createWorkerMutation.mutate(formattedValues as InsertWorker);
    }
  }

  const [activeTab, setActiveTab] = useState("personal");
  const [previewImage, setPreviewImage] = useState<string | null>(worker?.photograph || null);
  const [documentsList, setDocumentsList] = useState<{name: string, url: string}[]>([
    ...(worker?.documents ? worker.documents.map((doc, index) => ({
      name: `مستند ${index + 1}`,
      url: doc
    })) : [])
  ]);
  
  // معالجة تغيير الصورة
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // عادة في تطبيق حقيقي سنقوم برفع الصورة للخادم وتخزين الرابط
      // لكن لأغراض العرض سنستخدم URL محلي
      const imageUrl = URL.createObjectURL(file);
      setPreviewImage(imageUrl);
      form.setValue("photograph", imageUrl);
    }
  };
  
  // معالجة إضافة مستند
  const handleAddDocument = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // عادة في تطبيق حقيقي سنقوم برفع المستند للخادم وتخزين الرابط
      // لكن لأغراض العرض سنستخدم URL محلي
      const docUrl = URL.createObjectURL(file);
      const newDoc = {
        name: file.name,
        url: docUrl
      };
      
      const updatedDocs = [...documentsList, newDoc];
      setDocumentsList(updatedDocs);
      
      // تحديث قائمة المستندات في النموذج
      form.setValue("documents", updatedDocs.map(doc => doc.url));
    }
  };
  
  // حذف مستند
  const handleRemoveDocument = (index: number) => {
    const updatedDocs = documentsList.filter((_, i) => i !== index);
    setDocumentsList(updatedDocs);
    
    // تحديث قائمة المستندات في النموذج
    form.setValue("documents", updatedDocs.map(doc => doc.url));
  };

  // الحصول على أول حرفين من اسم العامل
  const getWorkerInitials = (name: string) => {
    if (!name) return "عا";
    return name.split(" ").slice(0, 2).map(part => part.charAt(0)).join("");
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* معاينة العامل */}
        <div className="flex flex-col md:flex-row items-start gap-6 mb-4">
          <div className="md:w-1/3">
            <Card className="w-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">معاينة بيانات العامل</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-col items-center space-y-3">
                  <div className="relative">
                    <Avatar className="h-24 w-24 border-2 border-primary">
                      {previewImage ? (
                        <AvatarImage src={previewImage} alt="صورة العامل" />
                      ) : (
                        <AvatarFallback className="bg-primary/10 text-primary text-xl">
                          {getWorkerInitials(form.watch("name"))}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1">
                      <label htmlFor="profile-image" className="cursor-pointer">
                        <div className="bg-primary text-white p-1.5 rounded-full hover:bg-primary/90 transition-colors">
                          <Camera className="h-4 w-4" />
                        </div>
                        <input
                          type="file"
                          id="profile-image"
                          accept="image/*"
                          className="hidden"
                          onChange={handleImageChange}
                        />
                      </label>
                    </div>
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg">
                      {form.watch("name") || "عامل جديد"}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {specializations.find(s => s.value === form.watch("specialization"))?.label || "لم يتم تحديد التخصص بعد"}
                    </p>
                  </div>
                </div>

                <div className="pt-2 space-y-2">
                  <div className="grid grid-cols-[24px_1fr] items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {form.watch("identityNumber") || "رقم الهوية غير محدد"}
                    </span>
                  </div>
                  <div className="grid grid-cols-[24px_1fr] items-center gap-2">
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {projects?.find((p: any) => p.id === form.watch("currentProjectId"))?.name || "لا يوجد مشروع حالي"}
                    </span>
                  </div>
                  <div className="grid grid-cols-[24px_1fr] items-center gap-2">
                    <WalletCards className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {form.watch("salaryAmount") ? `${form.watch("salaryAmount")} ريال (${salaryTypes.find(t => t.value === form.watch("salaryType"))?.label})` : "الراتب غير محدد"}
                    </span>
                  </div>
                  <div className="grid grid-cols-[24px_1fr] items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm" dir="ltr">
                      {form.watch("phoneNumber") || "رقم الهاتف غير محدد"}
                    </span>
                  </div>
                  <div className="grid grid-cols-[24px_1fr] items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {form.watch("joiningDate") 
                        ? `تاريخ الالتحاق: ${format(form.watch("joiningDate"), "dd/MM/yyyy", { locale: arSA })}` 
                        : "تاريخ الالتحاق غير محدد"}
                    </span>
                  </div>
                </div>

                <div className="pt-2">
                  <Badge className={cn(
                    "w-full justify-center",
                    form.watch("status") === "active" ? "bg-green-500 hover:bg-green-600" :
                    form.watch("status") === "leave" ? "bg-amber-500 hover:bg-amber-600" :
                    "bg-red-500 hover:bg-red-600"
                  )}>
                    {workerStatuses.find(s => s.value === form.watch("status"))?.label || "غير محدد"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="w-full md:w-2/3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-3 mb-4">
                <TabsTrigger value="personal" className="text-sm">
                  <User className="h-4 w-4 ml-1" />
                  البيانات الشخصية
                </TabsTrigger>
                <TabsTrigger value="work" className="text-sm">
                  <Briefcase className="h-4 w-4 ml-1" />
                  البيانات الوظيفية
                </TabsTrigger>
                <TabsTrigger value="documents" className="text-sm">
                  <FileText className="h-4 w-4 ml-1" />
                  المستندات
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="personal" className="space-y-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">البيانات الشخصية</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* الاسم */}
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>اسم العامل</FormLabel>
                            <FormControl>
                              <Input placeholder="أدخل اسم العامل" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* رقم الهوية */}
                      <FormField
                        control={form.control}
                        name="identityNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رقم الهوية</FormLabel>
                            <FormControl>
                              <Input placeholder="أدخل رقم الهوية" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* الجنسية */}
                      <FormField
                        control={form.control}
                        name="nationality"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الجنسية</FormLabel>
                            <FormControl>
                              <Input placeholder="الجنسية" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* رقم الهاتف */}
                      <FormField
                        control={form.control}
                        name="phoneNumber"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>رقم الهاتف</FormLabel>
                            <FormControl>
                              <Input placeholder="رقم الهاتف" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* البريد الإلكتروني */}
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>البريد الإلكتروني</FormLabel>
                            <FormControl>
                              <Input placeholder="البريد الإلكتروني" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* تاريخ الالتحاق */}
                      <FormField
                        control={form.control}
                        name="joiningDate"
                        render={({ field }) => (
                          <FormItem className="flex flex-col">
                            <FormLabel>تاريخ الالتحاق</FormLabel>
                            <Popover>
                              <PopoverTrigger asChild>
                                <FormControl>
                                  <Button
                                    variant={"outline"}
                                    className={cn(
                                      "w-full pl-3 text-right font-normal",
                                      !field.value && "text-muted-foreground"
                                    )}
                                  >
                                    {field.value ? (
                                      format(field.value, "dd/MM/yyyy", { locale: arSA })
                                    ) : (
                                      <span>اختر تاريخ</span>
                                    )}
                                    <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                  </Button>
                                </FormControl>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-0" align="end">
                                <Calendar
                                  mode="single"
                                  selected={field.value}
                                  onSelect={field.onChange}
                                  initialFocus
                                />
                              </PopoverContent>
                            </Popover>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="work" className="space-y-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">البيانات الوظيفية</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* التخصص */}
                      <FormField
                        control={form.control}
                        name="specialization"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>التخصص</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر التخصص" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {specializations.map((spec) => (
                                  <SelectItem key={spec.value} value={spec.value}>
                                    {spec.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* التصنيف الوظيفي */}
                      <FormField
                        control={form.control}
                        name="jobCategory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>التصنيف الوظيفي</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر التصنيف الوظيفي" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {jobCategories.map((category) => (
                                  <SelectItem key={category.value} value={category.value}>
                                    {category.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* حالة الكفالة */}
                      <FormField
                        control={form.control}
                        name="sponsorshipStatus"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>حالة الكفالة</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر حالة الكفالة" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {sponsorshipStatuses.map((status) => (
                                  <SelectItem key={status.value} value={status.value}>
                                    {status.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* نوع الراتب */}
                      <FormField
                        control={form.control}
                        name="salaryType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نوع الراتب</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر نوع الراتب" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {salaryTypes.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* مبلغ الراتب */}
                      <FormField
                        control={form.control}
                        name="salaryAmount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>مبلغ الراتب (ريال)</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="أدخل مبلغ الراتب"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* المشروع الحالي */}
                      <FormField
                        control={form.control}
                        name="currentProjectId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>المشروع الحالي</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(value === "null" ? null : parseInt(value))}
                              defaultValue={field.value?.toString() || "null"}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر المشروع الحالي" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="null">غير محدد</SelectItem>
                                {projects?.map((project: any) => (
                                  <SelectItem key={project.id} value={project.id.toString()}>
                                    {project.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* الحالة */}
                      <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>الحالة</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر حالة العامل" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {workerStatuses.map((status) => (
                                  <SelectItem key={status.value} value={status.value}>
                                    {status.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* ملاحظات */}
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ملاحظات</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="أدخل ملاحظات إضافية عن العامل"
                              className="resize-none h-20"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            يمكنك إضافة أي ملاحظات إضافية متعلقة بالعامل هنا.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="documents" className="space-y-6">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">المستندات والوثائق</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* قائمة المستندات */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium">المستندات المرفقة</h3>
                        <label htmlFor="add-document" className="cursor-pointer">
                          <div className="flex items-center text-primary hover:text-primary/90">
                            <PlusCircle className="h-4 w-4 ml-1" />
                            <span className="text-sm">إضافة مستند</span>
                          </div>
                          <input
                            type="file"
                            id="add-document"
                            className="hidden"
                            onChange={handleAddDocument}
                          />
                        </label>
                      </div>
                      
                      {documentsList.length === 0 ? (
                        <div className="text-sm text-muted-foreground p-4 border rounded border-dashed text-center">
                          لا توجد مستندات مرفقة، قم بإضافة المستندات (مثل الهوية، الإقامة، عقد العمل، إلخ)
                        </div>
                      ) : (
                        <div className="border rounded divide-y">
                          {documentsList.map((doc, index) => (
                            <div key={index} className="p-3 flex justify-between items-center">
                              <div className="flex items-center">
                                <FileText className="h-4 w-4 ml-2 text-primary" />
                                <span className="text-sm">{doc.name}</span>
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  type="button" 
                                  variant="ghost" 
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => window.open(doc.url, '_blank')}
                                >
                                  <FileText className="h-4 w-4 text-gray-500" />
                                </Button>
                                <Button 
                                  type="button" 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-50"
                                  onClick={() => handleRemoveDocument(index)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <FormDescription>
                        يمكنك إضافة صور من المستندات المهمة مثل (الهوية، الإقامة، شهادات التأهيل، عقد العمل، إلخ)
                      </FormDescription>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={onSuccess}
          >
            إلغاء
          </Button>
          <Button
            type="submit"
            disabled={createWorkerMutation.isPending || updateWorkerMutation.isPending}
            className="gap-1"
          >
            {createWorkerMutation.isPending || updateWorkerMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <UserRoundPlus className="h-4 w-4" />
            )}
            {isEditing ? "تحديث البيانات" : "إضافة عامل"}
          </Button>
        </div>
      </form>
    </Form>
  );
}