import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { arSA } from "date-fns/locale";
import { WorkerAttendance } from "@shared/schema.new";

interface AttendanceTableProps {
  attendanceRecords: WorkerAttendance[];
  projectNames?: Record<number, string>;
}

// تحويل حالة الحضور إلى مكون بادج مع اللون المناسب
function getStatusBadge(status: string) {
  switch (status) {
    case 'present':
      return <Badge variant="secondary">حاضر</Badge>;
    case 'absent':
      return <Badge variant="destructive">غائب</Badge>;
    case 'leave':
      return <Badge variant="outline">مجاز</Badge>;
    case 'late':
      return <Badge variant="default">متأخر</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

export function AttendanceTable({ attendanceRecords, projectNames = {} }: AttendanceTableProps) {
  // تنسيق التاريخ بطريقة عربية
  const formatDate = (date: string | Date) => {
    if (!date) return "-";
    try {
      return format(new Date(date), 'dd MMMM yyyy', { locale: arSA });
    } catch (error) {
      console.error("خطأ في تنسيق التاريخ:", date, error);
      return "تاريخ غير صالح";
    }
  };

  // ترتيب السجلات حسب التاريخ (الأحدث أولاً)
  const sortedRecords = [...attendanceRecords].sort((a, b) => {
    try {
      const dateA = a.date ? new Date(a.date) : new Date(0);
      const dateB = b.date ? new Date(b.date) : new Date(0);
      return dateB.getTime() - dateA.getTime();
    } catch (error) {
      console.error("خطأ في ترتيب التواريخ:", error);
      return 0;
    }
  });

  return (
    <div className="rounded-md border">
      <Table dir="rtl">
        <TableHeader>
          <TableRow>
            <TableHead className="text-right">التاريخ</TableHead>
            <TableHead className="text-right">المشروع</TableHead>
            <TableHead className="text-right">الحالة</TableHead>
            <TableHead className="text-right">ساعات العمل</TableHead>
            <TableHead className="text-right">ملاحظات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedRecords.length === 0 ? (
            <TableRow>
              <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                لا توجد سجلات حضور بعد
              </TableCell>
            </TableRow>
          ) : (
            sortedRecords.map((record) => (
              <TableRow key={record.id}>
                <TableCell>{formatDate(record.date)}</TableCell>
                <TableCell>{projectNames[record.projectId] || `مشروع #${record.projectId}`}</TableCell>
                <TableCell>{getStatusBadge(record.status)}</TableCell>
                <TableCell>{record.hoursWorked || "-"}</TableCell>
                <TableCell className="max-w-xs truncate">{record.notes || "-"}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}