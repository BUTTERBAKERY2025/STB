import { createContext, useContext, useEffect, useState, ReactNode } from "react";

type Direction = "rtl" | "ltr";
type Language = "ar" | "en";

type RtlContextType = {
  dir: Direction;
  lang: Language;
  setLanguage: (language: Language) => void;
};

const RtlContext = createContext<RtlContextType>({
  dir: "rtl",
  lang: "ar",
  setLanguage: () => null,
});

export function RtlProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar");
  const direction: Direction = language === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.dir = direction;
    document.documentElement.lang = language;
  }, [direction, language]);

  return (
    <RtlContext.Provider
      value={{
        dir: direction,
        lang: language,
        setLanguage,
      }}
    >
      {children}
    </RtlContext.Provider>
  );
}

export const useRtl = () => useContext(RtlContext);
