import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  ProjectorIcon, 
  ClipboardList, 
  Banknote, 
  Truck, 
  Users, 
  MessageSquare, 
  FileText, 
  Settings, 
  ChevronDown, 
  ChevronLeft,
  X,
  AlertTriangle,
  MapPin,
  FileSearch,
  Receipt,
  Calculator,
  TrendingUp,
  HardHat,
  DollarSign,
  BarChart,
  Home,
  PieChart,
  Landmark,
  FileSpreadsheet,
  FileCheck,
  Target,
  Waypoints,
  CircleDollarSign,
  Building2,
  GanttChart,
  UserCog,
  ScrollText,
  Workflow,
  Newspaper
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  closeSidebar: () => void;
}

const Sidebar = ({ isOpen, closeSidebar }: SidebarProps) => {
  const [location, setLocation] = useLocation();
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({});
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  // عند تحميل الصفحة، حدد القوائم التي يجب فتحها بناءً على المسار الحالي
  useEffect(() => {
    const autoExpand = () => {
      const expandedItems: Record<string, boolean> = {};
      
      navigationItems.forEach(item => {
        // فتح القائمة تلقائيًا إذا كان المسار الحالي هو أحد عناصرها الفرعية
        if (item.submenu && item.submenu.some(sub => sub.href === location)) {
          expandedItems[item.name] = true;
        }
      });
      
      setExpandedMenus(expandedItems);
    };
    
    autoExpand();
  }, [location]);

  const toggleSubmenu = (name: string) => {
    setExpandedMenus(prev => ({
      ...prev,
      [name]: !prev[name]
    }));
  };

  interface NavItem {
    name: string;
    href: string;
    icon: React.ReactNode;
    badge?: string | number;
    submenu?: NavSubItem[];
  }
  
  interface NavSubItem {
    name: string;
    href: string;
  }
  
  interface NavCategory {
    name: string;
    items: NavItem[];
  }

  // تنظيم عناصر التنقل حسب الفئات
  const navigationCategories: NavCategory[] = [
    {
      name: "العامة",
      items: [
        {
          name: "لوحة التحكم",
          href: "/",
          icon: <Home className="w-5 h-5" />,
        },
        {
          name: "المحادثات والدعم",
          href: "/chat",
          icon: <MessageSquare className="w-5 h-5" />,
          badge: 3,
        },
      ]
    },
    {
      name: "إدارة المشاريع",
      items: [
        {
          name: "المشاريع",
          href: "/projects",
          icon: <Building2 className="w-5 h-5" />,
          submenu: [
            {
              name: "قائمة المشاريع",
              href: "/projects",
            },
            {
              name: "دراسة الجدوى",
              href: "/project-profitability",
            },
            {
              name: "إصدار المستخلصات",
              href: "/payment-requests",
            },
          ]
        },
        {
          name: "التتبع الجغرافي",
          href: "/geo-tracking",
          icon: <Waypoints className="w-5 h-5" />,
          badge: "جديد",
        },
        {
          name: "تنبؤ المخاطر",
          href: "/risk-prediction",
          icon: <AlertTriangle className="w-5 h-5" />,
        },
      ]
    },
    {
      name: "المالية والمحاسبة",
      items: [
        {
          name: "النظام المالي",
          href: "/financial-system",
          icon: <Landmark className="w-5 h-5" />,
          badge: "متكامل",
          submenu: [
            {
              name: "النظام المالي الكامل",
              href: "/financial-system",
            },
            {
              name: "دليل الحسابات",
              href: "/accounts",
            },
            {
              name: "القيود المحاسبية",
              href: "/financial-center",
            },
          ],
        },
        {
          name: "التقارير المالية",
          href: "/finances",
          icon: <FileSpreadsheet className="w-5 h-5" />,
        },
      ]
    },
    {
      name: "التقارير والتحليلات",
      items: [
        {
          name: "تقارير المشاريع",
          href: "/reports",
          icon: <PieChart className="w-5 h-5" />,
          submenu: [
            {
              name: "تقارير الأداء",
              href: "/reports",
            },
            {
              name: "التقارير اليومية",
              href: "/daily-reports",
            },
          ]
        },
        {
          name: "تحليل البيانات",
          href: "/ai-analytics",
          icon: <TrendingUp className="w-5 h-5" />,
          badge: "AI",
        },
      ]
    },
    {
      name: "الموارد والمستندات",
      items: [
        {
          name: "إدارة الموارد",
          href: "/equipment",
          icon: <Workflow className="w-5 h-5" />,
          submenu: [
            {
              name: "المعدات",
              href: "/equipment",
            },
            {
              name: "القوى العاملة",
              href: "/workforce",
            },
          ]
        },
        {
          name: "المستندات",
          href: "/documents",
          icon: <ScrollText className="w-5 h-5" />,
          submenu: [
            {
              name: "معالجة المستندات OCR",
              href: "/ocr-processing",
            },
            {
              name: "أرشيف المستندات",
              href: "/documents",
            }
          ]
        },
      ]
    },
    {
      name: "النظام",
      items: [
        {
          name: "الإعدادات",
          href: "/settings",
          icon: <UserCog className="w-5 h-5" />,
        }
      ]
    }
  ];
  
  // دمج جميع عناصر التنقل في قائمة واحدة للاستخدام
  const navigationItems: NavItem[] = navigationCategories.flatMap(category => category.items);

  return (
    <aside 
      className={cn(
        "sidebar bg-white dark:bg-gray-800 shadow-lg w-72 flex-shrink-0 flex flex-col overflow-hidden transition-all duration-300 ease-in-out z-20",
        isOpen ? "fixed inset-y-0 right-0 md:relative sidebar-appear" : "hidden md:flex"
      )}
    >
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-primary flex items-center">
            <div className="flex items-center justify-center bg-primary text-white h-10 w-10 rounded-md ml-2 shadow-md">
              <span className="text-lg">STB</span>
            </div>
            <div className="flex flex-col">
              <span className="text-lg">نظام البنية التحتية</span>
              <span className="text-xs text-gray-500">النسخة 2.0</span>
            </div>
          </h1>
          <button 
            className="md:hidden bg-gray-100 p-1 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-200 transition-colors dark:bg-gray-700 dark:text-gray-400 dark:hover:text-gray-200" 
            onClick={closeSidebar}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <div className="p-3">
        <div className="relative">
          <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
            <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
              <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 19-4-4m0 0a7 7 0 1 0 0 14 7 7 0 0 0 0-14"/>
            </svg>
          </div>
          <input 
            type="text" 
            className="block w-full p-2 pr-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-600 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-blue-500 text-right" 
            placeholder="بحث..." 
          />
        </div>
      </div>
      
      <nav className="mt-2 flex-1 px-2 overflow-y-auto custom-scrollbar">
        {navigationCategories.map((category, categoryIndex) => (
          <div key={categoryIndex} className="mb-6">
            <div className="text-xs text-gray-400 px-2 py-2 font-medium mb-2 flex items-center">
              <div className="h-px bg-gray-200 dark:bg-gray-700 w-2 ml-2"></div>
              {category.name}
              <div className="h-px bg-gray-200 dark:bg-gray-700 flex-grow mr-2"></div>
            </div>
            <ul className="space-y-1">
              {category.items.map((item, index) => {
                // التحقق ما إذا كانت هذه القائمة أو إحدى قوائمها الفرعية نشطة حالياً
                const isCurrentPath = location === item.href;
                const hasActiveSubmenu = item.submenu?.some(sub => location === sub.href);
                const isActive = isCurrentPath || hasActiveSubmenu;
                
                // التحقق إذا كانت القائمة الفرعية مفتوحة
                const isExpanded = isActive || expandedMenus[item.name] || false;
                const isHovered = hoveredItem === item.name;

                return (
                <li key={index} className="rounded-md overflow-hidden">
                  <div className="flex flex-col">
                    <button 
                      onClick={() => {
                        if (item.submenu && item.submenu.length > 0) {
                          // إذا كانت هناك قائمة فرعية، تبديل حالة الفتح/الإغلاق
                          toggleSubmenu(item.name);
                        } else {
                          // إذا لم تكن هناك قائمة فرعية، الانتقال إلى الصفحة
                          setLocation(item.href);
                        }
                      }}
                      onMouseEnter={() => setHoveredItem(item.name)}
                      onMouseLeave={() => setHoveredItem(null)}
                      className={cn(
                        "w-full text-right px-3 py-2.5 flex items-center justify-between cursor-pointer transition-all duration-300 rounded-md group",
                        isActive 
                          ? "bg-primary text-white font-medium shadow-md"
                          : "hover:bg-gray-100 dark:hover:bg-gray-700",
                        isHovered && !isActive && "bg-gray-100 dark:bg-gray-700"
                      )}
                    >
                      <div className="flex items-center">
                        <div className={cn(
                          "rounded-full p-1.5 mr-2 transition-colors duration-300",
                          isActive 
                            ? "bg-white/20 text-white" 
                            : "bg-gray-100 text-primary group-hover:bg-primary/10 dark:bg-gray-700"
                        )}>
                          {item.icon}
                        </div>
                        <span className="text-base">{item.name}</span>
                      </div>
                      <div className="flex items-center">
                        {item.badge && (
                          <span className={cn(
                            "text-xs rounded-full px-2 py-0.5 ml-2 transition-colors duration-300",
                            isActive 
                              ? "bg-white/30 text-white" 
                              : "bg-primary/10 text-primary dark:bg-primary/30"
                          )}>
                            {item.badge}
                          </span>
                        )}
                        {item.submenu && item.submenu.length > 0 && (
                          <ChevronDown 
                            className={cn(
                              "h-4 w-4 transition-transform duration-300 mr-1",
                              isExpanded && "transform rotate-180"
                            )} 
                          />
                        )}
                      </div>
                    </button>
                    {item.submenu && (
                      <div 
                        className={cn(
                          "overflow-hidden transition-all duration-300 ease-in-out",
                          isExpanded ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                        )}
                      >
                        <ul className={cn(
                          "pt-1 pb-1 mr-4 border-r-2 transition-colors duration-300 mt-1",
                          isActive ? "border-primary" : "border-gray-200 dark:border-gray-700"
                        )}>
                          {item.submenu.map((subitem, subindex) => {
                            const isSubItemActive = location === subitem.href;
                            
                            return (
                              <li key={subindex} className="hover:bg-gray-50 dark:hover:bg-gray-800 rounded-md">
                                <button 
                                  onClick={() => {
                                    setLocation(subitem.href);
                                  }}
                                  className={cn(
                                    "block text-right w-full pr-3 py-1.5 hover:text-primary cursor-pointer flex items-center transition-all duration-300", 
                                    isSubItemActive 
                                      ? "text-primary font-medium bg-primary/5 rounded-md"
                                      : "text-gray-600 dark:text-gray-300"
                                  )}
                                >
                                  <div className={cn(
                                    "w-1.5 h-1.5 rounded-full ml-2",
                                    isSubItemActive ? "bg-primary" : "bg-gray-300 dark:bg-gray-600"
                                  )}></div>
                                  <span className="truncate text-sm">{subitem.name}</span>
                                </button>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}
                  </div>
                </li>
              )})}
            </ul>
          </div>
        ))}
      </nav>
      
      <div className="mt-auto p-4 bg-gray-50 dark:bg-gray-700/30 rounded-lg m-3 shadow-inner">
        <div className="flex items-center space-x-3 space-x-reverse">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=120&h=120&fit=crop&crop=faces" 
              alt="User profile" 
              className="w-12 h-12 rounded-full border-2 border-white shadow-md"
            />
            <div className="absolute -bottom-1 -left-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <p className="font-medium dark:text-white text-base">عبدالله العتيبي</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">مدير النظام</p>
          </div>
          <button className="p-1.5 rounded-full bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 transition-colors duration-300 mr-auto">
            <Settings className="h-4 w-4 text-gray-600 dark:text-gray-300" />
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
