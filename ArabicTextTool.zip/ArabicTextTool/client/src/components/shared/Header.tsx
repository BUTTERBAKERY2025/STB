import { Search, Menu, Globe, Bell, Moon, Sun, MessageSquareText } from "lucide-react";
import { FaWhatsapp } from "react-icons/fa";
import { useTheme } from "@/components/ui/theme-provider";
import { useRtl } from "@/components/ui/rtl-provider";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header = ({ toggleSidebar }: HeaderProps) => {
  const { theme, setTheme } = useTheme();
  const { lang, setLanguage } = useRtl();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm z-10">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <button 
            className="md:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-2" 
            onClick={toggleSidebar}
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="relative">
            <input 
              type="text" 
              placeholder="بحث سريع..." 
              className="bg-gray-100 dark:bg-gray-700 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary focus:bg-white dark:focus:bg-gray-600 transition duration-200 w-64 dark:text-gray-100 dark:placeholder-gray-400"
            />
            <Search className="absolute right-3 top-2.5 h-5 w-5 text-gray-400 dark:text-gray-500" />
          </div>
        </div>
        
        <div className="flex items-center space-x-4 space-x-reverse">
          {/* Language selector */}
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center text-gray-700 dark:text-gray-300 hover:text-primary dark:hover:text-primary">
              <Globe className="ml-1 h-5 w-5" />
              <span>{lang === 'ar' ? 'العربية' : 'English'}</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => setLanguage("ar")}>
                العربية
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setLanguage("en")}>
                English
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {/* Notifications */}
          <button className="relative p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
            <Bell className="h-5 w-5 text-gray-600 dark:text-gray-300" />
            <span className="absolute top-0 left-0 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
              2
            </span>
          </button>
          
          {/* Dark mode toggle */}
          <button 
            className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5 text-yellow-400" />
            ) : (
              <Moon className="h-5 w-5 text-gray-600" />
            )}
          </button>
          
          {/* WhatsApp integration */}
          <button className="p-1 rounded-full text-green-600 hover:bg-gray-100 dark:hover:bg-gray-700">
            <FaWhatsapp className="h-5 w-5" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
