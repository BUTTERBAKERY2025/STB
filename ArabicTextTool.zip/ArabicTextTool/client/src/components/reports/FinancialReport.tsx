import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Project } from "@shared/schema";
import { formatCurrency, formatNumber, formatDate } from "@/lib/utils";
import { 
  AlertTriangle, 
  Calendar, 
  Download, 
  Filter, 
  RefreshCw,
  CreditCard,
  Landmark,
  Building2,
  DollarSign,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  Tooltip,
  LineChart,
  Line,
  ComposedChart,
  Area
} from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// أنواع البيانات للتقارير المالية
type RevenueExpenseData = {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
};

type ExpenseCategoryData = {
  category: string;
  value: number;
};

type ProjectFinancialData = {
  projectName: string;
  budget: number;
  spent: number;
  revenue: number;
  profit: number;
};

type FinancialTrendData = {
  year: string;
  quarter: string;
  revenue: number;
  expenses: number;
  profit: number;
};

type CashFlowData = {
  month: string;
  inflow: number;
  outflow: number;
  balance: number;
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const FinancialReport = () => {
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [timeframe, setTimeframe] = useState('year'); // quarter, year, all
  const [reportType, setReportType] = useState('income'); // income, expense, cashFlow, profitability
  const { toast } = useToast();

  // استعلام لجلب بيانات المشاريع
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // استعلام لبيانات الإيرادات والمصروفات - ربط مباشر بواجهة API
  const { data: revenueExpenseData, isLoading: isLoadingRevenue } = useQuery<RevenueExpenseData[]>({
    queryKey: ['/api/financial/revenue-expenses', selectedProject, timeframe],
    // استخدام المعالج الافتراضي من queryClient
    enabled: true,
  });

  // استعلام لبيانات فئات المصروفات - ربط مباشر بواجهة API
  const { data: expenseCategoryData, isLoading: isLoadingExpenses } = useQuery<ExpenseCategoryData[]>({
    queryKey: ['/api/financial/expense-categories', selectedProject, timeframe],
    enabled: true,
  });

  // استعلام لبيانات مالية للمشاريع - ربط مباشر بواجهة API
  const { data: projectFinancialData, isLoading: isLoadingFinancials } = useQuery<ProjectFinancialData[]>({
    queryKey: ['/api/financial/project-financials', timeframe],
    enabled: true,
  });

  // استعلام لبيانات التدفق النقدي - ربط مباشر بواجهة API
  const { data: cashFlowData, isLoading: isLoadingCashFlow } = useQuery<CashFlowData[]>({
    queryKey: ['/api/financial/cash-flow', selectedProject, timeframe],
    enabled: true,
  });

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  const handleTimeframeChange = (value: string) => {
    setTimeframe(value);
  };

  const handleReportTypeChange = (value: string) => {
    setReportType(value);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/financial/revenue-expenses'] });
    queryClient.invalidateQueries({ queryKey: ['/api/financial/expense-categories'] });
    queryClient.invalidateQueries({ queryKey: ['/api/financial/project-financials'] });
    queryClient.invalidateQueries({ queryKey: ['/api/financial/trends'] });
    queryClient.invalidateQueries({ queryKey: ['/api/financial/cash-flow'] });
    toast({
      title: "تم تحديث البيانات",
      description: "تم تحديث بيانات التقارير المالية بنجاح",
    });
  };

  const handleExportReport = () => {
    toast({
      title: "تصدير التقرير",
      description: "سيتم توفير وظيفة تصدير التقرير قريبًا",
    });
  };

  // حساب إجمالي الإيرادات
  const getTotalRevenue = () => {
    if (!revenueExpenseData) return 0;
    return revenueExpenseData.reduce((total, item) => total + item.revenue, 0);
  };

  // حساب إجمالي المصروفات
  const getTotalExpenses = () => {
    if (!revenueExpenseData) return 0;
    return revenueExpenseData.reduce((total, item) => total + item.expenses, 0);
  };

  // حساب إجمالي الأرباح
  const getTotalProfit = () => {
    if (!revenueExpenseData) return 0;
    return revenueExpenseData.reduce((total, item) => total + item.profit, 0);
  };

  // حساب نسبة الربحية
  const getProfitabilityPercentage = () => {
    const totalRevenue = getTotalRevenue();
    const totalProfit = getTotalProfit();
    
    if (totalRevenue === 0) return 0;
    return Math.round((totalProfit / totalRevenue) * 100);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">التقارير المالية</h2>
          <p className="text-muted-foreground">
            تحليل شامل للإيرادات والمصروفات والأرباح على مستوى المشاريع والشركة
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="كل المشاريع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل المشاريع</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={timeframe} onValueChange={handleTimeframeChange}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="ml-2 h-4 w-4" />
              <SelectValue placeholder="الإطار الزمني" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="quarter">آخر ربع سنة</SelectItem>
              <SelectItem value="year">آخر سنة</SelectItem>
              <SelectItem value="all">كل الفترات</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={reportType} onValueChange={handleReportTypeChange}>
            <SelectTrigger className="w-[160px]">
              <Filter className="ml-2 h-4 w-4" />
              <SelectValue placeholder="نوع التقرير" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="income">قائمة الدخل</SelectItem>
              <SelectItem value="expense">المصروفات</SelectItem>
              <SelectItem value="cashFlow">التدفق النقدي</SelectItem>
              <SelectItem value="profitability">الربحية</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={handleRefresh}>
            <RefreshCw className="ml-2 h-4 w-4" />
            تحديث
          </Button>
          
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="ml-2 h-4 w-4" />
            تصدير
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">إجمالي الإيرادات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 rounded-full w-12 h-12 mb-2">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(getTotalRevenue())}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                خلال {timeframe === 'quarter' ? 'الربع الأخير' : timeframe === 'year' ? 'السنة الأخيرة' : 'كل الفترات'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">إجمالي المصروفات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 rounded-full w-12 h-12 mb-2">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(getTotalExpenses())}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                خلال {timeframe === 'quarter' ? 'الربع الأخير' : timeframe === 'year' ? 'السنة الأخيرة' : 'كل الفترات'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">صافي الأرباح</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 rounded-full w-12 h-12 mb-2">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(getTotalProfit())}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                خلال {timeframe === 'quarter' ? 'الربع الأخير' : timeframe === 'year' ? 'السنة الأخيرة' : 'كل الفترات'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">نسبة الربحية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 rounded-full w-12 h-12 mb-2">
                {getProfitabilityPercentage() >= 0 ? (
                  <TrendingUp className="h-6 w-6 text-primary" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-destructive" />
                )}
              </div>
              <p className={`text-3xl font-bold ${getProfitabilityPercentage() >= 0 ? 'text-primary' : 'text-destructive'}`}>
                {getProfitabilityPercentage()}%
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                من إجمالي الإيرادات
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="incomeStatement">
        <TabsList className="mb-4">
          <TabsTrigger value="incomeStatement">قائمة الدخل</TabsTrigger>
          <TabsTrigger value="expenses">تحليل المصروفات</TabsTrigger>
          <TabsTrigger value="cashFlow">التدفق النقدي</TabsTrigger>
          <TabsTrigger value="projects">المشاريع</TabsTrigger>
        </TabsList>
        
        <TabsContent value="incomeStatement">
          <Card>
            <CardHeader>
              <CardTitle>قائمة الدخل</CardTitle>
              <CardDescription>
                تحليل الإيرادات والمصروفات والأرباح عبر الفترة الزمنية
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart
                  data={revenueExpenseData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(value as number), '']} 
                  />
                  <Legend />
                  <Bar dataKey="revenue" name="الإيرادات" stackId="a" fill="#8884d8" />
                  <Bar dataKey="expenses" name="المصروفات" stackId="a" fill="#82ca9d" />
                  <Line type="monotone" dataKey="profit" name="صافي الربح" stroke="#ff7300" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>جدول قائمة الدخل</CardTitle>
                <CardDescription>
                  تفاصيل الإيرادات والمصروفات والأرباح حسب الشهر
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-muted border-b">
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الشهر</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الإيرادات</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المصروفات</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">صافي الربح</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">نسبة الربحية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {revenueExpenseData?.map((item, index) => {
                        const profitability = item.revenue > 0 ? 
                          Math.round((item.profit / item.revenue) * 100) : 0;
                        
                        return (
                          <tr key={index} className="border-b hover:bg-muted/50">
                            <td className="p-4 align-middle font-medium">{item.month}</td>
                            <td className="p-4 align-middle">{formatCurrency(item.revenue)}</td>
                            <td className="p-4 align-middle">{formatCurrency(item.expenses)}</td>
                            <td className={`p-4 align-middle ${item.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(item.profit)}
                            </td>
                            <td className={`p-4 align-middle ${profitability >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {profitability}%
                            </td>
                          </tr>
                        );
                      })}
                      <tr className="bg-muted/50 font-medium">
                        <td className="p-4 align-middle">الإجمالي</td>
                        <td className="p-4 align-middle">{formatCurrency(getTotalRevenue())}</td>
                        <td className="p-4 align-middle">{formatCurrency(getTotalExpenses())}</td>
                        <td className={`p-4 align-middle ${getTotalProfit() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(getTotalProfit())}
                        </td>
                        <td className={`p-4 align-middle ${getProfitabilityPercentage() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {getProfitabilityPercentage()}%
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="expenses">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <Card>
              <CardHeader>
                <CardTitle>توزيع المصروفات حسب الفئة</CardTitle>
                <CardDescription>
                  النسب المئوية للمصروفات حسب كل فئة
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="w-full max-w-md">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={expenseCategoryData}
                        dataKey="value"
                        nameKey="category"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        label={({ category, percent }) => `${category}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {expenseCategoryData?.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => [formatCurrency(value as number), '']} 
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>المصروفات حسب الفئة</CardTitle>
                <CardDescription>
                  مقارنة المصروفات لكل فئة من فئات التكاليف
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={expenseCategoryData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis type="category" dataKey="category" />
                    <Tooltip
                      formatter={(value) => [formatCurrency(value as number), '']} 
                    />
                    <Legend />
                    <Bar dataKey="value" name="المصروفات" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>تفاصيل المصروفات حسب الفئة</CardTitle>
              <CardDescription>
                قائمة بفئات المصروفات المختلفة وقيمها
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-muted border-b">
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">فئة المصروفات</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المبلغ</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">النسبة من الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenseCategoryData?.map((item, index) => {
                      const totalExpenses = expenseCategoryData.reduce((total, item) => total + item.value, 0);
                      const percentage = Math.round((item.value / totalExpenses) * 100);
                      
                      return (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="p-4 align-middle font-medium">{item.category}</td>
                          <td className="p-4 align-middle">{formatCurrency(item.value)}</td>
                          <td className="p-4 align-middle">
                            <div className="w-full bg-muted rounded-full h-2.5 mb-1">
                              <div 
                                className="bg-primary h-2.5 rounded-full" 
                                style={{ width: `${percentage}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-muted-foreground">{percentage}%</span>
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted/50 font-medium">
                      <td className="p-4 align-middle">الإجمالي</td>
                      <td className="p-4 align-middle">
                        {formatCurrency(expenseCategoryData?.reduce((total, item) => total + item.value, 0) || 0)}
                      </td>
                      <td className="p-4 align-middle">100%</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="cashFlow">
          <Card>
            <CardHeader>
              <CardTitle>التدفق النقدي</CardTitle>
              <CardDescription>
                تحليل التدفق النقدي الداخل والخارج والرصيد عبر الفترة الزمنية
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart
                  data={cashFlowData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(value as number), '']} 
                  />
                  <Legend />
                  <Bar dataKey="inflow" name="التدفق الداخل" fill="#82ca9d" />
                  <Bar dataKey="outflow" name="التدفق الخارج" fill="#ff7300" />
                  <Line type="monotone" dataKey="balance" name="الرصيد" stroke="#8884d8" />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>جدول التدفق النقدي</CardTitle>
                <CardDescription>
                  تفاصيل التدفق النقدي الداخل والخارج والرصيد حسب الشهر
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-muted border-b">
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الشهر</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">التدفق الداخل</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">التدفق الخارج</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">صافي التدفق</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الرصيد</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cashFlowData?.map((item, index) => {
                        const netFlow = item.inflow - item.outflow;
                        
                        return (
                          <tr key={index} className="border-b hover:bg-muted/50">
                            <td className="p-4 align-middle font-medium">{item.month}</td>
                            <td className="p-4 align-middle text-green-600">{formatCurrency(item.inflow)}</td>
                            <td className="p-4 align-middle text-red-600">{formatCurrency(item.outflow)}</td>
                            <td className={`p-4 align-middle ${netFlow >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(netFlow)}
                            </td>
                            <td className={`p-4 align-middle ${item.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(item.balance)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="projects">
          <Card>
            <CardHeader>
              <CardTitle>الأداء المالي للمشاريع</CardTitle>
              <CardDescription>
                مقارنة الميزانية، المصروفات، الإيرادات والربحية للمشاريع
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={projectFinancialData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="projectName" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(value as number), '']} 
                  />
                  <Legend />
                  <Bar dataKey="budget" name="الميزانية" fill="#8884d8" />
                  <Bar dataKey="spent" name="المصروفات" fill="#82ca9d" />
                  <Bar dataKey="revenue" name="الإيرادات" fill="#ffc658" />
                  <Bar dataKey="profit" name="الأرباح" fill="#ff7300" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>جدول الأداء المالي للمشاريع</CardTitle>
                <CardDescription>
                  تفاصيل مالية لكل مشروع
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-muted border-b">
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المشروع</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الميزانية</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المصروفات</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الإيرادات</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">صافي الربح</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">نسبة الربحية</th>
                      </tr>
                    </thead>
                    <tbody>
                      {projectFinancialData?.map((project, index) => {
                        const profitability = project.revenue > 0 ? 
                          Math.round((project.profit / project.revenue) * 100) : 0;
                        
                        return (
                          <tr key={index} className="border-b hover:bg-muted/50">
                            <td className="p-4 align-middle font-medium">{project.projectName}</td>
                            <td className="p-4 align-middle">{formatCurrency(project.budget)}</td>
                            <td className="p-4 align-middle">{formatCurrency(project.spent)}</td>
                            <td className="p-4 align-middle">{formatCurrency(project.revenue)}</td>
                            <td className={`p-4 align-middle ${project.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {formatCurrency(project.profit)}
                            </td>
                            <td className={`p-4 align-middle ${profitability >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {profitability}%
                            </td>
                          </tr>
                        );
                      })}
                      <tr className="bg-muted/50 font-medium">
                        <td className="p-4 align-middle">الإجمالي</td>
                        <td className="p-4 align-middle">
                          {formatCurrency(projectFinancialData?.reduce((total, item) => total + item.budget, 0) || 0)}
                        </td>
                        <td className="p-4 align-middle">
                          {formatCurrency(projectFinancialData?.reduce((total, item) => total + item.spent, 0) || 0)}
                        </td>
                        <td className="p-4 align-middle">
                          {formatCurrency(projectFinancialData?.reduce((total, item) => total + item.revenue, 0) || 0)}
                        </td>
                        <td className="p-4 align-middle">
                          {formatCurrency(projectFinancialData?.reduce((total, item) => total + item.profit, 0) || 0)}
                        </td>
                        <td className="p-4 align-middle">
                          {Math.round((projectFinancialData?.reduce((total, item) => total + item.profit, 0) || 0) / 
                            (projectFinancialData?.reduce((total, item) => total + item.revenue, 0) || 1) * 100)}%
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// وظائف مساعدة لتوليد بيانات تجريبية

const getMockRevenueExpenseData = (timeframe: string): RevenueExpenseData[] => {
  const data: RevenueExpenseData[] = [];
  let months = 0;
  
  switch (timeframe) {
    case 'quarter':
      months = 3;
      break;
    case 'year':
      months = 12;
      break;
    case 'all':
      months = 24;
      break;
    default:
      months = 12;
  }
  
  const today = new Date();
  const monthNames = [
    'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  for (let i = months - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setMonth(today.getMonth() - i);
    
    const monthName = monthNames[date.getMonth()];
    
    // توليد بيانات عشوائية
    const revenue = Math.floor(Math.random() * 500000) + 1000000;
    const expenses = Math.floor(Math.random() * 400000) + 800000;
    const profit = revenue - expenses;
    
    data.push({
      month: monthName,
      revenue,
      expenses,
      profit,
    });
  }
  
  return data;
};

const getMockExpenseCategoryData = (): ExpenseCategoryData[] => {
  return [
    { category: 'المواد والخامات', value: 625000 },
    { category: 'رواتب ومكافآت', value: 950000 },
    { category: 'معدات وآلات', value: 350000 },
    { category: 'مصاريف إدارية', value: 220000 },
    { category: 'نقل ومواصلات', value: 180000 },
    { category: 'تشغيل وصيانة', value: 140000 },
    { category: 'أخرى', value: 85000 },
  ];
};

const getMockProjectFinancialData = (projects: Project[]): ProjectFinancialData[] => {
  if (!projects.length) {
    return [
      { projectName: 'مشروع إنشاء مبنى سكني', budget: 1500000, spent: 950000, revenue: 1800000, profit: 850000 },
      { projectName: 'تطوير البنية التحتية للطرق', budget: 3500000, spent: 1200000, revenue: 4200000, profit: 3000000 },
      { projectName: 'إنشاء محطة توليد كهرباء', budget: 8500000, spent: 4600000, revenue: 9500000, profit: 4900000 },
      { projectName: 'تجديد مبنى إداري', budget: 750000, spent: 720000, revenue: 900000, profit: 180000 },
      { projectName: 'تطوير نظام مياه', budget: 2200000, spent: 980000, revenue: 2500000, profit: 1520000 },
    ];
  }
  
  return projects.map(project => ({
    projectName: project.name,
    budget: Math.floor(Math.random() * 5000000) + 1000000,
    spent: Math.floor(Math.random() * 3000000) + 500000,
    revenue: Math.floor(Math.random() * 6000000) + 1500000,
    profit: 0, // سيتم حسابه
  })).map(project => ({
    ...project,
    profit: project.revenue - project.spent,
  }));
};

const getMockFinancialTrendData = (timeframe: string): FinancialTrendData[] => {
  const data: FinancialTrendData[] = [];
  let quarters = 0;
  
  switch (timeframe) {
    case 'quarter':
      quarters = 4;
      break;
    case 'year':
      quarters = 8;
      break;
    case 'all':
      quarters = 12;
      break;
    default:
      quarters = 8;
  }
  
  const currentYear = new Date().getFullYear();
  const currentQuarter = Math.floor(new Date().getMonth() / 3) + 1;
  
  for (let i = quarters - 1; i >= 0; i--) {
    let year = currentYear;
    let quarter = currentQuarter - i;
    
    // التعامل مع الأرباع السالبة (السنة السابقة)
    while (quarter <= 0) {
      year--;
      quarter += 4;
    }
    
    // التعامل مع الأرباع التي تزيد عن 4 (السنة التالية)
    while (quarter > 4) {
      year++;
      quarter -= 4;
    }
    
    // توليد بيانات عشوائية
    const revenue = Math.floor(Math.random() * 2000000) + 3000000;
    const expenses = Math.floor(Math.random() * 1500000) + 2500000;
    const profit = revenue - expenses;
    
    data.push({
      year: year.toString(),
      quarter: `ر${quarter}`,
      revenue,
      expenses,
      profit,
    });
  }
  
  return data;
};

const getMockCashFlowData = (timeframe: string): CashFlowData[] => {
  const data: CashFlowData[] = [];
  let months = 0;
  
  switch (timeframe) {
    case 'quarter':
      months = 3;
      break;
    case 'year':
      months = 12;
      break;
    case 'all':
      months = 24;
      break;
    default:
      months = 12;
  }
  
  const today = new Date();
  const monthNames = [
    'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  let balance = 1000000; // رصيد افتتاحي
  
  for (let i = months - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setMonth(today.getMonth() - i);
    
    const monthName = monthNames[date.getMonth()];
    
    // توليد بيانات عشوائية
    const inflow = Math.floor(Math.random() * 500000) + 800000;
    const outflow = Math.floor(Math.random() * 400000) + 700000;
    
    // تحديث الرصيد
    balance = balance + inflow - outflow;
    
    data.push({
      month: monthName,
      inflow,
      outflow,
      balance,
    });
  }
  
  return data;
};

export default FinancialReport;