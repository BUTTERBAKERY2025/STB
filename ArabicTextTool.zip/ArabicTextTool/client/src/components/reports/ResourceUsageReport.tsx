import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Project } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  PieChart, 
  Pie, 
  Cell, 
  AreaChart,
  Area,
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis
} from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { RefreshCw, Download, Calendar, Filter } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, formatNumber } from '@/lib/utils';

// نوع بيانات استخدام الموارد
type ResourceUsageData = {
  resourceType: string;
  allocation: number;
  usage: number;
  efficiency: number;
  cost: number;
};

// نوع بيانات استخدام الموارد عبر الزمن
type ResourceTimeData = {
  date: string;
  equipment: number;
  labor: number;
  materials: number;
};

// نوع بيانات استخدام الموارد حسب المشروع
type ResourceProjectData = {
  projectName: string;
  equipment: number;
  labor: number;
  materials: number;
};

// نوع بيانات كفاءة استخدام الموارد
type ResourceEfficiencyData = {
  resource: string;
  efficiency: number;
  ideal: number;
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

const ResourceUsageReport = () => {
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [timeframe, setTimeframe] = useState('month'); // week, month, quarter, year
  const [resourceType, setResourceType] = useState('all'); // all, equipment, labor, materials
  const { toast } = useToast();

  // استعلام لجلب بيانات المشاريع
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // استعلام لبيانات استخدام الموارد - ربط مباشر بواجهة API
  const { data: resourceData, isLoading: isLoadingResource } = useQuery<ResourceUsageData[]>({
    queryKey: ['/api/resource-usage', selectedProject, timeframe, resourceType],
    enabled: true,
  });

  // استعلام لبيانات استخدام الموارد عبر الزمن - ربط مباشر بواجهة API
  const { data: timeData, isLoading: isLoadingTime } = useQuery<ResourceTimeData[]>({
    queryKey: ['/api/resource-time-usage', selectedProject, timeframe],
    enabled: true,
  });

  // استعلام لبيانات استخدام الموارد حسب المشروع - ربط مباشر بواجهة API
  const { data: projectData, isLoading: isLoadingProject } = useQuery<ResourceProjectData[]>({
    queryKey: ['/api/resource-project-usage', timeframe],
    enabled: !!projects.length,
  });

  // استعلام لبيانات كفاءة استخدام الموارد - ربط مباشر بواجهة API
  const { data: efficiencyData, isLoading: isLoadingEfficiency } = useQuery<ResourceEfficiencyData[]>({
    queryKey: ['/api/resource-efficiency', selectedProject, timeframe],
    enabled: true,
  });

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  const handleTimeframeChange = (value: string) => {
    setTimeframe(value);
  };

  const handleResourceTypeChange = (value: string) => {
    setResourceType(value);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/resource-usage'] });
    queryClient.invalidateQueries({ queryKey: ['/api/resource-time-usage'] });
    queryClient.invalidateQueries({ queryKey: ['/api/resource-project-usage'] });
    queryClient.invalidateQueries({ queryKey: ['/api/resource-efficiency'] });
    toast({
      title: "تم تحديث البيانات",
      description: "تم تحديث بيانات تقرير استخدام الموارد بنجاح",
    });
  };

  const handleExportReport = () => {
    toast({
      title: "تصدير التقرير",
      description: "سيتم توفير وظيفة تصدير التقرير قريبًا",
    });
  };

  const getTotalCost = () => {
    if (!resourceData) return 0;
    return resourceData.reduce((total, item) => total + item.cost, 0);
  };

  const getAverageEfficiency = () => {
    if (!resourceData) return 0;
    const total = resourceData.reduce((total, item) => total + item.efficiency, 0);
    return Math.round(total / resourceData.length);
  };

  // حساب النسبة المئوية للفرق بين التخصيص والاستخدام
  const getUsagePercentage = () => {
    if (!resourceData) return 0;
    const totalAllocation = resourceData.reduce((total, item) => total + item.allocation, 0);
    const totalUsage = resourceData.reduce((total, item) => total + item.usage, 0);
    
    if (totalAllocation === 0) return 0;
    return Math.round((totalUsage / totalAllocation) * 100);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">تقارير استخدام الموارد</h2>
          <p className="text-muted-foreground">
            تحليل استخدام الموارد وكفاءتها في المشاريع
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="كل المشاريع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل المشاريع</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={timeframe} onValueChange={handleTimeframeChange}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="ml-2 h-4 w-4" />
              <SelectValue placeholder="الإطار الزمني" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">آخر أسبوع</SelectItem>
              <SelectItem value="month">آخر شهر</SelectItem>
              <SelectItem value="quarter">آخر ربع سنة</SelectItem>
              <SelectItem value="year">آخر سنة</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={resourceType} onValueChange={handleResourceTypeChange}>
            <SelectTrigger className="w-[160px]">
              <Filter className="ml-2 h-4 w-4" />
              <SelectValue placeholder="نوع المورد" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الموارد</SelectItem>
              <SelectItem value="equipment">المعدات</SelectItem>
              <SelectItem value="labor">العمالة</SelectItem>
              <SelectItem value="materials">المواد</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={handleRefresh}>
            <RefreshCw className="ml-2 h-4 w-4" />
            تحديث
          </Button>
          
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="ml-2 h-4 w-4" />
            تصدير
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">إجمالي تكلفة الموارد</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(getTotalCost())}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                خلال الفترة {timeframe === 'week' ? 'الأسبوعية' : timeframe === 'month' ? 'الشهرية' : timeframe === 'quarter' ? 'الربع سنوية' : 'السنوية'}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">متوسط كفاءة الاستخدام</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {getAverageEfficiency()}%
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                (النسبة المثالية: 100%)
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">نسبة استخدام الموارد</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {getUsagePercentage()}%
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                من إجمالي الموارد المخصصة
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="distribution">
        <TabsList className="mb-4">
          <TabsTrigger value="distribution">توزيع الموارد</TabsTrigger>
          <TabsTrigger value="timeline">الاستخدام عبر الزمن</TabsTrigger>
          <TabsTrigger value="by-project">التوزيع حسب المشروع</TabsTrigger>
          <TabsTrigger value="efficiency">تحليل الكفاءة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="distribution">
          <Card>
            <CardHeader>
              <CardTitle>توزيع استخدام الموارد</CardTitle>
              <CardDescription>
                النسب المئوية لاستخدام الموارد حسب النوع
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div className="w-full max-w-md">
                <ResponsiveContainer width="100%" height={400}>
                  <PieChart>
                    <Pie
                      data={resourceData}
                      dataKey="usage"
                      nameKey="resourceType"
                      cx="50%"
                      cy="50%"
                      outerRadius={150}
                      fill="#8884d8"
                      label={({ resourceType, percent }) => `${resourceType}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {resourceData?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value) => [formatNumber(value as number), 'الاستخدام']} 
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle>استخدام الموارد عبر الزمن</CardTitle>
              <CardDescription>
                مقارنة استخدام الموارد المختلفة على مدار الفترة المحددة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart
                  data={timeData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [formatNumber(value as number), '']} 
                  />
                  <Legend />
                  <Area type="monotone" dataKey="equipment" name="معدات" stackId="1" stroke="#8884d8" fill="#8884d8" />
                  <Area type="monotone" dataKey="labor" name="عمالة" stackId="1" stroke="#82ca9d" fill="#82ca9d" />
                  <Area type="monotone" dataKey="materials" name="مواد" stackId="1" stroke="#ffc658" fill="#ffc658" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="by-project">
          <Card>
            <CardHeader>
              <CardTitle>استخدام الموارد حسب المشروع</CardTitle>
              <CardDescription>
                مقارنة توزيع الموارد عبر المشاريع المختلفة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={projectData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="projectName" />
                  <YAxis />
                  <Tooltip
                    formatter={(value) => [formatNumber(value as number), '']} 
                  />
                  <Legend />
                  <Bar dataKey="equipment" name="معدات" stackId="a" fill="#8884d8" />
                  <Bar dataKey="labor" name="عمالة" stackId="a" fill="#82ca9d" />
                  <Bar dataKey="materials" name="مواد" stackId="a" fill="#ffc658" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="efficiency">
          <Card>
            <CardHeader>
              <CardTitle>تحليل كفاءة استخدام الموارد</CardTitle>
              <CardDescription>
                مقارنة كفاءة استخدام الموارد المختلفة مقابل المعدل المثالي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={efficiencyData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="resource" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar name="الكفاءة الفعلية" dataKey="efficiency" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                  <Radar name="الكفاءة المثالية" dataKey="ideal" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                  <Legend />
                  <Tooltip
                    formatter={(value) => [`${value}%`, '']} 
                  />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ResourceUsageReport;