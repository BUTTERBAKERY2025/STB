import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Project } from "@shared/schema";
import { formatCurrency, formatNumber, formatDate } from "@/lib/utils";
import { 
  AlertTriangle, 
  Calendar, 
  CheckSquare, 
  Clock, 
  Download, 
  Filter, 
  FileBarChart, 
  RefreshCw 
} from "lucide-react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  Tooltip,
  LineChart,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

// نوع بيانات حالة المشاريع
type ProjectStatusData = {
  projectName: string;
  status: string;
  progress: number;
  startDate: string;
  endDate: string;
  daysLeft: number;
  budget: number;
  spent: number;
  budgetVariance: number;
  tasks: {
    completed: number;
    inProgress: number;
    notStarted: number;
    total: number;
  };
  team: {
    assigned: number;
    active: number;
  };
  risk: string; // low, medium, high
};

// نوع بيانات إحصائيات المشاريع
type ProjectStatisticsData = {
  category: string; // نشط، متأخر، مكتمل، متوقف، تخطيط
  value: number;
};

// نوع بيانات الميزانية عبر الزمن
type BudgetTimelineData = {
  month: string;
  planned: number;
  actual: number;
};

// نوع بيانات مخاطر المشاريع
type ProjectRiskData = {
  category: string;
  value: number;
  fullMark: number;
};

// نوع بيانات تقدم المهام
type TaskProgressData = {
  projectName: string;
  completed: number;
  inProgress: number;
  notStarted: number;
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];
const STATUS_COLORS = {
  completed: "#10b981",
  active: "#3b82f6",
  delayed: "#f59e0b",
  onHold: "#6b7280",
  cancelled: "#ef4444",
  planning: "#8b5cf6"
};

const ProjectStatusReport = () => {
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [timeframe, setTimeframe] = useState('quarter'); // month, quarter, year
  const [statusFilter, setStatusFilter] = useState('all'); // all, active, delayed, completed, etc.
  const { toast } = useToast();

  // استعلام لجلب بيانات المشاريع
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // استعلام لبيانات حالة المشاريع
  const { data: projectStatusData, isLoading: isLoadingStatus } = useQuery<ProjectStatusData[]>({
    queryKey: ['/api/projects-status', selectedProject, timeframe, statusFilter],
    enabled: true,
  });

  // استعلام لبيانات إحصائيات المشاريع
  const { data: projectStatisticsData, isLoading: isLoadingStats } = useQuery<ProjectStatisticsData[]>({
    queryKey: ['/api/project-statistics', timeframe],
    enabled: true,
  });

  // استعلام لبيانات الميزانية عبر الزمن
  const { data: budgetTimelineData, isLoading: isLoadingBudget } = useQuery<BudgetTimelineData[]>({
    queryKey: ['/api/budget-timeline', selectedProject, timeframe],
    enabled: true,
  });

  // استعلام لبيانات المخاطر
  const { data: projectRiskData, isLoading: isLoadingRisks } = useQuery<ProjectRiskData[]>({
    queryKey: ['/api/project-risks', selectedProject],
    enabled: true,
  });

  // استعلام لبيانات تقدم المهام
  const { data: taskProgressData, isLoading: isLoadingTasks } = useQuery<TaskProgressData[]>({
    queryKey: ['/api/task-progress', timeframe],
    enabled: true,
  });

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  const handleTimeframeChange = (value: string) => {
    setTimeframe(value);
  };

  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/projects-status'] });
    queryClient.invalidateQueries({ queryKey: ['/api/project-statistics'] });
    queryClient.invalidateQueries({ queryKey: ['/api/budget-timeline'] });
    queryClient.invalidateQueries({ queryKey: ['/api/project-risks'] });
    queryClient.invalidateQueries({ queryKey: ['/api/task-progress'] });
    toast({
      title: "تم تحديث البيانات",
      description: "تم تحديث بيانات تقرير حالة المشاريع بنجاح",
    });
  };

  const handleExportReport = () => {
    toast({
      title: "تصدير التقرير",
      description: "سيتم توفير وظيفة تصدير التقرير قريبًا",
    });
  };

  // استخراج إحصائيات عامة
  const getProjectStats = () => {
    if (!projectStatusData) return { 
      totalProjects: 0, 
      activeProjects: 0, 
      delayedProjects: 0, 
      completedProjects: 0,
      averageProgress: 0
    };

    const total = projectStatusData.length;
    const active = projectStatusData.filter(p => p.status === 'active').length;
    const delayed = projectStatusData.filter(p => p.status === 'delayed').length;
    const completed = projectStatusData.filter(p => p.status === 'completed').length;
    const avgProgress = projectStatusData.reduce((sum, p) => sum + p.progress, 0) / total;

    return {
      totalProjects: total,
      activeProjects: active,
      delayedProjects: delayed,
      completedProjects: completed,
      averageProgress: Math.round(avgProgress)
    };
  };

  // الحصول على إجمالي الميزانية المخصصة
  const getTotalBudget = () => {
    if (!projectStatusData) return 0;
    return projectStatusData.reduce((total, item) => total + item.budget, 0);
  };

  // الحصول على إجمالي المصروفات
  const getTotalSpent = () => {
    if (!projectStatusData) return 0;
    return projectStatusData.reduce((total, item) => total + item.spent, 0);
  };

  // حساب نسبة الالتزام بالميزانية
  const getBudgetVariancePercentage = () => {
    const totalBudget = getTotalBudget();
    const totalSpent = getTotalSpent();
    
    if (totalBudget === 0) return 0;
    return Math.round(((totalBudget - totalSpent) / totalBudget) * 100);
  };

  // تنسيق حالة المشروع باللون المناسب
  const formatStatus = (status: string) => {
    const statusMap: Record<string, { label: string, color: string }> = {
      'completed': { label: 'مكتمل', color: STATUS_COLORS.completed },
      'active': { label: 'نشط', color: STATUS_COLORS.active },
      'delayed': { label: 'متأخر', color: STATUS_COLORS.delayed },
      'onHold': { label: 'متوقف', color: STATUS_COLORS.onHold },
      'cancelled': { label: 'ملغي', color: STATUS_COLORS.cancelled },
      'planning': { label: 'تخطيط', color: STATUS_COLORS.planning }
    };

    const statusInfo = statusMap[status] || { label: status, color: '#6b7280' };
    
    return (
      <div className="flex items-center">
        <div 
          className="w-3 h-3 rounded-full mr-2" 
          style={{ backgroundColor: statusInfo.color }}
        ></div>
        <span>{statusInfo.label}</span>
      </div>
    );
  };

  const stats = getProjectStats();

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center flex-wrap gap-2">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">تقارير حالة المشاريع</h2>
          <p className="text-muted-foreground">
            نظرة شاملة عن حالة المشاريع، التقدم، الميزانية والمخاطر
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="كل المشاريع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل المشاريع</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={timeframe} onValueChange={handleTimeframeChange}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="ml-2 h-4 w-4" />
              <SelectValue placeholder="الإطار الزمني" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">آخر شهر</SelectItem>
              <SelectItem value="quarter">آخر ربع سنة</SelectItem>
              <SelectItem value="year">آخر سنة</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={statusFilter} onValueChange={handleStatusFilterChange}>
            <SelectTrigger className="w-[160px]">
              <Filter className="ml-2 h-4 w-4" />
              <SelectValue placeholder="حالة المشروع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="active">نشط</SelectItem>
              <SelectItem value="delayed">متأخر</SelectItem>
              <SelectItem value="completed">مكتمل</SelectItem>
              <SelectItem value="onHold">متوقف</SelectItem>
              <SelectItem value="planning">تخطيط</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={handleRefresh}>
            <RefreshCw className="ml-2 h-4 w-4" />
            تحديث
          </Button>
          
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="ml-2 h-4 w-4" />
            تصدير
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">إجمالي عدد المشاريع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {stats.totalProjects}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                مشروع
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">متوسط نسبة الإنجاز</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {stats.averageProgress}%
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                من كافة المشاريع
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">الالتزام بالميزانية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-primary">
                {getBudgetVariancePercentage()}%
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                متبقي من الميزانية المخصصة
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">المشاريع المتأخرة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <p className="text-3xl font-bold text-destructive">
                {stats.delayedProjects}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                تحتاج إلى متابعة
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="progress">التقدم والإنجاز</TabsTrigger>
          <TabsTrigger value="budget">الميزانية والتكاليف</TabsTrigger>
          <TabsTrigger value="risks">المخاطر والتحديات</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>حالة المشاريع</CardTitle>
              <CardDescription>
                توزيع المشاريع حسب الحالة
              </CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <div className="w-full max-w-md">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={projectStatisticsData}
                      dataKey="value"
                      nameKey="category"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      label={({ category, percent }) => `${category}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {projectStatisticsData?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value) => [formatNumber(value as number), 'عدد المشاريع']} 
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>قائمة المشاريع</CardTitle>
                <CardDescription>
                  عرض تفصيلي لحالة المشاريع ومؤشرات الأداء الرئيسية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-muted border-b">
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">اسم المشروع</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الحالة</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">نسبة الإنجاز</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الأيام المتبقية</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الميزانية</th>
                        <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المخاطر</th>
                      </tr>
                    </thead>
                    <tbody>
                      {projectStatusData?.map((project, index) => (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="p-4 align-middle font-medium">{project.projectName}</td>
                          <td className="p-4 align-middle">{formatStatus(project.status)}</td>
                          <td className="p-4 align-middle">
                            <div className="w-full bg-muted rounded-full h-2.5 mb-1">
                              <div className="bg-primary h-2.5 rounded-full" style={{ width: `${project.progress}%` }}></div>
                            </div>
                            <span className="text-xs text-muted-foreground">{project.progress}%</span>
                          </td>
                          <td className="p-4 align-middle">
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 ml-1" />
                              <span>{project.daysLeft} يوم</span>
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <div>
                              <div>{formatCurrency(project.spent)} / {formatCurrency(project.budget)}</div>
                              <div className="text-xs text-muted-foreground">{Math.round((project.spent / project.budget) * 100)}% من الميزانية</div>
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <div className={`
                              inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium
                              ${project.risk === 'low' ? 'bg-green-100 text-green-800' :
                                project.risk === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'}
                            `}>
                              <AlertTriangle className={`h-3 w-3 ml-1 ${
                                project.risk === 'low' ? 'text-green-500' :
                                project.risk === 'medium' ? 'text-yellow-500' :
                                'text-red-500'
                              }`} />
                              {project.risk === 'low' ? 'منخفضة' :
                               project.risk === 'medium' ? 'متوسطة' : 'عالية'}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="progress">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <Card>
              <CardHeader>
                <CardTitle>تقدم المهام حسب المشروع</CardTitle>
                <CardDescription>
                  توزيع المهام المكتملة، قيد التنفيذ، والمتبقية لكل مشروع
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={taskProgressData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis type="category" dataKey="projectName" />
                    <Tooltip
                      formatter={(value) => [formatNumber(value as number), 'عدد المهام']} 
                    />
                    <Legend />
                    <Bar dataKey="completed" name="مكتملة" stackId="a" fill="#10b981" />
                    <Bar dataKey="inProgress" name="قيد التنفيذ" stackId="a" fill="#3b82f6" />
                    <Bar dataKey="notStarted" name="لم تبدأ" stackId="a" fill="#6b7280" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>متوسط نسبة الإنجاز مع مرور الوقت</CardTitle>
                <CardDescription>
                  تطور نسبة الإنجاز خلال الفترة الزمنية المحددة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart
                    data={budgetTimelineData?.map(item => ({
                      month: item.month,
                      average: Math.round(Math.random() * 30) + 50, // بيانات تجريبية للتوضيح فقط
                    }))}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, 'نسبة الإنجاز']} 
                    />
                    <Legend />
                    <Line type="monotone" dataKey="average" name="متوسط الإنجاز" stroke="#3b82f6" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>إنجاز المهام عبر الوقت</CardTitle>
              <CardDescription>
                معدل إنجاز المهام خلال الفترة الزمنية المحددة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart
                  data={budgetTimelineData?.map(item => ({
                    month: item.month,
                    completed: Math.round(Math.random() * 20) + 10,
                    inProgress: Math.round(Math.random() * 15) + 5,
                  }))}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [formatNumber(value as number), 'عدد المهام']} 
                  />
                  <Legend />
                  <Line type="monotone" dataKey="completed" name="مهام مكتملة" stroke="#10b981" />
                  <Line type="monotone" dataKey="inProgress" name="مهام قيد التنفيذ" stroke="#3b82f6" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="budget">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <Card>
              <CardHeader>
                <CardTitle>الميزانية المخططة مقابل الفعلية</CardTitle>
                <CardDescription>
                  مقارنة الميزانية المخططة مع المصروفات الفعلية عبر الفترة الزمنية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={budgetTimelineData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [formatCurrency(value as number), '']} 
                    />
                    <Legend />
                    <Bar name="الميزانية المخططة" dataKey="planned" fill="#8884d8" />
                    <Bar name="المصروفات الفعلية" dataKey="actual" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>توزيع المصروفات حسب المشروع</CardTitle>
                <CardDescription>
                  النسبة المئوية للمصروفات الفعلية لكل مشروع
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="w-full max-w-md">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={projectStatusData?.map(project => ({
                          name: project.projectName,
                          value: project.spent
                        }))}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {projectStatusData?.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => [formatCurrency(value as number), 'المصروفات']} 
                      />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>نسبة الالتزام بالميزانية حسب المشروع</CardTitle>
              <CardDescription>
                نسبة المصروفات الفعلية مقارنة بالميزانية المخططة لكل مشروع
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-muted border-b">
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">اسم المشروع</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الميزانية المخططة</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المصروفات الفعلية</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">المبلغ المتبقي</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">نسبة الالتزام</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectStatusData?.map((project, index) => {
                      const remainingBudget = project.budget - project.spent;
                      const adherencePercentage = Math.round((remainingBudget / project.budget) * 100);
                      
                      return (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="p-4 align-middle font-medium">{project.projectName}</td>
                          <td className="p-4 align-middle">{formatCurrency(project.budget)}</td>
                          <td className="p-4 align-middle">{formatCurrency(project.spent)}</td>
                          <td className="p-4 align-middle">{formatCurrency(remainingBudget)}</td>
                          <td className={`p-4 align-middle ${adherencePercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {adherencePercentage}%
                          </td>
                        </tr>
                      );
                    })}
                    <tr className="bg-muted/50 font-medium">
                      <td className="p-4 align-middle">الإجمالي</td>
                      <td className="p-4 align-middle">{formatCurrency(getTotalBudget())}</td>
                      <td className="p-4 align-middle">{formatCurrency(getTotalSpent())}</td>
                      <td className="p-4 align-middle">{formatCurrency(getTotalBudget() - getTotalSpent())}</td>
                      <td className={`p-4 align-middle ${getBudgetVariancePercentage() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {getBudgetVariancePercentage()}%
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="risks">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <Card>
              <CardHeader>
                <CardTitle>تحليل المخاطر</CardTitle>
                <CardDescription>
                  تقييم مستويات المخاطر حسب الفئة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={projectRiskData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="category" />
                    <PolarRadiusAxis angle={90} domain={[0, 100]} />
                    <Radar name="مستوى المخاطر" dataKey="value" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                    <Legend />
                    <Tooltip formatter={(value) => [`${value}%`, 'مستوى المخاطر']} />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>توزيع المخاطر حسب المشروع</CardTitle>
                <CardDescription>
                  النسبة المئوية للمشاريع حسب مستوى المخاطر
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="w-full max-w-md">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'منخفضة', value: projectStatusData?.filter(p => p.risk === 'low').length || 0 },
                          { name: 'متوسطة', value: projectStatusData?.filter(p => p.risk === 'medium').length || 0 },
                          { name: 'عالية', value: projectStatusData?.filter(p => p.risk === 'high').length || 0 },
                        ]}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        <Cell fill="#10b981" />
                        <Cell fill="#f59e0b" />
                        <Cell fill="#ef4444" />
                      </Pie>
                      <Legend />
                      <Tooltip formatter={(value) => [formatNumber(value as number), 'عدد المشاريع']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>تقييم المخاطر للمشاريع</CardTitle>
              <CardDescription>
                تفاصيل المخاطر والتحديات لكل مشروع
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-muted border-b">
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">اسم المشروع</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">الحالة</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">مستوى المخاطر</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">تحديات الجدول الزمني</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">تحديات الميزانية</th>
                      <th className="h-12 px-4 text-right align-middle font-medium text-muted-foreground">إجراءات الحد من المخاطر</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projectStatusData?.map((project, index) => {
                      const timelineChallenges = project.daysLeft < 30 ? 'عالية' : project.daysLeft < 90 ? 'متوسطة' : 'منخفضة';
                      const budgetChallenges = (project.spent / project.budget) > 0.8 ? 'عالية' : (project.spent / project.budget) > 0.6 ? 'متوسطة' : 'منخفضة';
                      
                      return (
                        <tr key={index} className="border-b hover:bg-muted/50">
                          <td className="p-4 align-middle font-medium">{project.projectName}</td>
                          <td className="p-4 align-middle">{formatStatus(project.status)}</td>
                          <td className="p-4 align-middle">
                            <div className={`
                              inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium
                              ${project.risk === 'low' ? 'bg-green-100 text-green-800' :
                                project.risk === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'}
                            `}>
                              <AlertTriangle className={`h-3 w-3 ml-1 ${
                                project.risk === 'low' ? 'text-green-500' :
                                project.risk === 'medium' ? 'text-yellow-500' :
                                'text-red-500'
                              }`} />
                              {project.risk === 'low' ? 'منخفضة' :
                               project.risk === 'medium' ? 'متوسطة' : 'عالية'}
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <div className={`
                              inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium
                              ${timelineChallenges === 'منخفضة' ? 'bg-green-100 text-green-800' :
                                timelineChallenges === 'متوسطة' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'}
                            `}>
                              {timelineChallenges}
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <div className={`
                              inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium
                              ${budgetChallenges === 'منخفضة' ? 'bg-green-100 text-green-800' :
                                budgetChallenges === 'متوسطة' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-red-100 text-red-800'}
                            `}>
                              {budgetChallenges}
                            </div>
                          </td>
                          <td className="p-4 align-middle">
                            <Button variant="outline" size="sm">
                              <CheckSquare className="h-3 w-3 ml-1" />
                              عرض الإجراءات
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProjectStatusReport;