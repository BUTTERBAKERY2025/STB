import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Project } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { RefreshCw, Download, Calendar } from 'lucide-react';
import { queryClient } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/utils';

// نوع البيانات لتقارير أداء المشروع
type ProjectPerformanceData = {
  projectId: number;
  projectName: string;
  plannedCompletion: number; // النسبة المخطط لها للإكمال
  actualCompletion: number; // النسبة الفعلية للإكمال
  plannedCost: number; // التكلفة المخططة
  actualCost: number; // التكلفة الفعلية
  variance: number; // نسبة الانحراف
  lastUpdated: string; // تاريخ آخر تحديث
};

type TimelineData = {
  date: string;
  plannedCompletion: number;
  actualCompletion: number;
};

type CostData = {
  category: string;
  planned: number;
  actual: number;
};

const ProjectPerformanceReport = () => {
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [timeframe, setTimeframe] = useState('month'); // week, month, quarter, year
  const { toast } = useToast();

  // استعلام لجلب بيانات المشاريع
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // استعلام لبيانات أداء المشروع
  const { data: performanceData, isLoading } = useQuery<ProjectPerformanceData[]>({
    queryKey: ['/api/project-performance', selectedProject, timeframe],
    // استخدام API الحقيقي بدلاً من الدوال الوهمية
    // يعتمد على استخدام المعرفة السابقة في queryClient
    enabled: !!projects.length,
  });

  // بيانات الجدول الزمني
  const { data: timelineData, isLoading: isLoadingTimeline } = useQuery<TimelineData[]>({
    queryKey: ['/api/project-timeline', selectedProject, timeframe],
    // استخدام API الحقيقي
    enabled: !!selectedProject,
  });

  // بيانات تكاليف المشروع
  const { data: costData, isLoading: isLoadingCosts } = useQuery<CostData[]>({
    queryKey: ['/api/project-costs', selectedProject, timeframe],
    // استخدام API الحقيقي
    enabled: !!selectedProject,
  });

  const handleProjectChange = (value: string) => {
    setSelectedProject(value);
  };

  const handleTimeframeChange = (value: string) => {
    setTimeframe(value);
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/project-performance'] });
    queryClient.invalidateQueries({ queryKey: ['/api/project-timeline'] });
    queryClient.invalidateQueries({ queryKey: ['/api/project-costs'] });
    toast({
      title: "تم تحديث البيانات",
      description: "تم تحديث بيانات تقرير أداء المشروع بنجاح",
    });
  };

  const handleExportReport = () => {
    toast({
      title: "تصدير التقرير",
      description: "سيتم توفير وظيفة تصدير التقرير قريبًا",
    });
  };

  // إذا لم يتم اختيار مشروع، اعرض جميع المشاريع في جدول مقارنة
  if (!selectedProject) {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">تقارير أداء المشاريع</h2>
            <p className="text-muted-foreground">عرض ومقارنة أداء جميع المشاريع</p>
          </div>
          <div className="flex gap-2">
            <Select value={timeframe} onValueChange={handleTimeframeChange}>
              <SelectTrigger className="w-[160px]">
                <Calendar className="ml-2 h-4 w-4" />
                <SelectValue placeholder="الإطار الزمني" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">آخر أسبوع</SelectItem>
                <SelectItem value="month">آخر شهر</SelectItem>
                <SelectItem value="quarter">آخر ربع سنة</SelectItem>
                <SelectItem value="year">آخر سنة</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleRefresh}>
              <RefreshCw className="ml-2 h-4 w-4" />
              تحديث
            </Button>
            <Button variant="outline" onClick={handleExportReport}>
              <Download className="ml-2 h-4 w-4" />
              تصدير
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>مقارنة أداء المشاريع</CardTitle>
            <CardDescription>
              مقارنة بين المشاريع من حيث التقدم والتكلفة والجدول الزمني
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              <div>
                <h3 className="font-medium mb-2">مؤشر نسبة الإنجاز المخطط مقابل الفعلي</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={performanceData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="projectName" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, '']}
                      labelFormatter={(label) => `المشروع: ${label}`}
                    />
                    <Legend />
                    <Bar name="النسبة المخططة" dataKey="plannedCompletion" fill="#8884d8" />
                    <Bar name="النسبة الفعلية" dataKey="actualCompletion" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div>
                <h3 className="font-medium mb-2">مؤشر التكلفة المخططة مقابل الفعلية</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={performanceData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="projectName" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [formatCurrency(value as number), '']}
                      labelFormatter={(label) => `المشروع: ${label}`}
                    />
                    <Legend />
                    <Bar name="التكلفة المخططة" dataKey="plannedCost" fill="#8884d8" />
                    <Bar name="التكلفة الفعلية" dataKey="actualCost" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div>
                <h3 className="font-medium mb-2">نسب الانحراف في المشاريع</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={performanceData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="projectName" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value) => [`${value}%`, '']}
                      labelFormatter={(label) => `المشروع: ${label}`}
                    />
                    <Legend />
                    <Bar 
                      name="نسبة الانحراف" 
                      dataKey="variance" 
                      fill="#8884d8"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="mt-8">
              <Select value={selectedProject || ""} onValueChange={handleProjectChange}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="اختر مشروعاً لعرض تفاصيل أدائه" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const selectedProjectData = projects.find(p => p.id === parseInt(selectedProject));

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            تقرير أداء مشروع: {selectedProjectData?.name}
          </h2>
          <p className="text-muted-foreground">
            تحليل تفصيلي لأداء المشروع والمؤشرات الرئيسية
          </p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedProject} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="اختر مشروعاً" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={timeframe} onValueChange={handleTimeframeChange}>
            <SelectTrigger className="w-[160px]">
              <Calendar className="ml-2 h-4 w-4" />
              <SelectValue placeholder="الإطار الزمني" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">آخر أسبوع</SelectItem>
              <SelectItem value="month">آخر شهر</SelectItem>
              <SelectItem value="quarter">آخر ربع سنة</SelectItem>
              <SelectItem value="year">آخر سنة</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleRefresh}>
            <RefreshCw className="ml-2 h-4 w-4" />
            تحديث
          </Button>
          <Button variant="outline" onClick={handleExportReport}>
            <Download className="ml-2 h-4 w-4" />
            تصدير
          </Button>
          <Button variant="outline" onClick={() => setSelectedProject(null)}>
            العودة للمقارنة
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">نسبة الإنجاز</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">المخطط</p>
                <p className="text-2xl font-bold">
                  {performanceData?.[0]?.plannedCompletion || 0}%
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">الفعلي</p>
                <p className="text-2xl font-bold">
                  {performanceData?.[0]?.actualCompletion || 0}%
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">الانحراف</p>
                <p className={`text-2xl font-bold ${(performanceData && performanceData[0] && performanceData[0].variance > 0) ? 'text-red-500' : 'text-green-500'}`}>
                  {performanceData && performanceData[0] ? performanceData[0].variance : 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">التكلفة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">المخططة</p>
                <p className="text-2xl font-bold">
                  {formatCurrency(performanceData?.[0]?.plannedCost || 0)}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">الفعلية</p>
                <p className="text-2xl font-bold">
                  {formatCurrency(performanceData?.[0]?.actualCost || 0)}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">الفرق</p>
                <p className={`text-2xl font-bold ${(performanceData?.[0]?.actualCost || 0) > (performanceData?.[0]?.plannedCost || 0) ? 'text-red-500' : 'text-green-500'}`}>
                  {formatCurrency(Math.abs((performanceData?.[0]?.actualCost || 0) - (performanceData?.[0]?.plannedCost || 0)))}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">آخر تحديث</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">تاريخ التحديث</p>
                <p className="text-2xl font-bold">
                  {performanceData?.[0]?.lastUpdated || 'غير متوفر'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="timeline">
        <TabsList>
          <TabsTrigger value="timeline">الجدول الزمني</TabsTrigger>
          <TabsTrigger value="costs">تفاصيل التكاليف</TabsTrigger>
        </TabsList>
        <TabsContent value="timeline">
          <Card>
            <CardHeader>
              <CardTitle>تطور المشروع عبر الزمن</CardTitle>
              <CardDescription>
                يوضح الرسم البياني نسبة الإنجاز المخططة مقابل الفعلية عبر الزمن
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart
                  data={timelineData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [`${value}%`, '']}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="plannedCompletion" name="النسبة المخططة" stroke="#8884d8" activeDot={{ r: 8 }} />
                  <Line type="monotone" dataKey="actualCompletion" name="النسبة الفعلية" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="costs">
          <Card>
            <CardHeader>
              <CardTitle>تفاصيل التكاليف</CardTitle>
              <CardDescription>
                توزيع التكاليف المخططة والفعلية حسب الفئات
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={costData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="category" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value) => [formatCurrency(value as number), '']}
                  />
                  <Legend />
                  <Bar name="التكلفة المخططة" dataKey="planned" fill="#8884d8" />
                  <Bar name="التكلفة الفعلية" dataKey="actual" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// وظائف مساعدة لتوليد بيانات وهمية للتطوير

const getMockPerformanceData = (projects: Project[], projectId?: number): ProjectPerformanceData[] => {
  if (projectId) {
    const project = projects.find(p => p.id === projectId);
    if (!project) return [];
    
    return [{
      projectId: project.id,
      projectName: project.name,
      plannedCompletion: 75,
      actualCompletion: 65,
      plannedCost: 1200000,
      actualCost: 1350000,
      variance: 10,
      lastUpdated: new Date().toLocaleDateString('ar-SA'),
    }];
  }
  
  return projects.map(project => ({
    projectId: project.id,
    projectName: project.name,
    plannedCompletion: Math.floor(Math.random() * 100),
    actualCompletion: Math.floor(Math.random() * 100),
    plannedCost: Math.floor(Math.random() * 2000000) + 500000,
    actualCost: Math.floor(Math.random() * 2000000) + 500000,
    variance: Math.floor(Math.random() * 30) - 15,
    lastUpdated: new Date().toLocaleDateString('ar-SA'),
  }));
};

const getMockTimelineData = (timeframe: string): TimelineData[] => {
  const data: TimelineData[] = [];
  let days = 0;
  
  switch (timeframe) {
    case 'week':
      days = 7;
      break;
    case 'month':
      days = 30;
      break;
    case 'quarter':
      days = 90;
      break;
    case 'year':
      days = 365;
      break;
    default:
      days = 30;
  }
  
  // عدد النقاط على الرسم البياني
  const dataPoints = timeframe === 'week' ? days : 12;
  const step = Math.max(1, Math.floor(days / dataPoints));
  
  const today = new Date();
  
  for (let i = 0; i < dataPoints; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() - (dataPoints - i - 1) * step);
    
    const planned = Math.min(100, Math.floor((i + 1) * (100 / dataPoints) + Math.random() * 5));
    const actual = Math.min(100, Math.max(0, planned - Math.floor(Math.random() * 20)));
    
    data.push({
      date: date.toLocaleDateString('ar-SA'),
      plannedCompletion: planned,
      actualCompletion: actual,
    });
  }
  
  return data;
};

const getMockCostData = (): CostData[] => {
  return [
    { category: 'مواد', planned: 500000, actual: 530000 },
    { category: 'عمالة', planned: 300000, actual: 350000 },
    { category: 'معدات', planned: 200000, actual: 220000 },
    { category: 'إدارة', planned: 150000, actual: 180000 },
    { category: 'أخرى', planned: 50000, actual: 70000 },
  ];
};

export default ProjectPerformanceReport;