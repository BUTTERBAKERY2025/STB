import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Loader2, TrendingUp, TrendingDown, Info } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

type ProjectProfitability = {
  id: number;
  name: string;
  revenue: number;
  expenses: number;
  profit: number;
  margin: number;
  trend: 'up' | 'down' | 'stable';
  trendPercentage: number;
  status: 'active' | 'completed' | 'planned';
};

type ProfitabilityAnalysisProps = {
  data: ProjectProfitability[];
  loading?: boolean;
  period?: string;
};

const ProfitabilityAnalysis: React.FC<ProfitabilityAnalysisProps> = ({ 
  data, 
  loading = false,
  period = 'الشهر الحالي'
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!data || data.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
        <p>لا توجد بيانات متاحة لتحليل الربحية.</p>
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA') + ' ريال';
  };

  // حساب إجماليات الربحية
  const totalRevenue = data.reduce((acc, project) => acc + project.revenue, 0);
  const totalExpenses = data.reduce((acc, project) => acc + project.expenses, 0);
  const totalProfit = totalRevenue - totalExpenses;
  const averageMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

  // تصنيف المشاريع حسب الربحية
  const profitableProjects = data.filter(p => p.profit > 0);
  const unprofitableProjects = data.filter(p => p.profit <= 0);

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'planned': return 'bg-amber-100 text-amber-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'active': return 'نشط';
      case 'completed': return 'مكتمل';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  return (
    <div className="space-y-6">
      {/* ملخص الربحية الإجمالية */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">إجمالي الإيرادات</p>
              <p className="text-2xl font-semibold">{formatCurrency(totalRevenue)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">إجمالي المصروفات</p>
              <p className="text-2xl font-semibold">{formatCurrency(totalExpenses)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">صافي الربح</p>
              <p className={`text-2xl font-semibold ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatCurrency(Math.abs(totalProfit))}
                {totalProfit < 0 && ' خسارة'}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">متوسط هامش الربح</p>
              <p className={`text-2xl font-semibold ${averageMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {Math.round(averageMargin)}%
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* تحليل ربحية المشاريع */}
      <Card>
        <CardHeader>
          <CardTitle>ربحية المشاريع</CardTitle>
          <CardDescription>
            تحليل ربحية المشاريع {period}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>المشروع</TableHead>
                  <TableHead>الحالة</TableHead>
                  <TableHead>الإيرادات</TableHead>
                  <TableHead>المصروفات</TableHead>
                  <TableHead>الربح</TableHead>
                  <TableHead>هامش الربح</TableHead>
                  <TableHead>اتجاه الربحية</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStatusColor(project.status)}>
                        {getStatusText(project.status)}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatCurrency(project.revenue)}</TableCell>
                    <TableCell>{formatCurrency(project.expenses)}</TableCell>
                    <TableCell className={project.profit >= 0 ? 'text-green-600' : 'text-red-600'}>
                      {formatCurrency(Math.abs(project.profit))}
                      {project.profit < 0 && ' خسارة'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <div className="w-24">
                          <Progress 
                            value={Math.max(0, project.margin)} 
                            className={project.margin >= 0 ? 'bg-green-100' : 'bg-red-100'}
                          />
                        </div>
                        <div className={project.margin >= 0 ? 'text-green-600' : 'text-red-600'}>
                          {Math.round(project.margin)}%
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-1 space-x-reverse">
                        {project.trend === 'up' ? (
                          <TrendingUp className="h-4 w-4 text-green-500" />
                        ) : project.trend === 'down' ? (
                          <TrendingDown className="h-4 w-4 text-red-500" />
                        ) : null}
                        <span className={
                          project.trend === 'up' 
                            ? 'text-green-600' 
                            : project.trend === 'down' 
                              ? 'text-red-600' 
                              : ''
                        }>
                          {project.trend === 'up' ? '+' : ''}
                          {project.trendPercentage}%
                        </span>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger>
                              <Info className="h-4 w-4 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>التغير في الربحية مقارنة بالشهر السابق</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ملخص إحصائي */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>المشاريع الأكثر ربحية</CardTitle>
            <CardDescription>
              ترتيب المشاريع حسب هامش الربح
            </CardDescription>
          </CardHeader>
          <CardContent>
            {profitableProjects.length > 0 ? (
              <div className="space-y-4">
                {profitableProjects
                  .sort((a, b) => b.margin - a.margin)
                  .slice(0, 5)
                  .map((project, index) => (
                    <div key={project.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-muted-foreground w-6">{index + 1}.</span>
                        <span className="font-medium">{project.name}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-green-600 font-medium ml-2">
                          {Math.round(project.margin)}%
                        </span>
                        <span className="text-muted-foreground">
                          ({formatCurrency(project.profit)})
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-4">
                لا توجد مشاريع ذات ربحية حالياً
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>المشاريع الأقل ربحية</CardTitle>
            <CardDescription>
              المشاريع التي تحتاج إلى تحسين
            </CardDescription>
          </CardHeader>
          <CardContent>
            {unprofitableProjects.length > 0 ? (
              <div className="space-y-4">
                {unprofitableProjects
                  .sort((a, b) => a.margin - b.margin)
                  .slice(0, 5)
                  .map((project, index) => (
                    <div key={project.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <span className="text-muted-foreground w-6">{index + 1}.</span>
                        <span className="font-medium">{project.name}</span>
                      </div>
                      <div className="flex items-center">
                        <span className="text-red-600 font-medium ml-2">
                          {Math.round(project.margin)}%
                        </span>
                        <span className="text-muted-foreground">
                          ({formatCurrency(Math.abs(project.profit))} خسارة)
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-4">
                لا توجد مشاريع خاسرة حالياً
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfitabilityAnalysis;