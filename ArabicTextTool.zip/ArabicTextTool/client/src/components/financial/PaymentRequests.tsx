import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { 
  Check, 
  Clock, 
  Download, 
  FileText, 
  Loader2, 
  MoreHorizontal,
  PencilLine,
  Plus
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";

type PaymentRequestItem = {
  id: number;
  paymentRequestId: number;
  itemName: string;
  unit: string;
  unitPrice: number;
  plannedQuantity: number;
  completedQuantity: number;
  completionPercentage: number;
  previousPaymentPercentage: number;
  currentPaymentAmount: number;
};

type PaymentRequest = {
  id: number;
  type: string;
  title: string;
  projectId: number;
  projectName: string;
  status: string;
  startDate: string;
  endDate: string;
  issueDate: string;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  items: PaymentRequestItem[];
  attachments: string[];
};

type Invoice = {
  id: number;
  projectId: number;
  projectName: string;
  invoiceNumber: string;
  clientName: string;
  issueDate: string;
  dueDate: string;
  status: string;
  amount: number;
  description: string;
  attachmentUrl: string | null;
  paymentDate: string | null;
};

type PaymentRequestsProps = {
  paymentRequests: PaymentRequest[];
  invoices: Invoice[];
  loading?: boolean;
  onCreatePaymentRequest?: () => void;
  onCreateInvoice?: () => void;
  onViewDetails?: (id: number, type: 'payment' | 'invoice') => void;
};

const PaymentRequests: React.FC<PaymentRequestsProps> = ({
  paymentRequests,
  invoices,
  loading = false,
  onCreatePaymentRequest,
  onCreateInvoice,
  onViewDetails,
}) => {
  const [activeTab, setActiveTab] = useState<string>("payment-requests");
  
  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA') + ' ريال';
  };
  
  const getStatusBadge = (status: string, type: 'payment' | 'invoice') => {
    let color = '';
    let label = status;
    
    if (type === 'payment') {
      switch (status.toLowerCase()) {
        case 'draft':
          color = 'bg-slate-100 text-slate-800';
          label = 'مسودة';
          break;
        case 'submitted':
          color = 'bg-blue-100 text-blue-800';
          label = 'مقدم';
          break;
        case 'approved':
          color = 'bg-green-100 text-green-800';
          label = 'معتمد';
          break;
        case 'paid':
          color = 'bg-emerald-100 text-emerald-800';
          label = 'مدفوع';
          break;
        case 'rejected':
          color = 'bg-red-100 text-red-800';
          label = 'مرفوض';
          break;
        default:
          color = 'bg-gray-100 text-gray-800';
      }
    } else {
      switch (status.toLowerCase()) {
        case 'paid':
          color = 'bg-green-100 text-green-800';
          label = 'مدفوعة';
          break;
        case 'pending':
          color = 'bg-amber-100 text-amber-800';
          label = 'معلقة';
          break;
        case 'overdue':
          color = 'bg-red-100 text-red-800';
          label = 'متأخرة';
          break;
        case 'cancelled':
          color = 'bg-gray-100 text-gray-800';
          label = 'ملغاة';
          break;
        default:
          color = 'bg-gray-100 text-gray-800';
      }
    }
    
    return (
      <Badge variant="outline" className={color}>
        {label}
      </Badge>
    );
  };
  
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), 'dd/MM/yyyy');
    } catch (e) {
      return dateString;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // إحصائيات المستخلصات
  const totalPaymentRequests = paymentRequests.length;
  const approvedPaymentRequests = paymentRequests.filter(pr => 
    pr.status.toLowerCase() === 'approved' || pr.status.toLowerCase() === 'paid').length;
  const totalPaymentRequestsAmount = paymentRequests.reduce((sum, pr) => sum + pr.totalAmount, 0);
  const paidPaymentRequestsAmount = paymentRequests.reduce((sum, pr) => sum + pr.paidAmount, 0);
  
  // إحصائيات الفواتير
  const totalInvoices = invoices.length;
  const paidInvoices = invoices.filter(inv => inv.status.toLowerCase() === 'paid').length;
  const totalInvoicesAmount = invoices.reduce((sum, inv) => sum + inv.amount, 0);
  const paidInvoicesAmount = invoices.filter(inv => 
    inv.status.toLowerCase() === 'paid').reduce((sum, inv) => sum + inv.amount, 0);

  return (
    <div className="space-y-6">
      <Tabs defaultValue="payment-requests" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="payment-requests">المستخلصات</TabsTrigger>
          <TabsTrigger value="invoices">الفواتير</TabsTrigger>
        </TabsList>
        
        <TabsContent value="payment-requests" className="space-y-4">
          <div className="flex flex-wrap justify-between items-center gap-2">
            <div>
              <h3 className="text-lg font-medium">المستخلصات</h3>
              <p className="text-sm text-muted-foreground">
                إدارة ومتابعة مستخلصات المشاريع
              </p>
            </div>
            <Button onClick={onCreatePaymentRequest}>
              <Plus className="ml-2 h-4 w-4" />
              إنشاء مستخلص جديد
            </Button>
          </div>
          
          {/* إحصائيات المستخلصات */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">{totalPaymentRequests}</div>
                <p className="text-sm text-muted-foreground">إجمالي المستخلصات</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">{approvedPaymentRequests}</div>
                <p className="text-sm text-muted-foreground">المستخلصات المعتمدة</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold text-green-600">
                  {formatCurrency(totalPaymentRequestsAmount)}
                </div>
                <p className="text-sm text-muted-foreground">إجمالي قيمة المستخلصات</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">
                  {formatCurrency(paidPaymentRequestsAmount)}
                </div>
                <p className="text-sm text-muted-foreground">المبالغ المدفوعة</p>
                <div className="mt-2">
                  <Progress 
                    value={totalPaymentRequestsAmount > 0 ? 
                      (paidPaymentRequestsAmount / totalPaymentRequestsAmount) * 100 : 0} 
                    className="h-2"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {paymentRequests.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {paymentRequests.map((paymentRequest) => (
                <Card key={paymentRequest.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{paymentRequest.title}</CardTitle>
                        <CardDescription>
                          {paymentRequest.projectName}
                        </CardDescription>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onViewDetails?.(paymentRequest.id, 'payment')}>
                            <FileText className="ml-2 h-4 w-4" />
                            عرض التفاصيل
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <PencilLine className="ml-2 h-4 w-4" />
                            تعديل
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="ml-2 h-4 w-4" />
                            تصدير PDF
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">الحالة</span>
                        <span>
                          {getStatusBadge(paymentRequest.status, 'payment')}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">التاريخ</span>
                        <span className="text-sm">
                          {formatDate(paymentRequest.issueDate)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">الفترة</span>
                        <span className="text-sm">
                          {formatDate(paymentRequest.startDate)} - {formatDate(paymentRequest.endDate)}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">إجمالي المبلغ</span>
                        <span className="font-semibold">{formatCurrency(paymentRequest.totalAmount)}</span>
                      </div>
                      {paymentRequest.status.toLowerCase() === 'paid' && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">المدفوع</span>
                          <span className="text-green-600">{formatCurrency(paymentRequest.paidAmount)}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="bg-muted/30 flex justify-between">
                    <span className="text-sm font-medium">
                      {paymentRequest.items.length} {paymentRequest.items.length > 10 ? 'بنود' : 'بند'}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => onViewDetails?.(paymentRequest.id, 'payment')}
                    >
                      عرض التفاصيل
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-medium mb-2">لا توجد مستخلصات</h3>
                <p className="text-muted-foreground text-center mb-4">
                  لم يتم إنشاء أي مستخلصات بعد. يمكنك إنشاء مستخلص جديد لمتابعة تقدم المشروع وتحصيل الدفعات.
                </p>
                <Button onClick={onCreatePaymentRequest}>
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء مستخلص جديد
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="invoices" className="space-y-4">
          <div className="flex flex-wrap justify-between items-center gap-2">
            <div>
              <h3 className="text-lg font-medium">الفواتير</h3>
              <p className="text-sm text-muted-foreground">
                إدارة ومتابعة فواتير المشاريع والعملاء
              </p>
            </div>
            <Button onClick={onCreateInvoice}>
              <Plus className="ml-2 h-4 w-4" />
              إنشاء فاتورة جديدة
            </Button>
          </div>
          
          {/* إحصائيات الفواتير */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">{totalInvoices}</div>
                <p className="text-sm text-muted-foreground">إجمالي الفواتير</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">{paidInvoices}</div>
                <p className="text-sm text-muted-foreground">الفواتير المدفوعة</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold text-green-600">
                  {formatCurrency(totalInvoicesAmount)}
                </div>
                <p className="text-sm text-muted-foreground">إجمالي قيمة الفواتير</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-xl font-semibold">
                  {formatCurrency(paidInvoicesAmount)}
                </div>
                <p className="text-sm text-muted-foreground">المبالغ المحصلة</p>
                <div className="mt-2">
                  <Progress 
                    value={totalInvoicesAmount > 0 ? 
                      (paidInvoicesAmount / totalInvoicesAmount) * 100 : 0} 
                    className="h-2"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          
          {invoices.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {invoices.map((invoice) => (
                <Card key={invoice.id} className="overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">فاتورة #{invoice.invoiceNumber}</CardTitle>
                        <CardDescription>
                          {invoice.clientName} - {invoice.projectName}
                        </CardDescription>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onViewDetails?.(invoice.id, 'invoice')}>
                            <FileText className="ml-2 h-4 w-4" />
                            عرض التفاصيل
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <PencilLine className="ml-2 h-4 w-4" />
                            تعديل
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="ml-2 h-4 w-4" />
                            تصدير PDF
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">الحالة</span>
                        <span>
                          {getStatusBadge(invoice.status, 'invoice')}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">تاريخ الإصدار</span>
                        <span className="text-sm">
                          {formatDate(invoice.issueDate)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">تاريخ الاستحقاق</span>
                        <span className="text-sm">
                          {formatDate(invoice.dueDate)}
                        </span>
                      </div>
                      <Separator />
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">المبلغ</span>
                        <span className="font-semibold">{formatCurrency(invoice.amount)}</span>
                      </div>
                      {invoice.status.toLowerCase() === 'paid' && invoice.paymentDate && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">تاريخ الدفع</span>
                          <span className="flex items-center text-green-600">
                            <Check className="ml-1 h-3 w-3" />
                            {formatDate(invoice.paymentDate)}
                          </span>
                        </div>
                      )}
                      {invoice.status.toLowerCase() === 'overdue' && (
                        <div className="flex justify-between">
                          <span className="text-sm text-muted-foreground">متأخرة</span>
                          <span className="flex items-center text-red-600">
                            <Clock className="ml-1 h-3 w-3" />
                            {calculateOverdueDays(invoice.dueDate)} يوم
                          </span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="bg-muted/30 flex justify-between">
                    <span className="text-sm font-medium">
                      {invoice.description ? invoice.description.substring(0, 30) + '...' : ''}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => onViewDetails?.(invoice.id, 'invoice')}
                    >
                      عرض التفاصيل
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-xl font-medium mb-2">لا توجد فواتير</h3>
                <p className="text-muted-foreground text-center mb-4">
                  لم يتم إنشاء أي فواتير بعد. يمكنك إنشاء فاتورة جديدة لتحصيل المدفوعات من العملاء.
                </p>
                <Button onClick={onCreateInvoice}>
                  <Plus className="ml-2 h-4 w-4" />
                  إنشاء فاتورة جديدة
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

// دالة لحساب عدد أيام التأخير
const calculateOverdueDays = (dueDate: string) => {
  const due = new Date(dueDate);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - due.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

export default PaymentRequests;