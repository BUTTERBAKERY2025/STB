import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { Loader2 } from "lucide-react";

type BudgetItem = {
  category: string;
  subcategory?: string;
  plannedAmount: number;
  actualAmount: number;
  variance: number;
  variancePercentage: number;
};

type BudgetSummary = {
  fiscalYear: number;
  totalPlanned: number;
  totalActual: number;
  totalVariance: number;
  items: BudgetItem[];
};

type BudgetComparisonTableProps = {
  budgetSummary: BudgetSummary | undefined;
  loading?: boolean;
};

const BudgetComparisonTable: React.FC<BudgetComparisonTableProps> = ({ 
  budgetSummary, 
  loading = false 
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!budgetSummary) {
    return (
      <div className="text-center py-10 text-muted-foreground">
        لا توجد بيانات متاحة للميزانية
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA') + ' ريال';
  };

  const getProgressColor = (variancePercentage: number) => {
    if (variancePercentage <= -10) return "bg-red-500";
    if (variancePercentage < 0) return "bg-orange-500";
    if (variancePercentage <= 5) return "bg-green-500";
    return "bg-blue-500";
  };

  return (
    <div className="space-y-4">
      <div className="bg-muted p-4 rounded-md">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-2">
            <div className="text-muted-foreground text-sm">الميزانية المخططة</div>
            <div className="text-xl font-bold">{formatCurrency(budgetSummary.totalPlanned)}</div>
          </div>
          <div className="p-2">
            <div className="text-muted-foreground text-sm">المصروفات الفعلية</div>
            <div className="text-xl font-bold">{formatCurrency(budgetSummary.totalActual)}</div>
          </div>
          <div className="p-2">
            <div className="text-muted-foreground text-sm">الفرق</div>
            <div className={`text-xl font-bold ${budgetSummary.totalVariance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {formatCurrency(Math.abs(budgetSummary.totalVariance))}
              {budgetSummary.totalVariance >= 0 ? ' فائض' : ' عجز'}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-md border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">الفئة</TableHead>
              <TableHead className="text-left">الميزانية المخططة</TableHead>
              <TableHead className="text-left">المصروفات الفعلية</TableHead>
              <TableHead className="text-left">الفرق</TableHead>
              <TableHead className="text-left">نسبة الصرف</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {budgetSummary.items.map((item, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">
                  {item.category}
                  {item.subcategory && (
                    <span className="text-sm text-muted-foreground block">
                      {item.subcategory}
                    </span>
                  )}
                </TableCell>
                <TableCell className="text-left">
                  {formatCurrency(item.plannedAmount)}
                </TableCell>
                <TableCell className="text-left">
                  {formatCurrency(item.actualAmount)}
                </TableCell>
                <TableCell className={`text-left ${item.variance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {item.variance >= 0 ? '+' : ''}
                  {formatCurrency(item.variance)}
                  <span className="text-xs block">
                    ({item.variancePercentage >= 0 ? '+' : ''}
                    {item.variancePercentage.toFixed(1)}%)
                  </span>
                </TableCell>
                <TableCell className="text-left">
                  <div className="flex items-center gap-2">
                    <Progress 
                      value={Math.min(100, (item.actualAmount / item.plannedAmount) * 100)} 
                      className={`h-2 ${getProgressColor(item.variancePercentage)}`}
                    />
                    <span className="text-xs font-medium">
                      {Math.round((item.actualAmount / item.plannedAmount) * 100)}%
                    </span>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default BudgetComparisonTable;