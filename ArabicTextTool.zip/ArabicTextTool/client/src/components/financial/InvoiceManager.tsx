import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DatePicker } from "@/components/ui/date-picker";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Edit, 
  Trash2, 
  Download, 
  Plus, 
  FileText, 
  RefreshCw, 
  Search, 
  EyeIcon, 
  Printer, 
  CheckCircle, 
  XCircle, 
  File, 
  Calendar, 
  AlertCircle,
  FileCheck,
  FileX
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO, isAfter, isBefore, addDays } from "date-fns";
import { ar } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PaymentRequestManager } from "./PaymentRequestManager";

interface InvoiceManagerProps {
  projectId?: number;
}

const InvoiceManager: React.FC<InvoiceManagerProps> = ({ projectId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("invoices");
  
  // تحضير بارامترات الاستعلام
  const queryParams = new URLSearchParams();
  if (projectId) queryParams.append("projectId", projectId.toString());
  if (statusFilter && statusFilter !== "all") queryParams.append("status", statusFilter);
  
  // استعلام الفواتير
  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ["/api/invoices", projectId, statusFilter],
    enabled: !!projectId && activeTab === "invoices",
  });

  // استعلام المشاريع للاستخدام في الواجهة
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // mutation لإضافة فاتورة
  const addInvoiceMutation = useMutation({
    mutationFn: async (data: any) => {
      const formattedData = {
        ...data,
        issueDate: format(data.issueDate, "yyyy-MM-dd"),
        dueDate: format(data.dueDate, "yyyy-MM-dd"),
        paymentDate: data.paymentDate ? format(data.paymentDate, "yyyy-MM-dd") : null,
      };
      const response = await apiRequest("POST", "/api/invoices", formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة الفاتورة بنجاح",
      });
      setIsAddDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الإضافة",
        description: error.message || "حدث خطأ أثناء إضافة الفاتورة",
        variant: "destructive",
      });
    },
  });

  // mutation لتعديل فاتورة
  const updateInvoiceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const formattedData = {
        ...data,
        issueDate: format(data.issueDate, "yyyy-MM-dd"),
        dueDate: format(data.dueDate, "yyyy-MM-dd"),
        paymentDate: data.paymentDate ? format(data.paymentDate, "yyyy-MM-dd") : null,
      };
      const response = await apiRequest("PATCH", `/api/invoices/${id}`, formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التعديل",
        description: "تم تعديل الفاتورة بنجاح",
      });
      setIsEditDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التعديل",
        description: error.message || "حدث خطأ أثناء تعديل الفاتورة",
        variant: "destructive",
      });
    },
  });

  // mutation لحذف فاتورة
  const deleteInvoiceMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/invoices/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف الفاتورة بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الحذف",
        description: error.message || "حدث خطأ أثناء حذف الفاتورة",
        variant: "destructive",
      });
    },
  });

  // مناولة إضافة فاتورة جديدة
  const handleAddInvoice = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: projectId || parseInt(formData.get("projectId") as string),
      amount: parseFloat(formData.get("amount") as string),
      description: formData.get("description") as string,
      issueDate: new Date(formData.get("issueDate") as string),
      dueDate: new Date(formData.get("dueDate") as string),
      invoiceNumber: formData.get("invoiceNumber") as string,
      clientName: formData.get("clientName") as string,
      status: formData.get("status") as string,
      attachmentUrl: formData.get("attachmentUrl") as string || null,
    };
    addInvoiceMutation.mutate(data);
  };

  // مناولة تعديل فاتورة
  const handleEditInvoice = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedInvoice) return;
    
    const formData = new FormData(e.currentTarget);
    const data = {
      projectId: projectId || parseInt(formData.get("projectId") as string),
      amount: parseFloat(formData.get("amount") as string),
      description: formData.get("description") as string,
      issueDate: new Date(formData.get("issueDate") as string),
      dueDate: new Date(formData.get("dueDate") as string),
      invoiceNumber: formData.get("invoiceNumber") as string,
      clientName: formData.get("clientName") as string,
      status: formData.get("status") as string,
      paymentDate: formData.get("paymentDate") ? new Date(formData.get("paymentDate") as string) : null,
      attachmentUrl: formData.get("attachmentUrl") as string || null,
    };
    updateInvoiceMutation.mutate({ id: selectedInvoice.id, data });
  };

  // فتح مربع حوار التعديل وملء البيانات
  const handleEdit = (invoice: any) => {
    setSelectedInvoice(invoice);
    setIsEditDialogOpen(true);
  };

  // فتح مربع حوار العرض
  const handleView = (invoice: any) => {
    setSelectedInvoice(invoice);
    setIsViewDialogOpen(true);
  };

  // حذف فاتورة مع تأكيد
  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الفاتورة؟")) {
      deleteInvoiceMutation.mutate(id);
    }
  };

  // طباعة أو تنزيل الفاتورة
  const handlePrint = (invoice: any) => {
    if (invoice.attachmentUrl) {
      window.open(invoice.attachmentUrl, "_blank");
    } else {
      toast({
        title: "تعذر الطباعة",
        description: "لم يتم العثور على مرفق للفاتورة",
        variant: "destructive",
      });
    }
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA') + ' ريال';
  };

  // الحصول على اسم المشروع من المعرف
  const getProjectName = (projectId: number) => {
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(parseISO(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // تحديد لون الحالة
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
      case 'مدفوعة':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'قيد الانتظار':
        return 'bg-yellow-100 text-yellow-800';
      case 'overdue':
      case 'متأخرة':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // تحديد حالة الفاتورة استناداً إلى المواعيد
  const getInvoiceStatus = (invoice: any) => {
    if (invoice.status === 'paid') return 'مدفوعة';
    
    const today = new Date();
    const dueDate = parseISO(invoice.dueDate);
    
    if (isAfter(today, dueDate)) {
      return 'متأخرة';
    } else {
      return 'قيد الانتظار';
    }
  };

  // إعادة تعيين التصفية
  const resetFilters = () => {
    setStatusFilter(undefined);
    setSearchTerm("");
  };

  // تصفية الفواتير حسب نص البحث
  const filteredInvoices = invoices.filter((invoice: any) => {
    return (
      invoice.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // حساب عدد أيام التأخير أو المتبقية للفاتورة
  const getDaysInfo = (invoice: any) => {
    if (invoice.status === 'paid') return { days: 0, text: 'تم الدفع', isPast: false };
    
    const today = new Date();
    const dueDate = parseISO(invoice.dueDate);
    
    if (isAfter(today, dueDate)) {
      const days = Math.ceil((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
      return { days, text: `متأخرة بـ ${days} يوم`, isPast: true };
    } else {
      const days = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return { days, text: `متبقي ${days} يوم`, isPast: false };
    }
  };

  // حالة تحميل وقائمة فارغة
  const renderEmptyState = () => (
    <div className="text-center py-12 bg-white rounded-lg border">
      <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
      <h3 className="font-medium text-lg mb-2">لا توجد فواتير</h3>
      <p className="text-muted-foreground mb-4">
        لم يتم العثور على فواتير متطابقة مع معايير البحث
      </p>
      <Button 
        variant="outline" 
        onClick={resetFilters}
      >
        عرض جميع الفواتير
      </Button>
    </div>
  );

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-6">
          <TabsTrigger value="invoices">الفواتير</TabsTrigger>
          <TabsTrigger value="payment_requests">المستخلصات</TabsTrigger>
        </TabsList>
        
        <TabsContent value="invoices">
          {/* خلاصة الفواتير */}
          {projectId && filteredInvoices.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    إجمالي الفواتير
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <FileText className="w-5 h-5 text-blue-500 ml-2" />
                    <span className="text-2xl font-bold text-blue-600">
                      {filteredInvoices.length}
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    إجمالي المبالغ
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <FileCheck className="w-5 h-5 text-green-500 ml-2" />
                    <span className="text-2xl font-bold text-green-600">
                      {formatCurrency(
                        filteredInvoices.reduce((sum: number, invoice: any) => sum + invoice.amount, 0)
                      )}
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    الفواتير المدفوعة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-primary ml-2" />
                    <span className="text-2xl font-bold text-primary">
                      {filteredInvoices.filter((invoice: any) => invoice.status === 'paid').length}
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    الفواتير المتأخرة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <AlertCircle className="w-5 h-5 text-red-500 ml-2" />
                    <span className="text-2xl font-bold text-red-600">
                      {filteredInvoices.filter((invoice: any) => {
                        if (invoice.status === 'paid') return false;
                        const today = new Date();
                        const dueDate = parseISO(invoice.dueDate);
                        return isAfter(today, dueDate);
                      }).length}
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* شريط الأدوات والتصفية */}
          <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between">
            <div className="flex flex-col md:flex-row gap-2">
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="بحث في الفواتير..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="حالة الفاتورة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الحالات</SelectItem>
                  <SelectItem value="paid">مدفوعة</SelectItem>
                  <SelectItem value="pending">قيد الانتظار</SelectItem>
                  <SelectItem value="overdue">متأخرة</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                variant="outline" 
                onClick={resetFilters}
                className="h-10"
                disabled={!statusFilter && !searchTerm}
              >
                <RefreshCw className="ml-2 h-4 w-4" />
                إعادة تعيين
              </Button>
            </div>

            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="h-10">
                  <Plus className="ml-2 h-4 w-4" /> إضافة فاتورة
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>إضافة فاتورة جديدة</DialogTitle>
                  <DialogDescription>
                    أدخل تفاصيل الفاتورة الجديدة
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleAddInvoice}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="invoiceNumber" className="text-right">
                        رقم الفاتورة
                      </Label>
                      <Input
                        id="invoiceNumber"
                        name="invoiceNumber"
                        className="col-span-3"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="clientName" className="text-right">
                        اسم العميل
                      </Label>
                      <Input
                        id="clientName"
                        name="clientName"
                        className="col-span-3"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="amount" className="text-right">
                        المبلغ
                      </Label>
                      <Input
                        id="amount"
                        name="amount"
                        type="number"
                        min="0"
                        className="col-span-3"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="description" className="text-right">
                        الوصف
                      </Label>
                      <Textarea
                        id="description"
                        name="description"
                        className="col-span-3"
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">
                        تاريخ الإصدار
                      </Label>
                      <div className="col-span-3">
                        <Input
                          id="issueDate"
                          name="issueDate"
                          type="date"
                          defaultValue={format(new Date(), "yyyy-MM-dd")}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">
                        تاريخ الاستحقاق
                      </Label>
                      <div className="col-span-3">
                        <Input
                          id="dueDate"
                          name="dueDate"
                          type="date"
                          defaultValue={format(addDays(new Date(), 30), "yyyy-MM-dd")}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="status" className="text-right">
                        الحالة
                      </Label>
                      <Select name="status" defaultValue="pending">
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">قيد الانتظار</SelectItem>
                          <SelectItem value="paid">مدفوعة</SelectItem>
                          <SelectItem value="overdue">متأخرة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="attachmentUrl" className="text-right">
                        رابط المرفق (اختياري)
                      </Label>
                      <Input
                        id="attachmentUrl"
                        name="attachmentUrl"
                        className="col-span-3"
                      />
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button type="submit" disabled={addInvoiceMutation.isPending}>
                      {addInvoiceMutation.isPending ? "جاري الإضافة..." : "إضافة"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* قائمة الفواتير */}
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : filteredInvoices.length === 0 ? (
            renderEmptyState()
          ) : (
            <div className="overflow-x-auto border rounded-lg">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>رقم الفاتورة</TableHead>
                    <TableHead>العميل</TableHead>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>تاريخ الإصدار</TableHead>
                    <TableHead>تاريخ الاستحقاق</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>المدة</TableHead>
                    <TableHead>إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvoices.map((invoice: any) => {
                    const daysInfo = getDaysInfo(invoice);
                    return (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">
                          {invoice.invoiceNumber}
                        </TableCell>
                        <TableCell>{invoice.clientName}</TableCell>
                        <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                        <TableCell>{formatDate(invoice.issueDate)}</TableCell>
                        <TableCell>{formatDate(invoice.dueDate)}</TableCell>
                        <TableCell>
                          <Badge className={`${getStatusColor(invoice.status)}`}>
                            {getInvoiceStatus(invoice)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className={daysInfo.isPast ? 'text-red-600' : 'text-blue-600'}>
                            {daysInfo.text}
                          </span>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  width="18"
                                  height="18"
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                >
                                  <circle cx="12" cy="12" r="1" />
                                  <circle cx="12" cy="5" r="1" />
                                  <circle cx="12" cy="19" r="1" />
                                </svg>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem 
                                className="flex items-center gap-2"
                                onClick={() => handleView(invoice)}
                              >
                                <EyeIcon className="h-4 w-4" />
                                <span>عرض</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="flex items-center gap-2"
                                onClick={() => handleEdit(invoice)}
                              >
                                <Edit className="h-4 w-4" />
                                <span>تعديل</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="flex items-center gap-2"
                                onClick={() => handlePrint(invoice)}
                              >
                                <Printer className="h-4 w-4" />
                                <span>طباعة</span>
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="flex items-center gap-2 text-red-600"
                                onClick={() => handleDelete(invoice.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                                <span>حذف</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}

          {/* مربع حوار تعديل فاتورة */}
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>تعديل الفاتورة</DialogTitle>
                <DialogDescription>
                  تعديل تفاصيل الفاتورة
                </DialogDescription>
              </DialogHeader>
              
              {selectedInvoice && (
                <form onSubmit={handleEditInvoice}>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-invoiceNumber" className="text-right">
                        رقم الفاتورة
                      </Label>
                      <Input
                        id="edit-invoiceNumber"
                        name="invoiceNumber"
                        className="col-span-3"
                        defaultValue={selectedInvoice.invoiceNumber}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-clientName" className="text-right">
                        اسم العميل
                      </Label>
                      <Input
                        id="edit-clientName"
                        name="clientName"
                        className="col-span-3"
                        defaultValue={selectedInvoice.clientName}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-amount" className="text-right">
                        المبلغ
                      </Label>
                      <Input
                        id="edit-amount"
                        name="amount"
                        type="number"
                        min="0"
                        className="col-span-3"
                        defaultValue={selectedInvoice.amount}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-description" className="text-right">
                        الوصف
                      </Label>
                      <Textarea
                        id="edit-description"
                        name="description"
                        className="col-span-3"
                        defaultValue={selectedInvoice.description}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">
                        تاريخ الإصدار
                      </Label>
                      <div className="col-span-3">
                        <Input
                          id="edit-issueDate"
                          name="issueDate"
                          type="date"
                          defaultValue={format(parseISO(selectedInvoice.issueDate), "yyyy-MM-dd")}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">
                        تاريخ الاستحقاق
                      </Label>
                      <div className="col-span-3">
                        <Input
                          id="edit-dueDate"
                          name="dueDate"
                          type="date"
                          defaultValue={format(parseISO(selectedInvoice.dueDate), "yyyy-MM-dd")}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-status" className="text-right">
                        الحالة
                      </Label>
                      <Select name="status" defaultValue={selectedInvoice.status}>
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="اختر الحالة" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">قيد الانتظار</SelectItem>
                          <SelectItem value="paid">مدفوعة</SelectItem>
                          <SelectItem value="overdue">متأخرة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {selectedInvoice.status === 'paid' && (
                      <div className="grid grid-cols-4 items-center gap-4">
                        <Label className="text-right">
                          تاريخ الدفع
                        </Label>
                        <div className="col-span-3">
                          <Input
                            id="edit-paymentDate"
                            name="paymentDate"
                            type="date"
                            defaultValue={selectedInvoice.paymentDate ? 
                              format(parseISO(selectedInvoice.paymentDate), "yyyy-MM-dd") : 
                              format(new Date(), "yyyy-MM-dd")
                            }
                          />
                        </div>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="edit-attachmentUrl" className="text-right">
                        رابط المرفق (اختياري)
                      </Label>
                      <Input
                        id="edit-attachmentUrl"
                        name="attachmentUrl"
                        className="col-span-3"
                        defaultValue={selectedInvoice.attachmentUrl || ""}
                      />
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button type="submit" disabled={updateInvoiceMutation.isPending}>
                      {updateInvoiceMutation.isPending ? "جاري التعديل..." : "تعديل"}
                    </Button>
                  </DialogFooter>
                </form>
              )}
            </DialogContent>
          </Dialog>

          {/* مربع حوار عرض تفاصيل الفاتورة */}
          <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
            <DialogContent className="sm:max-w-[650px]">
              <DialogHeader>
                <DialogTitle>تفاصيل الفاتورة</DialogTitle>
                <DialogDescription>
                  عرض تفاصيل الفاتورة وحالتها
                </DialogDescription>
              </DialogHeader>
              
              {selectedInvoice && (
                <div className="py-4">
                  <div className="bg-gray-50 p-6 rounded-lg border mb-6">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <h2 className="text-2xl font-bold">{getProjectName(selectedInvoice.projectId)}</h2>
                        <p className="text-muted-foreground">فاتورة رقم: {selectedInvoice.invoiceNumber}</p>
                      </div>
                      <Badge className={`${getStatusColor(selectedInvoice.status)} text-sm px-3 py-1.5`}>
                        {getInvoiceStatus(selectedInvoice)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">معلومات العميل</h3>
                        <p className="font-medium">{selectedInvoice.clientName}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">تفاصيل المدفوعات</h3>
                        <p className="font-medium text-primary">{formatCurrency(selectedInvoice.amount)}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">تاريخ الإصدار</h3>
                        <p className="font-medium">{formatDate(selectedInvoice.issueDate)}</p>
                      </div>
                      
                      <div>
                        <h3 className="text-sm font-medium text-muted-foreground mb-1">تاريخ الاستحقاق</h3>
                        <p className="font-medium">{formatDate(selectedInvoice.dueDate)}</p>
                      </div>
                      
                      {selectedInvoice.status === 'paid' && selectedInvoice.paymentDate && (
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground mb-1">تاريخ الدفع</h3>
                          <p className="font-medium text-green-600">{formatDate(selectedInvoice.paymentDate)}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="mb-6">
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">الوصف</h3>
                      <p className="p-3 bg-white border rounded-md">{selectedInvoice.description}</p>
                    </div>
                    
                    {/* تقدم الحالة */}
                    <div className="mb-4">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">حالة الفاتورة</span>
                        <span className="text-sm">
                          {selectedInvoice.status === 'paid' ? '100%' : 
                           selectedInvoice.status === 'pending' ? '50%' : '25%'}
                        </span>
                      </div>
                      <Progress 
                        value={
                          selectedInvoice.status === 'paid' ? 100 : 
                          selectedInvoice.status === 'pending' ? 50 : 25
                        } 
                      />
                    </div>
                    
                    {selectedInvoice.attachmentUrl && (
                      <div className="flex justify-end mt-6">
                        <Button onClick={() => handlePrint(selectedInvoice)}>
                          <Download className="ml-2 h-4 w-4" />
                          تنزيل الفاتورة
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </TabsContent>
        
        <TabsContent value="payment_requests">
          <PaymentRequestManager projectId={projectId} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default InvoiceManager;