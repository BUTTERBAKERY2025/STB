import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Checkbox } from "@/components/ui/checkbox";
import { DatePicker } from "@/components/ui/date-picker";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  FileText, 
  Download, 
  Printer, 
  FileOutput, 
  FileSpreadsheet, 
  FilePlus, 
  Trash2, 
  Eye, 
  ExternalLink, 
  Share2, 
  Filter, 
  Calendar, 
  RefreshCw,
  Search
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO, subMonths } from "date-fns";
import { ar } from "date-fns/locale";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { insertFinancialReportSchema } from "@shared/schema.new";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";

interface FinancialReportGeneratorProps {
  projectId?: number;
}

// تعريف نموذج التقرير المالي
const reportFormSchema = z.object({
  projectId: z.number().int().nullable(),
  title: z.string().min(3, { message: "يجب أن يكون العنوان 3 أحرف على الأقل" }),
  type: z.string().min(1, { message: "يجب تحديد نوع التقرير" }),
  dateFrom: z.date({ message: "يجب تحديد تاريخ البداية" }),
  dateTo: z.date({ message: "يجب تحديد تاريخ النهاية" }),
  parameters: z.record(z.any()).optional(),
  status: z.string().min(1, { message: "يجب تحديد حالة التقرير" }),
  createdBy: z.number().int().positive(),
  outputFormat: z.string().min(1, { message: "يجب تحديد صيغة الإخراج" }),
  includeCharts: z.boolean().optional(),
  includeSummary: z.boolean().optional(),
  includeDetails: z.boolean().optional(),
});

type ReportFormValues = z.infer<typeof reportFormSchema>;

const FinancialReportGenerator: React.FC<FinancialReportGeneratorProps> = ({ projectId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isPreviewDialogOpen, setIsPreviewDialogOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<any>(null);
  const [reportTypeFilter, setReportTypeFilter] = useState<string | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("saved");
  
  // تاريخ البداية الافتراضي (3 أشهر للخلف)
  const defaultStartDate = subMonths(new Date(), 3);
  
  // استعلام التقارير المحفوظة
  const { data: reports = [], isLoading: reportsLoading } = useQuery({
    queryKey: ["/api/financial-reports", projectId, reportTypeFilter],
    enabled: !!projectId || activeTab === "saved",
  });

  // استعلام المشاريع للاستخدام في الواجهة
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // نموذج إنشاء تقرير جديد
  const createForm = useForm<ReportFormValues>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: {
      projectId: projectId || null,
      title: "",
      type: "",
      dateFrom: defaultStartDate,
      dateTo: new Date(),
      parameters: {},
      status: "draft",
      createdBy: 1, // افتراضي
      outputFormat: "pdf",
      includeCharts: true,
      includeSummary: true,
      includeDetails: true,
    },
  });

  // mutation لإنشاء تقرير مالي جديد
  const createReportMutation = useMutation({
    mutationFn: async (data: ReportFormValues) => {
      const formattedData = {
        ...data,
        dateFrom: format(data.dateFrom, "yyyy-MM-dd"),
        dateTo: format(data.dateTo, "yyyy-MM-dd"),
        // تحويل المعايير الخاصة إلى كائن JSON
        parameters: {
          ...data.parameters,
          includeCharts: data.includeCharts,
          includeSummary: data.includeSummary,
          includeDetails: data.includeDetails,
          outputFormat: data.outputFormat,
        },
      };
      
      const response = await apiRequest("POST", "/api/financial-reports", formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء التقرير",
        description: "تم إنشاء التقرير المالي بنجاح",
      });
      setIsCreateDialogOpen(false);
      createForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/financial-reports"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إنشاء التقرير",
        description: error.message || "حدث خطأ أثناء إنشاء التقرير المالي",
        variant: "destructive",
      });
    },
  });

  // mutation لإنشاء تقرير مالي وتنزيله مباشرة
  const generateReportMutation = useMutation({
    mutationFn: async (data: ReportFormValues) => {
      const formattedData = {
        ...data,
        dateFrom: format(data.dateFrom, "yyyy-MM-dd"),
        dateTo: format(data.dateTo, "yyyy-MM-dd"),
        // تحويل المعايير الخاصة إلى كائن JSON
        parameters: {
          ...data.parameters,
          includeCharts: data.includeCharts,
          includeSummary: data.includeSummary,
          includeDetails: data.includeDetails,
          outputFormat: data.outputFormat,
        },
      };
      
      const response = await apiRequest("POST", "/api/generate-financial-report", formattedData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم إنشاء التقرير",
        description: "تم إنشاء التقرير المالي وتجهيزه للتنزيل",
      });
      
      // إذا كان هناك رابط للتنزيل، قم بفتحه في نافذة جديدة
      if (data && data.fileUrl) {
        window.open(data.fileUrl, "_blank");
      }
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إنشاء التقرير",
        description: error.message || "حدث خطأ أثناء إنشاء وتنزيل التقرير المالي",
        variant: "destructive",
      });
    },
  });

  // mutation لحذف تقرير محفوظ
  const deleteReportMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/financial-reports/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف التقرير بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/financial-reports"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الحذف",
        description: error.message || "حدث خطأ أثناء حذف التقرير",
        variant: "destructive",
      });
    },
  });

  // تقديم نموذج إنشاء تقرير
  const onCreateSubmit = (data: ReportFormValues) => {
    // تأكد من أن المعايير تتضمن بيانات واجهة المستخدم
    const enhancedData = {
      ...data,
      parameters: {
        ...data.parameters,
        includeCharts: data.includeCharts,
        includeSummary: data.includeSummary,
        includeDetails: data.includeDetails,
        outputFormat: data.outputFormat,
      },
    };
    
    // حسب وضع التشغيل (حفظ أو إنشاء وتنزيل)
    if (activeTab === "create") {
      createReportMutation.mutate(enhancedData);
    } else {
      generateReportMutation.mutate(enhancedData);
    }
  };

  // معالجة النقر لعرض معاينة التقرير
  const handlePreview = (report: any) => {
    setSelectedReport(report);
    setIsPreviewDialogOpen(true);
  };

  // حذف تقرير مع تأكيد
  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا التقرير؟")) {
      deleteReportMutation.mutate(id);
    }
  };

  // تنزيل تقرير محفوظ
  const handleDownload = (report: any) => {
    if (report.fileUrl) {
      window.open(report.fileUrl, "_blank");
    } else {
      toast({
        title: "خطأ في التنزيل",
        description: "ملف التقرير غير متوفر للتنزيل",
        variant: "destructive",
      });
    }
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(parseISO(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // الحصول على اسم المشروع من المعرف
  const getProjectName = (projectId: number | null) => {
    if (!projectId) return 'جميع المشاريع';
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تنسيق نوع التقرير
  const formatReportType = (type: string) => {
    switch (type) {
      case 'budget': return 'تقرير الميزانية';
      case 'cashflow': return 'تقرير التدفق النقدي';
      case 'expenses': return 'تقرير المصروفات';
      case 'income': return 'تقرير الإيرادات';
      case 'profitloss': return 'تقرير الأرباح والخسائر';
      case 'summary': return 'تقرير ملخص مالي';
      default: return type;
    }
  };

  // تحديد لون الحالة
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'final':
      case 'نهائي':
        return 'bg-green-100 text-green-800';
      case 'draft':
      case 'مسودة':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
      case 'معتمد':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // إعادة تعيين التصفية
  const resetFilters = () => {
    setReportTypeFilter(undefined);
    setSearchTerm("");
  };

  // تصفية التقارير حسب نص البحث
  const filteredReports = reports.filter((report: any) => {
    return (report.title?.toLowerCase().includes(searchTerm.toLowerCase()) || 
            formatReportType(report.type).toLowerCase().includes(searchTerm.toLowerCase()) ||
            getProjectName(report.projectId).toLowerCase().includes(searchTerm.toLowerCase()));
  });

  // تحديد لون واجهة المستخدم حسب نوع التقرير
  const getReportTypeIcon = (type: string) => {
    switch (type) {
      case 'budget':
        return <FileText className="h-10 w-10 text-blue-500" />;
      case 'cashflow':
        return <FileText className="h-10 w-10 text-green-500" />;
      case 'expenses':
        return <FileText className="h-10 w-10 text-red-500" />;
      case 'income':
        return <FileText className="h-10 w-10 text-emerald-500" />;
      case 'profitloss':
        return <FileText className="h-10 w-10 text-purple-500" />;
      case 'summary':
        return <FileText className="h-10 w-10 text-orange-500" />;
      default:
        return <FileText className="h-10 w-10 text-gray-500" />;
    }
  };

  return (
    <div>
      <Tabs value={activeTab} onValueChange={setActiveTab} defaultValue="saved" className="w-full">
        <TabsList className="grid grid-cols-2 mb-6">
          <TabsTrigger value="saved">التقارير المحفوظة</TabsTrigger>
          <TabsTrigger value="create">إنشاء تقرير جديد</TabsTrigger>
        </TabsList>
        
        {/* التقارير المحفوظة */}
        <TabsContent value="saved">
          {/* شريط الأدوات والتصفية */}
          <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between">
            <div className="flex flex-col md:flex-row gap-2">
              <div className="relative w-full md:w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="بحث في التقارير..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Select value={reportTypeFilter} onValueChange={setReportTypeFilter}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="نوع التقرير" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="budget">تقرير الميزانية</SelectItem>
                  <SelectItem value="cashflow">تقرير التدفق النقدي</SelectItem>
                  <SelectItem value="expenses">تقرير المصروفات</SelectItem>
                  <SelectItem value="income">تقرير الإيرادات</SelectItem>
                  <SelectItem value="profitloss">تقرير الأرباح والخسائر</SelectItem>
                  <SelectItem value="summary">تقرير ملخص مالي</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                variant="outline" 
                onClick={resetFilters}
                className="h-10"
                disabled={!reportTypeFilter && !searchTerm}
              >
                <RefreshCw className="ml-2 h-4 w-4" />
                إعادة تعيين
              </Button>
            </div>

            <div>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-10">
                    <FilePlus className="ml-2 h-4 w-4" /> إنشاء تقرير جديد
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          </div>

          {/* قائمة التقارير */}
          {reportsLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="w-full">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-6 w-24" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                      <div className="flex justify-between mt-4">
                        <Skeleton className="h-8 w-20" />
                        <Skeleton className="h-8 w-20" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredReports.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border">
              <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="font-medium text-lg mb-2">لا توجد تقارير محفوظة</h3>
              <p className="text-muted-foreground mb-4">
                لم يتم العثور على تقارير مالية محفوظة. يمكنك إنشاء تقرير جديد.
              </p>
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button>إنشاء تقرير</Button>
                </DialogTrigger>
              </Dialog>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredReports.map((report: any) => (
                <Card key={report.id} className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16">
                    <div className="absolute transform rotate-45 bg-gray-200 text-gray-600 text-xs text-center font-medium py-1 right-[-35px] top-[32px] w-[170px]">
                      {format(parseISO(report.createdAt), 'dd/MM/yyyy')}
                    </div>
                  </div>
                  
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="space-y-1">
                        <CardTitle className="text-lg">{report.title}</CardTitle>
                        <CardDescription>
                          {getProjectName(report.projectId)}
                        </CardDescription>
                      </div>
                      <Badge className={`${getStatusColor(report.status)}`}>
                        {report.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex items-center mb-4">
                      {getReportTypeIcon(report.type)}
                      <div className="mr-3">
                        <div className="font-medium">{formatReportType(report.type)}</div>
                        <div className="text-sm text-muted-foreground">
                          الفترة: {formatDate(report.dateFrom)} - {formatDate(report.dateTo)}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  
                  <CardFooter className="flex justify-between pt-0">
                    <Button variant="outline" size="sm" onClick={() => handlePreview(report)}>
                      <Eye className="ml-1 h-4 w-4" />
                      معاينة
                    </Button>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleDownload(report)}
                        disabled={!report.fileUrl}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-red-600" 
                        onClick={() => handleDelete(report.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* إنشاء تقرير جديد */}
        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>إنشاء تقرير مالي جديد</CardTitle>
              <CardDescription>
                أدخل معايير التقرير المالي المطلوب إنشاؤه
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...createForm}>
                <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={createForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>عنوان التقرير</FormLabel>
                          <FormControl>
                            <Input placeholder="أدخل عنوان التقرير" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={createForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>نوع التقرير</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر نوع التقرير" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="budget">تقرير الميزانية</SelectItem>
                              <SelectItem value="cashflow">تقرير التدفق النقدي</SelectItem>
                              <SelectItem value="expenses">تقرير المصروفات</SelectItem>
                              <SelectItem value="income">تقرير الإيرادات</SelectItem>
                              <SelectItem value="profitloss">تقرير الأرباح والخسائر</SelectItem>
                              <SelectItem value="summary">تقرير ملخص مالي</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={createForm.control}
                      name="projectId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>المشروع</FormLabel>
                          <Select
                            onValueChange={(value) => field.onChange(value === "all" ? null : Number(value))}
                            value={field.value === null ? "all" : field.value?.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر المشروع" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="all">جميع المشاريع</SelectItem>
                              {projects.map((project: any) => (
                                <SelectItem key={project.id} value={project.id.toString()}>
                                  {project.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            اختر "جميع المشاريع" لإنشاء تقرير شامل أو حدد مشروع معين
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={createForm.control}
                      name="status"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>حالة التقرير</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="اختر حالة التقرير" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="draft">مسودة</SelectItem>
                              <SelectItem value="final">نهائي</SelectItem>
                              <SelectItem value="approved">معتمد</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={createForm.control}
                      name="dateFrom"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>تاريخ البداية</FormLabel>
                          <FormControl>
                            <DatePicker
                              date={field.value}
                              setDate={field.onChange}
                              placeholder="اختر تاريخ بداية التقرير"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={createForm.control}
                      name="dateTo"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>تاريخ النهاية</FormLabel>
                          <FormControl>
                            <DatePicker
                              date={field.value}
                              setDate={field.onChange}
                              placeholder="اختر تاريخ نهاية التقرير"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="border-t pt-6">
                    <h3 className="text-lg font-medium mb-4">خيارات التقرير</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={createForm.control}
                        name="outputFormat"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>صيغة الإخراج</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="اختر صيغة الإخراج" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="pdf">PDF</SelectItem>
                                <SelectItem value="excel">Excel</SelectItem>
                                <SelectItem value="csv">CSV</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="space-y-4">
                        <FormField
                          control={createForm.control}
                          name="includeCharts"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-2 space-x-reverse space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="mr-2">
                                تضمين الرسوم البيانية
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={createForm.control}
                          name="includeSummary"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-2 space-x-reverse space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="mr-2">
                                تضمين الملخص
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={createForm.control}
                          name="includeDetails"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-2 space-x-reverse space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                              <FormLabel className="mr-2">
                                تضمين التفاصيل
                              </FormLabel>
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-4 pt-4">
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={() => setActiveTab("saved")}
                    >
                      إلغاء
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createReportMutation.isPending || generateReportMutation.isPending}
                    >
                      {(createReportMutation.isPending || generateReportMutation.isPending) ? 
                        "جاري الإنشاء..." : (activeTab === "create" ? "حفظ التقرير" : "إنشاء وتنزيل")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* مربع حوار معاينة التقرير */}
      <Dialog open={isPreviewDialogOpen} onOpenChange={setIsPreviewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>معاينة التقرير</DialogTitle>
            <DialogDescription>
              {selectedReport?.title} - {formatReportType(selectedReport?.type)}
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-4 border rounded-md bg-gray-50">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h2 className="text-2xl font-bold">{selectedReport?.title}</h2>
                <p className="text-muted-foreground">
                  {getProjectName(selectedReport?.projectId)}
                </p>
                <p className="text-sm text-muted-foreground">
                  الفترة: {formatDate(selectedReport?.dateFrom)} إلى {formatDate(selectedReport?.dateTo)}
                </p>
              </div>
              <div>
                <Badge className={`${getStatusColor(selectedReport?.status)}`}>
                  {selectedReport?.status}
                </Badge>
              </div>
            </div>
            
            <div className="flex justify-center items-center py-20 border border-dashed rounded-md bg-white">
              <div className="text-center">
                <FileText className="h-20 w-20 mx-auto text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">معاينة التقرير</p>
                <p className="text-muted-foreground mb-4">
                  يمكنك تنزيل التقرير بالضغط على زر التنزيل أدناه
                </p>
                <Button 
                  onClick={() => handleDownload(selectedReport)}
                  disabled={!selectedReport?.fileUrl}
                >
                  <Download className="ml-2 h-4 w-4" />
                  تنزيل التقرير
                </Button>
              </div>
            </div>
            
            <div className="mt-6 text-sm text-muted-foreground">
              <p>تم إنشاء التقرير بواسطة: النظام</p>
              <p>تاريخ الإنشاء: {selectedReport?.createdAt ? formatDate(selectedReport.createdAt) : ''}</p>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsPreviewDialogOpen(false)}
            >
              إغلاق
            </Button>
            <Button 
              onClick={() => handleDownload(selectedReport)}
              disabled={!selectedReport?.fileUrl}
            >
              <Download className="ml-2 h-4 w-4" />
              تنزيل
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FinancialReportGenerator;