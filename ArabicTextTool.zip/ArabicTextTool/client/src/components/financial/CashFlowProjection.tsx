import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

type MonthlyProjection = {
  month: string;
  inflow: number;
  outflow: number;
  balance: number;
};

type CashFlowData = {
  monthlyProjections: MonthlyProjection[];
  totalInflow: number;
  totalOutflow: number;
  netCashflow: number;
};

type CashFlowProjectionProps = {
  projection: CashFlowData;
};

const CashFlowProjection: React.FC<CashFlowProjectionProps> = ({ projection }) => {
  const months = projection.monthlyProjections.map(item => item.month);
  const inflows = projection.monthlyProjections.map(item => item.inflow);
  const outflows = projection.monthlyProjections.map(item => item.outflow);
  const balances = projection.monthlyProjections.map(item => item.balance);

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA') + ' ريال';
  };

  const getBarChartData = () => ({
    labels: months,
    datasets: [
      {
        label: 'التدفقات الواردة',
        data: inflows,
        backgroundColor: 'rgba(34, 197, 94, 0.7)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 1,
      },
      {
        label: 'التدفقات الصادرة',
        data: outflows.map(value => -value), // Negate for visualization
        backgroundColor: 'rgba(239, 68, 68, 0.7)',
        borderColor: 'rgb(239, 68, 68)',
        borderWidth: 1,
      },
    ],
  });

  const getLineChartData = () => ({
    labels: months,
    datasets: [
      {
        label: 'صافي التدفق النقدي',
        data: balances,
        backgroundColor: 'rgba(59, 130, 246, 0.2)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 2,
      },
    ],
  });

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        stacked: true,
        grid: {
          display: false,
        },
      },
      y: {
        stacked: true,
        ticks: {
          callback: function(value: any) {
            return value.toLocaleString() + ' ريال';
          },
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.05)',
        },
      },
    },
    plugins: {
      legend: {
        position: 'top' as const,
        align: 'end' as const,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              // If it's outflow, we need to convert back to positive for display
              const value = context.dataset.label === 'التدفقات الصادرة' 
                ? -context.parsed.y 
                : context.parsed.y;
                
              label += new Intl.NumberFormat('ar-SA', { 
                style: 'currency',
                currency: 'SAR',
              }).format(value);
            }
            return label;
          }
        }
      },
    },
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4">
            <div className="text-sm font-medium text-green-800">إجمالي التدفقات الواردة</div>
            <div className="text-2xl font-bold text-green-700 mt-1">
              {formatCurrency(projection.totalInflow)}
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-4">
            <div className="text-sm font-medium text-red-800">إجمالي التدفقات الصادرة</div>
            <div className="text-2xl font-bold text-red-700 mt-1">
              {formatCurrency(projection.totalOutflow)}
            </div>
          </CardContent>
        </Card>
        
        <Card className={`${projection.netCashflow >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
          <CardContent className="p-4">
            <div className={`text-sm font-medium ${projection.netCashflow >= 0 ? 'text-blue-800' : 'text-orange-800'}`}>
              صافي التدفق النقدي
            </div>
            <div className={`text-2xl font-bold mt-1 ${projection.netCashflow >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
              {formatCurrency(Math.abs(projection.netCashflow))}
              {projection.netCashflow < 0 ? ' عجز' : ''}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="bar" className="w-full">
        <TabsList className="mb-2">
          <TabsTrigger value="bar">رسم بياني شريطي</TabsTrigger>
          <TabsTrigger value="balance">صافي التدفق</TabsTrigger>
          <TabsTrigger value="table">جدول التدفقات</TabsTrigger>
        </TabsList>
        
        <TabsContent value="bar" className="p-0">
          <div className="h-[400px] border rounded-md p-4">
            <div dir="ltr" className="h-full w-full">
              <Bar 
                data={getBarChartData()} 
                options={options} 
              />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="balance" className="p-0">
          <div className="h-[400px] border rounded-md p-4">
            <div dir="ltr" className="h-full w-full">
              <Bar 
                data={getLineChartData()} 
                options={{
                  ...options,
                  scales: {
                    ...options.scales,
                    y: {
                      ...options.scales.y,
                      stacked: false
                    }
                  }
                }} 
              />
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="table" className="p-0">
          <div className="border rounded-md overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/50">
                  <th className="py-3 px-4 text-right font-medium">الشهر</th>
                  <th className="py-3 px-4 text-left font-medium">التدفقات الواردة</th>
                  <th className="py-3 px-4 text-left font-medium">التدفقات الصادرة</th>
                  <th className="py-3 px-4 text-left font-medium">الرصيد الشهري</th>
                  <th className="py-3 px-4 text-left font-medium">الرصيد التراكمي</th>
                </tr>
              </thead>
              <tbody>
                {projection.monthlyProjections.map((month, index) => {
                  const cumulativeBalance = projection.monthlyProjections
                    .slice(0, index + 1)
                    .reduce((sum, item) => sum + item.balance, 0);
                    
                  return (
                    <tr key={index} className="border-b">
                      <td className="py-3 px-4 font-medium">{month.month}</td>
                      <td className="py-3 px-4 text-left text-green-600">
                        {formatCurrency(month.inflow)}
                      </td>
                      <td className="py-3 px-4 text-left text-red-600">
                        {formatCurrency(month.outflow)}
                      </td>
                      <td className={`py-3 px-4 text-left ${month.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {month.balance >= 0 ? '+' : ''}
                        {formatCurrency(month.balance)}
                      </td>
                      <td className={`py-3 px-4 text-left font-medium ${cumulativeBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(cumulativeBalance)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CashFlowProjection;