import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DatePicker } from "@/components/ui/date-picker";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Edit, 
  Trash2, 
  Download, 
  Plus, 
  FilePlus, 
  FileText, 
  RefreshCw, 
  Search, 
  EyeIcon, 
  Printer, 
  CheckCircle, 
  Clock, 
  X,
  FileClock,
  FileCheck
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO } from "date-fns";
import { ar } from "date-fns/locale";
import { 
  insertPaymentRequestItemSchema, 
  insertPaymentRequestSchema,
  PaymentRequest
} from "@shared/schema.new";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";

interface PaymentRequestManagerProps {
  projectId?: number;
}

export const PaymentRequestManager: React.FC<PaymentRequestManagerProps> = ({ projectId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState("");
  const [showItemsPanel, setShowItemsPanel] = useState(false);
  
  // تحضير بارامترات الاستعلام
  const queryParams = new URLSearchParams();
  if (projectId) queryParams.append("projectId", projectId.toString());
  if (statusFilter && statusFilter !== "all") queryParams.append("status", statusFilter);
  
  // استعلام طلبات الدفع (المستخلصات)
  const { data: paymentRequests = [], isLoading } = useQuery({
    queryKey: ["/api/payment-requests", projectId, statusFilter],
    enabled: !!projectId,
  });

  // استعلام المشاريع للاستخدام في الواجهة
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // تعريف نموذج طلب الدفع
  const paymentRequestFormSchema = z.object({
    projectId: z.number().int().positive(),
    requestNumber: z.string().min(1, { message: "يجب تحديد رقم المستخلص" }),
    title: z.string().min(3, { message: "يجب أن يكون العنوان 3 أحرف على الأقل" }),
    type: z.string().min(1, { message: "يجب تحديد نوع المستخلص" }),
    startDate: z.date({ message: "يجب تحديد تاريخ البداية" }),
    endDate: z.date({ message: "يجب تحديد تاريخ النهاية" }),
    issueDate: z.date({ message: "يجب تحديد تاريخ الإصدار" }),
    totalAmount: z.coerce.number().min(0, { message: "يجب أن يكون المبلغ الإجمالي أكبر من أو يساوي صفر" }),
    previousPaymentsAmount: z.coerce.number().min(0, { message: "يجب أن تكون الدفعات السابقة أكبر من أو تساوي صفر" }),
    currentPaymentAmount: z.coerce.number().min(0, { message: "يجب أن تكون الدفعة الحالية أكبر من أو تساوي صفر" }),
    totalCompletionPercentage: z.coerce.number().min(0, { message: "يجب أن تكون نسبة الإنجاز أكبر من أو تساوي صفر" }).max(100, { message: "يجب أن تكون نسبة الإنجاز أقل من أو تساوي 100" }),
    status: z.string().min(1, { message: "يجب تحديد حالة المستخلص" }),
    notes: z.string().optional(),
    createdBy: z.number().int().positive(),
    attachments: z.array(z.string()).optional(),
  });

  // نوع نموذج طلب الدفع
  type PaymentRequestFormValues = z.infer<typeof paymentRequestFormSchema>;

  // تعريف نموذج بند طلب الدفع
  const paymentRequestItemFormSchema = z.object({
    paymentRequestId: z.number().int().positive(),
    itemName: z.string().min(1, { message: "يجب تحديد اسم البند" }),
    itemDescription: z.string().optional(),
    unit: z.string().min(1, { message: "يجب تحديد وحدة القياس" }),
    unitPrice: z.coerce.number().min(0, { message: "يجب أن يكون سعر الوحدة أكبر من أو يساوي صفر" }),
    plannedQuantity: z.coerce.number().min(0, { message: "يجب أن تكون الكمية المخططة أكبر من أو تساوي صفر" }),
    completedQuantity: z.coerce.number().min(0, { message: "يجب أن تكون الكمية المنجزة أكبر من أو تساوي صفر" }),
    previousPaymentPercentage: z.coerce.number().min(0, { message: "يجب أن تكون نسبة الدفع السابقة أكبر من أو تساوي صفر" }).max(100, { message: "يجب أن تكون نسبة الدفع السابقة أقل من أو تساوي 100" }),
    notes: z.string().optional(),
  });

  // نوع نموذج بند طلب الدفع
  type PaymentRequestItemFormValues = z.infer<typeof paymentRequestItemFormSchema>;

  // نموذج إضافة طلب دفع
  const addForm = useForm<PaymentRequestFormValues>({
    resolver: zodResolver(paymentRequestFormSchema),
    defaultValues: {
      projectId: projectId || 0,
      requestNumber: "",
      title: "",
      type: "partial",
      startDate: new Date(),
      endDate: new Date(),
      issueDate: new Date(),
      totalAmount: 0,
      previousPaymentsAmount: 0,
      currentPaymentAmount: 0,
      totalCompletionPercentage: 0,
      status: "draft",
      notes: "",
      createdBy: 1, // افتراضي
      attachments: [],
    },
  });

  // نموذج إضافة بند طلب دفع
  const addItemForm = useForm<PaymentRequestItemFormValues>({
    resolver: zodResolver(paymentRequestItemFormSchema),
    defaultValues: {
      paymentRequestId: 0,
      itemName: "",
      itemDescription: "",
      unit: "",
      unitPrice: 0,
      plannedQuantity: 0,
      completedQuantity: 0,
      previousPaymentPercentage: 0,
      notes: "",
    },
  });

  // mutation لإضافة طلب دفع
  const addPaymentRequestMutation = useMutation({
    mutationFn: async (data: PaymentRequestFormValues) => {
      const formattedData = {
        ...data,
        startDate: format(data.startDate, "yyyy-MM-dd"),
        endDate: format(data.endDate, "yyyy-MM-dd"),
        issueDate: format(data.issueDate, "yyyy-MM-dd"),
      };
      const response = await apiRequest("POST", "/api/payment-requests", formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة المستخلص بنجاح",
      });
      setIsAddDialogOpen(false);
      addForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/payment-requests"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الإضافة",
        description: error.message || "حدث خطأ أثناء إضافة المستخلص",
        variant: "destructive",
      });
    },
  });

  // mutation لتعديل طلب دفع
  const updatePaymentRequestMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const formattedData = {
        ...data,
        startDate: format(data.startDate, "yyyy-MM-dd"),
        endDate: format(data.endDate, "yyyy-MM-dd"),
        issueDate: format(data.issueDate, "yyyy-MM-dd"),
      };
      const response = await apiRequest("PATCH", `/api/payment-requests/${id}`, formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التعديل",
        description: "تم تعديل المستخلص بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-requests"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التعديل",
        description: error.message || "حدث خطأ أثناء تعديل المستخلص",
        variant: "destructive",
      });
    },
  });

  // mutation لإضافة بند طلب دفع
  const addPaymentRequestItemMutation = useMutation({
    mutationFn: async (data: PaymentRequestItemFormValues) => {
      const response = await apiRequest("POST", "/api/payment-request-items", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة بند المستخلص بنجاح",
      });
      addItemForm.reset();
      if (selectedRequest) {
        queryClient.invalidateQueries({ queryKey: [`/api/payment-requests/${selectedRequest.id}/items`] });
      }
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الإضافة",
        description: error.message || "حدث خطأ أثناء إضافة بند المستخلص",
        variant: "destructive",
      });
    },
  });

  // mutation لحذف طلب دفع
  const deletePaymentRequestMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/payment-requests/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف المستخلص بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-requests"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الحذف",
        description: error.message || "حدث خطأ أثناء حذف المستخلص",
        variant: "destructive",
      });
    },
  });

  // استعلام لجلب بنود المستخلص المحدد
  const { data: selectedRequestItems = [], isLoading: itemsLoading } = useQuery({
    queryKey: [`/api/payment-requests/${selectedRequest?.id}/items`],
    enabled: !!selectedRequest?.id && showItemsPanel,
  });

  // تقديم نموذج إضافة طلب دفع
  const onAddSubmit = (data: PaymentRequestFormValues) => {
    addPaymentRequestMutation.mutate(data);
  };

  // تقديم نموذج إضافة بند طلب دفع
  const onAddItemSubmit = (data: PaymentRequestItemFormValues) => {
    addPaymentRequestItemMutation.mutate(data);
  };

  // مناولة عرض تفاصيل المستخلص
  const handleView = (request: any) => {
    setSelectedRequest(request);
    setShowItemsPanel(true);
    setIsViewDialogOpen(true);
    
    // إعادة تعيين نموذج إضافة بند
    addItemForm.reset({
      paymentRequestId: request.id,
      itemName: "",
      itemDescription: "",
      unit: "",
      unitPrice: 0,
      plannedQuantity: 0,
      completedQuantity: 0,
      previousPaymentPercentage: 0,
      notes: "",
    });
  };

  // حذف طلب دفع مع تأكيد
  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا المستخلص؟")) {
      deletePaymentRequestMutation.mutate(id);
    }
  };

  // تنزيل أو عرض المستخلص
  const handleDownload = (request: any) => {
    if (request.attachments && request.attachments.length > 0) {
      window.open(request.attachments[0], "_blank");
    } else {
      toast({
        title: "تعذر التنزيل",
        description: "لم يتم العثور على مرفقات للمستخلص",
        variant: "destructive",
      });
    }
  };

  // تحديث حالة المستخلص
  const handleUpdateStatus = (id: number, newStatus: string) => {
    updatePaymentRequestMutation.mutate({
      id,
      data: {
        status: newStatus,
      },
    });
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA') + ' ريال';
  };

  // الحصول على اسم المشروع من المعرف
  const getProjectName = (projectId: number) => {
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(parseISO(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // تحديد لون الحالة
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
      case 'معتمد':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'قيد المراجعة':
        return 'bg-yellow-100 text-yellow-800';
      case 'draft':
      case 'مسودة':
        return 'bg-gray-100 text-gray-800';
      case 'paid':
      case 'مدفوع':
        return 'bg-blue-100 text-blue-800';
      case 'rejected':
      case 'مرفوض':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // تنسيق نوع المستخلص
  const formatRequestType = (type: string) => {
    switch (type) {
      case 'initial': return 'ابتدائي';
      case 'partial': return 'جزئي';
      case 'final': return 'نهائي';
      default: return type;
    }
  };

  // إعادة تعيين التصفية
  const resetFilters = () => {
    setStatusFilter(undefined);
    setSearchTerm("");
  };

  // تصفية المستخلصات حسب نص البحث
  const filteredRequests = paymentRequests.filter((request: any) => {
    return (
      request.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      request.requestNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      formatRequestType(request.type).toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  // رمز الحالة
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'draft':
        return <FileClock className="h-5 w-5 text-gray-500" />;
      case 'paid':
        return <FileCheck className="h-5 w-5 text-blue-500" />;
      case 'rejected':
        return <X className="h-5 w-5 text-red-500" />;
      default:
        return <FileText className="h-5 w-5 text-gray-500" />;
    }
  };

  // حساب المبلغ الإجمالي لبند المستخلص
  const calculateItemTotal = (item: any) => {
    return (item.unitPrice * item.completedQuantity * (100 - item.previousPaymentPercentage) / 100);
  };

  // حالة تحميل وقائمة فارغة
  const renderEmptyState = () => (
    <div className="text-center py-12 bg-white rounded-lg border">
      <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
      <h3 className="font-medium text-lg mb-2">لا توجد مستخلصات</h3>
      <p className="text-muted-foreground mb-4">
        لم يتم العثور على مستخلصات متطابقة مع معايير البحث
      </p>
      <Button 
        variant="outline" 
        onClick={resetFilters}
      >
        عرض جميع المستخلصات
      </Button>
    </div>
  );

  return (
    <div>
      {/* شريط الأدوات والتصفية */}
      <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between">
        <div className="flex flex-col md:flex-row gap-2">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="بحث في المستخلصات..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="حالة المستخلص" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الحالات</SelectItem>
              <SelectItem value="draft">مسودة</SelectItem>
              <SelectItem value="pending">قيد المراجعة</SelectItem>
              <SelectItem value="approved">معتمد</SelectItem>
              <SelectItem value="paid">مدفوع</SelectItem>
              <SelectItem value="rejected">مرفوض</SelectItem>
            </SelectContent>
          </Select>

          <Button 
            variant="outline" 
            onClick={resetFilters}
            className="h-10"
            disabled={!statusFilter && !searchTerm}
          >
            <RefreshCw className="ml-2 h-4 w-4" />
            إعادة تعيين
          </Button>
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="h-10">
              <FilePlus className="ml-2 h-4 w-4" /> إضافة مستخلص
            </Button>
          </DialogTrigger>
          <DialogContent className="md:max-w-[700px]">
            <DialogHeader>
              <DialogTitle>إضافة مستخلص جديد</DialogTitle>
              <DialogDescription>
                أدخل تفاصيل المستخلص الجديد
              </DialogDescription>
            </DialogHeader>
            
            <Form {...addForm}>
              <form onSubmit={addForm.handleSubmit(onAddSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={addForm.control}
                    name="requestNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رقم المستخلص</FormLabel>
                        <FormControl>
                          <Input placeholder="أدخل رقم المستخلص" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>عنوان المستخلص</FormLabel>
                        <FormControl>
                          <Input placeholder="أدخل عنوان المستخلص" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نوع المستخلص</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر نوع المستخلص" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="initial">ابتدائي</SelectItem>
                            <SelectItem value="partial">جزئي</SelectItem>
                            <SelectItem value="final">نهائي</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>حالة المستخلص</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر حالة المستخلص" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="draft">مسودة</SelectItem>
                            <SelectItem value="pending">قيد المراجعة</SelectItem>
                            <SelectItem value="approved">معتمد</SelectItem>
                            <SelectItem value="paid">مدفوع</SelectItem>
                            <SelectItem value="rejected">مرفوض</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ بداية الفترة</FormLabel>
                        <FormControl>
                          <DatePicker
                            date={field.value}
                            setDate={field.onChange}
                            placeholder="اختر تاريخ البداية"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ نهاية الفترة</FormLabel>
                        <FormControl>
                          <DatePicker
                            date={field.value}
                            setDate={field.onChange}
                            placeholder="اختر تاريخ النهاية"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="issueDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ إصدار المستخلص</FormLabel>
                        <FormControl>
                          <DatePicker
                            date={field.value}
                            setDate={field.onChange}
                            placeholder="اختر تاريخ الإصدار"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="totalAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>إجمالي المبلغ</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="أدخل إجمالي المبلغ" 
                            {...field} 
                            min={0}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="previousPaymentsAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>مبالغ الدفعات السابقة</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="أدخل مبالغ الدفعات السابقة" 
                            {...field} 
                            min={0}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="currentPaymentAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>مبلغ الدفعة الحالية</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="أدخل مبلغ الدفعة الحالية" 
                            {...field} 
                            min={0}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={addForm.control}
                    name="totalCompletionPercentage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>نسبة الإنجاز الكلية (%)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="أدخل نسبة الإنجاز" 
                            {...field} 
                            min={0}
                            max={100}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={addForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات (اختياري)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="أدخل أي ملاحظات إضافية" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={addPaymentRequestMutation.isPending}
                  >
                    {addPaymentRequestMutation.isPending ? "جاري الإضافة..." : "إضافة"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* قائمة المستخلصات */}
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredRequests.length === 0 ? (
        renderEmptyState()
      ) : (
        <div className="overflow-x-auto border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>رقم المستخلص</TableHead>
                <TableHead>عنوان المستخلص</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>الفترة</TableHead>
                <TableHead>نسبة الإنجاز</TableHead>
                <TableHead>الدفعة الحالية</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequests.map((request: any) => (
                <TableRow key={request.id}>
                  <TableCell className="font-medium">
                    {request.requestNumber}
                  </TableCell>
                  <TableCell>{request.title}</TableCell>
                  <TableCell>{formatRequestType(request.type)}</TableCell>
                  <TableCell>
                    <div className="text-xs">
                      <div>{formatDate(request.startDate)}</div>
                      <div className="text-muted-foreground">إلى: {formatDate(request.endDate)}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col space-y-1">
                      <Progress 
                        value={request.totalCompletionPercentage || 0} 
                        className="h-2" 
                      />
                      <span className="text-xs">
                        {request.totalCompletionPercentage || 0}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>{formatCurrency(request.currentPaymentAmount)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(request.status)}
                      <Badge className={`${getStatusColor(request.status)}`}>
                        {request.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="12" cy="5" r="1" />
                            <circle cx="12" cy="19" r="1" />
                          </svg>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          className="flex items-center gap-2"
                          onClick={() => handleView(request)}
                        >
                          <EyeIcon className="h-4 w-4" />
                          <span>عرض التفاصيل</span>
                        </DropdownMenuItem>
                        
                        {request.status === 'draft' && (
                          <DropdownMenuItem 
                            className="flex items-center gap-2"
                            onClick={() => handleUpdateStatus(request.id, 'pending')}
                          >
                            <Clock className="h-4 w-4" />
                            <span>تقديم للمراجعة</span>
                          </DropdownMenuItem>
                        )}
                        
                        {request.status === 'pending' && (
                          <>
                            <DropdownMenuItem 
                              className="flex items-center gap-2 text-green-600"
                              onClick={() => handleUpdateStatus(request.id, 'approved')}
                            >
                              <CheckCircle className="h-4 w-4" />
                              <span>اعتماد</span>
                            </DropdownMenuItem>
                            
                            <DropdownMenuItem 
                              className="flex items-center gap-2 text-red-600"
                              onClick={() => handleUpdateStatus(request.id, 'rejected')}
                            >
                              <X className="h-4 w-4" />
                              <span>رفض</span>
                            </DropdownMenuItem>
                          </>
                        )}
                        
                        {request.status === 'approved' && (
                          <DropdownMenuItem 
                            className="flex items-center gap-2 text-blue-600"
                            onClick={() => handleUpdateStatus(request.id, 'paid')}
                          >
                            <FileCheck className="h-4 w-4" />
                            <span>تسجيل كمدفوع</span>
                          </DropdownMenuItem>
                        )}
                        
                        {request.attachments && request.attachments.length > 0 && (
                          <DropdownMenuItem 
                            className="flex items-center gap-2"
                            onClick={() => handleDownload(request)}
                          >
                            <Download className="h-4 w-4" />
                            <span>تنزيل</span>
                          </DropdownMenuItem>
                        )}
                        
                        {request.status === 'draft' && (
                          <DropdownMenuItem 
                            className="flex items-center gap-2 text-red-600"
                            onClick={() => handleDelete(request.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span>حذف</span>
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* مربع حوار عرض تفاصيل المستخلص وإدارة البنود */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="md:max-w-[900px]">
          <DialogHeader>
            <DialogTitle>تفاصيل المستخلص</DialogTitle>
            <DialogDescription>
              مراجعة وإدارة المستخلص وبنوده
            </DialogDescription>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="py-4">
              <div className="bg-gray-50 p-6 rounded-lg border mb-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-bold">{selectedRequest.title}</h2>
                    <p className="text-muted-foreground">
                      مستخلص رقم: {selectedRequest.requestNumber} - {getProjectName(selectedRequest.projectId)}
                    </p>
                  </div>
                  <Badge className={`${getStatusColor(selectedRequest.status)} text-sm px-3 py-1.5 mt-2 md:mt-0`}>
                    {selectedRequest.status}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">نوع المستخلص</h3>
                    <p className="font-medium">{formatRequestType(selectedRequest.type)}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">فترة المستخلص</h3>
                    <p className="font-medium">
                      {formatDate(selectedRequest.startDate)} إلى {formatDate(selectedRequest.endDate)}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">تاريخ الإصدار</h3>
                    <p className="font-medium">{formatDate(selectedRequest.issueDate)}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">إجمالي المبلغ</h3>
                    <p className="font-medium text-primary">{formatCurrency(selectedRequest.totalAmount)}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">الدفعات السابقة</h3>
                    <p className="font-medium">{formatCurrency(selectedRequest.previousPaymentsAmount)}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">الدفعة الحالية</h3>
                    <p className="font-medium text-green-600">{formatCurrency(selectedRequest.currentPaymentAmount)}</p>
                  </div>
                </div>
                
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-muted-foreground mb-1">نسبة الإنجاز</h3>
                  <div className="flex items-center gap-2">
                    <Progress value={selectedRequest.totalCompletionPercentage} className="flex-1 h-2" />
                    <span className="text-sm font-medium">{selectedRequest.totalCompletionPercentage}%</span>
                  </div>
                </div>
                
                {selectedRequest.notes && (
                  <div className="mt-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">ملاحظات</h3>
                    <p className="p-3 bg-white border rounded-md">{selectedRequest.notes}</p>
                  </div>
                )}
              </div>
              
              <div className="border-t pt-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold">بنود المستخلص</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowItemsPanel(!showItemsPanel)}
                  >
                    {showItemsPanel ? "إخفاء البنود" : "عرض البنود"}
                  </Button>
                </div>
                
                {showItemsPanel && (
                  <>
                    {itemsLoading ? (
                      <div className="flex justify-center p-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </div>
                    ) : selectedRequestItems.length === 0 ? (
                      <div className="text-center py-6 bg-gray-50 rounded-lg border">
                        <FileText className="h-10 w-10 mx-auto text-gray-400 mb-3" />
                        <p className="text-muted-foreground mb-3">
                          لا توجد بنود مضافة للمستخلص حتى الآن
                        </p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto border rounded-lg mb-6">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>البند</TableHead>
                              <TableHead>الوحدة</TableHead>
                              <TableHead>سعر الوحدة</TableHead>
                              <TableHead>الكمية المخططة</TableHead>
                              <TableHead>الكمية المنجزة</TableHead>
                              <TableHead>نسبة الدفع السابقة</TableHead>
                              <TableHead>المبلغ المستحق</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedRequestItems.map((item: any) => (
                              <TableRow key={item.id}>
                                <TableCell>
                                  <div>
                                    <div className="font-medium">{item.itemName}</div>
                                    {item.itemDescription && (
                                      <div className="text-xs text-muted-foreground">{item.itemDescription}</div>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell>{item.unit}</TableCell>
                                <TableCell>{formatCurrency(item.unitPrice)}</TableCell>
                                <TableCell>{item.plannedQuantity}</TableCell>
                                <TableCell>{item.completedQuantity}</TableCell>
                                <TableCell>{item.previousPaymentPercentage}%</TableCell>
                                <TableCell className="font-medium">
                                  {formatCurrency(calculateItemTotal(item))}
                                </TableCell>
                              </TableRow>
                            ))}
                            <TableRow>
                              <TableCell colSpan={6} className="text-left font-bold">
                                الإجمالي
                              </TableCell>
                              <TableCell className="font-bold text-primary">
                                {formatCurrency(
                                  selectedRequestItems.reduce(
                                    (sum: number, item: any) => sum + calculateItemTotal(item),
                                    0
                                  )
                                )}
                              </TableCell>
                            </TableRow>
                          </TableBody>
                        </Table>
                      </div>
                    )}
                    
                    {/* نموذج إضافة بند جديد */}
                    {selectedRequest.status === 'draft' && (
                      <Card className="mt-6">
                        <CardHeader>
                          <CardTitle>إضافة بند جديد</CardTitle>
                          <CardDescription>
                            أضف بند جديد للمستخلص
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Form {...addItemForm}>
                            <form onSubmit={addItemForm.handleSubmit(onAddItemSubmit)} className="space-y-6">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <FormField
                                  control={addItemForm.control}
                                  name="itemName"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>اسم البند</FormLabel>
                                      <FormControl>
                                        <Input placeholder="أدخل اسم البند" {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={addItemForm.control}
                                  name="unit"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>وحدة القياس</FormLabel>
                                      <FormControl>
                                        <Input placeholder="متر مربع، متر طولي، قطعة..." {...field} />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={addItemForm.control}
                                  name="unitPrice"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>سعر الوحدة</FormLabel>
                                      <FormControl>
                                        <Input 
                                          type="number" 
                                          placeholder="أدخل سعر الوحدة" 
                                          {...field} 
                                          min={0}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={addItemForm.control}
                                  name="plannedQuantity"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>الكمية المخططة</FormLabel>
                                      <FormControl>
                                        <Input 
                                          type="number" 
                                          placeholder="أدخل الكمية المخططة" 
                                          {...field} 
                                          min={0}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={addItemForm.control}
                                  name="completedQuantity"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>الكمية المنجزة</FormLabel>
                                      <FormControl>
                                        <Input 
                                          type="number" 
                                          placeholder="أدخل الكمية المنجزة" 
                                          {...field} 
                                          min={0}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={addItemForm.control}
                                  name="previousPaymentPercentage"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>نسبة الدفع السابقة (%)</FormLabel>
                                      <FormControl>
                                        <Input 
                                          type="number" 
                                          placeholder="أدخل نسبة الدفع السابقة" 
                                          {...field} 
                                          min={0}
                                          max={100}
                                        />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <FormField
                                control={addItemForm.control}
                                name="itemDescription"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>وصف البند (اختياري)</FormLabel>
                                    <FormControl>
                                      <Textarea 
                                        placeholder="أدخل وصفاً إضافياً للبند" 
                                        {...field} 
                                      />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <div className="flex justify-end">
                                <Button 
                                  type="submit" 
                                  disabled={addPaymentRequestItemMutation.isPending}
                                >
                                  {addPaymentRequestItemMutation.isPending ? "جاري الإضافة..." : "إضافة البند"}
                                </Button>
                              </div>
                            </form>
                          </Form>
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};