import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import {
  FileText,
  Download,
  Calendar,
  Filter,
  RefreshCw,
  ChevronDown,
  ArrowDownUp,
  Printer,
  Table as TableIcon,
  BarChart3,
  PieChart,
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import { ChartOfAccount, Project, AccountBalance, JournalEntry } from "@shared/schema";

// مكون عرض التقارير المالية
export default function FinancialReportsViewer() {
  const { toast } = useToast();
  const [selectedReportType, setSelectedReportType] = useState("balance-sheet");
  const [selectedPeriod, setSelectedPeriod] = useState<string>("current-month");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedProject, setSelectedProject] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  // استعلامات البيانات
  const {
    data: projects = [],
    isLoading: isLoadingProjects,
  } = useQuery({
    queryKey: ["/api/projects"],
    retry: 2,
  });

  const {
    data: accounts = [],
    isLoading: isLoadingAccounts,
  } = useQuery({
    queryKey: ["/api/accounts"],
    retry: 2,
  });

  const {
    data: accountBalances = [],
    isLoading: isLoadingBalances,
    error: balancesError,
  } = useQuery({
    queryKey: ["/api/account-balances", { 
      projectId: selectedProject, 
      fiscalYear: selectedDate.getFullYear(),
      fiscalMonth: selectedDate.getMonth() + 1 
    }],
    retry: 2,
  });

  // الحصول على اسم المشروع
  const getProjectName = (projectId: number | null) => {
    if (!projectId) return "الشركة (الكل)";
    const project = projects.find((p: Project) => p.id === projectId);
    return project ? project.name : "غير معروف";
  };

  // تحويل قيم التاريخ إلى بداية ونهاية الفترة المحددة
  useEffect(() => {
    const now = new Date();
    let fromDate: Date;
    let toDate: Date;

    switch (selectedPeriod) {
      case "current-month": {
        fromDate = new Date(now.getFullYear(), now.getMonth(), 1);
        toDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        setSelectedDate(fromDate);
        break;
      }
      case "last-month": {
        fromDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        toDate = new Date(now.getFullYear(), now.getMonth(), 0);
        setSelectedDate(fromDate);
        break;
      }
      case "current-quarter": {
        const currentQuarter = Math.floor(now.getMonth() / 3);
        fromDate = new Date(now.getFullYear(), currentQuarter * 3, 1);
        toDate = new Date(now.getFullYear(), (currentQuarter + 1) * 3, 0);
        setSelectedDate(fromDate);
        break;
      }
      case "current-year": {
        fromDate = new Date(now.getFullYear(), 0, 1);
        toDate = new Date(now.getFullYear(), 11, 31);
        setSelectedDate(fromDate);
        break;
      }
      case "last-year": {
        fromDate = new Date(now.getFullYear() - 1, 0, 1);
        toDate = new Date(now.getFullYear() - 1, 11, 31);
        setSelectedDate(fromDate);
        break;
      }
      case "custom": {
        // الفترة المخصصة تستخدم التاريخ المختار مباشرة
        break;
      }
    }
  }, [selectedPeriod]);

  // تنسيق المبلغ المالي 
  const formatAmount = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return "0.00";
    return new Intl.NumberFormat("ar-SA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // تصنيف الحسابات حسب النوع لعرض القوائم المالية
  const groupAccountsByType = () => {
    // تنظيم الحسابات وأرصدتها حسب النوع
    const accountGroups: Record<string, any[]> = {
      assets: [],
      liabilities: [],
      equity: [],
      revenues: [],
      expenses: [],
    };

    accounts.forEach((account: ChartOfAccount) => {
      const balance = accountBalances.find(
        (b: AccountBalance) => 
          b.accountId === account.id && 
          (selectedProject === null || b.projectId === selectedProject)
      );

      const accountWithBalance = {
        ...account,
        balance: balance?.balance || 0,
        debitTotal: balance?.debitTotal || 0,
        creditTotal: balance?.creditTotal || 0
      };

      switch (account.type) {
        case "asset":
          accountGroups.assets.push(accountWithBalance);
          break;
        case "liability":
          accountGroups.liabilities.push(accountWithBalance);
          break;
        case "equity":
          accountGroups.equity.push(accountWithBalance);
          break;
        case "revenue":
          accountGroups.revenues.push(accountWithBalance);
          break;
        case "expense":
          accountGroups.expenses.push(accountWithBalance);
          break;
      }
    });

    // ترتيب الحسابات داخل كل مجموعة حسب الكود
    Object.keys(accountGroups).forEach(group => {
      accountGroups[group].sort((a, b) => a.code.localeCompare(b.code));
    });

    return accountGroups;
  };

  // حساب المجاميع للتقارير المالية
  const calculateTotals = (accountGroups: Record<string, any[]>) => {
    const totals = {
      totalAssets: accountGroups.assets.reduce((sum, acc) => sum + acc.balance, 0),
      totalLiabilities: accountGroups.liabilities.reduce((sum, acc) => sum + acc.balance, 0),
      totalEquity: accountGroups.equity.reduce((sum, acc) => sum + acc.balance, 0),
      totalRevenues: accountGroups.revenues.reduce((sum, acc) => sum + acc.balance, 0),
      totalExpenses: accountGroups.expenses.reduce((sum, acc) => sum + acc.balance, 0),
      netIncome: 0
    };

    totals.netIncome = totals.totalRevenues - totals.totalExpenses;

    return totals;
  };

  const accountGroups = groupAccountsByType();
  const totals = calculateTotals(accountGroups);

  // عرض الميزانية العمومية
  const BalanceSheetReport = () => {
    return (
      <div>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">الميزانية العمومية</CardTitle>
            <CardDescription>
              {getProjectName(selectedProject)} | 
              {format(selectedDate, "MMMM yyyy", { locale: ar })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAccounts || isLoadingBalances ? (
              <div className="space-y-2">
                {Array(8).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-8" />
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {/* الأصول */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">الأصول</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50%]">الحساب</TableHead>
                          <TableHead className="text-left">الرصيد</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {accountGroups.assets.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={2} className="text-center text-muted-foreground h-16">
                              لا توجد حسابات أصول مسجلة
                            </TableCell>
                          </TableRow>
                        ) : (
                          accountGroups.assets.map((account) => (
                            <TableRow key={account.id}>
                              <TableCell>
                                <div className="font-medium">{account.name}</div>
                                <div className="text-xs text-muted-foreground">{account.code}</div>
                              </TableCell>
                              <TableCell className="text-left">
                                {formatAmount(account.balance)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                      <TableRow className="bg-muted/50">
                        <TableCell className="font-bold">إجمالي الأصول</TableCell>
                        <TableCell className="text-left font-bold">{formatAmount(totals.totalAssets)}</TableCell>
                      </TableRow>
                    </Table>
                  </div>
                </div>

                {/* الخصوم وحقوق الملكية */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">الخصوم وحقوق الملكية</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50%]">الحساب</TableHead>
                          <TableHead className="text-left">الرصيد</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {/* الخصوم */}
                        {accountGroups.liabilities.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={2} className="text-center text-muted-foreground h-16">
                              لا توجد حسابات خصوم مسجلة
                            </TableCell>
                          </TableRow>
                        ) : (
                          accountGroups.liabilities.map((account) => (
                            <TableRow key={account.id}>
                              <TableCell>
                                <div className="font-medium">{account.name}</div>
                                <div className="text-xs text-muted-foreground">{account.code}</div>
                              </TableCell>
                              <TableCell className="text-left">
                                {formatAmount(account.balance)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                        
                        {/* مجموع الخصوم */}
                        <TableRow>
                          <TableCell>
                            <div className="font-medium">إجمالي الخصوم</div>
                          </TableCell>
                          <TableCell className="text-left font-medium">
                            {formatAmount(totals.totalLiabilities)}
                          </TableCell>
                        </TableRow>
                        
                        {/* حقوق الملكية */}
                        {accountGroups.equity.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={2} className="text-center text-muted-foreground h-16">
                              لا توجد حسابات حقوق ملكية مسجلة
                            </TableCell>
                          </TableRow>
                        ) : (
                          accountGroups.equity.map((account) => (
                            <TableRow key={account.id}>
                              <TableCell>
                                <div className="font-medium">{account.name}</div>
                                <div className="text-xs text-muted-foreground">{account.code}</div>
                              </TableCell>
                              <TableCell className="text-left">
                                {formatAmount(account.balance)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                        
                        {/* صافي الدخل */}
                        <TableRow>
                          <TableCell>
                            <div className="font-medium">صافي الدخل للفترة</div>
                          </TableCell>
                          <TableCell className="text-left">
                            {formatAmount(totals.netIncome)}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                      <TableRow className="bg-muted/50">
                        <TableCell className="font-bold">إجمالي الخصوم وحقوق الملكية</TableCell>
                        <TableCell className="text-left font-bold">
                          {formatAmount(totals.totalLiabilities + totals.totalEquity + totals.netIncome)}
                        </TableCell>
                      </TableRow>
                    </Table>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end pt-2">
            <Button variant="outline" className="ml-2" onClick={() => window.print()}>
              <Printer className="h-4 w-4 ml-1 rtl:mr-1" /> طباعة التقرير
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  };

  // عرض قائمة الدخل
  const IncomeStatementReport = () => {
    return (
      <div>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">قائمة الدخل</CardTitle>
            <CardDescription>
              {getProjectName(selectedProject)} | 
              {format(selectedDate, "MMMM yyyy", { locale: ar })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAccounts || isLoadingBalances ? (
              <div className="space-y-2">
                {Array(8).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-8" />
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {/* الإيرادات */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">الإيرادات</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50%]">الحساب</TableHead>
                          <TableHead className="text-left">الرصيد</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {accountGroups.revenues.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={2} className="text-center text-muted-foreground h-16">
                              لا توجد حسابات إيرادات مسجلة
                            </TableCell>
                          </TableRow>
                        ) : (
                          accountGroups.revenues.map((account) => (
                            <TableRow key={account.id}>
                              <TableCell>
                                <div className="font-medium">{account.name}</div>
                                <div className="text-xs text-muted-foreground">{account.code}</div>
                              </TableCell>
                              <TableCell className="text-left">
                                {formatAmount(account.balance)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                      <TableRow className="bg-muted/50">
                        <TableCell className="font-bold">إجمالي الإيرادات</TableCell>
                        <TableCell className="text-left font-bold">{formatAmount(totals.totalRevenues)}</TableCell>
                      </TableRow>
                    </Table>
                  </div>
                </div>

                {/* المصروفات */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">المصروفات</h3>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[50%]">الحساب</TableHead>
                          <TableHead className="text-left">الرصيد</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {accountGroups.expenses.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={2} className="text-center text-muted-foreground h-16">
                              لا توجد حسابات مصروفات مسجلة
                            </TableCell>
                          </TableRow>
                        ) : (
                          accountGroups.expenses.map((account) => (
                            <TableRow key={account.id}>
                              <TableCell>
                                <div className="font-medium">{account.name}</div>
                                <div className="text-xs text-muted-foreground">{account.code}</div>
                              </TableCell>
                              <TableCell className="text-left">
                                {formatAmount(account.balance)}
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                      <TableRow className="bg-muted/50">
                        <TableCell className="font-bold">إجمالي المصروفات</TableCell>
                        <TableCell className="text-left font-bold">{formatAmount(totals.totalExpenses)}</TableCell>
                      </TableRow>
                    </Table>
                  </div>
                </div>

                {/* صافي الدخل */}
                <div className="rounded-md border">
                  <Table>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-semibold">صافي الدخل للفترة</TableCell>
                        <TableCell className="text-left font-semibold">
                          {formatAmount(totals.netIncome)}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end pt-2">
            <Button variant="outline" className="ml-2" onClick={() => window.print()}>
              <Printer className="h-4 w-4 ml-1 rtl:mr-1" /> طباعة التقرير
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  };

  // عرض أرصدة الحسابات
  const AccountBalancesReport = () => {
    // تنظيم الحسابات في هيكل شجري
    const buildAccountTree = (accounts: ChartOfAccount[]) => {
      const accountMap = new Map<number, ChartOfAccount & { children: any[], balance: number }>();
      const rootAccounts: (ChartOfAccount & { children: any[], balance: number })[] = [];

      // إضافة خاصية أطفال لكل حساب
      accounts.forEach((account) => {
        const balance = accountBalances.find(
          (b: AccountBalance) => 
            b.accountId === account.id && 
            (selectedProject === null || b.projectId === selectedProject)
        );
        
        accountMap.set(account.id, { 
          ...account, 
          children: [],
          balance: balance?.balance || 0
        });
      });

      // بناء شجرة الحسابات
      accounts.forEach((account) => {
        const accountWithChildren = accountMap.get(account.id)!;
        if (account.parentId === null) {
          rootAccounts.push(accountWithChildren);
        } else {
          const parent = accountMap.get(account.parentId);
          if (parent) {
            parent.children.push(accountWithChildren);
          } else {
            rootAccounts.push(accountWithChildren);
          }
        }
      });

      // ترتيب الحسابات حسب الكود
      const sortAccounts = (accounts: any[]) => {
        return accounts
          .sort((a, b) => a.code.localeCompare(b.code))
          .map((account) => ({
            ...account,
            children: sortAccounts(account.children),
          }));
      };

      return sortAccounts(rootAccounts);
    };

    const accountTree = buildAccountTree(accounts);

    // دالة عرض الحساب في الشجرة
    const renderAccountRow = (account: any, level = 0) => {
      const padding = `${level * 1}rem`;
      
      return (
        <>
          <TableRow key={account.id} className={level === 0 ? "bg-secondary/20" : ""}>
            <TableCell>
              <div style={{ paddingRight: padding }} className="flex items-center">
                {account.children.length > 0 && <ChevronDown className="mr-1 h-4 w-4" />}
                <span>{account.name}</span>
              </div>
            </TableCell>
            <TableCell>{account.code}</TableCell>
            <TableCell>
              {account.type === "asset" ? "أصول" : 
               account.type === "liability" ? "خصوم" :
               account.type === "equity" ? "حقوق ملكية" :
               account.type === "revenue" ? "إيرادات" : "مصروفات"}
            </TableCell>
            <TableCell className="text-left">{formatAmount(account.balance)}</TableCell>
          </TableRow>
          {account.children.map((child: any) => renderAccountRow(child, level + 1))}
        </>
      );
    };

    return (
      <div>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">تقرير أرصدة الحسابات</CardTitle>
            <CardDescription>
              {getProjectName(selectedProject)} | 
              {format(selectedDate, "MMMM yyyy", { locale: ar })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingAccounts || isLoadingBalances ? (
              <div className="space-y-2">
                {Array(12).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-8" />
                ))}
              </div>
            ) : accountTree.length === 0 ? (
              <Alert>
                <AlertTitle>لا توجد بيانات</AlertTitle>
                <AlertDescription>
                  لم يتم العثور على أي حسابات. يرجى إضافة حسابات لعرض أرصدتها.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40%]">الحساب</TableHead>
                      <TableHead className="w-[15%]">الرمز</TableHead>
                      <TableHead className="w-[15%]">النوع</TableHead>
                      <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accountTree.map((account) => renderAccountRow(account))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end pt-2">
            <Button variant="outline" className="ml-2" onClick={() => window.print()}>
              <Printer className="h-4 w-4 ml-1 rtl:mr-1" /> طباعة التقرير
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  };

  // المكون الرئيسي
  return (
    <div className="h-full flex flex-col">
      <div className="bg-background border-b p-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-semibold">التقارير المالية</h1>
          <p className="text-sm text-muted-foreground">عرض التقارير المالية والبيانات المحاسبية</p>
        </div>
        <div className="flex gap-2">
          <Select
            value={selectedReportType}
            onValueChange={setSelectedReportType}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="نوع التقرير" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="balance-sheet">الميزانية العمومية</SelectItem>
              <SelectItem value="income-statement">قائمة الدخل</SelectItem>
              <SelectItem value="account-balances">أرصدة الحسابات</SelectItem>
            </SelectContent>
          </Select>

          <Select
            value={selectedPeriod}
            onValueChange={setSelectedPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="الفترة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-month">الشهر الحالي</SelectItem>
              <SelectItem value="last-month">الشهر السابق</SelectItem>
              <SelectItem value="current-quarter">الربع الحالي</SelectItem>
              <SelectItem value="current-year">السنة الحالية</SelectItem>
              <SelectItem value="last-year">السنة السابقة</SelectItem>
              <SelectItem value="custom">فترة مخصصة</SelectItem>
            </SelectContent>
          </Select>

          {selectedPeriod === "custom" && (
            <Popover>
              <PopoverTrigger asChild>
                <Button variant={"outline"} className="w-[180px]">
                  {format(selectedDate, "MMMM yyyy", { locale: ar })}
                  <Calendar className="ml-auto h-4 w-4 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          )}

          <Select
            value={selectedProject !== null ? selectedProject.toString() : ""}
            onValueChange={(value) => setSelectedProject(value ? parseInt(value) : null)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="المشروع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل المشاريع</SelectItem>
              {projects.map((project: Project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/account-balances"] });
          }}>
            <RefreshCw className="h-4 w-4 ml-1 rtl:mr-1" /> تحديث
          </Button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        {selectedReportType === "balance-sheet" && <BalanceSheetReport />}
        {selectedReportType === "income-statement" && <IncomeStatementReport />}
        {selectedReportType === "account-balances" && <AccountBalancesReport />}
      </div>
    </div>
  );
}