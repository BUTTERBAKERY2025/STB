import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ChevronDown, ChevronRight, Plus, Edit, Trash2, Search, RefreshCw } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ChartOfAccount } from "@shared/schema";

// تعريف المخطط الخاص بإنشاء وتعديل الحسابات
const accountFormSchema = z.object({
  code: z.string().min(1, "رمز الحساب مطلوب"),
  name: z.string().min(1, "اسم الحساب مطلوب"),
  type: z.enum(["asset", "liability", "equity", "revenue", "expense"], {
    required_error: "نوع الحساب مطلوب",
  }),
  class: z.enum(
    [
      "current_asset",
      "fixed_asset",
      "current_liability",
      "long_term_liability",
      "equity",
      "revenue",
      "direct_expense",
      "indirect_expense",
      "other_income",
      "other_expense",
    ],
    {
      required_error: "تصنيف الحساب مطلوب",
    }
  ),
  parentId: z.number().nullable(),
  description: z.string().optional(),
  isActive: z.boolean().default(true),
});

type AccountFormValues = z.infer<typeof accountFormSchema>;

// القائمة الرئيسية لشجرة الحسابات
export default function ChartOfAccountsManager() {
  const { toast } = useToast();
  const [expandedAccounts, setExpandedAccounts] = useState<number[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<ChartOfAccount | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // استعلام لجلب شجرة الحسابات
  const {
    data: accounts = [],
    isLoading,
    error,
  } = useQuery({
    queryKey: ["/api/accounts"],
    retry: 2,
  });

  // إنشاء شجرة الحسابات (إعادة هيكلة البيانات)
  const buildAccountTree = (accounts: ChartOfAccount[]) => {
    const accountMap = new Map<number, ChartOfAccount & { children: any[] }>();
    const rootAccounts: (ChartOfAccount & { children: any[] })[] = [];

    // إضافة خاصية أطفال لكل حساب
    accounts.forEach((account) => {
      accountMap.set(account.id, { ...account, children: [] });
    });

    // بناء شجرة الحسابات
    accounts.forEach((account) => {
      const accountWithChildren = accountMap.get(account.id)!;
      if (account.parentId === null) {
        rootAccounts.push(accountWithChildren);
      } else {
        const parent = accountMap.get(account.parentId);
        if (parent) {
          parent.children.push(accountWithChildren);
        } else {
          rootAccounts.push(accountWithChildren);
        }
      }
    });

    // ترتيب الحسابات حسب الكود
    const sortAccounts = (accounts: any[]) => {
      return accounts
        .sort((a, b) => a.code.localeCompare(b.code))
        .map((account) => ({
          ...account,
          children: sortAccounts(account.children),
        }));
    };

    return sortAccounts(rootAccounts);
  };

  // الحصول على شجرة الحسابات
  const accountsTree = buildAccountTree(accounts || []);

  // فلترة الحسابات حسب البحث
  const filterAccountsBySearchTerm = (accounts: any[], searchTerm: string) => {
    if (!searchTerm.trim()) return accounts;

    return accounts.filter((account) => {
      const matchesSearch =
        account.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        account.name.toLowerCase().includes(searchTerm.toLowerCase());

      const hasMatchingChildren =
        account.children &&
        filterAccountsBySearchTerm(account.children, searchTerm).length > 0;

      return matchesSearch || hasMatchingChildren;
    });
  };

  const filteredAccountsTree = filterAccountsBySearchTerm(
    accountsTree,
    searchTerm
  );

  // إضافة حساب جديد
  const addAccountMutation = useMutation({
    mutationFn: async (values: AccountFormValues) => {
      const res = await apiRequest("POST", "/api/accounts", values);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم إضافة الحساب بنجاح",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setIsAddDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إضافة الحساب",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // تعديل حساب
  const updateAccountMutation = useMutation({
    mutationFn: async ({
      id,
      values,
    }: {
      id: number;
      values: Partial<AccountFormValues>;
    }) => {
      const res = await apiRequest("PATCH", `/api/accounts/${id}`, values);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "تم تعديل الحساب بنجاح",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setIsEditDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في تعديل الحساب",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // حذف حساب
  const deleteAccountMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("DELETE", `/api/accounts/${id}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "فشل في حذف الحساب");
      }
      return true;
    },
    onSuccess: () => {
      toast({
        title: "تم حذف الحساب بنجاح",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setSelectedAccount(null);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في حذف الحساب",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // توسيع/طي حساب
  const toggleAccountExpansion = (accountId: number) => {
    if (expandedAccounts.includes(accountId)) {
      setExpandedAccounts(expandedAccounts.filter((id) => id !== accountId));
    } else {
      setExpandedAccounts([...expandedAccounts, accountId]);
    }
  };

  // تصيير عنصر الحساب في الشجرة
  const renderAccountItem = (
    account: any,
    level: number = 0,
    isLastChild: boolean = false
  ) => {
    const isExpanded = expandedAccounts.includes(account.id);
    const hasChildren = account.children && account.children.length > 0;
    const isSelected = selectedAccount?.id === account.id;

    return (
      <div key={account.id} className="account-tree-item">
        <div
          className={`account-item flex items-center py-1 px-2 rounded cursor-pointer ${
            isSelected ? "bg-secondary/30" : "hover:bg-secondary/20"
          }`}
          style={{ paddingRight: `${level * 20 + 4}px` }}
          onClick={() => setSelectedAccount(account)}
        >
          {hasChildren ? (
            <button
              className="mr-1 p-0.5 rounded hover:bg-secondary/30"
              onClick={(e) => {
                e.stopPropagation();
                toggleAccountExpansion(account.id);
              }}
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </button>
          ) : (
            <span className="w-6"></span>
          )}
          <div className="flex-1 flex items-center">
            <span className="font-mono text-sm ml-2">{account.code}</span>
            <span className="font-medium">{account.name}</span>
          </div>
          <Badge
            variant={
              account.type === "asset"
                ? "default"
                : account.type === "liability"
                ? "secondary"
                : account.type === "equity"
                ? "outline"
                : account.type === "revenue"
                ? "success"
                : "destructive"
            }
            className="ml-2 text-xs"
          >
            {account.type === "asset"
              ? "أصول"
              : account.type === "liability"
              ? "خصوم"
              : account.type === "equity"
              ? "حقوق ملكية"
              : account.type === "revenue"
              ? "إيرادات"
              : "مصروفات"}
          </Badge>
          {!account.isActive && (
            <Badge variant="outline" className="ml-2 text-xs">
              غير نشط
            </Badge>
          )}
        </div>
        {isExpanded && hasChildren && (
          <div className="account-children">
            {account.children.map((child: any, index: number) =>
              renderAccountItem(
                child,
                level + 1,
                index === account.children.length - 1
              )
            )}
          </div>
        )}
      </div>
    );
  };

  // نموذج إضافة حساب
  const AddAccountForm = () => {
    const form = useForm<AccountFormValues>({
      resolver: zodResolver(accountFormSchema),
      defaultValues: {
        code: "",
        name: "",
        description: "",
        isActive: true,
        parentId: selectedAccount?.id || null,
      },
    });

    // تحديد تصنيفات الحساب حسب النوع المختار
    const accountTypeClasses = {
      asset: ["current_asset", "fixed_asset"],
      liability: ["current_liability", "long_term_liability"],
      equity: ["equity"],
      revenue: ["revenue", "other_income"],
      expense: ["direct_expense", "indirect_expense", "other_expense"],
    };

    const selectedType = form.watch("type");
    const availableClasses = accountTypeClasses[selectedType as keyof typeof accountTypeClasses] || [];

    const onSubmit = (values: AccountFormValues) => {
      addAccountMutation.mutate(values);
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>رمز الحساب</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="مثال: 1010" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>اسم الحساب</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="مثال: النقد في الصندوق" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع الحساب</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع الحساب" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="asset">أصول</SelectItem>
                      <SelectItem value="liability">خصوم</SelectItem>
                      <SelectItem value="equity">حقوق ملكية</SelectItem>
                      <SelectItem value="revenue">إيرادات</SelectItem>
                      <SelectItem value="expense">مصروفات</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="class"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>تصنيف الحساب</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر تصنيف الحساب" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {!selectedType && (
                        <SelectItem value="" disabled>
                          اختر نوع الحساب أولاً
                        </SelectItem>
                      )}
                      {selectedType === "asset" && (
                        <>
                          <SelectItem value="current_asset">
                            أصول متداولة
                          </SelectItem>
                          <SelectItem value="fixed_asset">أصول ثابتة</SelectItem>
                        </>
                      )}
                      {selectedType === "liability" && (
                        <>
                          <SelectItem value="current_liability">
                            خصوم متداولة
                          </SelectItem>
                          <SelectItem value="long_term_liability">
                            خصوم طويلة الأجل
                          </SelectItem>
                        </>
                      )}
                      {selectedType === "equity" && (
                        <SelectItem value="equity">حقوق ملكية</SelectItem>
                      )}
                      {selectedType === "revenue" && (
                        <>
                          <SelectItem value="revenue">إيرادات</SelectItem>
                          <SelectItem value="other_income">
                            إيرادات أخرى
                          </SelectItem>
                        </>
                      )}
                      {selectedType === "expense" && (
                        <>
                          <SelectItem value="direct_expense">
                            مصروفات مباشرة
                          </SelectItem>
                          <SelectItem value="indirect_expense">
                            مصروفات غير مباشرة
                          </SelectItem>
                          <SelectItem value="other_expense">
                            مصروفات أخرى
                          </SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <FormField
            control={form.control}
            name="parentId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الحساب الأب</FormLabel>
                <Select
                  onValueChange={(value) =>
                    field.onChange(value ? parseInt(value) : null)
                  }
                  value={field.value?.toString() || ""}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="بدون حساب أب" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">بدون حساب أب</SelectItem>
                    {accounts.map((account: ChartOfAccount) => (
                      <SelectItem key={account.id} value={account.id.toString()}>
                        {account.code} - {account.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وصف الحساب</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="وصف اختياري للحساب" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-2 space-y-0 rtl:space-x-reverse">
                <FormControl>
                  <input
                    type="checkbox"
                    checked={field.value}
                    onChange={field.onChange}
                    className="ml-2"
                  />
                </FormControl>
                <FormLabel>حساب نشط</FormLabel>
              </FormItem>
            )}
          />
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button type="submit" disabled={addAccountMutation.isPending}>
              {addAccountMutation.isPending ? "جاري الإضافة..." : "إضافة الحساب"}
            </Button>
          </DialogFooter>
        </form>
      </Form>
    );
  };

  // نموذج تعديل حساب
  const EditAccountForm = () => {
    const form = useForm<AccountFormValues>({
      resolver: zodResolver(accountFormSchema),
      defaultValues: {
        code: selectedAccount?.code || "",
        name: selectedAccount?.name || "",
        type: (selectedAccount?.type as any) || "asset",
        class: (selectedAccount?.class as any) || "current_asset",
        parentId: selectedAccount?.parentId || null,
        description: selectedAccount?.description || "",
        isActive: selectedAccount?.isActive ?? true,
      },
    });

    const selectedType = form.watch("type");

    const onSubmit = (values: AccountFormValues) => {
      if (selectedAccount) {
        updateAccountMutation.mutate({
          id: selectedAccount.id,
          values,
        });
      }
    };

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="code"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>رمز الحساب</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="مثال: 1010" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>اسم الحساب</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="مثال: النقد في الصندوق" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع الحساب</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع الحساب" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="asset">أصول</SelectItem>
                      <SelectItem value="liability">خصوم</SelectItem>
                      <SelectItem value="equity">حقوق ملكية</SelectItem>
                      <SelectItem value="revenue">إيرادات</SelectItem>
                      <SelectItem value="expense">مصروفات</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="class"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>تصنيف الحساب</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر تصنيف الحساب" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {!selectedType && (
                        <SelectItem value="" disabled>
                          اختر نوع الحساب أولاً
                        </SelectItem>
                      )}
                      {selectedType === "asset" && (
                        <>
                          <SelectItem value="current_asset">
                            أصول متداولة
                          </SelectItem>
                          <SelectItem value="fixed_asset">أصول ثابتة</SelectItem>
                        </>
                      )}
                      {selectedType === "liability" && (
                        <>
                          <SelectItem value="current_liability">
                            خصوم متداولة
                          </SelectItem>
                          <SelectItem value="long_term_liability">
                            خصوم طويلة الأجل
                          </SelectItem>
                        </>
                      )}
                      {selectedType === "equity" && (
                        <SelectItem value="equity">حقوق ملكية</SelectItem>
                      )}
                      {selectedType === "revenue" && (
                        <>
                          <SelectItem value="revenue">إيرادات</SelectItem>
                          <SelectItem value="other_income">
                            إيرادات أخرى
                          </SelectItem>
                        </>
                      )}
                      {selectedType === "expense" && (
                        <>
                          <SelectItem value="direct_expense">
                            مصروفات مباشرة
                          </SelectItem>
                          <SelectItem value="indirect_expense">
                            مصروفات غير مباشرة
                          </SelectItem>
                          <SelectItem value="other_expense">
                            مصروفات أخرى
                          </SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <FormField
            control={form.control}
            name="parentId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>الحساب الأب</FormLabel>
                <Select
                  onValueChange={(value) =>
                    field.onChange(value ? parseInt(value) : null)
                  }
                  value={field.value?.toString() || ""}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="بدون حساب أب" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">بدون حساب أب</SelectItem>
                    {accounts
                      .filter(
                        (account: ChartOfAccount) =>
                          account.id !== selectedAccount?.id
                      )
                      .map((account: ChartOfAccount) => (
                        <SelectItem
                          key={account.id}
                          value={account.id.toString()}
                        >
                          {account.code} - {account.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وصف الحساب</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="وصف اختياري للحساب" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="isActive"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-2 space-y-0 rtl:space-x-reverse">
                <FormControl>
                  <input
                    type="checkbox"
                    checked={field.value}
                    onChange={field.onChange}
                    className="ml-2"
                  />
                </FormControl>
                <FormLabel>حساب نشط</FormLabel>
              </FormItem>
            )}
          />
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button type="submit" disabled={updateAccountMutation.isPending}>
              {updateAccountMutation.isPending
                ? "جاري التعديل..."
                : "حفظ التعديلات"}
            </Button>
          </DialogFooter>
        </form>
      </Form>
    );
  };

  // عرض تفاصيل الحساب المختار
  const AccountDetails = () => {
    if (!selectedAccount) {
      return (
        <div className="flex items-center justify-center h-full p-6 text-muted-foreground">
          <p>يرجى اختيار حساب لعرض تفاصيله</p>
        </div>
      );
    }

    const getAccountTypeText = (type: string) => {
      switch (type) {
        case "asset":
          return "أصول";
        case "liability":
          return "خصوم";
        case "equity":
          return "حقوق ملكية";
        case "revenue":
          return "إيرادات";
        case "expense":
          return "مصروفات";
        default:
          return type;
      }
    };

    const getAccountClassText = (accountClass: string) => {
      switch (accountClass) {
        case "current_asset":
          return "أصول متداولة";
        case "fixed_asset":
          return "أصول ثابتة";
        case "current_liability":
          return "خصوم متداولة";
        case "long_term_liability":
          return "خصوم طويلة الأجل";
        case "equity":
          return "حقوق ملكية";
        case "revenue":
          return "إيرادات";
        case "direct_expense":
          return "مصروفات مباشرة";
        case "indirect_expense":
          return "مصروفات غير مباشرة";
        case "other_income":
          return "إيرادات أخرى";
        case "other_expense":
          return "مصروفات أخرى";
        default:
          return accountClass;
      }
    };

    const parentAccount = accounts.find(
      (acc: ChartOfAccount) => acc.id === selectedAccount.parentId
    );

    return (
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">تفاصيل الحساب</h3>
          <div className="space-x-2 rtl:space-x-reverse">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsEditDialogOpen(true)}
            >
              <Edit className="h-4 w-4 ml-1 rtl:mr-1" /> تعديل
            </Button>
            <Button
              size="sm"
              variant="destructive"
              onClick={() => {
                if (
                  window.confirm(
                    "هل أنت متأكد من حذف هذا الحساب؟ لا يمكن التراجع عن هذا الإجراء."
                  )
                ) {
                  deleteAccountMutation.mutate(selectedAccount.id);
                }
              }}
              disabled={deleteAccountMutation.isPending}
            >
              <Trash2 className="h-4 w-4 ml-1 rtl:mr-1" /> حذف
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <div>
              <Label>رمز الحساب</Label>
              <p className="font-mono">{selectedAccount.code}</p>
            </div>
            <div>
              <Label>اسم الحساب</Label>
              <p>{selectedAccount.name}</p>
            </div>
            <div>
              <Label>نوع الحساب</Label>
              <p>
                <Badge
                  variant={
                    selectedAccount.type === "asset"
                      ? "default"
                      : selectedAccount.type === "liability"
                      ? "secondary"
                      : selectedAccount.type === "equity"
                      ? "outline"
                      : selectedAccount.type === "revenue"
                      ? "success"
                      : "destructive"
                  }
                >
                  {getAccountTypeText(selectedAccount.type)}
                </Badge>
              </p>
            </div>
          </div>
          <div className="space-y-2">
            <div>
              <Label>تصنيف الحساب</Label>
              <p>{getAccountClassText(selectedAccount.class)}</p>
            </div>
            <div>
              <Label>الحساب الأب</Label>
              <p>
                {parentAccount
                  ? `${parentAccount.code} - ${parentAccount.name}`
                  : "لا يوجد"}
              </p>
            </div>
            <div>
              <Label>الحالة</Label>
              <p>
                {selectedAccount.isActive ? (
                  <Badge variant="success">نشط</Badge>
                ) : (
                  <Badge variant="secondary">غير نشط</Badge>
                )}
              </p>
            </div>
          </div>
        </div>

        {selectedAccount.description && (
          <div className="mt-4">
            <Label>الوصف</Label>
            <p className="text-sm text-muted-foreground mt-1">
              {selectedAccount.description}
            </p>
          </div>
        )}

        {/* هنا يمكن إضافة معلومات إضافية مثل الأرصدة والمعاملات المرتبطة بالحساب */}
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 flex">
        <Card className="w-1/3 flex flex-col overflow-hidden border-l">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>شجرة الحسابات</CardTitle>
              <Button size="sm" onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 ml-1 rtl:mr-1" /> إضافة حساب
              </Button>
            </div>
            <div className="relative mt-2">
              <Search className="absolute right-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="البحث في شجرة الحسابات..."
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto p-0">
            {isLoading ? (
              <div className="p-4 space-y-2">
                {Array(5)
                  .fill(0)
                  .map((_, index) => (
                    <Skeleton key={index} className="h-6 w-full" />
                  ))}
              </div>
            ) : error ? (
              <Alert variant="destructive" className="m-4">
                <AlertTitle>حدث خطأ</AlertTitle>
                <AlertDescription>
                  لم نتمكن من تحميل شجرة الحسابات. يرجى المحاولة مرة أخرى.
                </AlertDescription>
              </Alert>
            ) : filteredAccountsTree.length === 0 ? (
              searchTerm ? (
                <div className="p-4 text-center text-muted-foreground">
                  لا توجد نتائج مطابقة لـ "{searchTerm}"
                </div>
              ) : (
                <div className="p-4 text-center text-muted-foreground">
                  لا توجد حسابات مضافة. قم بإضافة حسابات جديدة لبدء دليل الحسابات.
                </div>
              )
            ) : (
              <ScrollArea className="h-full">
                <div className="p-2">
                  {filteredAccountsTree.map((account: any) =>
                    renderAccountItem(account)
                  )}
                </div>
              </ScrollArea>
            )}
          </CardContent>
          <CardFooter className="border-t py-3 justify-between">
            <p className="text-xs text-muted-foreground">
              إجمالي الحسابات: {accounts.length}
            </p>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
              }}
            >
              <RefreshCw className="h-4 w-4 ml-1 rtl:mr-1" /> تحديث
            </Button>
          </CardFooter>
        </Card>

        <Card className="flex-1 flex flex-col">
          <AccountDetails />
        </Card>
      </div>

      {/* نافذة إضافة حساب جديد */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>إضافة حساب جديد</DialogTitle>
            <DialogDescription>
              أدخل بيانات الحساب الجديد. الحقول المميزة بعلامة * مطلوبة.
            </DialogDescription>
          </DialogHeader>
          <AddAccountForm />
        </DialogContent>
      </Dialog>

      {/* نافذة تعديل حساب */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>تعديل الحساب</DialogTitle>
            <DialogDescription>
              قم بتعديل بيانات الحساب. الحقول المميزة بعلامة * مطلوبة.
            </DialogDescription>
          </DialogHeader>
          <EditAccountForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}