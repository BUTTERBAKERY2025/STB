import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Folder, 
  FolderPlus, 
  FolderClosed, 
  FileText, 
  ChevronRight, 
  ChevronDown, 
  Plus, 
  Edit, 
  Trash2, 
  MoreVertical, 
  Save, 
  X, 
  Eye, 
  Loader2
} from 'lucide-react';

/**
 * مدير شجرة الحسابات
 * 
 * مكون لإدارة وعرض شجرة الحسابات (دليل الحسابات):
 * - عرض شجرة الحسابات بشكل هرمي
 * - إضافة وتعديل الحسابات
 * - تفعيل وتعطيل الحسابات
 * - ربط الحسابات بالمشاريع
 */

// مخطط الحساب المحاسبي
const accountSchema = z.object({
  code: z.string().min(1, { message: 'رمز الحساب مطلوب' }),
  name: z.string().min(1, { message: 'اسم الحساب مطلوب' }),
  type: z.enum(['asset', 'liability', 'equity', 'revenue', 'expense']),
  parentId: z.number().optional().nullable(),
  description: z.string().optional().nullable(),
  isActive: z.boolean().default(true),
});

type AccountFormValues = z.infer<typeof accountSchema>;

// أنواع الحسابات
const accountTypes = [
  { value: 'asset', label: 'الأصول', color: 'blue' },
  { value: 'liability', label: 'الخصوم', color: 'amber' },
  { value: 'equity', label: 'حقوق الملكية', color: 'green' },
  { value: 'revenue', label: 'الإيرادات', color: 'emerald' },
  { value: 'expense', label: 'المصروفات', color: 'red' },
];

type AccountTreeManagerProps = {
  onAccountSelected?: (accountId: number) => void;
  showSelector?: boolean;
};

const AccountTreeManager: React.FC<AccountTreeManagerProps> = ({
  onAccountSelected,
  showSelector = false,
}) => {
  // حالة المكون
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<any | null>(null);
  const [expandedItems, setExpandedItems] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // نموذج إضافة/تعديل حساب
  const form = useForm<AccountFormValues>({
    resolver: zodResolver(accountSchema),
    defaultValues: {
      code: '',
      name: '',
      type: 'asset',
      parentId: null,
      description: '',
      isActive: true,
    },
  });

  // استعلام قائمة الحسابات
  const { 
    data: accounts = [], 
    isLoading: accountsLoading,
    isError: accountsError,
    refetch: refetchAccounts
  } = useQuery({
    queryKey: ['/api/financial/accounts'],
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // استعلام أرصدة الحسابات
  const { data: accountBalances = [] } = useQuery({
    queryKey: ['/api/financial/account-balances'],
    staleTime: 5 * 60 * 1000, // 5 دقائق
  });

  // حفظ حساب جديد
  const createAccountMutation = useMutation({
    mutationFn: async (data: AccountFormValues) => {
      const res = await apiRequest('POST', '/api/financial/accounts', data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/accounts'] });
      toast({
        title: 'تم إنشاء الحساب بنجاح',
        description: 'تم إضافة الحساب الجديد إلى دليل الحسابات',
      });
      form.reset();
      setIsAddDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ في إنشاء الحساب',
        description: error.message || 'حدث خطأ أثناء إنشاء الحساب',
        variant: 'destructive',
      });
    },
  });

  // تحديث حساب
  const updateAccountMutation = useMutation({
    mutationFn: async (data: AccountFormValues & { id: number }) => {
      const { id, ...accountData } = data;
      const res = await apiRequest('PATCH', `/api/financial/accounts/${id}`, accountData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/accounts'] });
      toast({
        title: 'تم تحديث الحساب بنجاح',
        description: 'تم تحديث بيانات الحساب',
      });
      setSelectedAccount(null);
      setIsEditDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ في تحديث الحساب',
        description: error.message || 'حدث خطأ أثناء تحديث الحساب',
        variant: 'destructive',
      });
    },
  });

  // تغيير حالة الحساب (نشط/غير نشط)
  const updateAccountStatusMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      const res = await apiRequest('PATCH', `/api/financial/accounts/${id}/status`, { isActive });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/financial/accounts'] });
      toast({
        title: 'تم تحديث حالة الحساب',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'خطأ في تحديث حالة الحساب',
        description: error.message || 'حدث خطأ أثناء تحديث حالة الحساب',
        variant: 'destructive',
      });
    },
  });

  // إرسال نموذج إنشاء حساب جديد
  const onSubmitNewAccount = (data: AccountFormValues) => {
    createAccountMutation.mutate(data);
  };

  // إرسال نموذج تعديل حساب
  const onSubmitEditAccount = (data: AccountFormValues) => {
    if (!selectedAccount) return;
    updateAccountMutation.mutate({ ...data, id: selectedAccount.id });
  };

  // فتح مربع حوار تعديل حساب
  const handleEditAccount = (account: any) => {
    setSelectedAccount(account);
    form.reset({
      code: account.code,
      name: account.name,
      type: account.type,
      parentId: account.parentId,
      description: account.description || '',
      isActive: account.isActive,
    });
    setIsEditDialogOpen(true);
  };

  // تغيير حالة حساب
  const handleToggleAccountStatus = (account: any) => {
    updateAccountStatusMutation.mutate({
      id: account.id,
      isActive: !account.isActive,
    });
  };

  // اختيار حساب (للاستخدام في مكونات أخرى)
  const handleSelectAccount = (account: any) => {
    if (onAccountSelected) {
      onAccountSelected(account.id);
    }
  };

  // توسيع/طي عنصر في الشجرة
  const toggleExpandItem = (itemId: string) => {
    if (expandedItems.includes(itemId)) {
      setExpandedItems(expandedItems.filter(id => id !== itemId));
    } else {
      setExpandedItems([...expandedItems, itemId]);
    }
  };

  // الحصول على رصيد الحساب
  const getAccountBalance = (accountId: number) => {
    const balance = accountBalances.find((bal: any) => bal.accountId === accountId);
    return balance ? balance.closingBalance : 0;
  };

  // بناء شجرة الحسابات
  const buildAccountTree = (accounts: any[], parentId: number | null = null) => {
    return accounts
      .filter(account => account.parentId === parentId)
      .map(account => ({
        ...account,
        children: buildAccountTree(accounts, account.id),
      }));
  };

  // تنسيق الحسابات في شكل مسطح حسب المستوى
  const flattenAccounts = (
    accounts: any[],
    parentId: number | null = null,
    level = 0,
    result: any[] = []
  ) => {
    accounts
      .filter(account => account.parentId === parentId)
      .forEach(account => {
        const hasChildren = accounts.some(a => a.parentId === account.id);
        result.push({
          ...account,
          level,
          hasChildren,
        });
        flattenAccounts(accounts, account.id, level + 1, result);
      });
    return result;
  };

  // تصفية الحسابات بناءً على البحث ونوع الحساب
  const filterAccounts = (accounts: any[]) => {
    if (!searchQuery && !typeFilter) return accounts;

    return accounts.filter(account => {
      const matchesSearch = !searchQuery || 
                            account.code.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            account.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = !typeFilter || account.type === typeFilter;
      return matchesSearch && matchesType;
    });
  };

  // تحويل الحسابات إلى شجرة
  const accountTree = buildAccountTree(accounts);
  
  // تحويل الحسابات إلى قائمة مسطحة مع مستويات
  const flattenedAccounts = flattenAccounts(accounts);
  
  // تصفية الحسابات
  const filteredAccounts = filterAccounts(flattenedAccounts);

  // الحصول على جميع الحسابات التي يمكن استخدامها كآباء
  const potentialParents = accounts
    .filter(account => account.id !== selectedAccount?.id)
    .map(account => ({
      id: account.id,
      code: account.code,
      name: account.name,
      fullName: `${account.code} - ${account.name}`,
    }));

  // واجهة مستخدم المكون
  return (
    <div className="space-y-4">
      {/* رأس المكون */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">دليل الحسابات</h2>
          <p className="text-muted-foreground">إدارة شجرة الحسابات المحاسبية</p>
        </div>

        <Button onClick={() => {
          form.reset({
            code: '',
            name: '',
            type: 'asset',
            parentId: null,
            description: '',
            isActive: true,
          });
          setIsAddDialogOpen(true);
        }}>
          <Plus className="h-4 w-4 ml-2" />
          حساب جديد
        </Button>
      </div>

      {/* أدوات البحث والتصفية */}
      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1">
          <Input
            placeholder="بحث عن حساب..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-sm"
          />
        </div>

        <Select
          value={typeFilter || ''}
          onValueChange={(value) => setTypeFilter(value || null)}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="نوع الحساب" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع الأنواع</SelectItem>
            {accountTypes.map((type) => (
              <SelectItem key={type.value} value={type.value}>
                {type.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* عرض شجرة الحسابات */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle>دليل الحسابات</CardTitle>
          <CardDescription>
            عرض وإدارة شجرة الحسابات المحاسبية
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {accountsLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : accountsError ? (
            <div className="text-center py-8 text-red-500">
              حدث خطأ أثناء تحميل الحسابات
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2 mx-auto block"
                onClick={() => refetchAccounts()}
              >
                إعادة المحاولة
              </Button>
            </div>
          ) : filteredAccounts.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchQuery || typeFilter
                ? 'لا توجد نتائج تطابق معايير البحث'
                : 'لا توجد حسابات لعرضها'}
            </div>
          ) : (
            <ScrollArea className="h-[500px]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[140px]">رمز الحساب</TableHead>
                    <TableHead>اسم الحساب</TableHead>
                    <TableHead>نوع الحساب</TableHead>
                    <TableHead className="text-center">الرصيد</TableHead>
                    <TableHead className="text-center w-[100px]">الحالة</TableHead>
                    <TableHead className="text-center w-[120px]">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAccounts.map((account) => {
                    const accountTypeInfo = accountTypes.find(
                      (type) => type.value === account.type
                    );
                    const accountBalance = getAccountBalance(account.id);

                    return (
                      <TableRow key={account.id} className={account.level > 0 ? 'border-t-0' : ''}>
                        <TableCell className="font-medium">
                          <div
                            className="flex items-center"
                            style={{ paddingRight: `${account.level * 1.5}rem` }}
                          >
                            {account.hasChildren && (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-5 w-5 p-0 ml-1"
                                onClick={() => toggleExpandItem(account.id.toString())}
                              >
                                {expandedItems.includes(account.id.toString()) ? (
                                  <ChevronDown className="h-4 w-4" />
                                ) : (
                                  <ChevronRight className="h-4 w-4" />
                                )}
                              </Button>
                            )}
                            {account.hasChildren ? (
                              <Folder className="h-4 w-4 text-muted-foreground ml-1" />
                            ) : (
                              <FileText className="h-4 w-4 text-muted-foreground ml-1" />
                            )}
                            {account.code}
                          </div>
                        </TableCell>
                        <TableCell>{account.name}</TableCell>
                        <TableCell>
                          <Badge
                            className={`bg-${accountTypeInfo?.color}-100 text-${accountTypeInfo?.color}-800`}
                          >
                            {accountTypeInfo?.label}
                          </Badge>
                        </TableCell>
                        <TableCell className={`text-center ${accountBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {accountBalance.toLocaleString('ar-SA', { maximumFractionDigits: 2 })}
                        </TableCell>
                        <TableCell className="text-center">
                          <Switch
                            checked={account.isActive}
                            onCheckedChange={() => handleToggleAccountStatus(account)}
                            disabled={updateAccountStatusMutation.isPending}
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex justify-center items-center space-x-1 space-x-reverse">
                            {showSelector && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleSelectAccount(account)}
                                title="اختيار الحساب"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditAccount(account)}
                              title="تعديل الحساب"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
        <CardFooter className="py-2">
          <div className="text-muted-foreground text-sm">
            إجمالي الحسابات: {accounts.length}
          </div>
        </CardFooter>
      </Card>

      {/* مربع حوار إضافة حساب جديد */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>إضافة حساب جديد</DialogTitle>
            <DialogDescription>
              قم بإدخال معلومات الحساب الجديد
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitNewAccount)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رمز الحساب</FormLabel>
                      <FormControl>
                        <Input placeholder="مثال: 10101" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع الحساب</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر نوع الحساب" />
                        </SelectTrigger>
                        <SelectContent>
                          {accountTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>اسم الحساب</FormLabel>
                    <FormControl>
                      <Input placeholder="اسم الحساب" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="parentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحساب الرئيسي (اختياري)</FormLabel>
                    <Select
                      value={field.value?.toString() || ''}
                      onValueChange={(value) => field.onChange(value ? parseInt(value) : null)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الحساب الرئيسي" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="null">بدون حساب رئيسي</SelectItem>
                        {potentialParents.map((parent) => (
                          <SelectItem key={parent.id} value={parent.id.toString()}>
                            {parent.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      اختر الحساب الرئيسي الذي ينتمي إليه هذا الحساب
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الوصف (اختياري)</FormLabel>
                    <FormControl>
                      <Input placeholder="وصف الحساب" {...field} value={field.value || ''} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>حساب نشط</FormLabel>
                      <FormDescription>
                        الحسابات النشطة فقط يمكن استخدامها في العمليات المحاسبية
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsAddDialogOpen(false)}
                  disabled={createAccountMutation.isPending}
                >
                  إلغاء
                </Button>
                <Button 
                  type="submit" 
                  disabled={createAccountMutation.isPending}
                >
                  {createAccountMutation.isPending && (
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  )}
                  إضافة الحساب
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* مربع حوار تعديل حساب */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تعديل الحساب</DialogTitle>
            <DialogDescription>
              تعديل معلومات الحساب {selectedAccount?.code} - {selectedAccount?.name}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitEditAccount)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>رمز الحساب</FormLabel>
                      <FormControl>
                        <Input placeholder="مثال: 10101" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع الحساب</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="اختر نوع الحساب" />
                        </SelectTrigger>
                        <SelectContent>
                          {accountTypes.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>اسم الحساب</FormLabel>
                    <FormControl>
                      <Input placeholder="اسم الحساب" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="parentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الحساب الرئيسي (اختياري)</FormLabel>
                    <Select
                      value={field.value?.toString() || ''}
                      onValueChange={(value) => field.onChange(value ? parseInt(value) : null)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر الحساب الرئيسي" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="null">بدون حساب رئيسي</SelectItem>
                        {potentialParents.map((parent) => (
                          <SelectItem key={parent.id} value={parent.id.toString()}>
                            {parent.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      اختر الحساب الرئيسي الذي ينتمي إليه هذا الحساب
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>الوصف (اختياري)</FormLabel>
                    <FormControl>
                      <Input placeholder="وصف الحساب" {...field} value={field.value || ''} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>حساب نشط</FormLabel>
                      <FormDescription>
                        الحسابات النشطة فقط يمكن استخدامها في العمليات المحاسبية
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditDialogOpen(false)}
                  disabled={updateAccountMutation.isPending}
                >
                  إلغاء
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateAccountMutation.isPending}
                >
                  {updateAccountMutation.isPending && (
                    <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                  )}
                  حفظ التغييرات
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AccountTreeManager;