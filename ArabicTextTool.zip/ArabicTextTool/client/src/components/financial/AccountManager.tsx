import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import AccountTreeManager from './AccountTreeManager';
import JournalEntryManager from './JournalEntryManager';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  FileText, 
  BookOpen,
  FileSpreadsheet,
  ArrowLeftRight,
  FileUp,
  FileDown
} from 'lucide-react';

const AccountManager = () => {
  const [activeTab, setActiveTab] = React.useState("chart-of-accounts");

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">إدارة الحسابات المالية</h1>
        
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <FileUp className="mr-2 h-4 w-4" />
            استيراد بيانات
          </Button>
          <Button variant="outline">
            <FileDown className="mr-2 h-4 w-4" />
            تصدير بيانات
          </Button>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-muted">
          <TabsTrigger value="chart-of-accounts" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            شجرة الحسابات
          </TabsTrigger>
          <TabsTrigger value="journal-entries" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            القيود المحاسبية
          </TabsTrigger>
          <TabsTrigger value="account-statements" className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4" />
            كشوفات الحسابات
          </TabsTrigger>
          <TabsTrigger value="financial-reports" className="flex items-center gap-2">
            <ArrowLeftRight className="h-4 w-4" />
            التقارير المالية
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="chart-of-accounts" className="mt-6">
          <AccountTreeManager />
        </TabsContent>
        
        <TabsContent value="journal-entries" className="mt-6">
          <JournalEntryManager />
        </TabsContent>
        
        <TabsContent value="account-statements" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>كشوفات الحسابات</CardTitle>
              <CardDescription>
                عرض الأرصدة والحركات التفصيلية للحسابات حسب الفترة المحددة
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center text-muted-foreground">
                يمكنك عرض كشوفات الحسابات والأرصدة التفصيلية من خلال صفحة المركز المالي - قسم كشوفات الحسابات
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="financial-reports" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>التقارير المالية</CardTitle>
              <CardDescription>
                توليد التقارير المالية المختلفة للشركة والمشاريع
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center text-muted-foreground">
                يمكنك عرض وتوليد التقارير المالية المختلفة من خلال صفحة المركز المالي
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AccountManager;