import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { TrendingUp, TrendingDown, ArrowRight, Layers, PiggyBank, CircleDollarSign, Loader2 } from 'lucide-react';

type FinancialSummary = {
  totalIncome: number;
  totalExpenses: number;
  netBalance: number;
  categorySummary: Record<string, number>;
};

type FinancialSummaryCardsProps = {
  summary: FinancialSummary | undefined;
  loading?: boolean;
};

const FinancialSummaryCards: React.FC<FinancialSummaryCardsProps> = ({ summary, loading = false }) => {
  if (loading) {
    return (
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        {Array(3).fill(0).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-muted rounded-full w-1/2 mb-4" />
              <div className="h-6 bg-muted rounded-full w-3/4 mb-2" />
              <div className="h-4 bg-muted rounded-full w-1/4" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!summary) {
    return (
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardContent className="p-6 flex flex-col items-center text-center">
            <div className="text-muted-foreground mb-2">
              لا توجد بيانات مالية متاحة
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { totalIncome, totalExpenses, netBalance } = summary;
  const isProfit = netBalance >= 0;

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA') + ' ريال';
  };

  return (
    <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
      <Card>
        <CardContent className="p-6 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">إجمالي الإيرادات</span>
            <PiggyBank className="h-4 w-4 text-green-500" />
          </div>
          <div className="text-2xl font-bold">{formatCurrency(totalIncome)}</div>
          
          <div className="mt-2 flex items-center text-sm text-green-600">
            <TrendingUp className="h-4 w-4 mr-1" />
            <span>+5.2% من الشهر السابق</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">إجمالي المصروفات</span>
            <Layers className="h-4 w-4 text-red-500" />
          </div>
          <div className="text-2xl font-bold">{formatCurrency(totalExpenses)}</div>
          
          <div className="mt-2 flex items-center text-sm text-red-600">
            <TrendingDown className="h-4 w-4 mr-1" />
            <span>+2.8% من الشهر السابق</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">صافي الميزانية</span>
            <CircleDollarSign className={cn("h-4 w-4", isProfit ? "text-green-500" : "text-red-500")} />
          </div>
          <div className={cn("text-2xl font-bold", isProfit ? "text-green-600" : "text-red-600")}>
            {formatCurrency(Math.abs(netBalance))}
            {isProfit ? " ربح" : " خسارة"}
          </div>
          
          <div className="mt-2 flex items-center text-sm">
            <ArrowRight className="h-4 w-4 mr-1" />
            <span>{isProfit ? 'نسبة الربح: ' : 'نسبة الخسارة: '}
              {Math.abs(Math.round((netBalance / (totalIncome || 1)) * 100))}%
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialSummaryCards;