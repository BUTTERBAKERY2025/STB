import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription  
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Edit, 
  Trash2, 
  Download, 
  Plus, 
  PieChart, 
  Filter, 
  RefreshCw 
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { insertBudgetSchema } from "@shared/schema.new";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";

interface BudgetManagerProps {
  projectId?: number;
}

// شكل نموذج إضافة/تعديل الميزانية
const budgetFormSchema = insertBudgetSchema.extend({
  plannedAmount: z.coerce.number().min(1, {
    message: "يجب أن يكون المبلغ أكبر من صفر",
  }),
  fiscalYear: z.coerce.number().min(2020, {
    message: "يجب أن تكون السنة المالية صالحة",
  }),
});

type BudgetFormValues = z.infer<typeof budgetFormSchema>;

const BudgetManager: React.FC<BudgetManagerProps> = ({ projectId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedBudget, setSelectedBudget] = useState<any>(null);
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>(undefined);
  const [yearFilter, setYearFilter] = useState<string | undefined>(undefined);
  
  // تحضير بارامترات الاستعلام
  const queryParams = new URLSearchParams();
  if (projectId) queryParams.append("projectId", projectId.toString());
  if (categoryFilter) queryParams.append("category", categoryFilter);
  if (yearFilter) queryParams.append("fiscalYear", yearFilter);

  // استعلام الميزانيات
  const { data: budgets = [], isLoading } = useQuery({
    queryKey: ["/api/budgets", projectId, categoryFilter, yearFilter],
    enabled: !!projectId,
  });

  // جلب المشاريع لاستخدامها في الواجهة
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // نموذج إضافة ميزانية جديدة
  const addForm = useForm<BudgetFormValues>({
    resolver: zodResolver(budgetFormSchema),
    defaultValues: {
      projectId: projectId || 0,
      fiscalYear: new Date().getFullYear(),
      category: "",
      subcategory: "",
      plannedAmount: 0,
      status: "proposed",
      notes: "",
      createdBy: 1, // افتراضي
    },
  });

  // نموذج تعديل ميزانية
  const editForm = useForm<BudgetFormValues>({
    resolver: zodResolver(budgetFormSchema),
    defaultValues: {
      projectId: projectId || 0,
      fiscalYear: new Date().getFullYear(),
      category: "",
      subcategory: "",
      plannedAmount: 0,
      status: "proposed",
      notes: "",
      createdBy: 1, // افتراضي
    },
  });

  // mutations لإضافة ميزانية
  const addBudgetMutation = useMutation({
    mutationFn: async (data: BudgetFormValues) => {
      const response = await apiRequest("POST", "/api/budgets", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة الميزانية بنجاح",
      });
      setIsAddDialogOpen(false);
      addForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/budget-summary"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الإضافة",
        description: error.message || "حدث خطأ أثناء إضافة الميزانية",
        variant: "destructive",
      });
    },
  });

  // mutation لتعديل ميزانية
  const updateBudgetMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: BudgetFormValues }) => {
      const response = await apiRequest("PATCH", `/api/budgets/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التعديل",
        description: "تم تعديل الميزانية بنجاح",
      });
      setIsEditDialogOpen(false);
      editForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/budget-summary"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التعديل",
        description: error.message || "حدث خطأ أثناء تعديل الميزانية",
        variant: "destructive",
      });
    },
  });

  // mutation لحذف ميزانية
  const deleteBudgetMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/budgets/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف الميزانية بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/budget-summary"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الحذف",
        description: error.message || "حدث خطأ أثناء حذف الميزانية",
        variant: "destructive",
      });
    },
  });

  // جلب ملخص الميزانية مقابل الصرف الفعلي
  const { data: budgetSummary, isLoading: summaryLoading } = useQuery({
    queryKey: ["/api/budget-summary", projectId],
    enabled: !!projectId,
  });

  // تقديم نموذج إضافة ميزانية
  const onAddSubmit = (data: BudgetFormValues) => {
    addBudgetMutation.mutate(data);
  };

  // تقديم نموذج تعديل ميزانية
  const onEditSubmit = (data: BudgetFormValues) => {
    if (selectedBudget) {
      updateBudgetMutation.mutate({ id: selectedBudget.id, data });
    }
  };

  // فتح مربع حوار التعديل وملء البيانات
  const handleEdit = (budget: any) => {
    setSelectedBudget(budget);
    editForm.reset({
      projectId: budget.projectId,
      fiscalYear: budget.fiscalYear,
      category: budget.category,
      subcategory: budget.subcategory || "",
      plannedAmount: budget.plannedAmount,
      revisedAmount: budget.revisedAmount,
      status: budget.status,
      notes: budget.notes || "",
      createdBy: budget.createdBy,
    });
    setIsEditDialogOpen(true);
  };

  // حذف ميزانية مع تأكيد
  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذه الميزانية؟")) {
      deleteBudgetMutation.mutate(id);
    }
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA') + ' ريال';
  };

  // الحصول على اسم المشروع من المعرف
  const getProjectName = (projectId: number) => {
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تحديد لون الحالة
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
      case 'معتمد':
        return 'bg-green-100 text-green-800';
      case 'proposed':
      case 'مقترح':
        return 'bg-yellow-100 text-yellow-800';
      case 'expired':
      case 'منتهي':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  // إعادة تعيين التصفية
  const resetFilters = () => {
    setCategoryFilter(undefined);
    setYearFilter(undefined);
  };

  // حساب نسبة الاستهلاك من الميزانية
  const calculateUsagePercentage = (budget: any) => {
    if (!budgetSummary) return 0;
    const usageByCategory = budgetSummary.usageByCategory || {};
    const usage = usageByCategory[budget.category] || 0;
    const total = budget.plannedAmount;
    return total > 0 ? Math.min(100, Math.round((usage / total) * 100)) : 0;
  };

  return (
    <div>
      {/* شريط الأدوات والتصفية */}
      <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between">
        <div className="flex flex-col md:flex-row gap-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="تصنيف الميزانية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع التصنيفات</SelectItem>
              <SelectItem value="materials">مواد</SelectItem>
              <SelectItem value="labor">أجور عمال</SelectItem>
              <SelectItem value="equipment">معدات</SelectItem>
              <SelectItem value="subcontractors">مقاولي الباطن</SelectItem>
              <SelectItem value="administrative">مصاريف إدارية</SelectItem>
              <SelectItem value="operational">مصاريف تشغيلية</SelectItem>
              <SelectItem value="other">أخرى</SelectItem>
            </SelectContent>
          </Select>

          <Select value={yearFilter} onValueChange={setYearFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="السنة المالية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع السنوات</SelectItem>
              <SelectItem value="2025">2025</SelectItem>
              <SelectItem value="2024">2024</SelectItem>
              <SelectItem value="2023">2023</SelectItem>
            </SelectContent>
          </Select>

          <Button 
            variant="outline" 
            onClick={resetFilters}
            className="h-10"
            disabled={!categoryFilter && !yearFilter}
          >
            <RefreshCw className="ml-2 h-4 w-4" />
            إعادة تعيين
          </Button>
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="h-10">
              <Plus className="ml-2 h-4 w-4" /> إضافة ميزانية
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>إضافة ميزانية جديدة</DialogTitle>
              <DialogDescription>
                أدخل تفاصيل الميزانية الجديدة للمشروع
              </DialogDescription>
            </DialogHeader>

            <Form {...addForm}>
              <form onSubmit={addForm.handleSubmit(onAddSubmit)} className="space-y-4">
                <FormField
                  control={addForm.control}
                  name="fiscalYear"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>السنة المالية</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل السنة المالية" 
                          {...field} 
                          min={2020}
                          max={2050}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تصنيف الميزانية</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر تصنيف الميزانية" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="materials">مواد</SelectItem>
                          <SelectItem value="labor">أجور عمال</SelectItem>
                          <SelectItem value="equipment">معدات</SelectItem>
                          <SelectItem value="subcontractors">مقاولي الباطن</SelectItem>
                          <SelectItem value="administrative">مصاريف إدارية</SelectItem>
                          <SelectItem value="operational">مصاريف تشغيلية</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="subcategory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تصنيف فرعي (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل التصنيف الفرعي" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="plannedAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المبلغ المخطط</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل المبلغ المخطط" 
                          {...field} 
                          min={0}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحالة</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر حالة الميزانية" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="proposed">مقترحة</SelectItem>
                          <SelectItem value="approved">معتمدة</SelectItem>
                          <SelectItem value="expired">منتهية</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل أي ملاحظات" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={addBudgetMutation.isPending}
                  >
                    {addBudgetMutation.isPending ? "جاري الإضافة..." : "إضافة"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>تعديل الميزانية</DialogTitle>
              <DialogDescription>
                تعديل تفاصيل الميزانية الحالية
              </DialogDescription>
            </DialogHeader>

            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                <FormField
                  control={editForm.control}
                  name="fiscalYear"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>السنة المالية</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل السنة المالية" 
                          {...field} 
                          min={2020}
                          max={2050}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تصنيف الميزانية</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر تصنيف الميزانية" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="materials">مواد</SelectItem>
                          <SelectItem value="labor">أجور عمال</SelectItem>
                          <SelectItem value="equipment">معدات</SelectItem>
                          <SelectItem value="subcontractors">مقاولي الباطن</SelectItem>
                          <SelectItem value="administrative">مصاريف إدارية</SelectItem>
                          <SelectItem value="operational">مصاريف تشغيلية</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="subcategory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>تصنيف فرعي (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل التصنيف الفرعي" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="plannedAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المبلغ المخطط</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل المبلغ المخطط" 
                          {...field} 
                          min={0}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحالة</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر حالة الميزانية" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="proposed">مقترحة</SelectItem>
                          <SelectItem value="approved">معتمدة</SelectItem>
                          <SelectItem value="expired">منتهية</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أدخل أي ملاحظات" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={updateBudgetMutation.isPending}
                  >
                    {updateBudgetMutation.isPending ? "جاري التعديل..." : "تعديل"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* ملخص الميزانية */}
      {budgetSummary && projectId && (
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle>ملخص الميزانية</CardTitle>
            <CardDescription>
              الميزانية المخططة مقابل المصروفات الفعلية
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-muted-foreground mb-1">إجمالي الميزانية المخططة</div>
                <div className="text-2xl font-bold text-primary">{formatCurrency(budgetSummary?.totalPlanned || 0)}</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-muted-foreground mb-1">إجمالي المصروفات الفعلية</div>
                <div className="text-2xl font-bold text-destructive">{formatCurrency(budgetSummary?.totalUsed || 0)}</div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-sm font-medium text-muted-foreground mb-1">المتبقي من الميزانية</div>
                <div className="text-2xl font-bold text-green-600">{formatCurrency((budgetSummary?.totalPlanned || 0) - (budgetSummary?.totalUsed || 0))}</div>
              </div>
            </div>
            <div className="mt-4">
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">نسبة الصرف من الميزانية</span>
                <span className="text-sm font-medium">
                  {budgetSummary?.usagePercentage || 0}%
                </span>
              </div>
              <Progress value={budgetSummary?.usagePercentage || 0} />
            </div>
          </CardContent>
        </Card>
      )}

      {/* قائمة الميزانيات */}
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : budgets.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border">
          <PieChart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="font-medium text-lg mb-2">لا توجد ميزانيات</h3>
          <p className="text-muted-foreground mb-4">
            لم يتم العثور على ميزانيات للمشروع. يمكنك إضافة ميزانية جديدة.
          </p>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>إضافة ميزانية</Button>
            </DialogTrigger>
          </Dialog>
        </div>
      ) : (
        <div className="overflow-x-auto border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الرقم</TableHead>
                <TableHead>التصنيف</TableHead>
                <TableHead>السنة المالية</TableHead>
                <TableHead>المبلغ المخطط</TableHead>
                <TableHead>المبلغ المستهلك</TableHead>
                <TableHead>نسبة الاستهلاك</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {budgets.map((budget: any) => (
                <TableRow key={budget.id}>
                  <TableCell>{budget.id}</TableCell>
                  <TableCell>{budget.category}{budget.subcategory ? ` - ${budget.subcategory}` : ''}</TableCell>
                  <TableCell>{budget.fiscalYear}</TableCell>
                  <TableCell>{formatCurrency(budget.plannedAmount)}</TableCell>
                  <TableCell className="text-red-600">
                    {formatCurrency(
                      budgetSummary?.usageByCategory?.[budget.category] || 0
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col space-y-1">
                      <Progress 
                        value={calculateUsagePercentage(budget)} 
                        className="h-2" 
                      />
                      <span className="text-xs">
                        {calculateUsagePercentage(budget)}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(budget.status)}`}>
                      {budget.status}
                    </div>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="12" cy="5" r="1" />
                            <circle cx="12" cy="19" r="1" />
                          </svg>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          className="flex items-center gap-2"
                          onClick={() => handleEdit(budget)}
                        >
                          <Edit className="h-4 w-4" />
                          <span>تعديل</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="flex items-center gap-2 text-red-600"
                          onClick={() => handleDelete(budget.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>حذف</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default BudgetManager;