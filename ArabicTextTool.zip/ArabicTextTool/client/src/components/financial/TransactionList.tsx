import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format, parseISO } from "date-fns";
import { ar } from "date-fns/locale";
import { DatePicker } from "@/components/ui/date-picker";
import { 
  FileText, 
  Plus, 
  Search, 
  Trash2,
  Edit,
  Download
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useQuery } from "@tanstack/react-query";

interface TransactionListProps {
  projectId?: number;
}

const TransactionList: React.FC<TransactionListProps> = ({ projectId }) => {
  // حالات البحث والتصفية
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState<string | undefined>(undefined);
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>(undefined);
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);

  // تحويل التواريخ لصيغة مناسبة للواجهة الخلفية
  const queryParams = new URLSearchParams();
  if (projectId) queryParams.append("projectId", projectId.toString());
  if (typeFilter && typeFilter !== "all") queryParams.append("type", typeFilter);
  if (categoryFilter && categoryFilter !== "all") queryParams.append("category", categoryFilter);
  if (fromDate) queryParams.append("fromDate", format(fromDate, "yyyy-MM-dd"));
  if (toDate) queryParams.append("toDate", format(toDate, "yyyy-MM-dd"));
  
  // جلب المعاملات المالية مع مراعاة حالات التصفية
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['/api/financial-transactions', projectId, typeFilter, categoryFilter, fromDate?.toISOString(), toDate?.toISOString()],
    queryFn: () => fetch(`/api/financial-transactions?${queryParams.toString()}`).then(res => res.json()),
  });

  // جلب معلومات المشاريع للاستخدام في الواجهة
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // تصفية المعاملات حسب نص البحث
  const filteredTransactions = transactions.filter((transaction: any) => {
    return (
      transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.type?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const getProjectName = (projectId: number) => {
    if (!Array.isArray(projects)) return `مشروع ${projectId}`;
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'completed':
      case 'مكتمل':
        return 'bg-green-100 text-green-800';
      case 'pending':
      case 'قيد الانتظار':
        return 'bg-yellow-100 text-yellow-800';
      case 'canceled':
      case 'ملغى':
        return 'bg-red-100 text-red-800';
      case 'draft':
      case 'مسودة':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'income':
      case 'إيراد':
        return 'bg-green-100 text-green-800';
      case 'expense':
      case 'مصروف':
        return 'bg-red-100 text-red-800';
      case 'transfer':
      case 'تحويل':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA') + ' ريال';
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(parseISO(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  const resetFilters = () => {
    setSearchTerm('');
    setTypeFilter(undefined);
    setCategoryFilter(undefined);
    setFromDate(undefined);
    setToDate(undefined);
  };

  return (
    <div>
      {/* شريط البحث والتصفية */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="ابحث عن المعاملات..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="w-full md:w-48">
              <Select
                value={typeFilter}
                onValueChange={setTypeFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="نوع المعاملة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="income">إيراد</SelectItem>
                  <SelectItem value="expense">مصروف</SelectItem>
                  <SelectItem value="transfer">تحويل</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-full md:w-48">
              <Select
                value={categoryFilter}
                onValueChange={setCategoryFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="التصنيف" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع التصنيفات</SelectItem>
                  <SelectItem value="salaries">رواتب</SelectItem>
                  <SelectItem value="materials">مواد</SelectItem>
                  <SelectItem value="equipment">معدات</SelectItem>
                  <SelectItem value="services">خدمات</SelectItem>
                  <SelectItem value="payments">دفعات مستخلص</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex flex-col md:flex-row gap-4">
            <div className="w-full md:w-48">
              <DatePicker
                date={fromDate}
                setDate={setFromDate}
                placeholder="من تاريخ"
              />
            </div>
            <div className="w-full md:w-48">
              <DatePicker
                date={toDate}
                setDate={setToDate}
                placeholder="إلى تاريخ"
              />
            </div>
            <div className="flex-1 flex justify-end">
              <Button 
                variant="outline" 
                onClick={resetFilters}
                className="ml-2"
              >
                إعادة تعيين
              </Button>
              <Button 
                variant="default" 
                className="ml-2"
                onClick={() => alert('سيتم إنشاء معاملة جديدة')}
              >
                <Plus className="ml-2 h-4 w-4" /> إضافة معاملة
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* جدول المعاملات */}
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredTransactions.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border">
          <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="font-medium text-lg mb-2">لا توجد معاملات</h3>
          <p className="text-muted-foreground mb-4">
            لم يتم العثور على معاملات مالية تطابق معايير البحث
          </p>
          <Button 
            variant="outline" 
            onClick={resetFilters}
          >
            عرض جميع المعاملات
          </Button>
        </div>
      ) : (
        <div className="overflow-x-auto border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الرقم</TableHead>
                <TableHead>التاريخ</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>الوصف</TableHead>
                <TableHead>المشروع</TableHead>
                <TableHead>التصنيف</TableHead>
                <TableHead>المبلغ</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTransactions.map((transaction: any) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.id}</TableCell>
                  <TableCell>{formatDate(transaction.date)}</TableCell>
                  <TableCell>
                    <Badge className={`${getTypeColor(transaction.type)}`}>
                      {transaction.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {transaction.description}
                  </TableCell>
                  <TableCell>{getProjectName(transaction.projectId)}</TableCell>
                  <TableCell>{transaction.category}</TableCell>
                  <TableCell className={transaction.type?.toLowerCase() === 'expense' || transaction.type?.toLowerCase() === 'مصروف' ? 'text-red-600' : 'text-green-600'}>
                    {formatCurrency(transaction.amount)}
                  </TableCell>
                  <TableCell>
                    <Badge className={`${getStatusColor(transaction.status)}`}>
                      {transaction.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="12" cy="5" r="1" />
                            <circle cx="12" cy="19" r="1" />
                          </svg>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem className="flex items-center gap-2">
                          <Edit className="h-4 w-4" />
                          <span>تعديل</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="flex items-center gap-2">
                          <Download className="h-4 w-4" />
                          <span>تصدير</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem className="flex items-center gap-2 text-red-600">
                          <Trash2 className="h-4 w-4" />
                          <span>حذف</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default TransactionList;