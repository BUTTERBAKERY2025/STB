import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import {
  BarChart3,
  Briefcase,
  Building,
  CalendarRange,
  ChevronsUpDown,
  CircleDollarSign,
  Download,
  FileText,
  Filter,
  PieChart,
  Printer,
  RefreshCw,
} from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

import { Project, ChartOfAccount, AccountBalance, JournalEntry } from "@shared/schema";

// مكون عرض المركز المالي للمشروع
export default function ProjectFinancialCenter() {
  const { toast } = useToast();
  const [selectedProject, setSelectedProject] = useState<number | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<string>("current-month");
  const [fiscalYear, setFiscalYear] = useState<number>(new Date().getFullYear());
  const [fiscalMonth, setFiscalMonth] = useState<number>(new Date().getMonth() + 1);

  // استعلامات البيانات
  const {
    data: projects = [],
    isLoading: isLoadingProjects,
  } = useQuery({
    queryKey: ["/api/projects"],
    retry: 2,
  });

  const {
    data: accounts = [],
    isLoading: isLoadingAccounts,
  } = useQuery({
    queryKey: ["/api/accounts"],
    retry: 2,
  });

  const {
    data: financialCenter = null,
    isLoading: isLoadingFinancialCenter,
    error: financialCenterError,
  } = useQuery({
    queryKey: ["/api/project-financial-center", { projectId: selectedProject, fiscalYear, fiscalMonth }],
    retry: 2,
    enabled: selectedProject !== null,
  });

  // التأثير لتحديث الفترة المالية استناداً إلى الفترة المختارة
  useEffect(() => {
    const now = new Date();
    
    switch (selectedPeriod) {
      case "current-month":
        setFiscalYear(now.getFullYear());
        setFiscalMonth(now.getMonth() + 1);
        break;
      case "last-month":
        if (now.getMonth() === 0) {
          setFiscalYear(now.getFullYear() - 1);
          setFiscalMonth(12);
        } else {
          setFiscalYear(now.getFullYear());
          setFiscalMonth(now.getMonth());
        }
        break;
      case "ytd": // Year to date
        setFiscalYear(now.getFullYear());
        // نحن نستخدم الشهر الحالي هنا لأن البيانات تراكمية من بداية العام
        setFiscalMonth(now.getMonth() + 1);
        break;
      case "last-year":
        setFiscalYear(now.getFullYear() - 1);
        setFiscalMonth(12); // نستخدم ديسمبر للسنة الكاملة
        break;
    }
  }, [selectedPeriod]);

  // تنسيق المبلغ المالي 
  const formatAmount = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return "0.00";
    return new Intl.NumberFormat("ar-SA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // الحصول على اسم المشروع
  const getProjectName = (projectId: number | null) => {
    if (!projectId) return "الشركة (الكل)";
    const project = projects.find((p: Project) => p.id === projectId);
    return project ? project.name : "غير معروف";
  };

  // الحصول على اسم الفترة المالية
  const getPeriodName = () => {
    const date = new Date(fiscalYear, fiscalMonth - 1, 1);
    
    switch (selectedPeriod) {
      case "current-month":
      case "last-month":
        return format(date, "MMMM yyyy", { locale: ar });
      case "ytd":
        return `من بداية السنة حتى ${format(date, "MMMM yyyy", { locale: ar })}`;
      case "last-year":
        return fiscalYear.toString();
      default:
        return "";
    }
  };

  // مكون ملخص المركز المالي
  const FinancialCenterSummary = () => {
    // في حالة عدم وجود مشروع محدد
    if (selectedProject === null) {
      return (
        <div className="p-8 text-center">
          <Building className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold mb-2">يرجى اختيار مشروع</h2>
          <p className="text-muted-foreground">
            اختر مشروعًا من القائمة المنسدلة لعرض المركز المالي الخاص به
          </p>
        </div>
      );
    }

    if (isLoadingFinancialCenter) {
      return (
        <div className="p-4 space-y-4">
          <Skeleton className="h-8 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Array(3).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-32 w-full" />
            ))}
          </div>
          <Skeleton className="h-64 w-full" />
        </div>
      );
    }

    if (financialCenterError) {
      return (
        <Alert variant="destructive" className="m-4">
          <AlertTitle>حدث خطأ</AlertTitle>
          <AlertDescription>
            لم نتمكن من تحميل بيانات المركز المالي للمشروع.
          </AlertDescription>
        </Alert>
      );
    }

    // استخدام بيانات المركز المالي المستلمة من الخادم أو بيانات افتراضية إذا كانت غير موجودة
    const fcData = financialCenter || {
      totalAssets: 0,
      totalLiabilities: 0,
      totalEquity: 0,
      totalRevenue: 0,
      totalExpenses: 0,
      netIncome: 0,
      cashBalance: 0,
      accountsReceivable: 0,
      accountsPayable: 0,
    };

    // حساب النسب المالية
    const currentRatio = fcData.totalLiabilities ? fcData.totalAssets / fcData.totalLiabilities : 0;
    const profitMargin = fcData.totalRevenue ? (fcData.netIncome / fcData.totalRevenue) * 100 : 0;
    
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* الأصول والخصوم */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">الأصول والخصوم</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>إجمالي الأصول</span>
                  <span className="font-medium">{formatAmount(fcData.totalAssets)}</span>
                </div>
                <div className="flex justify-between">
                  <span>إجمالي الخصوم</span>
                  <span className="font-medium">{formatAmount(fcData.totalLiabilities)}</span>
                </div>
                <div className="flex justify-between">
                  <span>صافي الأصول</span>
                  <span className="font-semibold">{formatAmount(fcData.totalAssets - fcData.totalLiabilities)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* الإيرادات والمصروفات */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">الإيرادات والمصروفات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>إجمالي الإيرادات</span>
                  <span className="font-medium">{formatAmount(fcData.totalRevenue)}</span>
                </div>
                <div className="flex justify-between">
                  <span>إجمالي المصروفات</span>
                  <span className="font-medium">{formatAmount(fcData.totalExpenses)}</span>
                </div>
                <div className="flex justify-between">
                  <span>صافي الدخل</span>
                  <span className={`font-semibold ${fcData.netIncome < 0 ? 'text-destructive' : 'text-green-600'}`}>
                    {formatAmount(fcData.netIncome)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* النسب المالية */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">النسب المالية</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>نسبة السيولة</span>
                  <span className="font-medium">{currentRatio.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>هامش الربح</span>
                  <span className={`font-medium ${profitMargin < 0 ? 'text-destructive' : 'text-green-600'}`}>
                    {profitMargin.toFixed(2)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>الإيرادات/المصروفات</span>
                  <span className="font-medium">
                    {fcData.totalExpenses ? (fcData.totalRevenue / fcData.totalExpenses).toFixed(2) : "∞"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* الرسم البياني والتفاصيل */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">التمثيل البياني لإيرادات ومصروفات المشروع</CardTitle>
            </CardHeader>
            <CardContent className="h-64 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <BarChart3 className="h-12 w-12 mx-auto mb-4" />
                <p>رسم بياني للإيرادات والمصروفات</p>
                <p className="text-sm">(سيتم تنفيذه لاحقًا)</p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">مؤشرات إضافية</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">النقد والأرصدة البنكية</div>
                  <div className="text-lg font-medium">{formatAmount(fcData.cashBalance)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">الذمم المدينة</div>
                  <div className="text-lg font-medium">{formatAmount(fcData.accountsReceivable)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-1">الذمم الدائنة</div>
                  <div className="text-lg font-medium">{formatAmount(fcData.accountsPayable)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  // مكون تفاصيل المركز المالي
  const FinancialCenterDetails = () => {
    return (
      <div className="space-y-6">
        <Tabs defaultValue="assets" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="assets">الأصول</TabsTrigger>
            <TabsTrigger value="liabilities">الخصوم</TabsTrigger>
            <TabsTrigger value="revenue">الإيرادات</TabsTrigger>
            <TabsTrigger value="expenses">المصروفات</TabsTrigger>
            <TabsTrigger value="equity">حقوق الملكية</TabsTrigger>
          </TabsList>
          
          <TabsContent value="assets" className="border rounded-md p-4 mt-2">
            <h3 className="text-lg font-semibold mb-4">تفاصيل الأصول</h3>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">الرمز</TableHead>
                    <TableHead className="w-[15%]">النوع</TableHead>
                    <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAccounts ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center">
                        <Skeleton className="h-4 w-full mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : accounts.filter((acc: ChartOfAccount) => acc.type === "asset").length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        لا توجد حسابات أصول مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts
                      .filter((acc: ChartOfAccount) => acc.type === "asset")
                      .map((account: ChartOfAccount) => (
                        <TableRow key={account.id}>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>{account.code}</TableCell>
                          <TableCell>
                            {account.class === "current_asset" ? "أصول متداولة" : "أصول ثابتة"}
                          </TableCell>
                          <TableCell className="text-left">
                            {formatAmount(0)} {/* سيتم استبدالها برصيد فعلي */}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          <TabsContent value="liabilities" className="border rounded-md p-4 mt-2">
            <h3 className="text-lg font-semibold mb-4">تفاصيل الخصوم</h3>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">الرمز</TableHead>
                    <TableHead className="w-[15%]">النوع</TableHead>
                    <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAccounts ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center">
                        <Skeleton className="h-4 w-full mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : accounts.filter((acc: ChartOfAccount) => acc.type === "liability").length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        لا توجد حسابات خصوم مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts
                      .filter((acc: ChartOfAccount) => acc.type === "liability")
                      .map((account: ChartOfAccount) => (
                        <TableRow key={account.id}>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>{account.code}</TableCell>
                          <TableCell>
                            {account.class === "current_liability" ? "خصوم متداولة" : "خصوم طويلة الأجل"}
                          </TableCell>
                          <TableCell className="text-left">
                            {formatAmount(0)} {/* سيتم استبدالها برصيد فعلي */}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          <TabsContent value="revenue" className="border rounded-md p-4 mt-2">
            <h3 className="text-lg font-semibold mb-4">تفاصيل الإيرادات</h3>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">الرمز</TableHead>
                    <TableHead className="w-[15%]">النوع</TableHead>
                    <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAccounts ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center">
                        <Skeleton className="h-4 w-full mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : accounts.filter((acc: ChartOfAccount) => acc.type === "revenue").length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        لا توجد حسابات إيرادات مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts
                      .filter((acc: ChartOfAccount) => acc.type === "revenue")
                      .map((account: ChartOfAccount) => (
                        <TableRow key={account.id}>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>{account.code}</TableCell>
                          <TableCell>
                            {account.class === "revenue" ? "إيرادات رئيسية" : "إيرادات أخرى"}
                          </TableCell>
                          <TableCell className="text-left">
                            {formatAmount(0)} {/* سيتم استبدالها برصيد فعلي */}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          <TabsContent value="expenses" className="border rounded-md p-4 mt-2">
            <h3 className="text-lg font-semibold mb-4">تفاصيل المصروفات</h3>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">الرمز</TableHead>
                    <TableHead className="w-[15%]">النوع</TableHead>
                    <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAccounts ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center">
                        <Skeleton className="h-4 w-full mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : accounts.filter((acc: ChartOfAccount) => acc.type === "expense").length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        لا توجد حسابات مصروفات مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts
                      .filter((acc: ChartOfAccount) => acc.type === "expense")
                      .map((account: ChartOfAccount) => (
                        <TableRow key={account.id}>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>{account.code}</TableCell>
                          <TableCell>
                            {account.class === "direct_expense" ? "مصروفات مباشرة" : 
                             account.class === "indirect_expense" ? "مصروفات غير مباشرة" : "مصروفات أخرى"}
                          </TableCell>
                          <TableCell className="text-left">
                            {formatAmount(0)} {/* سيتم استبدالها برصيد فعلي */}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          <TabsContent value="equity" className="border rounded-md p-4 mt-2">
            <h3 className="text-lg font-semibold mb-4">تفاصيل حقوق الملكية</h3>
            <div className="rounded-md border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">الرمز</TableHead>
                    <TableHead className="w-[15%]">النوع</TableHead>
                    <TableHead className="w-[30%] text-left">الرصيد</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoadingAccounts ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center">
                        <Skeleton className="h-4 w-full mx-auto" />
                      </TableCell>
                    </TableRow>
                  ) : accounts.filter((acc: ChartOfAccount) => acc.type === "equity").length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="h-24 text-center text-muted-foreground">
                        لا توجد حسابات حقوق ملكية مسجلة
                      </TableCell>
                    </TableRow>
                  ) : (
                    accounts
                      .filter((acc: ChartOfAccount) => acc.type === "equity")
                      .map((account: ChartOfAccount) => (
                        <TableRow key={account.id}>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>{account.code}</TableCell>
                          <TableCell>حقوق ملكية</TableCell>
                          <TableCell className="text-left">
                            {formatAmount(0)} {/* سيتم استبدالها برصيد فعلي */}
                          </TableCell>
                        </TableRow>
                      ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    );
  };

  // المكون الرئيسي
  return (
    <div className="h-full flex flex-col">
      <div className="bg-background border-b p-4 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-semibold">المركز المالي للمشروع</h1>
          <p className="text-sm text-muted-foreground">عرض وتحليل البيانات المالية للمشروع</p>
        </div>
        <div className="flex gap-2">
          <Select
            value={selectedProject !== null ? selectedProject.toString() : ""}
            onValueChange={(value) => setSelectedProject(value ? parseInt(value) : null)}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="اختر المشروع" />
            </SelectTrigger>
            <SelectContent>
              {isLoadingProjects ? (
                <SelectItem value="" disabled>جاري تحميل المشاريع...</SelectItem>
              ) : projects.length === 0 ? (
                <SelectItem value="" disabled>لا توجد مشاريع</SelectItem>
              ) : (
                projects.map((project: Project) => (
                  <SelectItem key={project.id} value={project.id.toString()}>
                    {project.name}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>

          <Select
            value={selectedPeriod}
            onValueChange={setSelectedPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="الفترة المالية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current-month">الشهر الحالي</SelectItem>
              <SelectItem value="last-month">الشهر السابق</SelectItem>
              <SelectItem value="ytd">من بداية العام</SelectItem>
              <SelectItem value="last-year">السنة السابقة</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" onClick={() => {
            queryClient.invalidateQueries({ queryKey: ["/api/project-financial-center"] });
          }}>
            <RefreshCw className="h-4 w-4 ml-1 rtl:mr-1" /> تحديث
          </Button>
        </div>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        <Tabs defaultValue="summary" className="w-full">
          <TabsList className="w-60 mx-auto mb-4">
            <TabsTrigger value="summary">ملخص المركز المالي</TabsTrigger>
            <TabsTrigger value="details">التفاصيل</TabsTrigger>
          </TabsList>

          <TabsContent value="summary">
            {selectedProject && (
              <div className="mb-4">
                <Card className="bg-muted/40">
                  <CardContent className="pt-4 pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <h2 className="text-xl font-semibold">{getProjectName(selectedProject)}</h2>
                        <p className="text-sm text-muted-foreground">
                          المركز المالي لـ {getPeriodName()}
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Printer className="h-4 w-4 ml-1 rtl:mr-1" /> طباعة
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            <FinancialCenterSummary />
          </TabsContent>

          <TabsContent value="details">
            {selectedProject && (
              <div className="mb-4">
                <Card className="bg-muted/40">
                  <CardContent className="pt-4 pb-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <h2 className="text-xl font-semibold">{getProjectName(selectedProject)}</h2>
                        <p className="text-sm text-muted-foreground">
                          تفاصيل المركز المالي لـ {getPeriodName()}
                        </p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Printer className="h-4 w-4 ml-1 rtl:mr-1" /> طباعة
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {selectedProject === null ? (
              <div className="p-8 text-center">
                <Building className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h2 className="text-xl font-semibold mb-2">يرجى اختيار مشروع</h2>
                <p className="text-muted-foreground">
                  اختر مشروعًا من القائمة المنسدلة لعرض تفاصيل المركز المالي الخاص به
                </p>
              </div>
            ) : (
              <FinancialCenterDetails />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}