import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Search, Filter, ArrowLeft, ArrowRight, FileText, Download } from 'lucide-react';

/**
 * عرض أرصدة الحسابات
 * 
 * مكون لعرض أرصدة الحسابات:
 * - عرض أرصدة الحسابات بحسب المشاريع
 * - عرض أرصدة الحسابات بحسب الفترات
 * - عرض تفاصيل حركة الحساب
 * - تصفية وبحث الحسابات
 */

type AccountBalancesViewProps = {
  projectId?: number;
  fiscalYear?: number;
  fiscalMonth?: number;
};

const AccountBalancesView: React.FC<AccountBalancesViewProps> = ({
  projectId,
  fiscalYear = new Date().getFullYear(),
  fiscalMonth = new Date().getMonth() + 1,
}) => {
  // حالة المكون
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);
  const [selectedProject, setSelectedProject] = useState<number | undefined>(projectId);
  const [year, setYear] = useState<number>(fiscalYear);
  const [month, setMonth] = useState<number>(fiscalMonth);
  const [searchQuery, setSearchQuery] = useState('');
  const [accountTypeFilter, setAccountTypeFilter] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('balances');

  // استعلام قائمة الحسابات
  const { data: accounts = [], isLoading: accountsLoading } = useQuery({
    queryKey: ['/api/financial/accounts'],
    staleTime: 5 * 60 * 1000, // 5 دقائق
  });

  // استعلام قائمة المشاريع
  const { data: projects = [], isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 5 * 60 * 1000, // 5 دقائق
  });

  // استعلام أرصدة الحسابات
  const { data: accountBalances = [], isLoading: balancesLoading } = useQuery({
    queryKey: ['/api/financial/account-balances', selectedProject, year, month],
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // استعلام تفاصيل حركة الحساب المحدد
  const { data: accountDetails = [], isLoading: detailsLoading } = useQuery({
    queryKey: ['/api/financial/account-details', selectedAccountId, selectedProject, year, month],
    enabled: !!selectedAccountId,
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // إنشاء قائمة السنوات
  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 5; i <= currentYear + 2; i++) {
    years.push(i);
  }

  // إنشاء قائمة الأشهر
  const months = [
    { value: 1, label: 'يناير' },
    { value: 2, label: 'فبراير' },
    { value: 3, label: 'مارس' },
    { value: 4, label: 'أبريل' },
    { value: 5, label: 'مايو' },
    { value: 6, label: 'يونيو' },
    { value: 7, label: 'يوليو' },
    { value: 8, label: 'أغسطس' },
    { value: 9, label: 'سبتمبر' },
    { value: 10, label: 'أكتوبر' },
    { value: 11, label: 'نوفمبر' },
    { value: 12, label: 'ديسمبر' },
  ];

  // الحصول على اسم المشروع
  const getProjectName = (projectId?: number) => {
    if (!projectId) return 'جميع المشاريع';
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // الحصول على معلومات الحساب
  const getAccountInfo = (accountId: number) => {
    const account = accounts.find((acc: any) => acc.id === accountId);
    return account ? { name: account.name, code: account.code, type: account.type } : { name: 'غير معروف', code: '', type: '' };
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-SA', { maximumFractionDigits: 2 });
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(new Date(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // تصفية الأرصدة بناءً على البحث ونوع الحساب
  const filteredBalances = accountBalances.filter((balance: any) => {
    const account = getAccountInfo(balance.accountId);
    
    // تصفية حسب البحث
    const matchesSearch = !searchQuery || 
                          account.code.includes(searchQuery) || 
                          account.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // تصفية حسب نوع الحساب
    const matchesType = !accountTypeFilter || account.type === accountTypeFilter;
    
    return matchesSearch && matchesType;
  });

  // تغيير الشهر مع التعامل مع تغيير السنة
  const handleMonthChange = (newMonth: number) => {
    setMonth(newMonth);
  };

  // الانتقال للشهر السابق
  const goToPreviousMonth = () => {
    if (month === 1) {
      setMonth(12);
      setYear(year - 1);
    } else {
      setMonth(month - 1);
    }
  };

  // الانتقال للشهر التالي
  const goToNextMonth = () => {
    if (month === 12) {
      setMonth(1);
      setYear(year + 1);
    } else {
      setMonth(month + 1);
    }
  };

  // عرض تفاصيل حركة الحساب
  const handleViewAccountDetails = (accountId: number) => {
    setSelectedAccountId(accountId);
    setActiveTab('details');
  };

  // تحميل كشف حساب
  const handleDownloadAccountStatement = (accountId: number) => {
    // تنفيذ تحميل كشف الحساب (تكامل مع واجهة برمجية التطبيق)
    window.open(`/api/financial/account-statement-export?accountId=${accountId}&projectId=${selectedProject}&year=${year}&month=${month}`);
  };

  return (
    <div className="space-y-6">
      {/* رأس الصفحة مع عناصر التحكم */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">أرصدة الحسابات</h2>
          <p className="text-muted-foreground">
            {getProjectName(selectedProject)} - {months.find(m => m.value === month)?.label} {year}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!projectId && (
            <Select
              value={selectedProject ? selectedProject.toString() : ''}
              onValueChange={(value) => setSelectedProject(value ? parseInt(value) : undefined)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="اختر المشروع" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع المشاريع</SelectItem>
                {projects.map((project: any) => (
                  <SelectItem key={project.id} value={project.id.toString()}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              onClick={goToPreviousMonth}
              title="الشهر السابق"
            >
              <ArrowRight className="h-4 w-4" />
            </Button>

            <Select
              value={month.toString()}
              onValueChange={(value) => handleMonthChange(parseInt(value))}
            >
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((monthOption) => (
                  <SelectItem key={monthOption.value} value={monthOption.value.toString()}>
                    {monthOption.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={year.toString()}
              onValueChange={(value) => setYear(parseInt(value))}
            >
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map((yearOption) => (
                  <SelectItem key={yearOption} value={yearOption.toString()}>
                    {yearOption}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="icon"
              onClick={goToNextMonth}
              title="الشهر التالي"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* علامات التبويب */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="balances">أرصدة الحسابات</TabsTrigger>
          <TabsTrigger value="details" disabled={!selectedAccountId}>
            تفاصيل الحركة
          </TabsTrigger>
        </TabsList>

        <TabsContent value="balances" className="space-y-4">
          {/* أدوات البحث والتصفية */}
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1">
              <Search className="absolute top-2.5 right-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث عن حساب..."
                className="pr-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <Select
              value={accountTypeFilter || ''}
              onValueChange={(value) => setAccountTypeFilter(value || null)}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="نوع الحساب" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأنواع</SelectItem>
                <SelectItem value="asset">أصول</SelectItem>
                <SelectItem value="liability">التزامات</SelectItem>
                <SelectItem value="equity">حقوق ملكية</SelectItem>
                <SelectItem value="revenue">إيرادات</SelectItem>
                <SelectItem value="expense">مصروفات</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* جدول أرصدة الحسابات */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>أرصدة الحسابات</CardTitle>
              <CardDescription>
                عرض أرصدة الحسابات في {months.find(m => m.value === month)?.label} {year}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {balancesLoading ? (
                <div className="flex justify-center items-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                </div>
              ) : filteredBalances.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {searchQuery || accountTypeFilter
                    ? 'لا توجد نتائج تطابق معايير البحث'
                    : 'لا توجد أرصدة للحسابات في هذه الفترة'}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رمز الحساب</TableHead>
                      <TableHead>اسم الحساب</TableHead>
                      <TableHead>نوع الحساب</TableHead>
                      <TableHead className="text-center">الرصيد الافتتاحي</TableHead>
                      <TableHead className="text-center">إجمالي المدين</TableHead>
                      <TableHead className="text-center">إجمالي الدائن</TableHead>
                      <TableHead className="text-center">الرصيد الختامي</TableHead>
                      <TableHead className="text-center">الإجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBalances.map((balance: any) => {
                      const account = getAccountInfo(balance.accountId);
                      return (
                        <TableRow key={balance.id}>
                          <TableCell className="font-medium">{account.code}</TableCell>
                          <TableCell>{account.name}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                account.type === 'asset'
                                  ? 'bg-blue-100 text-blue-800'
                                  : account.type === 'liability'
                                  ? 'bg-amber-100 text-amber-800'
                                  : account.type === 'equity'
                                  ? 'bg-green-100 text-green-800'
                                  : account.type === 'revenue'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-red-100 text-red-800'
                              }
                            >
                              {account.type === 'asset'
                                ? 'أصول'
                                : account.type === 'liability'
                                ? 'التزامات'
                                : account.type === 'equity'
                                ? 'حقوق ملكية'
                                : account.type === 'revenue'
                                ? 'إيرادات'
                                : 'مصروفات'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            {formatCurrency(balance.openingBalance)}
                          </TableCell>
                          <TableCell className="text-center">
                            {formatCurrency(balance.debitTotal)}
                          </TableCell>
                          <TableCell className="text-center">
                            {formatCurrency(balance.creditTotal)}
                          </TableCell>
                          <TableCell 
                            className={`text-center font-medium ${
                              balance.closingBalance >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}
                          >
                            {formatCurrency(Math.abs(balance.closingBalance))}
                            {balance.closingBalance < 0 && ' -'}
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex justify-center space-x-1 space-x-reverse">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleViewAccountDetails(balance.accountId)}
                                title="عرض تفاصيل الحركة"
                              >
                                <FileText className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDownloadAccountStatement(balance.accountId)}
                                title="تحميل كشف الحساب"
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
            <CardFooter className="py-2">
              <div className="text-muted-foreground text-sm">
                إجمالي الحسابات: {filteredBalances.length}
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          {selectedAccountId && (
            <>
              {/* رأس تفاصيل الحساب */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h3 className="text-xl font-bold">
                    تفاصيل حركة الحساب: {getAccountInfo(selectedAccountId).code} -{' '}
                    {getAccountInfo(selectedAccountId).name}
                  </h3>
                  <p className="text-muted-foreground">
                    {getProjectName(selectedProject)} - {months.find(m => m.value === month)?.label} {year}
                  </p>
                </div>

                <Button variant="outline" onClick={() => setActiveTab('balances')}>
                  <ArrowRight className="h-4 w-4 ml-2" />
                  العودة للأرصدة
                </Button>
              </div>

              {/* جدول تفاصيل حركة الحساب */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle>حركة الحساب</CardTitle>
                  <CardDescription>
                    جميع الحركات على الحساب خلال الفترة
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  {detailsLoading ? (
                    <div className="flex justify-center items-center py-8">
                      <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                    </div>
                  ) : accountDetails.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      لا توجد حركات على هذا الحساب خلال هذه الفترة
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>التاريخ</TableHead>
                          <TableHead>رقم القيد</TableHead>
                          <TableHead>البيان</TableHead>
                          <TableHead className="text-center">مدين</TableHead>
                          <TableHead className="text-center">دائن</TableHead>
                          <TableHead className="text-center">الرصيد</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {/* صف الرصيد الافتتاحي */}
                        <TableRow>
                          <TableCell>{formatDate(`${year}-${String(month).padStart(2, '0')}-01`)}</TableCell>
                          <TableCell>-</TableCell>
                          <TableCell className="font-medium">رصيد افتتاحي</TableCell>
                          <TableCell className="text-center">-</TableCell>
                          <TableCell className="text-center">-</TableCell>
                          <TableCell className={`text-center font-medium ${
                            accountDetails.openingBalance >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {formatCurrency(Math.abs(accountDetails.openingBalance || 0))}
                            {accountDetails.openingBalance < 0 && ' -'}
                          </TableCell>
                        </TableRow>
                        {accountDetails.transactions?.map((transaction: any, index: number) => (
                          <TableRow key={index}>
                            <TableCell>{formatDate(transaction.date)}</TableCell>
                            <TableCell>{transaction.entryNumber}</TableCell>
                            <TableCell>{transaction.description}</TableCell>
                            <TableCell className="text-center">
                              {transaction.debit > 0 ? formatCurrency(transaction.debit) : '-'}
                            </TableCell>
                            <TableCell className="text-center">
                              {transaction.credit > 0 ? formatCurrency(transaction.credit) : '-'}
                            </TableCell>
                            <TableCell className={`text-center font-medium ${
                              transaction.balance >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              {formatCurrency(Math.abs(transaction.balance))}
                              {transaction.balance < 0 && ' -'}
                            </TableCell>
                          </TableRow>
                        ))}
                        {/* صف الرصيد الختامي */}
                        <TableRow className="bg-muted/50 font-bold">
                          <TableCell colSpan={3} className="text-left">
                            الإجمالي
                          </TableCell>
                          <TableCell className="text-center">
                            {formatCurrency(accountDetails.totalDebit || 0)}
                          </TableCell>
                          <TableCell className="text-center">
                            {formatCurrency(accountDetails.totalCredit || 0)}
                          </TableCell>
                          <TableCell className={`text-center ${
                            accountDetails.closingBalance >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {formatCurrency(Math.abs(accountDetails.closingBalance || 0))}
                            {accountDetails.closingBalance < 0 && ' -'}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AccountBalancesView;