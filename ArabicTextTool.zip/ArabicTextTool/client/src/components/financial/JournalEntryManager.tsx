import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { Plus, Edit, Trash2, FileText, Calculator, ArrowLeft, ArrowRight, Calendar, RefreshCw } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { JournalEntry, JournalEntryItem, ChartOfAccount, Project } from "@shared/schema";

// تعريف المخطط الخاص بإنشاء القيود المحاسبية
const journalEntryFormSchema = z.object({
  date: z.date({
    required_error: "تاريخ القيد مطلوب",
  }),
  reference: z.string().optional(),
  description: z.string().min(3, "الوصف مطلوب (3 أحرف على الأقل)"),
  projectId: z.number().nullable(),
  status: z.string().default("draft"),
  type: z.string().default("standard"),
  items: z
    .array(
      z.object({
        accountId: z.number({
          required_error: "الحساب مطلوب",
        }),
        description: z.string().optional(),
        debit: z.number().min(0, "يجب أن تكون القيمة أكبر من أو تساوي صفر"),
        credit: z.number().min(0, "يجب أن تكون القيمة أكبر من أو تساوي صفر"),
        projectId: z.number().nullable(),
      })
    )
    .min(2, "يجب إضافة عنصرين على الأقل")
    .refine(
      (items) => {
        // التحقق من أن مجموع المدين يساوي مجموع الدائن
        const totalDebit = items.reduce((sum, item) => sum + (item.debit || 0), 0);
        const totalCredit = items.reduce((sum, item) => sum + (item.credit || 0), 0);
        return Math.abs(totalDebit - totalCredit) < 0.001; // مقارنة مع هامش خطأ صغير للأرقام العشرية
      },
      {
        message: "يجب أن يكون مجموع المدين مساوياً لمجموع الدائن",
        path: ["items"],
      }
    ),
});

type JournalEntryFormValues = z.infer<typeof journalEntryFormSchema>;

// القائمة الرئيسية لإدارة القيود المحاسبية
export default function JournalEntryManager() {
  const { toast } = useToast();
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
  const [selectedEntryItems, setSelectedEntryItems] = useState<JournalEntryItem[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [filterMonth, setFilterMonth] = useState<Date>(new Date());
  const [showCalendar, setShowCalendar] = useState(false);

  // استعلام لجلب القيود المحاسبية
  const {
    data: journalEntries = [],
    isLoading: isLoadingEntries,
    error: entriesError,
  } = useQuery({
    queryKey: ["/api/journal-entries"],
    retry: 2,
  });

  // استعلام لجلب الحسابات
  const {
    data: accounts = [],
    isLoading: isLoadingAccounts,
  } = useQuery({
    queryKey: ["/api/accounts"],
    retry: 2,
  });

  // استعلام لجلب المشاريع
  const {
    data: projects = [],
    isLoading: isLoadingProjects,
  } = useQuery({
    queryKey: ["/api/projects"],
    retry: 2,
  });

  // تحميل عناصر القيد المحدد
  useEffect(() => {
    if (selectedEntry) {
      const fetchEntryItems = async () => {
        try {
          const res = await apiRequest("GET", `/api/journal-entries/${selectedEntry.id}/items`);
          if (res.ok) {
            const data = await res.json();
            setSelectedEntryItems(data);
          } else {
            toast({
              title: "خطأ في تحميل عناصر القيد",
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error("Error fetching entry items:", error);
          toast({
            title: "خطأ في تحميل عناصر القيد",
            variant: "destructive",
          });
        }
      };

      fetchEntryItems();
    } else {
      setSelectedEntryItems([]);
    }
  }, [selectedEntry, toast]);

  // إضافة قيد محاسبي جديد
  const addJournalEntryMutation = useMutation({
    mutationFn: async (values: JournalEntryFormValues) => {
      // إنشاء القيد المحاسبي
      const entryResponse = await apiRequest("POST", "/api/journal-entries", {
        date: format(values.date, "yyyy-MM-dd"),
        reference: values.reference,
        description: values.description,
        projectId: values.projectId,
        status: values.status,
        type: values.type,
      });

      if (!entryResponse.ok) {
        throw new Error("فشل في إنشاء القيد المحاسبي");
      }

      const entry = await entryResponse.json();

      // إضافة عناصر القيد
      for (const item of values.items) {
        const itemResponse = await apiRequest(
          "POST",
          `/api/journal-entries/${entry.id}/items`,
          {
            ...item,
            journalEntryId: entry.id,
          }
        );

        if (!itemResponse.ok) {
          throw new Error("فشل في إضافة عناصر القيد المحاسبي");
        }
      }

      return entry;
    },
    onSuccess: () => {
      toast({
        title: "تم إنشاء القيد المحاسبي بنجاح",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      setIsAddDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في إنشاء القيد المحاسبي",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // تنسيق تاريخ القيد
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return format(date, "dd MMMM yyyy", { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // تنسيق المبلغ المالي
  const formatAmount = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return "0.00";
    return new Intl.NumberFormat("ar-SA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  // الحصول على اسم الحساب من الرقم
  const getAccountName = (accountId: number | null) => {
    if (!accountId) return "غير محدد";
    const account = accounts.find((acc: ChartOfAccount) => acc.id === accountId);
    return account ? `${account.code} - ${account.name}` : "غير محدد";
  };

  // الحصول على اسم المشروع من الرقم
  const getProjectName = (projectId: number | null) => {
    if (!projectId) return "غير محدد";
    const project = projects.find((proj: Project) => proj.id === projectId);
    return project ? project.name : "غير محدد";
  };

  // فلترة القيود حسب الشهر
  const filteredEntries = journalEntries.filter((entry: JournalEntry) => {
    const entryDate = new Date(entry.date);
    return (
      entryDate.getMonth() === filterMonth.getMonth() &&
      entryDate.getFullYear() === filterMonth.getFullYear()
    );
  });

  // نموذج إضافة قيد محاسبي
  const AddJournalEntryForm = () => {
    const form = useForm<JournalEntryFormValues>({
      resolver: zodResolver(journalEntryFormSchema),
      defaultValues: {
        date: new Date(),
        reference: "",
        description: "",
        projectId: null,
        status: "draft",
        type: "standard",
        items: [
          { accountId: 0, description: "", debit: 0, credit: 0, projectId: null },
          { accountId: 0, description: "", debit: 0, credit: 0, projectId: null },
        ],
      },
    });

    const { fields, append, remove } = useFieldArray({
      control: form.control,
      name: "items",
    });

    const onSubmit = (values: JournalEntryFormValues) => {
      addJournalEntryMutation.mutate(values);
    };

    // حساب مجموع المدين والدائن
    const totalDebit = form.watch("items").reduce(
      (sum, item) => sum + (parseFloat(item.debit?.toString() || "0") || 0),
      0
    );
    const totalCredit = form.watch("items").reduce(
      (sum, item) => sum + (parseFloat(item.credit?.toString() || "0") || 0),
      0
    );
    const isBalanced = Math.abs(totalDebit - totalCredit) < 0.001;

    return (
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ القيد*</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={`w-full text-right pl-3 font-normal ${
                            !field.value ? "text-muted-foreground" : ""
                          }`}
                        >
                          {field.value ? (
                            format(field.value, "dd MMMM yyyy", { locale: ar })
                          ) : (
                            <span>اختر تاريخ</span>
                          )}
                          <Calendar className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="reference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>الإشارة المرجعية</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="رقم مرجعي اختياري للقيد" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>وصف القيد*</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="وصف عام للقيد المحاسبي"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="projectId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>المشروع المرتبط</FormLabel>
                  <Select
                    onValueChange={(value) =>
                      field.onChange(value ? parseInt(value) : null)
                    }
                    value={field.value?.toString() || ""}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المشروع (اختياري)" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">بدون مشروع</SelectItem>
                      {projects.map((project: Project) => (
                        <SelectItem
                          key={project.id}
                          value={project.id.toString()}
                        >
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع القيد</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع القيد" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="standard">قيد عادي</SelectItem>
                      <SelectItem value="adjustment">قيد تسوية</SelectItem>
                      <SelectItem value="opening">قيد افتتاحي</SelectItem>
                      <SelectItem value="closing">قيد إقفال</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Separator className="my-4" />

          <div>
            <div className="flex justify-between items-center mb-2">
              <Label className="text-lg font-semibold">بنود القيد المحاسبي*</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() =>
                  append({
                    accountId: 0,
                    description: "",
                    debit: 0,
                    credit: 0,
                    projectId: form.getValues("projectId"),
                  })
                }
              >
                <Plus className="h-4 w-4 ml-1 rtl:mr-1" /> إضافة بند
              </Button>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40%]">الحساب</TableHead>
                    <TableHead className="w-[20%]">مدين</TableHead>
                    <TableHead className="w-[20%]">دائن</TableHead>
                    <TableHead className="w-[15%]">المشروع</TableHead>
                    <TableHead className="w-[5%]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fields.map((field, index) => (
                    <TableRow key={field.id}>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.accountId`}
                          render={({ field }) => (
                            <FormItem>
                              <Select
                                onValueChange={(value) =>
                                  field.onChange(parseInt(value))
                                }
                                value={field.value ? field.value.toString() : ""}
                              >
                                <FormControl>
                                  <SelectTrigger className="w-full">
                                    <SelectValue placeholder="اختر الحساب" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {accounts.map((account: ChartOfAccount) => (
                                    <SelectItem
                                      key={account.id}
                                      value={account.id.toString()}
                                    >
                                      {account.code} - {account.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.debit`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input
                                  type="number"
                                  min="0"
                                  step="0.01"
                                  placeholder="0.00"
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    // إذا كانت هناك قيمة مدين، اجعل الدائن صفر
                                    if (parseFloat(e.target.value) > 0) {
                                      form.setValue(
                                        `items.${index}.credit`,
                                        0
                                      );
                                    }
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.credit`}
                          render={({ field }) => (
                            <FormItem>
                              <FormControl>
                                <Input
                                  type="number"
                                  min="0"
                                  step="0.01"
                                  placeholder="0.00"
                                  {...field}
                                  onChange={(e) => {
                                    field.onChange(parseFloat(e.target.value) || 0);
                                    // إذا كانت هناك قيمة دائن، اجعل المدين صفر
                                    if (parseFloat(e.target.value) > 0) {
                                      form.setValue(
                                        `items.${index}.debit`,
                                        0
                                      );
                                    }
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        <FormField
                          control={form.control}
                          name={`items.${index}.projectId`}
                          render={({ field }) => (
                            <FormItem>
                              <Select
                                onValueChange={(value) =>
                                  field.onChange(value ? parseInt(value) : null)
                                }
                                value={field.value?.toString() || ""}
                              >
                                <FormControl>
                                  <SelectTrigger className="w-full">
                                    <SelectValue placeholder="المشروع" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="none">بدون مشروع</SelectItem>
                                  {projects.map((project: Project) => (
                                    <SelectItem
                                      key={project.id}
                                      value={project.id.toString()}
                                    >
                                      {project.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TableCell>
                      <TableCell>
                        {index > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => remove(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableRow className="bg-muted/50">
                  <TableCell className="font-bold">المجموع</TableCell>
                  <TableCell>
                    <span
                      className={
                        !isBalanced && totalDebit > 0
                          ? "text-destructive font-bold"
                          : "font-bold"
                      }
                    >
                      {formatAmount(totalDebit)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span
                      className={
                        !isBalanced && totalCredit > 0
                          ? "text-destructive font-bold"
                          : "font-bold"
                      }
                    >
                      {formatAmount(totalCredit)}
                    </span>
                  </TableCell>
                  <TableCell colSpan={2}>
                    {!isBalanced && (
                      <Badge variant="destructive">
                        القيد غير متوازن ({formatAmount(Math.abs(totalDebit - totalCredit))})
                      </Badge>
                    )}
                    {isBalanced && totalDebit > 0 && (
                      <Badge className="bg-green-600">القيد متوازن</Badge>
                    )}
                  </TableCell>
                </TableRow>
              </Table>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddDialogOpen(false)}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              disabled={addJournalEntryMutation.isPending || !isBalanced || totalDebit === 0}
            >
              {addJournalEntryMutation.isPending
                ? "جاري الإنشاء..."
                : "إنشاء القيد"}
            </Button>
          </DialogFooter>
        </form>
      </Form>
    );
  };

  // عرض تفاصيل القيد المحاسبي
  const EntryDetailsView = () => {
    if (!selectedEntry) {
      return (
        <div className="flex items-center justify-center h-full p-6 text-muted-foreground">
          <p>يرجى اختيار قيد محاسبي لعرض تفاصيله</p>
        </div>
      );
    }

    const totalDebit = selectedEntryItems.reduce(
      (sum, item) => sum + (item.debit || 0),
      0
    );
    const totalCredit = selectedEntryItems.reduce(
      (sum, item) => sum + (item.credit || 0),
      0
    );

    const getStatusBadge = (status: string) => {
      switch (status) {
        case "draft":
          return <Badge variant="outline">مسودة</Badge>;
        case "posted":
          return <Badge variant="default">مُرحّل</Badge>;
        case "approved":
          return <Badge variant="success">معتمد</Badge>;
        case "rejected":
          return <Badge variant="destructive">مرفوض</Badge>;
        default:
          return <Badge>{status}</Badge>;
      }
    };

    const getTypeText = (type: string) => {
      switch (type) {
        case "standard":
          return "قيد عادي";
        case "adjustment":
          return "قيد تسوية";
        case "opening":
          return "قيد افتتاحي";
        case "closing":
          return "قيد إقفال";
        default:
          return type;
      }
    };

    return (
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">تفاصيل القيد المحاسبي</h3>
          <div className="space-x-2 rtl:space-x-reverse">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setIsViewDialogOpen(true)}
            >
              <FileText className="h-4 w-4 ml-1 rtl:mr-1" /> عرض كامل
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <div>
              <Label>رقم القيد</Label>
              <p className="font-mono">{selectedEntry.id}</p>
            </div>
            <div>
              <Label>تاريخ القيد</Label>
              <p>{formatDate(selectedEntry.date)}</p>
            </div>
            <div>
              <Label>الإشارة المرجعية</Label>
              <p>{selectedEntry.reference || "لا يوجد"}</p>
            </div>
          </div>
          <div className="space-y-2">
            <div>
              <Label>الحالة</Label>
              <p>{getStatusBadge(selectedEntry.status)}</p>
            </div>
            <div>
              <Label>نوع القيد</Label>
              <p>{getTypeText(selectedEntry.type)}</p>
            </div>
            <div>
              <Label>المشروع</Label>
              <p>
                {selectedEntry.projectId
                  ? getProjectName(selectedEntry.projectId)
                  : "غير مرتبط بمشروع"}
              </p>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <Label>وصف القيد</Label>
          <p>{selectedEntry.description}</p>
        </div>

        <div className="mb-4">
          <h4 className="font-semibold mb-2">بنود القيد</h4>
          {selectedEntryItems.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد بنود لهذا القيد</p>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50%]">الحساب</TableHead>
                    <TableHead className="w-[15%]">المشروع</TableHead>
                    <TableHead className="w-[15%]">مدين</TableHead>
                    <TableHead className="w-[15%]">دائن</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedEntryItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{getAccountName(item.accountId)}</TableCell>
                      <TableCell>
                        {item.projectId
                          ? getProjectName(item.projectId)
                          : "غير محدد"}
                      </TableCell>
                      <TableCell>
                        {item.debit ? formatAmount(item.debit) : "-"}
                      </TableCell>
                      <TableCell>
                        {item.credit ? formatAmount(item.credit) : "-"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableRow className="bg-muted/50">
                  <TableCell colSpan={2} className="font-bold">المجموع</TableCell>
                  <TableCell className="font-bold">{formatAmount(totalDebit)}</TableCell>
                  <TableCell className="font-bold">{formatAmount(totalCredit)}</TableCell>
                </TableRow>
              </Table>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 flex">
        <Card className="w-1/2 flex flex-col overflow-hidden border-l">
          <CardHeader className="pb-3">
            <div className="flex justify-between items-center">
              <CardTitle>القيود المحاسبية</CardTitle>
              <Button size="sm" onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 ml-1 rtl:mr-1" /> قيد جديد
              </Button>
            </div>
            <div className="flex justify-between items-center mt-2">
              <div className="flex items-center">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const newDate = new Date(filterMonth);
                    newDate.setMonth(newDate.getMonth() - 1);
                    setFilterMonth(newDate);
                  }}
                >
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="min-w-32"
                  onClick={() => setShowCalendar((prev) => !prev)}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  {format(filterMonth, "MMMM yyyy", { locale: ar })}
                </Button>
                {showCalendar && (
                  <div className="absolute z-10 mt-1 bg-background border rounded-md shadow-md top-32">
                    <CalendarComponent
                      mode="single"
                      selected={filterMonth}
                      onSelect={(date) => {
                        if (date) {
                          setFilterMonth(date);
                          setShowCalendar(false);
                        }
                      }}
                      initialFocus
                    />
                  </div>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const newDate = new Date(filterMonth);
                    newDate.setMonth(newDate.getMonth() + 1);
                    setFilterMonth(newDate);
                  }}
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
                }}
              >
                <RefreshCw className="h-4 w-4 ml-1 rtl:mr-1" /> تحديث
              </Button>
            </div>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto p-0">
            {isLoadingEntries ? (
              <div className="p-4 space-y-2">
                {Array(5)
                  .fill(0)
                  .map((_, index) => (
                    <Skeleton key={index} className="h-16 w-full" />
                  ))}
              </div>
            ) : entriesError ? (
              <Alert variant="destructive" className="m-4">
                <AlertTitle>حدث خطأ</AlertTitle>
                <AlertDescription>
                  لم نتمكن من تحميل القيود المحاسبية. يرجى المحاولة مرة أخرى.
                </AlertDescription>
              </Alert>
            ) : filteredEntries.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">
                لا توجد قيود محاسبية في الشهر المحدد. يمكنك إنشاء قيد جديد باستخدام زر "قيد جديد".
              </div>
            ) : (
              <ScrollArea className="h-full">
                <div className="p-4 space-y-2">
                  {filteredEntries
                    .sort((a: JournalEntry, b: JournalEntry) => {
                      // ترتيب تنازلي حسب التاريخ (الأحدث أولاً)
                      return new Date(b.date).getTime() - new Date(a.date).getTime();
                    })
                    .map((entry: JournalEntry) => (
                      <div
                        key={entry.id}
                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                          selectedEntry?.id === entry.id
                            ? "bg-secondary/30 border-primary"
                            : "hover:bg-secondary/20"
                        }`}
                        onClick={() => setSelectedEntry(entry)}
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-semibold mb-1">
                              {entry.reference ? `${entry.reference} - ` : ""}
                              {entry.description}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {formatDate(entry.date)} | {getTypeText(entry.type)}
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <Badge className="mb-1" variant="outline">
                              #{entry.id}
                            </Badge>
                            {getStatusBadge(entry.status)}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
          <CardFooter className="border-t py-2">
            <p className="text-xs text-muted-foreground">
              إجمالي القيود: {filteredEntries.length}
            </p>
          </CardFooter>
        </Card>

        <Card className="flex-1 flex flex-col">
          <EntryDetailsView />
        </Card>
      </div>

      {/* نافذة إضافة قيد محاسبي جديد */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>إنشاء قيد محاسبي جديد</DialogTitle>
            <DialogDescription>
              أدخل بيانات القيد الجديد. الحقول المميزة بعلامة * مطلوبة.
            </DialogDescription>
          </DialogHeader>
          <AddJournalEntryForm />
        </DialogContent>
      </Dialog>

      {/* نافذة عرض تفاصيل القيد كاملة */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>
              تفاصيل القيد المحاسبي #{selectedEntry?.id}
            </DialogTitle>
            <DialogDescription>
              عرض كامل لتفاصيل القيد المحاسبي
            </DialogDescription>
          </DialogHeader>
          {selectedEntry && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>رقم القيد</Label>
                  <p className="font-mono mb-2">{selectedEntry.id}</p>
                  
                  <Label>تاريخ القيد</Label>
                  <p className="mb-2">{formatDate(selectedEntry.date)}</p>
                  
                  <Label>الإشارة المرجعية</Label>
                  <p className="mb-2">{selectedEntry.reference || "لا يوجد"}</p>
                  
                  <Label>تاريخ الإنشاء</Label>
                  <p className="mb-2">
                    {formatDate(selectedEntry.createdAt?.toString() || "")}
                  </p>
                </div>
                <div>
                  <Label>الحالة</Label>
                  <p className="mb-2">{getStatusBadge(selectedEntry.status)}</p>
                  
                  <Label>نوع القيد</Label>
                  <p className="mb-2">{getTypeText(selectedEntry.type)}</p>
                  
                  <Label>المشروع</Label>
                  <p className="mb-2">
                    {selectedEntry.projectId
                      ? getProjectName(selectedEntry.projectId)
                      : "غير مرتبط بمشروع"}
                  </p>
                </div>
              </div>
              
              <div>
                <Label>وصف القيد</Label>
                <p className="mb-4">{selectedEntry.description}</p>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="font-semibold mb-2">بنود القيد المحاسبي</h4>
                <div className="rounded-md border overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[45%]">الحساب</TableHead>
                        <TableHead className="w-[20%]">البيان</TableHead>
                        <TableHead className="w-[15%]">المشروع</TableHead>
                        <TableHead className="w-[10%]">مدين</TableHead>
                        <TableHead className="w-[10%]">دائن</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedEntryItems.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>{getAccountName(item.accountId)}</TableCell>
                          <TableCell>{item.description || "-"}</TableCell>
                          <TableCell>
                            {item.projectId
                              ? getProjectName(item.projectId)
                              : "-"}
                          </TableCell>
                          <TableCell>
                            {item.debit ? formatAmount(item.debit) : "-"}
                          </TableCell>
                          <TableCell>
                            {item.credit ? formatAmount(item.credit) : "-"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableRow className="bg-muted/50">
                      <TableCell colSpan={3} className="font-bold">المجموع</TableCell>
                      <TableCell className="font-bold">{formatAmount(selectedEntryItems.reduce(
                        (sum, item) => sum + (item.debit || 0),
                        0
                      ))}</TableCell>
                      <TableCell className="font-bold">{formatAmount(selectedEntryItems.reduce(
                        (sum, item) => sum + (item.credit || 0),
                        0
                      ))}</TableCell>
                    </TableRow>
                  </Table>
                </div>
              </div>
              
              <DialogFooter>
                <Button onClick={() => setIsViewDialogOpen(false)}>
                  إغلاق
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}