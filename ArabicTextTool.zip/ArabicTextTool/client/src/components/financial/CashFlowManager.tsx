import React, { useState } from "react";
import { 
  Table, 
  TableHeader, 
  TableRow, 
  TableHead, 
  TableBody, 
  TableCell 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DatePicker } from "@/components/ui/date-picker";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Edit, 
  Trash2, 
  Plus, 
  RefreshCw, 
  ArrowLeftRight,
  Calendar,
  DollarSign,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CreditCard,
  Filter
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { insertCashFlowItemSchema } from "@shared/schema.new";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { format, parseISO, addMonths, isSameMonth, isBefore, isAfter } from "date-fns";
import { ar } from "date-fns/locale";
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

interface CashFlowManagerProps {
  projectId?: number;
}

// تعريف شكل نموذج التدفق النقدي
const cashFlowFormSchema = z.object({
  projectId: z.number().int().positive(),
  type: z.string().min(1, { message: "يجب تحديد نوع التدفق النقدي" }),
  category: z.string().min(1, { message: "يجب تحديد تصنيف التدفق النقدي" }),
  expectedDate: z.date({ message: "يجب تحديد التاريخ المتوقع" }),
  expectedAmount: z.coerce.number().min(1, { message: "يجب أن يكون المبلغ أكبر من صفر" }),
  probability: z.coerce.number().min(0, { message: "يجب أن تكون النسبة بين 0 و 100" }).max(100, { message: "يجب أن تكون النسبة بين 0 و 100" }),
  description: z.string().min(3, { message: "يجب إدخال وصف مناسب" }),
  status: z.string().min(1, { message: "يجب تحديد الحالة" }),
  notes: z.string().optional(),
  createdBy: z.number().int().positive(),
});

type CashFlowFormValues = z.infer<typeof cashFlowFormSchema>;

const CashFlowManager: React.FC<CashFlowManagerProps> = ({ projectId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedCashFlow, setSelectedCashFlow] = useState<any>(null);
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [projectionMonths, setProjectionMonths] = useState<number>(6);
  const [typeFilter, setTypeFilter] = useState<string | undefined>(undefined);
  
  // تحضير بارامترات الاستعلام
  const queryParams = new URLSearchParams();
  if (projectId) queryParams.append("projectId", projectId.toString());
  if (typeFilter && typeFilter !== "all") queryParams.append("type", typeFilter);
  if (fromDate) queryParams.append("fromDate", format(fromDate, "yyyy-MM-dd"));
  if (toDate) queryParams.append("toDate", format(toDate, "yyyy-MM-dd"));
  
  // استعلام عناصر التدفق النقدي
  const { data: cashFlowItems = [], isLoading } = useQuery({
    queryKey: ["/api/cash-flow", projectId, typeFilter, fromDate?.toISOString(), toDate?.toISOString()],
    enabled: !!projectId,
  });

  // استعلام معلومات المشاريع
  const { data: projects = [] } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000 * 5, // 5 دقائق
  });

  // استعلام توقعات التدفق النقدي
  const { data: cashFlowProjection = {}, isLoading: projectionLoading } = useQuery({
    queryKey: ["/api/cash-flow-projection", projectId, projectionMonths],
    enabled: !!projectId,
  });

  // نموذج إضافة عنصر تدفق نقدي جديد
  const addForm = useForm<CashFlowFormValues>({
    resolver: zodResolver(cashFlowFormSchema),
    defaultValues: {
      projectId: projectId || 0,
      type: "",
      category: "",
      expectedDate: new Date(),
      expectedAmount: 0,
      probability: 100,
      description: "",
      status: "expected",
      notes: "",
      createdBy: 1, // افتراضي
    },
  });

  // نموذج تعديل عنصر تدفق نقدي
  const editForm = useForm<CashFlowFormValues>({
    resolver: zodResolver(cashFlowFormSchema),
    defaultValues: {
      projectId: projectId || 0,
      type: "",
      category: "",
      expectedDate: new Date(),
      expectedAmount: 0,
      probability: 100,
      description: "",
      status: "expected",
      notes: "",
      createdBy: 1, // افتراضي
    },
  });

  // mutation لإضافة عنصر تدفق نقدي
  const addCashFlowMutation = useMutation({
    mutationFn: async (data: CashFlowFormValues) => {
      const formattedData = {
        ...data,
        expectedDate: format(data.expectedDate, "yyyy-MM-dd"), // تنسيق التاريخ
      };
      const response = await apiRequest("POST", "/api/cash-flow", formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تمت الإضافة",
        description: "تم إضافة عنصر التدفق النقدي بنجاح",
      });
      setIsAddDialogOpen(false);
      addForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow-projection"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الإضافة",
        description: error.message || "حدث خطأ أثناء إضافة عنصر التدفق النقدي",
        variant: "destructive",
      });
    },
  });

  // mutation لتعديل عنصر تدفق نقدي
  const updateCashFlowMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: CashFlowFormValues }) => {
      const formattedData = {
        ...data,
        expectedDate: format(data.expectedDate, "yyyy-MM-dd"), // تنسيق التاريخ
      };
      const response = await apiRequest("PATCH", `/api/cash-flow/${id}`, formattedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم التعديل",
        description: "تم تعديل عنصر التدفق النقدي بنجاح",
      });
      setIsEditDialogOpen(false);
      editForm.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow-projection"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في التعديل",
        description: error.message || "حدث خطأ أثناء تعديل عنصر التدفق النقدي",
        variant: "destructive",
      });
    },
  });

  // mutation لحذف عنصر تدفق نقدي
  const deleteCashFlowMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/cash-flow/${id}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "تم الحذف",
        description: "تم حذف عنصر التدفق النقدي بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cash-flow-projection"] });
    },
    onError: (error: any) => {
      toast({
        title: "خطأ في الحذف",
        description: error.message || "حدث خطأ أثناء حذف عنصر التدفق النقدي",
        variant: "destructive",
      });
    },
  });

  // تقديم نموذج إضافة عنصر تدفق نقدي
  const onAddSubmit = (data: CashFlowFormValues) => {
    addCashFlowMutation.mutate(data);
  };

  // تقديم نموذج تعديل عنصر تدفق نقدي
  const onEditSubmit = (data: CashFlowFormValues) => {
    if (selectedCashFlow) {
      updateCashFlowMutation.mutate({ id: selectedCashFlow.id, data });
    }
  };

  // فتح مربع حوار التعديل وملء البيانات
  const handleEdit = (cashFlow: any) => {
    setSelectedCashFlow(cashFlow);
    editForm.reset({
      projectId: cashFlow.projectId,
      type: cashFlow.type,
      category: cashFlow.category,
      expectedDate: parseISO(cashFlow.expectedDate),
      expectedAmount: cashFlow.expectedAmount,
      probability: cashFlow.probability,
      description: cashFlow.description,
      status: cashFlow.status,
      notes: cashFlow.notes || "",
      createdBy: cashFlow.createdBy,
    });
    setIsEditDialogOpen(true);
  };

  // حذف عنصر تدفق نقدي مع تأكيد
  const handleDelete = (id: number) => {
    if (confirm("هل أنت متأكد من حذف هذا العنصر؟")) {
      deleteCashFlowMutation.mutate(id);
    }
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA') + ' ريال';
  };

  // الحصول على اسم المشروع من المعرف
  const getProjectName = (projectId: number) => {
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تنسيق التاريخ
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    try {
      return format(parseISO(dateString), 'dd MMM yyyy', { locale: ar });
    } catch (error) {
      return dateString;
    }
  };

  // تحديد لون النوع (إيراد/مصروف)
  const getTypeColor = (type: string) => {
    switch (type?.toLowerCase()) {
      case 'income':
      case 'إيراد':
        return 'bg-green-100 text-green-800';
      case 'expense':
      case 'مصروف':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // تحديد لون الحالة
  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'realized':
      case 'محقق':
        return 'bg-green-100 text-green-800';
      case 'expected':
      case 'متوقع':
        return 'bg-blue-100 text-blue-800';
      case 'canceled':
      case 'ملغي':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // إعادة تعيين التصفية
  const resetFilters = () => {
    setTypeFilter(undefined);
    setFromDate(undefined);
    setToDate(undefined);
  };

  // تحضير بيانات التوقعات للرسم البياني
  const prepareChartData = () => {
    if (!cashFlowProjection || !cashFlowProjection.monthlyProjections) {
      return [];
    }

    return cashFlowProjection.monthlyProjections.map((month: any) => ({
      name: month.monthLabel,
      إيرادات: month.income,
      مصروفات: month.expenses,
      صافي: month.netCashFlow,
      رصيد_متراكم: month.runningBalance,
    }));
  };

  // بيانات الرسم البياني
  const chartData = prepareChartData();

  return (
    <div>
      {/* خلاصة التدفق النقدي */}
      {projectId && cashFlowProjection && !projectionLoading && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                إجمالي الإيرادات المتوقعة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <TrendingUp className="w-5 h-5 text-green-500 ml-2" />
                <span className="text-2xl font-bold text-green-600">
                  {formatCurrency(cashFlowProjection.totalIncome || 0)}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                إجمالي المصروفات المتوقعة
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <TrendingDown className="w-5 h-5 text-red-500 ml-2" />
                <span className="text-2xl font-bold text-red-600">
                  {formatCurrency(cashFlowProjection.totalExpenses || 0)}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                صافي التدفق النقدي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <ArrowLeftRight className="w-5 h-5 text-blue-500 ml-2" />
                <span className={`text-2xl font-bold ${(cashFlowProjection.netCashFlow || 0) >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                  {formatCurrency(cashFlowProjection.netCashFlow || 0)}
                </span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                الرصيد المتوقع (بعد {projectionMonths} أشهر)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <DollarSign className="w-5 h-5 text-purple-500 ml-2" />
                <span className={`text-2xl font-bold ${(cashFlowProjection.endingBalance || 0) >= 0 ? 'text-purple-600' : 'text-red-600'}`}>
                  {formatCurrency(cashFlowProjection.endingBalance || 0)}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* رسم بياني للتدفق النقدي المتوقع */}
      {projectId && chartData.length > 0 && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>توقعات التدفق النقدي</CardTitle>
            <CardDescription>توقعات الإيرادات والمصروفات والرصيد التراكمي</CardDescription>
            <div className="flex justify-end items-center gap-2 mt-2">
              <Label>فترة التوقع:</Label>
              <Select
                value={projectionMonths.toString()}
                onValueChange={(value) => setProjectionMonths(parseInt(value))}
              >
                <SelectTrigger className="w-24">
                  <SelectValue placeholder="6 أشهر" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 أشهر</SelectItem>
                  <SelectItem value="6">6 أشهر</SelectItem>
                  <SelectItem value="12">12 شهر</SelectItem>
                  <SelectItem value="24">24 شهر</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="إيرادات" fill="#10b981" />
                <Bar dataKey="مصروفات" fill="#ef4444" />
                <Line type="monotone" dataKey="صافي" stroke="#3b82f6" />
                <Line type="monotone" dataKey="رصيد_متراكم" stroke="#8b5cf6" strokeWidth={2} />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* شريط الأدوات والتصفية */}
      <div className="flex flex-col md:flex-row gap-4 mb-6 justify-between">
        <div className="flex flex-col md:flex-row gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="نوع التدفق النقدي" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الأنواع</SelectItem>
              <SelectItem value="income">إيرادات</SelectItem>
              <SelectItem value="expense">مصروفات</SelectItem>
            </SelectContent>
          </Select>

          <div className="w-full md:w-48">
            <DatePicker
              date={fromDate}
              setDate={setFromDate}
              placeholder="من تاريخ"
            />
          </div>

          <div className="w-full md:w-48">
            <DatePicker
              date={toDate}
              setDate={setToDate}
              placeholder="إلى تاريخ"
            />
          </div>

          <Button 
            variant="outline" 
            onClick={resetFilters}
            className="h-10"
            disabled={!typeFilter && !fromDate && !toDate}
          >
            <RefreshCw className="ml-2 h-4 w-4" />
            إعادة تعيين
          </Button>
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="h-10">
              <Plus className="ml-2 h-4 w-4" /> إضافة تدفق نقدي
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>إضافة عنصر تدفق نقدي جديد</DialogTitle>
              <DialogDescription>
                أدخل تفاصيل التدفق النقدي المتوقع
              </DialogDescription>
            </DialogHeader>

            <Form {...addForm}>
              <form onSubmit={addForm.handleSubmit(onAddSubmit)} className="space-y-4">
                <FormField
                  control={addForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع التدفق</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر نوع التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="income">إيراد</SelectItem>
                          <SelectItem value="expense">مصروف</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>التصنيف</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر تصنيف التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="materials">مواد</SelectItem>
                          <SelectItem value="labor">أجور عمال</SelectItem>
                          <SelectItem value="equipment">معدات</SelectItem>
                          <SelectItem value="payments">دفعات مستخلص</SelectItem>
                          <SelectItem value="subcontractors">مقاولي الباطن</SelectItem>
                          <SelectItem value="administrative">مصاريف إدارية</SelectItem>
                          <SelectItem value="operational">مصاريف تشغيلية</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="expectedDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>التاريخ المتوقع</FormLabel>
                      <FormControl>
                        <DatePicker
                          date={field.value}
                          setDate={field.onChange}
                          placeholder="اختر التاريخ المتوقع"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="expectedAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المبلغ المتوقع</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل المبلغ المتوقع" 
                          {...field} 
                          min={0}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="probability"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>احتمالية التحقق (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل نسبة احتمالية التحقق" 
                          {...field} 
                          min={0}
                          max={100}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الوصف</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="أدخل وصفاً مفصلاً" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحالة</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر حالة التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="expected">متوقع</SelectItem>
                          <SelectItem value="realized">محقق</SelectItem>
                          <SelectItem value="canceled">ملغي</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={addForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أي ملاحظات إضافية" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={addCashFlowMutation.isPending}
                  >
                    {addCashFlowMutation.isPending ? "جاري الإضافة..." : "إضافة"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>تعديل عنصر التدفق النقدي</DialogTitle>
              <DialogDescription>
                قم بتعديل تفاصيل التدفق النقدي
              </DialogDescription>
            </DialogHeader>

            <Form {...editForm}>
              <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
                <FormField
                  control={editForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>نوع التدفق</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر نوع التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="income">إيراد</SelectItem>
                          <SelectItem value="expense">مصروف</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>التصنيف</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر تصنيف التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="materials">مواد</SelectItem>
                          <SelectItem value="labor">أجور عمال</SelectItem>
                          <SelectItem value="equipment">معدات</SelectItem>
                          <SelectItem value="payments">دفعات مستخلص</SelectItem>
                          <SelectItem value="subcontractors">مقاولي الباطن</SelectItem>
                          <SelectItem value="administrative">مصاريف إدارية</SelectItem>
                          <SelectItem value="operational">مصاريف تشغيلية</SelectItem>
                          <SelectItem value="other">أخرى</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="expectedDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>التاريخ المتوقع</FormLabel>
                      <FormControl>
                        <DatePicker
                          date={field.value}
                          setDate={field.onChange}
                          placeholder="اختر التاريخ المتوقع"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="expectedAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>المبلغ المتوقع</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل المبلغ المتوقع" 
                          {...field} 
                          min={0}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="probability"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>احتمالية التحقق (%)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="أدخل نسبة احتمالية التحقق" 
                          {...field} 
                          min={0}
                          max={100}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الوصف</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="أدخل وصفاً مفصلاً" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>الحالة</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="اختر حالة التدفق" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="expected">متوقع</SelectItem>
                          <SelectItem value="realized">محقق</SelectItem>
                          <SelectItem value="canceled">ملغي</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={editForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ملاحظات (اختياري)</FormLabel>
                      <FormControl>
                        <Input placeholder="أي ملاحظات إضافية" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={updateCashFlowMutation.isPending}
                  >
                    {updateCashFlowMutation.isPending ? "جاري التعديل..." : "تعديل"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* تنبيهات السيولة النقدية */}
      {cashFlowProjection && cashFlowProjection.alerts && cashFlowProjection.alerts.length > 0 && (
        <Card className="mb-6 border-yellow-300 bg-yellow-50">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center text-yellow-800">
              <AlertTriangle className="ml-2 h-5 w-5" />
              تنبيهات السيولة النقدية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {cashFlowProjection.alerts.map((alert: string, index: number) => (
                <li key={index} className="flex items-start">
                  <span className="ml-2 text-yellow-600">•</span>
                  <span className="text-yellow-800">{alert}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* قائمة عناصر التدفق النقدي */}
      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : cashFlowItems.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border">
          <ArrowLeftRight className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h3 className="font-medium text-lg mb-2">لا توجد عناصر تدفق نقدي</h3>
          <p className="text-muted-foreground mb-4">
            لم يتم إضافة أي توقعات للتدفق النقدي حتى الآن. يمكنك إضافة تدفق نقدي جديد.
          </p>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>إضافة تدفق نقدي</Button>
            </DialogTrigger>
          </Dialog>
        </div>
      ) : (
        <div className="overflow-x-auto border rounded-lg">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>الرقم</TableHead>
                <TableHead>التاريخ المتوقع</TableHead>
                <TableHead>النوع</TableHead>
                <TableHead>التصنيف</TableHead>
                <TableHead>المبلغ المتوقع</TableHead>
                <TableHead>احتمالية التحقق</TableHead>
                <TableHead>الوصف</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cashFlowItems.map((item: any) => (
                <TableRow key={item.id}>
                  <TableCell>{item.id}</TableCell>
                  <TableCell>{formatDate(item.expectedDate)}</TableCell>
                  <TableCell>
                    <Badge className={`${getTypeColor(item.type)}`}>
                      {item.type === 'income' ? 'إيراد' : 'مصروف'}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.category}</TableCell>
                  <TableCell className={item.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                    {formatCurrency(item.expectedAmount)}
                  </TableCell>
                  <TableCell>
                    {item.probability}%
                  </TableCell>
                  <TableCell className="max-w-xs truncate">
                    {item.description}
                  </TableCell>
                  <TableCell>
                    <Badge className={`${getStatusColor(item.status)}`}>
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          >
                            <circle cx="12" cy="12" r="1" />
                            <circle cx="12" cy="5" r="1" />
                            <circle cx="12" cy="19" r="1" />
                          </svg>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem 
                          className="flex items-center gap-2"
                          onClick={() => handleEdit(item)}
                        >
                          <Edit className="h-4 w-4" />
                          <span>تعديل</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          className="flex items-center gap-2 text-red-600"
                          onClick={() => handleDelete(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>حذف</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default CashFlowManager;