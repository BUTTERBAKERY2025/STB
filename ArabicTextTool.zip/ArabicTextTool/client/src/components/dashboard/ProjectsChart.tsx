import { Card, CardContent } from "@/components/ui/card";
import { useTheme } from "@/components/ui/theme-provider";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Download } from "lucide-react";

interface ProjectsChartProps {
  data: {
    name: string;
    planned: number;
    actual: number;
    month: string;
  }[];
}

const ProjectsChart = ({ data }: ProjectsChartProps) => {
  const { theme } = useTheme();
  const [period, setPeriod] = useState("monthly");

  const isDark = theme === "dark";
  const textColor = isDark ? "#f3f4f6" : "#1f2937";
  const gridColor = isDark ? "#374151" : "#e5e7eb";

  return (
    <Card className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-lg dark:text-white">تقدم المشاريع</h2>
          <div className="flex items-center space-x-2 space-x-reverse">
            <button className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
              <Download className="h-5 w-5" />
            </button>
            <select 
              className="text-sm bg-gray-100 dark:bg-gray-700 border-0 rounded p-1 dark:text-gray-200"
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
            >
              <option value="monthly">شهري</option>
              <option value="quarterly">ربع سنوي</option>
              <option value="yearly">سنوي</option>
            </select>
          </div>
        </div>
        
        <div className="h-64 md:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis 
                dataKey="month" 
                stroke={textColor} 
                tick={{ fill: textColor }}
              />
              <YAxis 
                stroke={textColor}
                tick={{ fill: textColor }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: isDark ? "#374151" : "#ffffff",
                  color: textColor,
                  border: `1px solid ${gridColor}`,
                  borderRadius: "0.5rem"
                }}
              />
              <Legend
                wrapperStyle={{
                  color: textColor
                }}
              />
              <Bar 
                name="المخطط"
                dataKey="planned" 
                fill="hsl(var(--primary))" 
                radius={[4, 4, 0, 0]}
              />
              <Bar 
                name="الفعلي"
                dataKey="actual" 
                fill="hsl(var(--accent))" 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectsChart;
