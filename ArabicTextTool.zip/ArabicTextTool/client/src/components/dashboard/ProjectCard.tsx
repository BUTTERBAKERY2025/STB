import { Card } from "@/components/ui/card";
import { MoreHorizontal } from "lucide-react";
import TeamMember from "./TeamMember";
import { getStatusBadgeColor, getStatusText } from "@/lib/utils";

interface TeamMemberData {
  id: number;
  avatar: string;
  name: string;
}

interface ProjectCardProps {
  id: number;
  name: string;
  description: string;
  location: string;
  duration: number;
  progress: number;
  status: string;
  imageUrl: string;
  team: TeamMemberData[];
  extraTeamCount?: number;
}

const ProjectCard = ({
  id,
  name,
  description,
  location,
  duration,
  progress,
  status,
  imageUrl,
  team,
  extraTeamCount = 0,
}: ProjectCardProps) => {
  const progressColor = 
    progress >= 80 ? "text-green-600" : 
    progress >= 60 ? "text-primary" : 
    progress >= 40 ? "text-yellow-600" : 
    "text-red-600";

  const progressBgColor = 
    progress >= 80 ? "bg-green-600" : 
    progress >= 60 ? "bg-primary" : 
    progress >= 40 ? "bg-yellow-600" : 
    "bg-red-600";

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
      <div className="relative h-40">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover"
        />
        <div className={`absolute top-2 right-2 ${getStatusBadgeColor(status)} text-white text-xs rounded-full px-2 py-1`}>
          {getStatusText(status)}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2 dark:text-white">{name}</h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">{description}</p>
        
        <div className="flex justify-between mb-3">
          <div className="text-sm">
            <span className="text-gray-500 dark:text-gray-400">الموقع:</span>
            <span className="font-medium dark:text-gray-200 mr-1">{location}</span>
          </div>
          <div className="text-sm">
            <span className="text-gray-500 dark:text-gray-400">المدة:</span>
            <span className="font-medium dark:text-gray-200 mr-1">{duration} أشهر</span>
          </div>
        </div>
        
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1 text-sm">
            <span className="dark:text-gray-300">نسبة الإنجاز</span>
            <span className={progressColor}>{progress}%</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div className={`${progressBgColor} h-2 rounded-full`} style={{ width: `${progress}%` }} />
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <div className="flex -space-x-2 space-x-reverse">
            {team.map((member) => (
              <TeamMember 
                key={member.id}
                avatar={member.avatar}
                name={member.name}
              />
            ))}
            {extraTeamCount > 0 && (
              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center text-xs font-medium dark:text-gray-200">
                +{extraTeamCount}
              </div>
            )}
          </div>
          <button className="text-primary hover:bg-blue-50 dark:hover:bg-blue-900/20 p-2 rounded-full">
            <MoreHorizontal className="h-5 w-5" />
          </button>
        </div>
      </div>
    </Card>
  );
};

export default ProjectCard;
