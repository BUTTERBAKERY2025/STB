import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DeadlineItem {
  id: number;
  day: string;
  title: string;
  project: string;
  timeLeft: string;
  isUrgent: boolean;
}

interface DeadlinesListProps {
  deadlines: DeadlineItem[];
  onViewAllClick?: () => void;
}

const DeadlinesList = ({ deadlines, onViewAllClick }: DeadlinesListProps) => {
  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-lg dark:text-white">المواعيد القادمة</h2>
          <a 
            href="#"
            className="text-primary hover:underline text-sm"
            onClick={(e) => {
              e.preventDefault();
              onViewAllClick?.();
            }}
          >
            عرض التقويم
          </a>
        </div>
        
        <div className="space-y-3">
          {deadlines.map((deadline) => (
            <div 
              key={deadline.id}
              className={`flex items-start p-3 ${deadline.isUrgent ? 'bg-red-50 dark:bg-red-900/20 border-r-4 border-error' : 'bg-gray-50 dark:bg-gray-700/30 border-r-4 border-gray-400 dark:border-gray-500'} rounded-lg`}
            >
              <div className="ml-3">
                <div 
                  className={`w-10 h-10 ${deadline.isUrgent ? 'bg-red-100 dark:bg-red-900/30' : 'bg-gray-100 dark:bg-gray-700'} rounded-lg flex items-center justify-center`}
                >
                  <span className={`font-bold ${deadline.isUrgent ? 'text-error' : 'text-gray-600 dark:text-gray-300'}`}>
                    {deadline.day}
                  </span>
                </div>
              </div>
              <div>
                <h4 className={`font-medium ${deadline.isUrgent ? 'text-error' : 'dark:text-white'}`}>
                  {deadline.title}
                </h4>
                <p className="text-sm text-gray-700 dark:text-gray-300">{deadline.project}</p>
                <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
                  <span className="ml-1">⏰</span>
                  <span>{deadline.timeLeft}</span>
                </div>
              </div>
            </div>
          ))}
          
          <Button
            variant="ghost"
            className="w-full py-2 text-primary hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-md text-sm font-medium mt-2"
            onClick={onViewAllClick}
          >
            عرض جميع المواعيد
            <ArrowLeft className="mr-1 h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DeadlinesList;
