import { Card, CardContent } from "@/components/ui/card";
import { MoreVertical } from "lucide-react";

interface ProjectData {
  id: number;
  name: string;
  progress: number;
  progressColor: string;
}

interface ProjectProgressProps {
  projects: ProjectData[];
}

const ProjectProgress = ({ projects }: ProjectProgressProps) => {
  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-lg dark:text-white">نسب إنجاز المشاريع</h2>
          <button className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary">
            <MoreVertical className="h-5 w-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          {projects.map((project) => (
            <div key={project.id}>
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium dark:text-white">{project.name}</span>
                <span className={project.progressColor}>{project.progress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                <div 
                  className={`${project.progressColor.replace('text-', 'bg-')} h-2.5 rounded-full`} 
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ProjectProgress;
