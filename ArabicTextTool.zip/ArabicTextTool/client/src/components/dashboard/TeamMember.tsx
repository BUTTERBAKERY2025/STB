import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface TeamMemberProps {
  avatar: string;
  name: string;
}

const TeamMember = ({ avatar, name }: TeamMemberProps) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Avatar className="w-8 h-8 border-2 border-white dark:border-gray-800">
            <AvatarImage src={avatar} alt={name} />
          </Avatar>
        </TooltipTrigger>
        <TooltipContent>
          <p>{name}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default TeamMember;
