import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatisticCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  iconColor: string;
  iconBgColor: string;
  changeValue?: string | number;
  changeText?: string;
  changeDirection?: "up" | "down" | "neutral";
}

const StatisticCard = ({
  title,
  value,
  icon: Icon,
  iconColor,
  iconBgColor,
  changeValue,
  changeText,
  changeDirection = "neutral",
}: StatisticCardProps) => {
  const getChangeColor = () => {
    switch (changeDirection) {
      case "up":
        return "text-green-600 dark:text-green-500";
      case "down":
        return "text-red-600 dark:text-red-500";
      default:
        return "text-yellow-600 dark:text-yellow-500";
    }
  };

  const getChangeIcon = () => {
    switch (changeDirection) {
      case "up":
        return "↑";
      case "down":
        return "↓";
      default:
        return "—";
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4">
      <div className="flex items-center">
        <div className={`rounded-full ${iconBgColor} p-3 ml-3`}>
          <Icon className={`${iconColor} text-xl`} />
        </div>
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
          <h3 className="text-2xl font-bold dark:text-white">{value}</h3>
        </div>
      </div>
      {(changeValue || changeText) && (
        <div className="mt-4 flex items-center text-sm">
          <span className={`flex items-center ${getChangeColor()}`}>
            <span className="ml-1">{getChangeIcon()}</span>
            {changeValue && <span>{changeValue}</span>}
          </span>
          {changeText && <span className="text-gray-400 dark:text-gray-500 mr-2">{changeText}</span>}
        </div>
      )}
    </Card>
  );
};

export default StatisticCard;
