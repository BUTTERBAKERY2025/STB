import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw } from "lucide-react";

interface ActivityItem {
  id: number;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  title: string;
  category: string;
  categoryBgColor: string;
  categoryColor: string;
  description: string;
  time: string;
  isLastItem?: boolean;
}

interface ActivityFeedProps {
  activities: ActivityItem[];
  onRefresh?: () => void;
}

const ActivityFeed = ({ activities, onRefresh }: ActivityFeedProps) => {
  return (
    <Card className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-lg dark:text-white">آخر الأنشطة</h2>
          <button 
            className="text-gray-500 dark:text-gray-400 hover:text-primary dark:hover:text-primary" 
            onClick={onRefresh}
          >
            <RefreshCw className="h-5 w-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          {activities.map((activity) => (
            <div className="flex" key={activity.id}>
              <div className="ml-4 flex flex-col items-center">
                <div className={`h-8 w-8 rounded-full ${activity.iconBgColor} flex items-center justify-center`}>
                  <span className={`${activity.iconColor} text-lg`}>{activity.icon}</span>
                </div>
                {!activity.isLastItem && <div className="h-full w-0.5 bg-gray-200 dark:bg-gray-700 mt-2"></div>}
              </div>
              <div>
                <div className="flex items-center">
                  <h4 className="font-medium dark:text-white">{activity.title}</h4>
                  <span className={`mr-2 ${activity.categoryBgColor} ${activity.categoryColor} text-xs rounded-full px-2 py-1`}>
                    {activity.category}
                  </span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">{activity.description}</p>
                <span className="text-xs text-gray-500 dark:text-gray-400">{activity.time}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;
