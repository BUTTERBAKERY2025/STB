import { useState } from "react";
import { PlusIcon, Filter, Search, Phone, Mail, Check, X, Users, Briefcase, LinkIcon, Building, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useUsers, useProjects, useTeamByProject, useCreateTeamAssignment, useDeleteTeamAssignment } from "@/lib/data";
import { formatDate } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const Teams = () => {
  const { data: users = [], isLoading: isLoadingUsers } = useUsers();
  const { data: projects = [], isLoading: isLoadingProjects } = useProjects();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewTeamMemberDialog, setShowNewTeamMemberDialog] = useState(false);
  const [showTeamAssignmentDialog, setShowTeamAssignmentDialog] = useState(false);
  const [selectedProject, setSelectedProject] = useState<number | null>(null);
  const [selectedMember, setSelectedMember] = useState<number | null>(null);
  const [assignmentRole, setAssignmentRole] = useState<string>("member");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  
  const { data: teamAssignments = [], isLoading: isLoadingTeam } = useTeamByProject(selectedProject || 0);
  const { mutate: createAssignment, isPending: isCreatingAssignment } = useCreateTeamAssignment();
  const { mutate: deleteAssignment, isPending: isDeletingAssignment } = useDeleteTeamAssignment();

  // Sample team data
  const teamMembers = [
    {
      id: 1,
      fullName: "عبدالله العتيبي",
      role: "admin",
      email: "abdullah@stb.com",
      phone: "+966 50 123 4567",
      skills: ["إدارة", "تخطيط", "مالية"],
      avatar: "https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=120&h=120&fit=crop&crop=faces",
      projectsCount: 12,
      active: true
    },
    {
      id: 2,
      fullName: "أحمد محمد",
      role: "engineer",
      email: "ahmed@stb.com",
      phone: "+966 55 765 4321",
      skills: ["كهرباء", "تخطيط", "تصميم"],
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=50&h=50&fit=crop",
      projectsCount: 5,
      active: true
    },
    {
      id: 3,
      fullName: "سارة العلي",
      role: "supervisor",
      email: "sara@stb.com",
      phone: "+966 54 321 7654",
      skills: ["إشراف", "تقارير", "جودة"],
      avatar: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=50&h=50&fit=crop",
      projectsCount: 8,
      active: true
    },
    {
      id: 4,
      fullName: "خالد عبدالله",
      role: "worker",
      email: "khalid@stb.com",
      phone: "+966 58 987 6543",
      skills: ["إنشاءات", "حفر", "تركيبات"],
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop",
      projectsCount: 3,
      active: true
    },
    {
      id: 5,
      fullName: "نورة الغامدي",
      role: "engineer",
      email: "noura@stb.com",
      phone: "+966 52 345 6789",
      skills: ["اتصالات", "تصميم", "تطوير"],
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=50&h=50&fit=crop",
      projectsCount: 4,
      active: false
    }
  ];

  // Filter team members based on search query
  const filteredTeamMembers = teamMembers.filter(member => 
    member.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const getRoleBadge = (role: string) => {
    switch (role) {
      case "admin":
        return <Badge className="bg-purple-500">مدير</Badge>;
      case "engineer":
        return <Badge className="bg-primary">مهندس</Badge>;
      case "supervisor":
        return <Badge className="bg-green-500">مشرف</Badge>;
      case "worker":
        return <Badge className="bg-yellow-500">عامل</Badge>;
      default:
        return <Badge className="bg-gray-500">{role}</Badge>;
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case "admin": return "مدير";
      case "engineer": return "مهندس";
      case "supervisor": return "مشرف";
      case "worker": return "عامل";
      default: return role;
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(part => part.charAt(0)).join('');
  };

  if (isLoadingUsers || isLoadingProjects) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  const handleTeamAssignment = () => {
    if (!selectedProject || !selectedMember) return;

    const assignment = {
      projectId: selectedProject,
      userId: selectedMember,
      role: assignmentRole,
      startDate: startDate ? new Date(startDate) : new Date(),
      endDate: endDate ? new Date(endDate) : undefined,
    };

    createAssignment(assignment, {
      onSuccess: () => {
        setShowTeamAssignmentDialog(false);
        // Reset form
        setSelectedMember(null);
        setAssignmentRole("member");
        setStartDate("");
        setEndDate("");
      }
    });
  };

  const handleRemoveTeamMember = (assignmentId: number) => {
    if (!selectedProject) return;
    
    if (confirm("هل أنت متأكد من إزالة هذا العضو من الفريق؟")) {
      deleteAssignment({
        id: assignmentId,
        projectId: selectedProject
      });
    }
  };

  const getMemberById = (userId: number) => {
    return teamMembers.find(member => member.id === userId) || null;
  };

  return (
    <>
      <div className="flex flex-col space-y-6">
        {/* Header with title and actions */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold dark:text-white">إدارة الفرق</h1>
          <div className="flex space-x-2 space-x-reverse">
            <Dialog open={showTeamAssignmentDialog} onOpenChange={setShowTeamAssignmentDialog}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="flex items-center gap-1">
                  <LinkIcon size={16} />
                  <span>تعيين فريق</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>تعيين عضو فريق للمشروع</DialogTitle>
                  <DialogDescription>
                    قم بتعيين عضو فريق لمشروع محدد مع تحديد دوره ومدة عمله.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project" className="text-right">
                      المشروع
                    </Label>
                    <Select value={selectedProject?.toString() || ""} onValueChange={(value) => setSelectedProject(parseInt(value))}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="member" className="text-right">
                      عضو الفريق
                    </Label>
                    <Select value={selectedMember?.toString() || ""} onValueChange={(value) => setSelectedMember(parseInt(value))}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر عضو الفريق" />
                      </SelectTrigger>
                      <SelectContent>
                        {teamMembers.map((member) => (
                          <SelectItem key={member.id} value={member.id.toString()}>
                            {member.fullName} - {getRoleText(member.role)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="assignmentRole" className="text-right">
                      الدور في المشروع
                    </Label>
                    <Select value={assignmentRole} onValueChange={setAssignmentRole}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الدور" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lead">قائد المشروع</SelectItem>
                        <SelectItem value="member">عضو فريق</SelectItem>
                        <SelectItem value="consultant">استشاري</SelectItem>
                        <SelectItem value="supervisor">مشرف</SelectItem>
                        <SelectItem value="contractor">مقاول</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="startDate" className="text-right">
                      تاريخ البدء
                    </Label>
                    <Input 
                      id="startDate" 
                      type="date" 
                      className="col-span-3"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="endDate" className="text-right">
                      تاريخ الانتهاء
                    </Label>
                    <Input 
                      id="endDate" 
                      type="date" 
                      className="col-span-3"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowTeamAssignmentDialog(false)}>إلغاء</Button>
                  <Button 
                    onClick={handleTeamAssignment} 
                    disabled={!selectedProject || !selectedMember || isCreatingAssignment}
                  >
                    {isCreatingAssignment ? "جاري التعيين..." : "تعيين للمشروع"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Filter size={16} />
              <span>تصفية</span>
            </Button>
            <Dialog open={showNewTeamMemberDialog} onOpenChange={setShowNewTeamMemberDialog}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-1">
                  <PlusIcon size={16} />
                  <span>عضو جديد</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>إضافة عضو فريق جديد</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      الاسم الكامل
                    </Label>
                    <Input id="name" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="role" className="text-right">
                      الدور
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الدور" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">مدير</SelectItem>
                        <SelectItem value="engineer">مهندس</SelectItem>
                        <SelectItem value="supervisor">مشرف</SelectItem>
                        <SelectItem value="worker">عامل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="email" className="text-right">
                      البريد الإلكتروني
                    </Label>
                    <Input id="email" type="email" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="phone" className="text-right">
                      رقم الهاتف
                    </Label>
                    <Input id="phone" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="skills" className="text-right">
                      المهارات
                    </Label>
                    <Input id="skills" placeholder="فصل بفواصل" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="avatar" className="text-right">
                      الصورة
                    </Label>
                    <Input id="avatar" type="file" className="col-span-3" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewTeamMemberDialog(false)}>إلغاء</Button>
                  <Button type="submit" onClick={() => setShowNewTeamMemberDialog(false)}>حفظ</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="ابحث عن اسم العضو أو الدور أو المهارات..."
              className="pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Tabs defaultValue="all" className="w-full sm:w-auto">
            <TabsList>
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="admin">مدراء</TabsTrigger>
              <TabsTrigger value="engineer">مهندسون</TabsTrigger>
              <TabsTrigger value="supervisor">مشرفون</TabsTrigger>
              <TabsTrigger value="worker">عمال</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTeamMembers.map(member => (
            <Card key={member.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Avatar className="h-12 w-12 ml-4">
                    <AvatarImage src={member.avatar} alt={member.fullName} />
                    <AvatarFallback>{getInitials(member.fullName)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{member.fullName}</CardTitle>
                    <div className="flex items-center mt-1">
                      {getRoleBadge(member.role)}
                      <span className={`mr-2 flex items-center text-xs ${member.active ? 'text-green-500' : 'text-gray-400'}`}>
                        {member.active ? <Check className="h-3 w-3 ml-1" /> : <X className="h-3 w-3 ml-1" />}
                        {member.active ? 'نشط' : 'غير نشط'}
                      </span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 ml-2 text-gray-500 dark:text-gray-400" />
                    <span>{member.email}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 ml-2 text-gray-500 dark:text-gray-400" />
                    <span>{member.phone}</span>
                  </div>
                  <div className="pt-1">
                    <span className="text-gray-500 dark:text-gray-400 mb-1 block">المهارات:</span>
                    <div className="flex flex-wrap gap-1">
                      {member.skills.map((skill, index) => (
                        <Badge key={index} variant="outline" className="font-normal">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="pt-1">
                    <span className="text-gray-500 dark:text-gray-400 mb-1 block">
                      المشاركة في {member.projectsCount} مشاريع
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty state */}
        {filteredTeamMembers.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium text-gray-600 dark:text-gray-300">لا يوجد أعضاء فريق مطابقين للبحث</h3>
            <p className="text-gray-500 mt-2">حاول تغيير معايير البحث أو إضافة عضو جديد</p>
          </div>
        )}
        
        {/* Project Team Section */}
        <Separator className="my-4" />
        <div className="mt-6 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-semibold">فرق المشاريع</h2>
              <p className="text-sm text-muted-foreground">عرض أعضاء الفرق المعينين للمشاريع</p>
            </div>
            <div>
              <Select value={selectedProject?.toString() || ""} onValueChange={(value) => setSelectedProject(value ? parseInt(value) : null)}>
                <SelectTrigger className="w-[240px]">
                  <SelectValue placeholder="اختر المشروع لعرض الفريق" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {selectedProject ? (
            isLoadingTeam ? (
              <div className="text-center py-10">جاري تحميل بيانات الفريق...</div>
            ) : teamAssignments.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-10 text-center">
                  <Users className="h-12 w-12 text-gray-300 mb-4" />
                  <h3 className="text-xl font-medium">لم يتم تعيين أعضاء فريق لهذا المشروع</h3>
                  <p className="text-muted-foreground mt-2 mb-6">
                    قم بتعيين أعضاء فريق للمشروع لعرضهم هنا
                  </p>
                  <Button
                    onClick={() => setShowTeamAssignmentDialog(true)}
                  >
                    <PlusIcon className="h-4 w-4 ml-2" />
                    تعيين عضو الآن
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Briefcase className="h-5 w-5 ml-2" />
                      الفريق المعين لـ: {projects.find(p => p.id === selectedProject)?.name}
                    </div>
                    <Button
                      size="sm"
                      onClick={() => setShowTeamAssignmentDialog(true)}
                    >
                      <PlusIcon className="h-4 w-4 ml-1" />
                      إضافة عضو
                    </Button>
                  </CardTitle>
                  <CardDescription>
                    قائمة بأعضاء الفريق المعينين للمشروع المحدد مع أدوارهم وتواريخ عملهم
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>الاسم</TableHead>
                        <TableHead>الدور</TableHead>
                        <TableHead>تاريخ البدء</TableHead>
                        <TableHead>تاريخ الانتهاء</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {teamAssignments.map((assignment) => {
                        const member = getMemberById(assignment.userId);
                        return (
                          <TableRow key={assignment.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center">
                                <Avatar className="h-8 w-8 ml-2">
                                  <AvatarImage src={member?.avatar} />
                                  <AvatarFallback>{member ? getInitials(member.fullName) : "??"}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div>{member?.fullName || `عضو #${assignment.userId}`}</div>
                                  <div className="text-xs text-muted-foreground">{member?.email || ""}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge className={assignment.role === "lead" ? "bg-purple-500" : 
                                     assignment.role === "supervisor" ? "bg-green-500" : 
                                     assignment.role === "consultant" ? "bg-amber-500" : 
                                     assignment.role === "contractor" ? "bg-indigo-500" : "bg-blue-500"}>
                                {assignment.role === "lead" ? "قائد المشروع" : 
                                 assignment.role === "member" ? "عضو فريق" : 
                                 assignment.role === "supervisor" ? "مشرف" : 
                                 assignment.role === "consultant" ? "استشاري" : 
                                 assignment.role === "contractor" ? "مقاول" : assignment.role}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {assignment.startDate ? formatDate(new Date(assignment.startDate)) : "-"}
                            </TableCell>
                            <TableCell>
                              {assignment.endDate ? formatDate(new Date(assignment.endDate)) : "غير محدد"}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-500 hover:text-red-700 hover:bg-red-100"
                                onClick={() => handleRemoveTeamMember(assignment.id)}
                                disabled={isDeletingAssignment}
                              >
                                إزالة
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center p-10 text-center">
                <Building className="h-12 w-12 text-gray-300 mb-4" />
                <h3 className="text-xl font-medium">اختر مشروعًا لعرض الفريق المعين له</h3>
                <p className="text-muted-foreground mt-2">
                  حدد المشروع من القائمة المنسدلة لعرض أعضاء الفريق المعينين له
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </>
  );
};

export default Teams;
