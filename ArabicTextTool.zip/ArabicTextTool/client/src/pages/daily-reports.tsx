import { useState, useRef } from "react";
import { 
  Calendar, Clock, Filter, PlusIcon, File, FileText, RefreshCw, Download, 
  Printer, Search, AlertCircle, RotateCw, Eye, AlertTriangle, 
  CloudRain, Sun, Cloud, CloudOff 
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";

import { useProjects, useDailyReportsByProject, useCreateDailyReport, useCreateActivity } from "@/lib/data";
import { formatDate } from "@/lib/utils";
import { queryClient } from "@/lib/queryClient";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

import type { DailyReport, InsertDailyReport } from "@shared/schema";

// Icons for various weather conditions
const weatherIcons = {
  sunny: <Sun className="h-5 w-5 text-yellow-500" />,
  cloudy: <Cloud className="h-5 w-5 text-gray-500" />,
  rainy: <CloudRain className="h-5 w-5 text-blue-500" />,
  stormy: <AlertTriangle className="h-5 w-5 text-orange-500" />,
  other: <CloudOff className="h-5 w-5 text-gray-400" />
};

const DailyReports = () => {
  const { toast } = useToast();
  const [filterDateFrom, setFilterDateFrom] = useState<Date | undefined>(undefined);
  const [filterDateTo, setFilterDateTo] = useState<Date | undefined>(undefined);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [filterProjectId, setFilterProjectId] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [searchTerm, setSearchTerm] = useState("");
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showNewReportDialog, setShowNewReportDialog] = useState(false);
  const [showReportDetails, setShowReportDetails] = useState(false);
  const [selectedReport, setSelectedReport] = useState<DailyReport | null>(null);
  
  // Reference for PDF export
  const reportDetailRef = useRef<HTMLDivElement>(null);
  
  // Form data
  const [formData, setFormData] = useState({
    projectId: "",
    reportDate: new Date().toISOString().split('T')[0],
    workCompleted: "",
    workersPresent: "",
    hoursWorked: "",
    issues: "",
    equipmentUsed: "",
    weatherConditions: "sunny"
  });
  
  // Data fetching
  const { data: projects, isLoading: isLoadingProjects } = useProjects();
  const { 
    data: projectReports, 
    isLoading: isLoadingReports, 
    error: reportsError 
  } = useDailyReportsByProject(
    filterProjectId !== "all" ? parseInt(filterProjectId) : projects?.[0]?.id || 0
  );
  
  // Mutations
  const createDailyReport = useCreateDailyReport();
  const createActivity = useCreateActivity();
  
  // Helper functions
  const getProjectName = (projectId: number) => {
    const project = projects?.find(p => p.id === projectId);
    return project ? project.name : "مشروع غير معروف";
  };
  
  const resetForm = () => {
    setFormData({
      projectId: "",
      reportDate: new Date().toISOString().split('T')[0],
      workCompleted: "",
      workersPresent: "",
      hoursWorked: "",
      issues: "",
      equipmentUsed: "",
      weatherConditions: "sunny"
    });
  };
  
  // Event handlers
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleProjectChange = (value: string) => {
    setFormData(prev => ({ ...prev, projectId: value }));
  };
  
  const handleWeatherChange = (value: string) => {
    setFormData(prev => ({ ...prev, weatherConditions: value }));
  };
  
  const handleRefresh = () => {
    setIsRefreshing(true);
    queryClient.invalidateQueries({ 
      queryKey: [`/api/projects/${filterProjectId !== "all" ? filterProjectId : projects?.[0]?.id}/daily-reports`] 
    }).then(() => {
      setTimeout(() => setIsRefreshing(false), 500);
      toast({
        title: "تم تحديث البيانات",
        description: "تم تحديث قائمة التقارير اليومية بنجاح"
      });
    }).catch(() => {
      setIsRefreshing(false);
      toast({
        title: "خطأ في التحديث",
        description: "حدث خطأ أثناء محاولة تحديث البيانات",
        variant: "destructive"
      });
    });
  };
  
  const handleSubmit = () => {
    // Validate form
    if (!formData.projectId || !formData.reportDate || !formData.workCompleted || 
        !formData.workersPresent || !formData.hoursWorked) {
      toast({
        title: "معلومات ناقصة",
        description: "الرجاء ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }
    
    // Prepare data
    const reportData: InsertDailyReport = {
      projectId: parseInt(formData.projectId),
      reportDate: formData.reportDate,
      workCompleted: formData.workCompleted,
      workersPresent: parseInt(formData.workersPresent),
      hoursWorked: parseFloat(formData.hoursWorked),
      issues: formData.issues || null,
      equipmentUsed: formData.equipmentUsed.split(',').map(item => item.trim()),
      weatherConditions: formData.weatherConditions || null,
      submittedBy: 1 // Current user
    };
    
    // Submit data
    createDailyReport.mutate(reportData, {
      onSuccess: () => {
        toast({
          title: "تم إنشاء التقرير",
          description: "تم إنشاء التقرير اليومي بنجاح"
        });
        
        createActivity.mutate({
          projectId: parseInt(formData.projectId),
          userId: 1,
          action: "إنشاء تقرير",
          description: `تم إنشاء تقرير يومي جديد بتاريخ ${formData.reportDate}`,
          category: "report"
        });
        
        setShowNewReportDialog(false);
        resetForm();
      },
      onError: (error) => {
        toast({
          title: "خطأ في إنشاء التقرير",
          description: "حدث خطأ أثناء محاولة إنشاء التقرير اليومي",
          variant: "destructive"
        });
        console.error("Error creating report:", error);
      }
    });
  };
  
  const handleViewDetails = (report: DailyReport) => {
    setSelectedReport(report);
    setShowReportDetails(true);
  };
  
  const handleExportPDF = async () => {
    if (!selectedReport || !reportDetailRef.current) return;
    
    try {
      const projectName = getProjectName(selectedReport.projectId);
      const reportDate = formatDate(new Date(selectedReport.reportDate));
      const filename = `تقرير_يومي_${projectName}_${reportDate}.pdf`;
      
      toast({
        title: "جاري التصدير",
        description: "يتم الآن تصدير التقرير إلى ملف PDF..."
      });
      
      const element = reportDetailRef.current;
      
      // Clone content for export
      const contentClone = element.cloneNode(true) as HTMLElement;
      
      // Create a temporary div for export
      const tempDiv = document.createElement('div');
      tempDiv.appendChild(contentClone);
      tempDiv.style.padding = '20px';
      tempDiv.style.width = '210mm';
      tempDiv.style.direction = 'rtl';
      tempDiv.style.backgroundColor = 'white';
      tempDiv.style.color = 'black';
      tempDiv.style.fontFamily = 'Arial, sans-serif';
      
      // Add header
      const header = document.createElement('div');
      header.style.textAlign = 'center';
      header.style.marginBottom = '20px';
      header.style.borderBottom = '2px solid #444';
      header.style.paddingBottom = '10px';
      
      const title = document.createElement('h1');
      title.textContent = 'تقرير يومي';
      title.style.margin = '5px 0';
      title.style.fontSize = '24px';
      title.style.fontWeight = 'bold';
      
      const subtitle = document.createElement('h2');
      subtitle.textContent = projectName;
      subtitle.style.margin = '5px 0';
      subtitle.style.fontSize = '20px';
      
      const dateText = document.createElement('p');
      dateText.textContent = `التاريخ: ${reportDate}`;
      dateText.style.margin = '5px 0';
      dateText.style.fontSize = '14px';
      
      header.appendChild(title);
      header.appendChild(subtitle);
      header.appendChild(dateText);
      
      tempDiv.insertBefore(header, tempDiv.firstChild);
      
      // Add footer
      const footer = document.createElement('div');
      footer.style.textAlign = 'center';
      footer.style.marginTop = '30px';
      footer.style.paddingTop = '10px';
      footer.style.borderTop = '1px solid #ddd';
      footer.style.fontSize = '12px';
      footer.style.color = '#666';
      
      const footerText = document.createElement('p');
      footerText.textContent = `نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}`;
      footer.appendChild(footerText);
      
      tempDiv.appendChild(footer);
      
      // Add to document
      document.body.appendChild(tempDiv);
      
      // Wait for fonts and content
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Convert to image
      const canvas = await html2canvas(tempDiv, {
        scale: 2,
        useCORS: true,
        logging: false,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });
      
      // Remove temp div
      document.body.removeChild(tempDiv);
      
      // Create PDF
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
        compress: true
      });
      
      // Support Arabic
      pdf.setR2L(true);
      
      // Add image to PDF
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const imgWidth = 210;
      const pageHeight = 297;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      
      pdf.addImage(imgData, 'JPEG', 0, 0, imgWidth, imgHeight);
      
      // Save file
      pdf.save(filename);
      
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير التقرير اليومي إلى ملف PDF بنجاح",
        duration: 3000
      });
      
      createActivity.mutate({
        projectId: selectedReport.projectId,
        userId: 1,
        action: "تصدير تقرير",
        description: `تم تصدير التقرير اليومي للمشروع: ${projectName} بتاريخ ${reportDate} بصيغة PDF`,
        category: "report"
      });
    } catch (error) {
      console.error("خطأ في تصدير ملف PDF:", error);
      toast({
        title: "خطأ في التصدير",
        description: "حدث خطأ أثناء محاولة تصدير الملف. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
        duration: 5000
      });
    }
  };
  
  const handlePrint = () => {
    if (!selectedReport) return;
    
    try {
      const projectName = getProjectName(selectedReport.projectId);
      const reportDate = formatDate(new Date(selectedReport.reportDate));
      
      const printWindow = window.open('', 'PRINT', 'height=800,width=1200');
      
      if (!printWindow || !reportDetailRef.current) return;
      
      // Clone content
      const contentElement = reportDetailRef.current.cloneNode(true) as HTMLElement;
      
      // Remove buttons
      const buttonsToRemove = contentElement.querySelectorAll('button');
      buttonsToRemove.forEach(button => button.remove());
      
      // Write content
      printWindow.document.write(`
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>تقرير يومي - ${projectName}</title>
          <style>
            @media print {
              @page { 
                size: A4; 
                margin: 15mm; 
              }
              
              * {
                box-sizing: border-box;
                font-family: 'Arial', 'Tahoma', sans-serif;
              }
              
              body {
                direction: rtl;
                text-align: right;
                color: #333;
                line-height: 1.6;
                font-size: 12pt;
                background-color: white;
                padding: 0;
                margin: 0;
              }
              
              h1, h2, h3, h4, h5 { 
                font-weight: bold;
                margin-top: 10px;
                margin-bottom: 10px;
              }
              
              .header { 
                border-bottom: 2px solid #444;
                margin-bottom: 25px;
                padding-bottom: 15px;
                text-align: center;
              }
              
              .footer { 
                margin-top: 40px; 
                padding-top: 10px;
                border-top: 1px solid #ddd;
                text-align: center; 
                font-size: 10pt; 
                color: #666; 
              }
              
              .text-green-600, .text-green { color: #16a34a !important; }
              .text-red-600, .text-red { color: #dc2626 !important; }
              .text-yellow-600 { color: #ca8a04 !important; }
              
              .font-bold { font-weight: bold; }
              .text-lg { font-size: 18px; }
              .mt-4 { margin-top: 16px; }
              .mb-2 { margin-bottom: 8px; }
              
              table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
              }
              
              th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: right;
              }
              
              th {
                background-color: #f2f2f2;
                font-weight: bold;
              }
              
              .grid {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 20px;
              }
              
              .card {
                border: 1px solid #ddd;
                border-radius: 5px;
                padding: 15px;
                margin-bottom: 15px;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>تقرير يومي</h1>
            <h2>${projectName}</h2>
            <p>التاريخ: ${reportDate}</p>
          </div>
          
          <div class="content">
            ${contentElement.outerHTML}
          </div>
          
          <div class="footer">
            <p>نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}</p>
          </div>
        </body>
        </html>
      `);
      
      printWindow.document.close();
      printWindow.focus();
      
      setTimeout(() => {
        printWindow.print();
        
        createActivity.mutate({
          projectId: selectedReport.projectId,
          userId: 1,
          action: "طباعة تقرير",
          description: `تم طباعة التقرير اليومي للمشروع: ${projectName} بتاريخ ${reportDate}`,
          category: "report"
        });
      }, 500);
    } catch (error) {
      console.error("خطأ في طباعة التقرير:", error);
      toast({
        title: "خطأ في الطباعة",
        description: "حدث خطأ أثناء محاولة طباعة التقرير. يرجى المحاولة مرة أخرى.",
        variant: "destructive"
      });
    }
  };
  
  // Filter reports based on criteria
  const filteredReports = () => {
    if (!projectReports) return [];
    
    return projectReports.filter(report => {
      // Filter by project
      if (filterProjectId !== "all" && report.projectId !== parseInt(filterProjectId)) {
        return false;
      }
      
      // Filter by date
      const reportDate = new Date(report.reportDate);
      if (filterDateFrom && reportDate < filterDateFrom) {
        return false;
      }
      if (filterDateTo) {
        const nextDay = new Date(filterDateTo);
        nextDay.setDate(nextDay.getDate() + 1);
        if (reportDate >= nextDay) {
          return false;
        }
      }
      
      // Filter by search term
      if (searchTerm.trim() !== "") {
        const searchLower = searchTerm.toLowerCase();
        const projectName = getProjectName(report.projectId).toLowerCase();
        const work = report.workCompleted.toLowerCase();
        const issues = report.issues?.toLowerCase() || "";
        
        return (
          projectName.includes(searchLower) || 
          work.includes(searchLower) || 
          issues.includes(searchLower)
        );
      }
      
      return true;
    });
  };
  
  // Show loading state
  if (isLoadingProjects) {
    return <div className="p-8 text-center">جاري تحميل بيانات المشاريع...</div>;
  }
  
  return (
    <div className="flex flex-col space-y-6">
      {/* Header with actions */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold dark:text-white">التقارير اليومية</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">إدارة وعرض تقارير سير العمل اليومية للمشاريع</p>
        </div>
        <div className="flex space-x-2 space-x-reverse">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="icon" 
                  onClick={handleRefresh} 
                  disabled={isRefreshing}
                >
                  <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>تحديث البيانات</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <Dialog open={showNewReportDialog} onOpenChange={setShowNewReportDialog}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <PlusIcon size={16} />
                <span>تقرير جديد</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>إضافة تقرير يومي جديد</DialogTitle>
                <DialogDescription>
                  أدخل بيانات التقرير اليومي للمشروع. جميع الحقول المميزة بعلامة * مطلوبة.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="projectId" className="text-right">
                    المشروع *
                  </Label>
                  <Select
                    value={formData.projectId}
                    onValueChange={handleProjectChange}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects?.map(project => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="reportDate" className="text-right">
                    التاريخ *
                  </Label>
                  <Input 
                    id="reportDate" 
                    type="date" 
                    className="col-span-3"
                    value={formData.reportDate}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="workCompleted" className="text-right pt-2">
                    العمل المنجز *
                  </Label>
                  <Textarea 
                    id="workCompleted" 
                    className="col-span-3 min-h-[100px]"
                    value={formData.workCompleted}
                    onChange={handleInputChange}
                    placeholder="وصف تفصيلي للعمل المنجز خلال اليوم..."
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="workersPresent" className="text-right">
                    عدد العمال *
                  </Label>
                  <Input 
                    id="workersPresent" 
                    type="number" 
                    className="col-span-3"
                    value={formData.workersPresent}
                    onChange={handleInputChange}
                    min="0"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="hoursWorked" className="text-right">
                    ساعات العمل *
                  </Label>
                  <Input 
                    id="hoursWorked" 
                    type="number" 
                    step="0.5" 
                    className="col-span-3"
                    value={formData.hoursWorked}
                    onChange={handleInputChange}
                    min="0"
                    max="24"
                  />
                </div>
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label htmlFor="issues" className="text-right pt-2">
                    المشاكل والتحديات
                  </Label>
                  <Textarea 
                    id="issues" 
                    className="col-span-3"
                    value={formData.issues}
                    onChange={handleInputChange}
                    placeholder="مشاكل أو تحديات واجهت فريق العمل..."
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="equipmentUsed" className="text-right">
                    المعدات المستخدمة *
                  </Label>
                  <Input 
                    id="equipmentUsed" 
                    placeholder="حفارة, شاحنة, رافعة..."
                    className="col-span-3"
                    value={formData.equipmentUsed}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="weatherConditions" className="text-right">
                    حالة الطقس
                  </Label>
                  <Select
                    value={formData.weatherConditions}
                    onValueChange={handleWeatherChange}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="اختر حالة الطقس" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sunny">مشمس</SelectItem>
                      <SelectItem value="cloudy">غائم</SelectItem>
                      <SelectItem value="rainy">ممطر</SelectItem>
                      <SelectItem value="stormy">عاصف</SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setShowNewReportDialog(false);
                  resetForm();
                }}>إلغاء</Button>
                <Button 
                  type="submit" 
                  onClick={handleSubmit} 
                  disabled={createDailyReport.isPending}
                >
                  {createDailyReport.isPending ? (
                    <><RotateCw className="w-4 h-4 mr-2 animate-spin" /> جاري الحفظ...</>
                  ) : 'حفظ التقرير'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Filters and search */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:items-center">
        <div className="md:col-span-3">
          <Select
            value={filterProjectId}
            onValueChange={setFilterProjectId}
          >
            <SelectTrigger>
              <SelectValue placeholder="جميع المشاريع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع المشاريع</SelectItem>
              {projects?.map(project => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="md:col-span-4 relative">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              placeholder="بحث في التقارير..."
              className="pl-3 pr-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="md:col-span-3">
          <Popover open={showDatePicker} onOpenChange={setShowDatePicker}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="w-full justify-between">
                {filterDateFrom ? (
                  filterDateTo ? (
                    `${formatDate(filterDateFrom)} - ${formatDate(filterDateTo)}`
                  ) : (
                    `من ${formatDate(filterDateFrom)}`
                  )
                ) : (
                  filterDateTo ? (
                    `حتى ${formatDate(filterDateTo)}`
                  ) : (
                    'تصفية حسب التاريخ'
                  )
                )}
                <Calendar className="ml-2 h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <div className="flex flex-col gap-2 p-3">
                <div className="space-y-1">
                  <h4 className="text-sm font-medium">من تاريخ</h4>
                  <CalendarComponent
                    mode="single"
                    selected={filterDateFrom}
                    onSelect={setFilterDateFrom}
                    initialFocus
                  />
                </div>
                <Separator />
                <div className="space-y-1">
                  <h4 className="text-sm font-medium">إلى تاريخ</h4>
                  <CalendarComponent
                    mode="single"
                    selected={filterDateTo}
                    onSelect={setFilterDateTo}
                    initialFocus
                  />
                </div>
                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setFilterDateFrom(undefined);
                      setFilterDateTo(undefined);
                    }}
                  >
                    مسح
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setShowDatePicker(false)}
                  >
                    تطبيق
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
        
        <div className="md:col-span-2">
          <Tabs value={viewMode} onValueChange={setViewMode} className="w-full">
            <TabsList className="w-full">
              <TabsTrigger value="list" className="flex-1">قائمة</TabsTrigger>
              <TabsTrigger value="grid" className="flex-1">شبكة</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Reports display */}
      {isLoadingReports ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-[200px]" />
                    <Skeleton className="h-4 w-[150px]" />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : reportsError ? (
        <Card className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertCircle className="text-red-500 h-10 w-10" />
              <div>
                <h3 className="font-bold text-lg">خطأ في تحميل البيانات</h3>
                <p className="text-red-600 dark:text-red-400">حدث خطأ أثناء محاولة تحميل التقارير اليومية. يرجى المحاولة مرة أخرى لاحقاً.</p>
                <Button className="mt-2" onClick={handleRefresh}>إعادة المحاولة</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : filteredReports().length === 0 ? (
        <Card>
          <CardContent className="pt-6 pb-10 flex flex-col items-center justify-center text-center">
            <FileText className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
            <h3 className="font-bold text-lg">لا توجد تقارير</h3>
            <p className="text-gray-500 dark:text-gray-400 max-w-md mb-4">
              {searchTerm || filterDateFrom || filterDateTo || filterProjectId !== "all" 
                ? "لا توجد تقارير تطابق معايير البحث والتصفية. حاول تغيير المعايير أو إنشاء تقرير جديد."
                : "لم يتم العثور على أي تقارير يومية. يمكنك إنشاء تقرير جديد باستخدام الزر أعلاه."
              }
            </p>
            <Button
              onClick={() => {
                resetForm();
                setShowNewReportDialog(true);
              }}
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              إنشاء تقرير جديد
            </Button>
          </CardContent>
        </Card>
      ) : viewMode === 'list' ? (
        <div className="space-y-4">
          {filteredReports().map(report => (
            <Card key={report.id} className="hover:shadow-md transition-shadow overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg flex items-center gap-2">
                      تقرير {getProjectName(report.projectId)}
                      {report.weatherConditions && (
                        <span className="inline-block ml-2" title={`الطقس: ${report.weatherConditions}`}>
                          {weatherIcons[report.weatherConditions as keyof typeof weatherIcons] || weatherIcons.other}
                        </span>
                      )}
                    </CardTitle>
                    <div className="flex items-center mt-1 text-sm text-gray-500 dark:text-gray-400">
                      <Calendar className="h-4 w-4 ml-1" />
                      <span>{formatDate(new Date(report.reportDate))}</span>
                      <Clock className="h-4 w-4 mr-4 ml-1" />
                      <span>{report.hoursWorked} ساعات</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-1" 
                      onClick={() => {
                        setSelectedReport(report);
                        handleExportPDF();
                      }}
                    >
                      <FileText className="h-4 w-4" />
                      <span>PDF</span>
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleViewDetails(report)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div>
                    <h4 className="text-sm font-medium dark:text-gray-200">العمل المنجز:</h4>
                    <p className="text-gray-600 dark:text-gray-300">
                      {report.workCompleted.length > 150 
                        ? `${report.workCompleted.substring(0, 150)}...` 
                        : report.workCompleted
                      }
                    </p>
                  </div>
                  
                  {report.issues && (
                    <div>
                      <h4 className="text-sm font-medium dark:text-gray-200">المشاكل والتحديات:</h4>
                      <p className="text-gray-600 dark:text-gray-300">
                        {report.issues.length > 100 
                          ? `${report.issues.substring(0, 100)}...` 
                          : report.issues
                        }
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div>
                      <h4 className="text-sm font-medium dark:text-gray-200">العمال الحاضرون:</h4>
                      <p className="text-gray-600 dark:text-gray-300">{report.workersPresent} عامل</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium dark:text-gray-200">المعدات المستخدمة:</h4>
                      <p className="text-gray-600 dark:text-gray-300">
                        {Array.isArray(report.equipmentUsed) 
                          ? report.equipmentUsed.join(", ")
                          : "غير محدد"
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0 flex justify-end">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => handleViewDetails(report)}
                >
                  عرض التفاصيل
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredReports().map(report => (
            <Card key={report.id} className="hover:shadow-md transition-shadow h-full flex flex-col">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">تقرير {getProjectName(report.projectId)}</CardTitle>
                    <div className="flex items-center mt-1 text-sm text-gray-500 dark:text-gray-400">
                      <Calendar className="h-4 w-4 ml-1" />
                      <span>{formatDate(new Date(report.reportDate))}</span>
                    </div>
                  </div>
                  {report.weatherConditions && (
                    <div className="p-1" title={`الطقس: ${report.weatherConditions}`}>
                      {weatherIcons[report.weatherConditions as keyof typeof weatherIcons] || weatherIcons.other}
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex-grow">
                <div className="space-y-2">
                  <div>
                    <h4 className="text-sm font-medium dark:text-gray-200">العمل المنجز:</h4>
                    <p className="text-gray-600 dark:text-gray-300 line-clamp-3">{report.workCompleted}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 pt-2">
                    <div>
                      <h4 className="text-sm font-medium dark:text-gray-200">العمال:</h4>
                      <p className="text-gray-600 dark:text-gray-300">{report.workersPresent} عامل</p>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium dark:text-gray-200">ساعات العمل:</h4>
                      <p className="text-gray-600 dark:text-gray-300">{report.hoursWorked} ساعات</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-0 border-t">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="w-full" 
                  onClick={() => handleViewDetails(report)}
                >
                  عرض التفاصيل
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
      
      {/* Report Details Sheet */}
      <Sheet open={showReportDetails} onOpenChange={setShowReportDetails}>
        <SheetContent className="overflow-y-auto w-full max-w-3xl" side="right">
          {selectedReport && (
            <div>
              <SheetHeader className="mb-6">
                <SheetTitle className="text-xl">تفاصيل التقرير اليومي</SheetTitle>
                <SheetDescription>
                  مشروع: {getProjectName(selectedReport.projectId)} | تاريخ: {formatDate(new Date(selectedReport.reportDate))}
                </SheetDescription>
              </SheetHeader>
              
              <div className="flex justify-between items-center mb-4">
                <Badge className="py-1 px-2 text-xs">
                  تم إنشاءه: {new Date(selectedReport.submittedAt).toLocaleDateString('ar-SA')}
                </Badge>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={handlePrint}>
                    <Printer size={16} className="ml-1" />
                    طباعة
                  </Button>
                  <Button size="sm" onClick={handleExportPDF}>
                    <Download size={16} className="ml-1" />
                    تصدير PDF
                  </Button>
                </div>
              </div>
              
              <div ref={reportDetailRef} className="space-y-6">
                <div>
                  <h3 className="text-lg font-bold mb-2">العمل المنجز</h3>
                  <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                    <p className="whitespace-pre-line">{selectedReport.workCompleted}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-bold mb-2">معلومات العمل</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">العمال الحاضرون:</span>
                        <span className="font-medium">{selectedReport.workersPresent} عامل</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">ساعات العمل:</span>
                        <span className="font-medium">{selectedReport.hoursWorked} ساعات</span>
                      </div>
                      {selectedReport.weatherConditions && (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600 dark:text-gray-400">حالة الطقس:</span>
                          <span className="font-medium flex items-center gap-1">
                            {weatherIcons[selectedReport.weatherConditions as keyof typeof weatherIcons] || weatherIcons.other}
                            {selectedReport.weatherConditions === 'sunny' && 'مشمس'}
                            {selectedReport.weatherConditions === 'cloudy' && 'غائم'}
                            {selectedReport.weatherConditions === 'rainy' && 'ممطر'}
                            {selectedReport.weatherConditions === 'stormy' && 'عاصف'}
                            {selectedReport.weatherConditions === 'other' && 'أخرى'}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-bold mb-2">المعدات المستخدمة</h3>
                    <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                      <div className="flex flex-wrap gap-1">
                        {Array.isArray(selectedReport.equipmentUsed) ? (
                          selectedReport.equipmentUsed.map((item, index) => (
                            <Badge key={index} variant="outline" className="mb-1">
                              {item}
                            </Badge>
                          ))
                        ) : (
                          <span>لا توجد معدات مسجلة</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                
                {selectedReport.issues && (
                  <div>
                    <h3 className="text-lg font-bold mb-2">المشاكل والتحديات</h3>
                    <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                      <p className="whitespace-pre-line">{selectedReport.issues}</p>
                    </div>
                  </div>
                )}
              </div>
              
              <SheetFooter className="mt-8">
                <Button variant="secondary" onClick={() => setShowReportDetails(false)}>
                  إغلاق
                </Button>
              </SheetFooter>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default DailyReports;