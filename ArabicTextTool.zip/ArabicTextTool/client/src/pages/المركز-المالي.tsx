import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Helmet } from 'react-helmet-async';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import {
  ArrowLeft,
  ArrowRight,
  Download,
  FileText,
  Printer,
  RefreshCcw,
  BarChart3,
  Wallet,
  CreditCard,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Building,
  CalendarIcon,
  Loader2,
} from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';

import AccountBalancesView from '@/components/financial/AccountBalancesView';
import JournalEntryManager from '@/components/financial/JournalEntryManager';
import { useToast } from '@/hooks/use-toast';

/**
 * صفحة المركز المالي للمشروع
 * 
 * تقدم:
 * - ملخص مالي للمشروع
 * - الحالة النقدية
 * - أرصدة الحسابات
 * - حركة القيود المحاسبية
 * - تحليل النفقات والإيرادات
 * - التقارير المالية
 */

const ProjectFinancialCenter: React.FC = () => {
  // حالة المكون
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);
  const [selectedProjectId, setSelectedProjectId] = useState<number | undefined>();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  // استخراج معرف المشروع من عنوان URL إذا وجد
  React.useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const projectIdParam = params.get('projectId');
    if (projectIdParam) {
      setSelectedProjectId(Number(projectIdParam));
    }
  }, [location]);

  // استعلام قائمة المشاريع
  const { data: projects = [], isLoading: projectsLoading } = useQuery({
    queryKey: ['/api/projects'],
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // استعلام ملخص مالي للمشروع
  const { 
    data: projectSummary = {}, 
    isLoading: projectSummaryLoading,
    refetch: refetchProjectSummary
  } = useQuery({
    queryKey: ['/api/financial/project-summary', selectedProjectId, selectedYear, selectedMonth],
    enabled: !!selectedProjectId,
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // استعلام المركز المالي للمشروع
  const { 
    data: financialCenter = {}, 
    isLoading: financialCenterLoading,
    refetch: refetchFinancialCenter
  } = useQuery({
    queryKey: ['/api/financial/project-financial-center', selectedProjectId, selectedYear, selectedMonth],
    enabled: !!selectedProjectId,
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // إنشاء قائمة السنوات
  const years = [];
  const currentYear = new Date().getFullYear();
  for (let i = currentYear - 5; i <= currentYear + 2; i++) {
    years.push(i);
  }

  // إنشاء قائمة الأشهر
  const months = [
    { value: 1, label: 'يناير' },
    { value: 2, label: 'فبراير' },
    { value: 3, label: 'مارس' },
    { value: 4, label: 'أبريل' },
    { value: 5, label: 'مايو' },
    { value: 6, label: 'يونيو' },
    { value: 7, label: 'يوليو' },
    { value: 8, label: 'أغسطس' },
    { value: 9, label: 'سبتمبر' },
    { value: 10, label: 'أكتوبر' },
    { value: 11, label: 'نوفمبر' },
    { value: 12, label: 'ديسمبر' },
  ];

  // الحصول على اسم المشروع
  const getProjectName = (projectId?: number) => {
    if (!projectId || projectsLoading) return 'تحميل...';
    const project = projects.find((p: any) => p.id === projectId);
    return project ? project.name : `مشروع ${projectId}`;
  };

  // تغيير الشهر مع التعامل مع تغيير السنة
  const handleMonthChange = (newMonth: number) => {
    setSelectedMonth(newMonth);
  };

  // الانتقال للشهر السابق
  const goToPreviousMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear(selectedYear - 1);
    } else {
      setSelectedMonth(selectedMonth - 1);
    }
  };

  // الانتقال للشهر التالي
  const goToNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear(selectedYear + 1);
    } else {
      setSelectedMonth(selectedMonth + 1);
    }
  };

  // تنسيق المبالغ المالية
  const formatCurrency = (amount: number) => {
    return amount?.toLocaleString('ar-SA', { maximumFractionDigits: 2 }) || '0';
  };

  // تصدير المركز المالي كملف PDF
  const handleExportFinancialCenter = () => {
    if (!selectedProjectId) {
      toast({
        title: 'لم يتم اختيار مشروع',
        description: 'يرجى اختيار مشروع أولا',
        variant: 'destructive',
      });
      return;
    }

    // هنا سيتم فتح الاستعلام في نافذة جديدة مع تنسيق PDF
    window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=financial_center&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`);
  };

  // تحديث البيانات المالية
  const handleRefreshData = () => {
    if (!selectedProjectId) return;
    refetchProjectSummary();
    refetchFinancialCenter();
    toast({
      title: 'جاري تحديث البيانات',
    });
  };

  // في حالة عدم اختيار مشروع
  if (!selectedProjectId) {
    return (
      <div className="container mx-auto py-6 space-y-6">
        <Helmet>
          <title>المركز المالي للمشروع</title>
        </Helmet>

        <h1 className="text-3xl font-bold">المركز المالي للمشروع</h1>

        <Card className="border-dashed">
          <CardHeader>
            <CardTitle>اختر مشروعاً</CardTitle>
            <CardDescription>
              يرجى اختيار مشروع لعرض المركز المالي الخاص به
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">المشروع</label>
                <Select
                  value={selectedProjectId?.toString()}
                  onValueChange={(value) => {
                    const projectId = parseInt(value);
                    setSelectedProjectId(projectId);
                    setLocation(`/المركز-المالي?projectId=${projectId}`);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="اختر المشروع" />
                  </SelectTrigger>
                  <SelectContent>
                    {projectsLoading ? (
                      <div className="flex items-center justify-center py-2">
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        <span>جاري تحميل المشاريع...</span>
                      </div>
                    ) : projects.length === 0 ? (
                      <div className="py-2 text-center">لا توجد مشاريع</div>
                    ) : (
                      projects.map((project: any) => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Helmet>
        <title>المركز المالي - {getProjectName(selectedProjectId)}</title>
      </Helmet>

      {/* رأس الصفحة ومعلومات المشروع والفترة */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">المركز المالي للمشروع</h1>
          <p className="text-muted-foreground">
            {getProjectName(selectedProjectId)} - {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleRefreshData} title="تحديث البيانات">
            <RefreshCcw className="h-4 w-4" />
          </Button>

          <Button variant="outline" size="icon" onClick={handleExportFinancialCenter} title="تصدير كتقرير PDF">
            <FileText className="h-4 w-4" />
          </Button>

          <Button variant="outline" size="icon" onClick={() => window.print()} title="طباعة">
            <Printer className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              onClick={goToPreviousMonth}
              title="الشهر السابق"
            >
              <ArrowRight className="h-4 w-4" />
            </Button>

            <Select
              value={selectedMonth.toString()}
              onValueChange={(value) => handleMonthChange(parseInt(value))}
            >
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {months.map((monthOption) => (
                  <SelectItem key={monthOption.value} value={monthOption.value.toString()}>
                    {monthOption.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              value={selectedYear.toString()}
              onValueChange={(value) => setSelectedYear(parseInt(value))}
            >
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map((yearOption) => (
                  <SelectItem key={yearOption} value={yearOption.toString()}>
                    {yearOption}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="icon"
              onClick={goToNextMonth}
              title="الشهر التالي"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* علامات التبويب الرئيسية */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="accounts">أرصدة الحسابات</TabsTrigger>
          <TabsTrigger value="journal">القيود المحاسبية</TabsTrigger>
          <TabsTrigger value="reports">التقارير المالية</TabsTrigger>
        </TabsList>

        {/* محتوى نظرة عامة للمركز المالي */}
        <TabsContent value="overview" className="space-y-4">
          {/* بطاقات الملخص المالي */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-500" />
                  إجمالي الإيرادات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {projectSummaryLoading ? (
                    <div className="flex items-center">
                      <Loader2 className="h-5 w-5 animate-spin ml-2" />
                      تحميل...
                    </div>
                  ) : (
                    formatCurrency(projectSummary.totalRevenue || 0)
                  )}
                </div>
                <p className="text-muted-foreground text-sm">
                  {projectSummary.revenueChange > 0 ? (
                    <span className="text-green-500 flex items-center">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +{formatCurrency(projectSummary.revenueChange)}
                    </span>
                  ) : projectSummary.revenueChange < 0 ? (
                    <span className="text-red-500 flex items-center">
                      <TrendingDown className="h-3 w-3 mr-1" />
                      {formatCurrency(projectSummary.revenueChange)}
                    </span>
                  ) : (
                    <span>لا تغيير عن الشهر السابق</span>
                  )}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <CreditCard className="h-5 w-5 mr-2 text-red-500" />
                  إجمالي المصروفات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {projectSummaryLoading ? (
                    <div className="flex items-center">
                      <Loader2 className="h-5 w-5 animate-spin ml-2" />
                      تحميل...
                    </div>
                  ) : (
                    formatCurrency(projectSummary.totalExpenses || 0)
                  )}
                </div>
                <p className="text-muted-foreground text-sm">
                  {projectSummary.expenseChange > 0 ? (
                    <span className="text-red-500 flex items-center">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +{formatCurrency(projectSummary.expenseChange)}
                    </span>
                  ) : projectSummary.expenseChange < 0 ? (
                    <span className="text-green-500 flex items-center">
                      <TrendingDown className="h-3 w-3 mr-1" />
                      {formatCurrency(Math.abs(projectSummary.expenseChange || 0))}
                    </span>
                  ) : (
                    <span>لا تغيير عن الشهر السابق</span>
                  )}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <Building className="h-5 w-5 mr-2 text-blue-500" />
                  صافي الربح
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${(projectSummary.netProfit || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {projectSummaryLoading ? (
                    <div className="flex items-center">
                      <Loader2 className="h-5 w-5 animate-spin ml-2" />
                      تحميل...
                    </div>
                  ) : (
                    formatCurrency(Math.abs(projectSummary.netProfit || 0)) + 
                    ((projectSummary.netProfit || 0) < 0 ? ' -' : '')
                  )}
                </div>
                <p className="text-muted-foreground text-sm">
                  {projectSummary.profitChange > 0 ? (
                    <span className="text-green-500 flex items-center">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      +{formatCurrency(projectSummary.profitChange)}
                    </span>
                  ) : projectSummary.profitChange < 0 ? (
                    <span className="text-red-500 flex items-center">
                      <TrendingDown className="h-3 w-3 mr-1" />
                      {formatCurrency(projectSummary.profitChange)}
                    </span>
                  ) : (
                    <span>لا تغيير عن الشهر السابق</span>
                  )}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <Wallet className="h-5 w-5 mr-2 text-amber-500" />
                  الرصيد النقدي
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${(projectSummary.cashBalance || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {projectSummaryLoading ? (
                    <div className="flex items-center">
                      <Loader2 className="h-5 w-5 animate-spin ml-2" />
                      تحميل...
                    </div>
                  ) : (
                    formatCurrency(Math.abs(projectSummary.cashBalance || 0)) + 
                    ((projectSummary.cashBalance || 0) < 0 ? ' -' : '')
                  )}
                </div>
                <p className="text-muted-foreground text-sm">
                  حتى {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* معلومات المركز المالي التفصيلية */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* الأصول والالتزامات */}
            <Card>
              <CardHeader>
                <CardTitle>الأصول والالتزامات</CardTitle>
                <CardDescription>
                  ملخص الأصول والالتزامات المالية للمشروع
                </CardDescription>
              </CardHeader>
              <CardContent>
                {financialCenterLoading ? (
                  <div className="flex justify-center items-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* الأصول */}
                    <div>
                      <h3 className="font-bold mb-2">الأصول</h3>
                      <div className="space-y-2">
                        {financialCenter.assets?.map((asset: any, index: number) => (
                          <div key={index} className="flex justify-between">
                            <span>{asset.name}</span>
                            <span>{formatCurrency(asset.amount)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-bold pt-2 border-t">
                          <span>إجمالي الأصول</span>
                          <span>{formatCurrency(financialCenter.totalAssets || 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* الخصوم */}
                    <div>
                      <h3 className="font-bold mb-2">الالتزامات والخصوم</h3>
                      <div className="space-y-2">
                        {financialCenter.liabilities?.map((liability: any, index: number) => (
                          <div key={index} className="flex justify-between">
                            <span>{liability.name}</span>
                            <span>{formatCurrency(liability.amount)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-bold pt-2 border-t">
                          <span>إجمالي الالتزامات</span>
                          <span>{formatCurrency(financialCenter.totalLiabilities || 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* صافي الأصول */}
                    <div className="pt-2 border-t-2">
                      <div className="flex justify-between font-bold text-lg">
                        <span>صافي الأصول</span>
                        <span className={`${(financialCenter.netAssets || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(Math.abs(financialCenter.netAssets || 0))}
                          {(financialCenter.netAssets || 0) < 0 && ' -'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* الإيرادات والمصروفات */}
            <Card>
              <CardHeader>
                <CardTitle>الإيرادات والمصروفات</CardTitle>
                <CardDescription>
                  ملخص الإيرادات والمصروفات للمشروع في الفترة الحالية
                </CardDescription>
              </CardHeader>
              <CardContent>
                {financialCenterLoading ? (
                  <div className="flex justify-center items-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* الإيرادات */}
                    <div>
                      <h3 className="font-bold mb-2 text-green-600">الإيرادات</h3>
                      <div className="space-y-2">
                        {financialCenter.revenues?.map((revenue: any, index: number) => (
                          <div key={index} className="flex justify-between">
                            <span>{revenue.name}</span>
                            <span>{formatCurrency(revenue.amount)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-bold pt-2 border-t text-green-600">
                          <span>إجمالي الإيرادات</span>
                          <span>{formatCurrency(financialCenter.totalRevenues || 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* المصروفات */}
                    <div>
                      <h3 className="font-bold mb-2 text-red-600">المصروفات</h3>
                      <div className="space-y-2">
                        {financialCenter.expenses?.map((expense: any, index: number) => (
                          <div key={index} className="flex justify-between">
                            <span>{expense.name}</span>
                            <span>{formatCurrency(expense.amount)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-bold pt-2 border-t text-red-600">
                          <span>إجمالي المصروفات</span>
                          <span>{formatCurrency(financialCenter.totalExpenses || 0)}</span>
                        </div>
                      </div>
                    </div>

                    {/* صافي الربح */}
                    <div className="pt-2 border-t-2">
                      <div className="flex justify-between font-bold text-lg">
                        <span>صافي الربح (الخسارة)</span>
                        <span className={`${(financialCenter.netIncome || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(Math.abs(financialCenter.netIncome || 0))}
                          {(financialCenter.netIncome || 0) < 0 && ' -'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* رسم بياني للمؤشرات المالية */}
          <Card>
            <CardHeader>
              <CardTitle>المؤشرات المالية</CardTitle>
              <CardDescription>
                تحليل الأداء المالي للمشروع خلال الفترة الحالية
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center">
              {/* يمكن استبدال هذا بمكون رسم بياني حقيقي */}
              <div className="text-center text-muted-foreground">
                <BarChart3 className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p>سيتم إضافة رسوم بيانية تفصيلية هنا لاحقاً</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* محتوى أرصدة الحسابات */}
        <TabsContent value="accounts">
          <AccountBalancesView 
            projectId={selectedProjectId} 
            fiscalYear={selectedYear}
            fiscalMonth={selectedMonth}
          />
        </TabsContent>

        {/* محتوى القيود المحاسبية */}
        <TabsContent value="journal">
          <JournalEntryManager projectId={selectedProjectId} />
        </TabsContent>

        {/* محتوى التقارير المالية */}
        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>التقارير المالية للمشروع</CardTitle>
              <CardDescription>
                اختر تقريراً ماليا لعرضه أو تصديره
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=income_statement&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">قائمة الدخل</div>
                    <div className="text-sm text-muted-foreground">
                      {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                    </div>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=balance_sheet&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">الميزانية العمومية</div>
                    <div className="text-sm text-muted-foreground">
                      {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                    </div>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=cash_flow&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">قائمة التدفقات النقدية</div>
                    <div className="text-sm text-muted-foreground">
                      {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                    </div>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=budget_comparison&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">تقرير مقارنة الميزانية</div>
                    <div className="text-sm text-muted-foreground">
                      مقارنة الفعلي بالمخطط
                    </div>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=expense_analysis&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">تحليل المصروفات</div>
                    <div className="text-sm text-muted-foreground">
                      حسب الفئات والأنواع
                    </div>
                  </div>
                </Button>

                <Button 
                  variant="outline" 
                  className="h-auto py-4 flex flex-col items-center justify-center gap-2"
                  onClick={() => window.open(`/api/generate-financial-report?projectId=${selectedProjectId}&reportType=account_statement&dateFrom=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-01&dateTo=${selectedYear}-${selectedMonth.toString().padStart(2, '0')}-31&format=pdf`)}
                >
                  <FileText className="h-8 w-8" />
                  <div>
                    <div className="font-semibold">كشف حساب تفصيلي</div>
                    <div className="text-sm text-muted-foreground">
                      لجميع الحسابات
                    </div>
                  </div>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProjectFinancialCenter;