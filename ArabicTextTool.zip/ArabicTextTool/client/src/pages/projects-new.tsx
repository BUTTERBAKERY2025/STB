import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { 
  PlusIcon, 
  Filter, 
  Search, 
  Calendar, 
  MapPin, 
  Coins, 
  Clock, 
  BarChart as BarChartIcon, 
  Edit, 
  Trash2, 
  EyeIcon,
  ChevronLeft,
  FileTextIcon,
  AlertTriangle,
  MessageSquare,
  ClipboardList,
  UsersIcon,
  Truck,
  Banknote,
  Receipt,
  LayoutDashboard,
  Table as TableIcon,
  List,
  KanbanSquare,
  MapIcon,
  SlidersHorizontal,
  BookOpen,
  DollarSign,
  CalendarRange,
  X,
  TrendingUp
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";

// Import custom components
import ProjectKanbanView from "@/components/projects/ProjectKanbanView";
import ProjectMap from "@/components/projects/ProjectMap";
import ProjectDetailsView from "@/components/projects/ProjectDetailsView";

import { 
  useProjects, 
  useCreateProject, 
  useUpdateProject, 
  useDeleteProject,
  useTeamByProject,
  useEquipmentByProject,
  useExpensesByProject,
  useDailyReportsByProject,
  useInvoicesByProject,
  useDocumentsByProject,
  useProjectRisks,
  useDeadlinesByProject,
  useActivitiesByProject,
  useUsers
} from "@/lib/data";

import { formatDate, formatCurrency, getCategoryText, getCategoryIcon } from "@/lib/utils";

import type { Project, InsertProject } from "@shared/schema";

// Define project form data type
interface ProjectFormData {
  name: string;
  description: string;
  location: string;
  status: string;
  startDate: string;
  endDate: string;
  duration: string;
  budget: string;
  category: string;
  progress?: string;
  imageUrl?: string;
  clientName?: string; // New field
  contractNumber?: string; // New field
}

// Project Form component
const ProjectForm = ({ 
  initialData, 
  onSubmit, 
  onCancel,
  isSubmitting 
}: { 
  initialData?: ProjectFormData; 
  onSubmit: (data: ProjectFormData) => void; 
  onCancel: () => void;
  isSubmitting: boolean;
}) => {
  const [formData, setFormData] = useState<ProjectFormData>(
    initialData || {
      name: "",
      description: "",
      location: "",
      status: "planned",
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
      duration: "6",
      budget: "0",
      category: "electricity",
      progress: "0",
      imageUrl: "",
      clientName: "", // New field
      contractNumber: "" // New field
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">اسم المشروع</Label>
            <Input
              id="name"
              name="name"
              placeholder="أدخل اسم المشروع"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="clientName">اسم العميل / المالك</Label>
            <Input
              id="clientName"
              name="clientName"
              placeholder="أدخل اسم الجهة المالكة"
              value={formData.clientName}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="contractNumber">رقم العقد</Label>
            <Input
              id="contractNumber"
              name="contractNumber"
              placeholder="أدخل رقم العقد"
              value={formData.contractNumber}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">الموقع</Label>
            <Input
              id="location"
              name="location"
              placeholder="موقع المشروع"
              value={formData.location}
              onChange={handleChange}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">الحالة</Label>
              <Select 
                name="status" 
                value={formData.status} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger id="status">
                  <SelectValue placeholder="اختر حالة المشروع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">مخطط</SelectItem>
                  <SelectItem value="inProgress">قيد التنفيذ</SelectItem>
                  <SelectItem value="delayed">متأخر</SelectItem>
                  <SelectItem value="completed">مكتمل</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">التصنيف</Label>
              <Select 
                name="category" 
                value={formData.category} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}
              >
                <SelectTrigger id="category">
                  <SelectValue placeholder="اختر تصنيف المشروع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="electricity">كهرباء</SelectItem>
                  <SelectItem value="water">مياه</SelectItem>
                  <SelectItem value="communications">اتصالات</SelectItem>
                  <SelectItem value="roads">طرق</SelectItem>
                  <SelectItem value="buildings">مباني</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">تاريخ البداية</Label>
              <Input
                id="startDate"
                name="startDate"
                type="date"
                value={formData.startDate}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">تاريخ النهاية</Label>
              <Input
                id="endDate"
                name="endDate"
                type="date"
                value={formData.endDate}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="duration">المدة (شهور)</Label>
              <Input
                id="duration"
                name="duration"
                type="number"
                min="1"
                value={formData.duration}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="budget">الميزانية</Label>
              <Input
                id="budget"
                name="budget"
                type="number"
                min="0"
                value={formData.budget}
                onChange={handleChange}
                required
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description">وصف المشروع</Label>
            <Textarea
              id="description"
              name="description"
              placeholder="وصف تفصيلي للمشروع"
              value={formData.description}
              onChange={handleChange}
              required
              className="min-h-[150px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="imageUrl">رابط الصورة</Label>
            <Input
              id="imageUrl"
              name="imageUrl"
              placeholder="رابط صورة المشروع (اختياري)"
              value={formData.imageUrl || ""}
              onChange={handleChange}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="progress">نسبة الإنجاز (%)</Label>
            <Input
              id="progress"
              name="progress"
              type="number"
              min="0"
              max="100"
              value={formData.progress || "0"}
              onChange={handleChange}
            />
            <div className="w-full bg-gray-200 h-2 rounded-full mt-2">
              <div 
                className="bg-primary h-2 rounded-full" 
                style={{ width: `${formData.progress || 0}%` }} 
              />
            </div>
          </div>
        </div>
      </div>

      <DialogFooter className="flex justify-end gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          إلغاء
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting ? "جاري الحفظ..." : initialData ? "تحديث المشروع" : "إضافة المشروع"}
        </Button>
      </DialogFooter>
    </form>
  );
};

// Project grid view
const ProjectGridView = ({ 
  projects, 
  onEdit, 
  onDelete, 
  onViewDetails 
}: { 
  projects: Project[]; 
  onEdit: (project: Project) => void; 
  onDelete: (projectId: number) => void;
  onViewDetails: (projectId: number) => void;
}) => {
  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'inProgress':
        return 'bg-yellow-100 text-yellow-800';
      case 'delayed':
        return 'bg-red-100 text-red-800';
      case 'planned':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  // Rating indicator (calculate based on progress vs timeline)
  const getProjectRating = (project: Project): number => {
    // Simple calculation based on progress and status
    if (project.status === 'completed') return 5;
    if (project.status === 'delayed') return 2;
    
    // For in-progress and planned, calculate based on progress
    // In a real system, this would be more sophisticated based on financials and deadlines
    return Math.ceil(project.progress / 20);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <span key={star} className={`text-xs ${star <= rating ? 'text-yellow-400' : 'text-gray-300'}`}>★</span>
        ))}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {projects.map(project => (
        <Card key={project.id} className="overflow-hidden hover:shadow-md transition-shadow">
          <div className="relative h-32 overflow-hidden bg-gradient-to-b from-primary/20 to-primary/5">
            {project.imageUrl && (
              <img 
                src={project.imageUrl} 
                alt={project.name} 
                className="w-full h-full object-cover"
              />
            )}
            <div className="absolute top-2 left-2">
              <Badge className={getStatusBadgeClass(project.status)}>
                {getStatusDisplayText(project.status)}
              </Badge>
            </div>
            <div className="absolute bottom-0 right-0 left-0 bg-black/30 text-white p-2">
              <h3 className="font-bold truncate">{project.name}</h3>
            </div>
          </div>
          
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center text-muted-foreground text-sm">
                <MapPin className="h-3.5 w-3.5 ml-1" />
                <span className="truncate max-w-[150px]">{project.location}</span>
              </div>
              <div className="text-xs">
                {renderStars(getProjectRating(project))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">الميزانية:</span>
                <span className="font-semibold">{formatCurrency(project.budget)}</span>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">المدة:</span>
                <span>{project.duration} شهر</span>
              </div>
              
              <div className="flex flex-col space-y-1">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">الإنجاز:</span>
                  <span>{project.progress}%</span>
                </div>
                <div className="w-full bg-gray-200 h-1.5 rounded-full">
                  <div 
                    className="bg-primary h-1.5 rounded-full" 
                    style={{ width: `${project.progress}%` }} 
                  />
                </div>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="border-t px-4 py-2 flex justify-between">
            <div className="flex space-x-1 space-x-reverse">
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0" 
                onClick={() => onViewDetails(project.id)}
              >
                <EyeIcon className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0" 
                onClick={() => onEdit(project)}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0 text-red-500" 
                onClick={() => onDelete(project.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
            <div className="text-xs text-muted-foreground">
              {formatDate(new Date(project.startDate))}
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};

// Project list view
const ProjectListView = ({ 
  projects, 
  onEdit, 
  onDelete, 
  onViewDetails 
}: { 
  projects: Project[]; 
  onEdit: (project: Project) => void; 
  onDelete: (projectId: number) => void;
  onViewDetails: (projectId: number) => void;
}) => {
  // Helper for status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'inProgress':
        return 'bg-yellow-100 text-yellow-800';
      case 'delayed':
        return 'bg-red-100 text-red-800';
      case 'planned':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper to get status display text
  const getStatusDisplayText = (status: string) => {
    switch (status) {
      case 'completed': return 'مكتمل';
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-muted/50">
            <th className="text-right py-3 px-4 font-medium">المشروع</th>
            <th className="text-right py-3 px-4 font-medium">الموقع</th>
            <th className="text-right py-3 px-4 font-medium">الحالة</th>
            <th className="text-right py-3 px-4 font-medium">التاريخ</th>
            <th className="text-right py-3 px-4 font-medium">المدة</th>
            <th className="text-right py-3 px-4 font-medium">الميزانية</th>
            <th className="text-right py-3 px-4 font-medium">الإنجاز</th>
            <th className="text-right py-3 px-4 font-medium">الإجراءات</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((project, index) => (
            <tr 
              key={project.id} 
              className={`border-b hover:bg-muted/20 ${index % 2 === 0 ? 'bg-muted/5' : ''}`}
            >
              <td className="py-3 px-4">
                <div className="font-medium">{project.name}</div>
                <div className="text-xs text-muted-foreground">{getCategoryText(project.category)}</div>
              </td>
              <td className="py-3 px-4">{project.location}</td>
              <td className="py-3 px-4">
                <Badge className={getStatusBadgeClass(project.status)}>
                  {getStatusDisplayText(project.status)}
                </Badge>
              </td>
              <td className="py-3 px-4">
                <div className="text-sm">{formatDate(new Date(project.startDate))}</div>
                <div className="text-xs text-muted-foreground">إلى {formatDate(new Date(project.endDate))}</div>
              </td>
              <td className="py-3 px-4">{project.duration} شهر</td>
              <td className="py-3 px-4 font-medium">{formatCurrency(project.budget)}</td>
              <td className="py-3 px-4">
                <div className="flex items-center space-x-2 space-x-reverse">
                  <div className="w-20 bg-gray-200 h-1.5 rounded-full">
                    <div 
                      className="bg-primary h-1.5 rounded-full" 
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                  <span className="text-sm">{project.progress}%</span>
                </div>
              </td>
              <td className="py-3 px-4">
                <div className="flex space-x-1 space-x-reverse">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 w-8 p-0" 
                    onClick={() => onViewDetails(project.id)}
                  >
                    <EyeIcon className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 w-8 p-0" 
                    onClick={() => onEdit(project)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-8 w-8 p-0 text-red-500" 
                    onClick={() => onDelete(project.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

// Project Analysis Dashboard Component
const ProjectDashboardView = ({
  projects,
  onViewDetails
}: {
  projects: Project[];
  onViewDetails: (projectId: number) => void;
}) => {
  // Calculate metrics
  const totalProjects = projects.length;
  const completedProjects = projects.filter(p => p.status === 'completed').length;
  const inProgressProjects = projects.filter(p => p.status === 'inProgress').length;
  const delayedProjects = projects.filter(p => p.status === 'delayed').length;
  const plannedProjects = projects.filter(p => p.status === 'planned').length;
  
  const totalBudget = projects.reduce((sum, project) => sum + project.budget, 0);
  
  // Find projects with highest and lowest progress
  const sortedByProgress = [...projects].sort((a, b) => b.progress - a.progress);
  const highestProgressProjects = sortedByProgress.slice(0, 3);
  const lowestProgressProjects = [...sortedByProgress].reverse().slice(0, 3);
  
  // Projects ending soon (next 30 days)
  const today = new Date();
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(today.getDate() + 30);
  
  const projectsEndingSoon = projects
    .filter(p => {
      const endDate = new Date(p.endDate);
      return endDate >= today && endDate <= thirtyDaysFromNow && p.status !== 'completed';
    })
    .sort((a, b) => new Date(a.endDate).getTime() - new Date(b.endDate).getTime());
  
  // Helper for progress color
  const getProgressColorClass = (progress: number, status: string) => {
    if (status === 'delayed') return 'text-red-500';
    if (progress < 25) return 'text-red-500';
    if (progress < 50) return 'text-yellow-500';
    if (progress < 75) return 'text-blue-500';
    return 'text-green-500';
  };

  return (
    <div className="space-y-6">
      {/* Summary stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي المشاريع</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProjects}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">قيد التنفيذ</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">{inProgressProjects}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((inProgressProjects / totalProjects) * 100)}% من المشاريع
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">مكتملة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{completedProjects}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((completedProjects / totalProjects) * 100)}% من المشاريع
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">متأخرة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{delayedProjects}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((delayedProjects / totalProjects) * 100)}% من المشاريع
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الميزانيات</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalBudget)}</div>
            <p className="text-xs text-muted-foreground">
              {formatCurrency(totalBudget / Math.max(1, totalProjects))} متوسط
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Info cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* Projects ending soon */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <CalendarRange className="ml-2 h-5 w-5 text-yellow-500" />
              مشاريع تنتهي قريباً
            </CardTitle>
            <CardDescription>المشاريع التي ستنتهي خلال 30 يوم</CardDescription>
          </CardHeader>
          <CardContent>
            {projectsEndingSoon.length > 0 ? (
              <div className="space-y-4">
                {projectsEndingSoon.map(project => (
                  <div key={project.id} className="flex items-center justify-between">
                    <div>
                      <div 
                        className="font-medium text-sm hover:text-primary cursor-pointer"
                        onClick={() => onViewDetails(project.id)}
                      >
                        {project.name}
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3 ml-1" />
                        {formatDate(new Date(project.endDate))}
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-20 bg-gray-200 h-1.5 rounded-full ml-2">
                        <div 
                          className="bg-primary h-1.5 rounded-full" 
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                      <span className={`text-xs font-medium ${getProgressColorClass(project.progress, project.status)}`}>
                        {project.progress}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                لا توجد مشاريع تنتهي خلال الفترة القادمة
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Highest progress projects */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <TrendingUp className="ml-2 h-5 w-5 text-green-500" />
              أعلى تقدم
            </CardTitle>
            <CardDescription>المشاريع ذات نسبة الإنجاز الأعلى</CardDescription>
          </CardHeader>
          <CardContent>
            {highestProgressProjects.length > 0 ? (
              <div className="space-y-4">
                {highestProgressProjects.map(project => (
                  <div key={project.id} className="flex items-center justify-between">
                    <div>
                      <div 
                        className="font-medium text-sm hover:text-primary cursor-pointer"
                        onClick={() => onViewDetails(project.id)}
                      >
                        {project.name}
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Badge className={
                          project.status === 'completed' ? 'bg-green-100 text-green-800' : 
                          project.status === 'inProgress' ? 'bg-yellow-100 text-yellow-800' : 
                          project.status === 'delayed' ? 'bg-red-100 text-red-800' : 
                          'bg-blue-100 text-blue-800'
                        }>
                          {project.status === 'completed' ? 'مكتمل' : 
                           project.status === 'inProgress' ? 'قيد التنفيذ' : 
                           project.status === 'delayed' ? 'متأخر' : 'مخطط'}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-20 bg-gray-200 h-1.5 rounded-full ml-2">
                        <div 
                          className="bg-green-500 h-1.5 rounded-full" 
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                      <span className="text-xs font-medium text-green-500">{project.progress}%</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                لا توجد بيانات متاحة
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Projects needing attention (low progress or delayed) */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <AlertTriangle className="ml-2 h-5 w-5 text-red-500" />
              تحتاج اهتمام
            </CardTitle>
            <CardDescription>المشاريع المتأخرة أو ذات الإنجاز المنخفض</CardDescription>
          </CardHeader>
          <CardContent>
            {lowestProgressProjects.length > 0 ? (
              <div className="space-y-4">
                {lowestProgressProjects
                  .filter(p => p.status !== 'completed' && p.status !== 'planned')
                  .map(project => (
                    <div key={project.id} className="flex items-center justify-between">
                      <div>
                        <div 
                          className="font-medium text-sm hover:text-primary cursor-pointer"
                          onClick={() => onViewDetails(project.id)}
                        >
                          {project.name}
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Badge className={
                            project.status === 'delayed' ? 'bg-red-100 text-red-800' : 
                            'bg-yellow-100 text-yellow-800'
                          }>
                            {project.status === 'delayed' ? 'متأخر' : 'قيد التنفيذ'}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <div className="w-20 bg-gray-200 h-1.5 rounded-full ml-2">
                          <div 
                            className="bg-red-500 h-1.5 rounded-full" 
                            style={{ width: `${project.progress}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium text-red-500">{project.progress}%</span>
                      </div>
                    </div>
                  ))}
              </div>
            ) : (
              <div className="text-center py-6 text-muted-foreground">
                لا توجد مشاريع تحتاج اهتمام حالياً
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      {/* Categories and Budget summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Projects by category */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">المشاريع حسب التصنيف</CardTitle>
          </CardHeader>
          <CardContent>
            {/* Here we'd normally have a chart, but for simplicity we'll use a table */}
            <div className="space-y-3">
              {[
                { category: 'electricity', label: 'كهرباء', color: 'bg-yellow-100' },
                { category: 'water', label: 'مياه', color: 'bg-blue-100' },
                { category: 'communications', label: 'اتصالات', color: 'bg-purple-100' },
                { category: 'roads', label: 'طرق', color: 'bg-green-100' },
                { category: 'buildings', label: 'مباني', color: 'bg-orange-100' }
              ].map(cat => {
                const count = projects.filter(p => p.category === cat.category).length;
                const percentage = Math.round((count / Math.max(1, totalProjects)) * 100);
                
                if (count === 0) return null;
                
                return (
                  <div key={cat.category} className="flex items-center">
                    <div className="ml-2">
                      <div className={`w-3 h-3 rounded-full ${cat.color}`}></div>
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between mb-1">
                        <span>{cat.label}</span>
                        <span className="font-medium">{count} مشروع</span>
                      </div>
                      <div className="w-full bg-gray-100 h-2 rounded-full">
                        <div 
                          className="h-2 rounded-full bg-primary" 
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                    <div className="mr-2 min-w-[40px] text-right">
                      <span className="text-sm">{percentage}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
        
        {/* Budget summary */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">ملخص الميزانية</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-sm text-muted-foreground">إجمالي الميزانيات</div>
                  <div className="text-xl font-bold">{formatCurrency(totalBudget)}</div>
                </div>
                <DollarSign className="h-8 w-8 text-primary/40" />
              </div>
              
              <Separator />
              
              <div className="space-y-3">
                {[
                  { status: 'completed', label: 'المشاريع المكتملة', icon: <CheckIcon className="h-4 w-4 text-green-500" /> },
                  { status: 'inProgress', label: 'المشاريع الجارية', icon: <Clock className="h-4 w-4 text-yellow-500" /> },
                  { status: 'delayed', label: 'المشاريع المتأخرة', icon: <AlertTriangle className="h-4 w-4 text-red-500" /> },
                  { status: 'planned', label: 'المشاريع المخططة', icon: <Calendar className="h-4 w-4 text-blue-500" /> }
                ].map(item => {
                  const projectsInCategory = projects.filter(p => p.status === item.status);
                  const budgetSum = projectsInCategory.reduce((sum, p) => sum + p.budget, 0);
                  const percentage = Math.round((budgetSum / Math.max(1, totalBudget)) * 100);
                  
                  if (projectsInCategory.length === 0) return null;
                  
                  return (
                    <div key={item.status} className="flex items-center space-x-4 space-x-reverse">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10">
                        {item.icon}
                      </div>
                      <div className="flex-grow">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm">{item.label}</span>
                          <span className="text-sm font-semibold">{formatCurrency(budgetSum)}</span>
                        </div>
                        <div className="flex items-center">
                          <div className="flex-grow">
                            <div className="w-full bg-gray-100 h-1.5 rounded-full">
                              <div 
                                className={`h-1.5 rounded-full ${
                                  item.status === 'completed' ? 'bg-green-500' : 
                                  item.status === 'inProgress' ? 'bg-yellow-500' : 
                                  item.status === 'delayed' ? 'bg-red-500' : 'bg-blue-500'
                                }`} 
                                style={{ width: `${percentage}%` }}
                              />
                            </div>
                          </div>
                          <span className="text-xs mr-2">{percentage}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Helper icon for budget/completed section
const CheckIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

// Projects page main component
const Projects = () => {
  const { data: projects, isLoading } = useProjects();
  const { data: users } = useUsers();
  const createProject = useCreateProject();
  const updateProject = useUpdateProject();
  const deleteProject = useDeleteProject();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [activeViewType, setActiveViewType] = useState<"grid" | "list" | "kanban" | "map" | "dashboard">("grid");
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  
  // Filter states
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [locationFilter, setLocationFilter] = useState<string | null>(null);
  const [budgetRangeFilter, setBudgetRangeFilter] = useState<[number, number] | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  
  // Dialog states
  const [showNewProjectDialog, setShowNewProjectDialog] = useState(false);
  const [showEditProjectDialog, setShowEditProjectDialog] = useState(false);
  const [showDeleteConfirmDialog, setShowDeleteConfirmDialog] = useState(false);
  
  // Editing states
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [projectToDelete, setProjectToDelete] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Additional data for project details view
  const { data: teamMembers } = useTeamByProject(selectedProjectId || 0);
  const { data: projectEquipment } = useEquipmentByProject(selectedProjectId || 0);
  const { data: projectExpenses } = useExpensesByProject(selectedProjectId || 0);
  const { data: projectInvoices } = useInvoicesByProject(selectedProjectId || 0);
  const { data: projectDailyReports } = useDailyReportsByProject(selectedProjectId || 0);
  const { data: projectDocuments } = useDocumentsByProject(selectedProjectId || 0);
  const { data: projectRisks } = useProjectRisks(selectedProjectId || 0);
  const { data: projectDeadlines } = useDeadlinesByProject(selectedProjectId || 0);
  const { data: projectActivities } = useActivitiesByProject(selectedProjectId || 0);

  // Find the selected project
  const selectedProject = selectedProjectId !== null 
    ? projects?.find(p => p.id === selectedProjectId) 
    : null;
  
  // Log for debugging
  console.log('Selected Project ID:', selectedProjectId);
  console.log('Selected Project Data:', selectedProject);

  // Filter projects based on search query, active tab, and additional filters
  const filteredProjects = projects?.filter(project => {
    // Search filter
    const matchesSearch = project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Status filter (tab)
    const matchesStatus = activeTab === "all" || project.status === activeTab;
    
    // Category filter
    const matchesCategory = !categoryFilter || project.category === categoryFilter;
    
    // Location filter
    const matchesLocation = !locationFilter || project.location.includes(locationFilter);
    
    // Budget range filter
    const matchesBudget = !budgetRangeFilter || 
      (project.budget >= budgetRangeFilter[0] && project.budget <= budgetRangeFilter[1]);
    
    return matchesSearch && matchesStatus && matchesCategory && matchesLocation && matchesBudget;
  });

  // Format date helper
  const formatDateForInput = (date: Date): string => {
    return date.toISOString().split('T')[0];
  };

  // Handlers
  const handleCreateProject = async (data: ProjectFormData) => {
    try {
      setIsSubmitting(true);
      
      // تأكد من تحويل القيم النصية إلى أنواع البيانات المناسبة
      const progress = data.progress ? parseInt(data.progress, 10) : 0;
      const duration = parseInt(data.duration, 10);
      const budget = parseFloat(data.budget);
      
      // Prepare data for server
      const projectData: InsertProject = {
        name: data.name,
        description: data.description,
        location: data.location,
        status: data.status,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
        duration: duration,
        budget: budget,
        category: data.category,
        progress: progress,
        imageUrl: data.imageUrl || null
      };
      
      console.log('Sending project data:', projectData);
      
      await createProject.mutateAsync(projectData);
      setShowNewProjectDialog(false);
      toast({
        title: "تم إضافة المشروع",
        description: "تم إضافة المشروع الجديد بنجاح",
      });
    } catch (error) {
      console.error('Error creating project:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء إضافة المشروع. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditProject = (project: Project) => {
    // Format dates for the form
    const formData = {
      ...project,
      startDate: formatDateForInput(new Date(project.startDate)),
      endDate: formatDateForInput(new Date(project.endDate)),
    };
    setCurrentProject(formData as unknown as Project);
    setShowEditProjectDialog(true);
  };

  const handleUpdateProject = async (data: ProjectFormData) => {
    if (!currentProject) return;
    
    try {
      setIsSubmitting(true);
      
      // تأكد من تحويل القيم النصية إلى أنواع البيانات المناسبة
      const progress = data.progress ? parseInt(data.progress, 10) : 0;
      const duration = parseInt(data.duration, 10);
      const budget = parseFloat(data.budget);
      
      // Prepare data for server
      const projectData: Partial<InsertProject> = {
        name: data.name,
        description: data.description,
        location: data.location,
        status: data.status,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
        duration: duration,
        budget: budget,
        category: data.category,
        progress: progress,
        imageUrl: data.imageUrl || null
      };
      
      await updateProject.mutateAsync({
        id: currentProject.id,
        project: projectData
      });
      
      setShowEditProjectDialog(false);
      toast({
        title: "تم تحديث المشروع",
        description: "تم تحديث المشروع بنجاح",
      });
    } catch (error) {
      console.error('Error updating project:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تحديث المشروع. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteConfirmation = (projectId: number) => {
    setProjectToDelete(projectId);
    setShowDeleteConfirmDialog(true);
  };

  const handleDeleteProject = async () => {
    if (!projectToDelete) return;
    
    try {
      await deleteProject.mutateAsync(projectToDelete);
      setShowDeleteConfirmDialog(false);
      setProjectToDelete(null);
      toast({
        title: "تم حذف المشروع",
        description: "تم حذف المشروع بنجاح",
      });
    } catch (error) {
      console.error('Error deleting project:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء حذف المشروع. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  const handleViewProjectDetails = (projectId: number) => {
    console.log('Viewing project details for ID:', projectId);
    setSelectedProjectId(projectId);
  };

  const handleBackToProjects = () => {
    setSelectedProjectId(null);
  };

  const handleUpdateProjectStatus = async (projectId: number, newStatus: string) => {
    const project = projects?.find(p => p.id === projectId);
    if (!project) return;
    
    try {
      await updateProject.mutateAsync({
        id: projectId,
        project: { status: newStatus }
      });
      toast({
        title: "تم تحديث حالة المشروع",
        description: `تم تغيير حالة المشروع إلى "${
          newStatus === 'completed' ? 'مكتمل' :
          newStatus === 'inProgress' ? 'قيد التنفيذ' :
          newStatus === 'delayed' ? 'متأخر' : 'مخطط'
        }"`,
      });
    } catch (error) {
      console.error('Error updating project status:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تحديث حالة المشروع.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  // Show project details if a project is selected
  if (selectedProject) {
    return (
      <ProjectDetailsView 
        project={selectedProject}
        dailyReports={projectDailyReports || []}
        expenses={projectExpenses || []}
        invoices={projectInvoices || []}
        team={teamMembers || []}
        equipment={projectEquipment || []}
        documents={projectDocuments || []}
        risks={projectRisks || []}
        deadlines={projectDeadlines || []}
        users={users || []}
        onBack={handleBackToProjects}
        onEdit={handleEditProject}
      />
    );
  }

  return (
    <div className="flex flex-col space-y-6">
      {/* Header with title and actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold dark:text-white">إدارة المشاريع</h1>
          <p className="text-muted-foreground mt-1">إدارة وتتبع مشاريع البنية التحتية</p>
        </div>
        <div className="flex items-center space-x-2 space-x-reverse">
          {/* View selection buttons */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                {activeViewType === "grid" && <LayoutDashboard className="h-4 w-4" />}
                {activeViewType === "list" && <List className="h-4 w-4" />}
                {activeViewType === "kanban" && <KanbanSquare className="h-4 w-4" />}
                {activeViewType === "map" && <MapIcon className="h-4 w-4" />}
                {activeViewType === "dashboard" && <BarChartIcon className="h-4 w-4" />}
                <span>طريقة العرض</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>اختر طريقة العرض</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setActiveViewType("grid")}>
                <LayoutDashboard className="h-4 w-4 ml-2" />
                <span>شبكة</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveViewType("list")}>
                <List className="h-4 w-4 ml-2" />
                <span>قائمة</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveViewType("kanban")}>
                <KanbanSquare className="h-4 w-4 ml-2" />
                <span>كانبان</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveViewType("map")}>
                <MapIcon className="h-4 w-4 ml-2" />
                <span>خريطة</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setActiveViewType("dashboard")}>
                <BarChartIcon className="h-4 w-4 ml-2" />
                <span>لوحة التحكم</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Popover open={showFilters} onOpenChange={setShowFilters}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1">
                <SlidersHorizontal className="h-4 w-4" />
                <span>تصفية</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-4">
                <h4 className="font-medium">تصفية حسب</h4>
                
                <div className="space-y-2">
                  <Label htmlFor="category-filter">التصنيف</Label>
                  <Select 
                    value={categoryFilter || ""} 
                    onValueChange={(val) => setCategoryFilter(val || null)}
                  >
                    <SelectTrigger id="category-filter">
                      <SelectValue placeholder="جميع التصنيفات" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all-categories">جميع التصنيفات</SelectItem>
                      <SelectItem value="electricity">كهرباء</SelectItem>
                      <SelectItem value="water">مياه</SelectItem>
                      <SelectItem value="communications">اتصالات</SelectItem>
                      <SelectItem value="roads">طرق</SelectItem>
                      <SelectItem value="buildings">مباني</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="location-filter">الموقع</Label>
                  <Input 
                    id="location-filter"
                    placeholder="جميع المواقع"
                    value={locationFilter || ""}
                    onChange={(e) => setLocationFilter(e.target.value || null)}
                  />
                </div>
                
                <div className="pt-2 flex justify-end space-x-2 space-x-reverse">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setCategoryFilter(null);
                      setLocationFilter(null);
                      setBudgetRangeFilter(null);
                    }}
                  >
                    إعادة ضبط
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => setShowFilters(false)}
                  >
                    تطبيق
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
          
          <Dialog open={showNewProjectDialog} onOpenChange={setShowNewProjectDialog}>
            <DialogTrigger asChild>
              <Button className="gap-1">
                <PlusIcon className="h-4 w-4" />
                <span>مشروع جديد</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>إضافة مشروع جديد</DialogTitle>
                <DialogDescription>
                  أضف مشروعًا جديدًا وحدد التفاصيل الأساسية له.
                </DialogDescription>
              </DialogHeader>
              <ProjectForm 
                onSubmit={handleCreateProject} 
                onCancel={() => setShowNewProjectDialog(false)}
                isSubmitting={isSubmitting}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Tab Filters */}
      {activeViewType !== "dashboard" && (
        <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="البحث عن مشروع..."
              className="pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="inProgress">قيد التنفيذ</TabsTrigger>
              <TabsTrigger value="planned">مخطط</TabsTrigger>
              <TabsTrigger value="delayed">متأخر</TabsTrigger>
              <TabsTrigger value="completed">مكتمل</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      )}

      {/* Different view types */}
      {activeViewType === "grid" && (
        <ProjectGridView 
          projects={filteredProjects || []} 
          onEdit={handleEditProject}
          onDelete={handleDeleteConfirmation}
          onViewDetails={handleViewProjectDetails}
        />
      )}
      
      {activeViewType === "list" && (
        <ProjectListView 
          projects={filteredProjects || []} 
          onEdit={handleEditProject}
          onDelete={handleDeleteConfirmation}
          onViewDetails={handleViewProjectDetails}
        />
      )}
      
      {activeViewType === "kanban" && (
        <ProjectKanbanView 
          projects={filteredProjects || []} 
          onEdit={handleEditProject}
          onDelete={handleDeleteConfirmation}
          onViewDetails={handleViewProjectDetails}
          onStatusChange={handleUpdateProjectStatus}
        />
      )}
      
      {activeViewType === "map" && (
        <ProjectMap 
          projects={filteredProjects || []} 
          onViewDetails={handleViewProjectDetails}
        />
      )}
      
      {activeViewType === "dashboard" && (
        <ProjectDashboardView 
          projects={filteredProjects || []} 
          onViewDetails={handleViewProjectDetails}
        />
      )}

      {/* Empty state */}
      {filteredProjects?.length === 0 && (
        <div className="text-center py-12">
          <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <h3 className="text-xl font-medium text-gray-600 dark:text-gray-300">لا توجد مشاريع مطابقة للبحث</h3>
          <p className="text-gray-500 mt-2 mb-6">حاول تغيير معايير البحث أو إضافة مشروع جديد</p>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <PlusIcon className="h-4 w-4 ml-2" />
                إضافة مشروع جديد
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl">
              <DialogHeader>
                <DialogTitle>إضافة مشروع جديد</DialogTitle>
                <DialogDescription>
                  أضف مشروعًا جديدًا وحدد التفاصيل الأساسية له.
                </DialogDescription>
              </DialogHeader>
              <ProjectForm 
                onSubmit={handleCreateProject} 
                onCancel={() => setShowNewProjectDialog(false)}
                isSubmitting={isSubmitting}
              />
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Edit project dialog */}
      <Dialog open={showEditProjectDialog} onOpenChange={setShowEditProjectDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>تعديل المشروع</DialogTitle>
            <DialogDescription>
              تعديل تفاصيل المشروع.
            </DialogDescription>
          </DialogHeader>
          {currentProject && (
            <ProjectForm 
              initialData={currentProject as unknown as ProjectFormData}
              onSubmit={handleUpdateProject}
              onCancel={() => setShowEditProjectDialog(false)}
              isSubmitting={isSubmitting}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Delete confirmation dialog */}
      <Dialog open={showDeleteConfirmDialog} onOpenChange={setShowDeleteConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد حذف المشروع</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا المشروع؟ لا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end space-x-2 space-x-reverse pt-4">
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteConfirmDialog(false)}
            >
              إلغاء
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteProject}
              disabled={deleteProject.isPending}
            >
              {deleteProject.isPending ? "جاري الحذف..." : "حذف المشروع"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Projects;