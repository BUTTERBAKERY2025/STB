import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChevronLeft, ChevronRight, BarChart, PieChart, LineChart, CalendarRange, FileSpreadsheet, FileText, Truck, FileBarChart } from 'lucide-react';
import ProjectPerformanceReport from '@/components/reports/ProjectPerformanceReport';
import ResourceUsageReport from '@/components/reports/ResourceUsageReport';
import ProjectStatusReport from '@/components/reports/ProjectStatusReport';
import FinancialReport from '@/components/reports/FinancialReport';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const ReportsPage = () => {
  const [activeTab, setActiveTab] = useState('performance');
  const { toast } = useToast();

  const handleReportTypeChange = (value: string) => {
    setActiveTab(value);
  };

  const handleExportAll = () => {
    toast({
      title: "تصدير التقارير",
      description: "سيتم توفير وظيفة تصدير كافة التقارير قريبًا",
    });
  };

  const handleScheduleReports = () => {
    toast({
      title: "جدولة التقارير",
      description: "سيتم توفير وظيفة جدولة التقارير قريبًا",
    });
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">التقارير والتحليلات</h1>
          <p className="text-muted-foreground mt-1">
            عرض تقارير مفصلة وتحليلات لأداء المشاريع والمؤشرات المالية
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleScheduleReports}>
            <CalendarRange className="ml-2 h-4 w-4" />
            جدولة التقارير
          </Button>
          <Button variant="outline" onClick={handleExportAll}>
            <FileSpreadsheet className="ml-2 h-4 w-4" />
            تصدير الكل
          </Button>
        </div>
      </div>

      <div className="bg-muted/40 rounded-lg p-4">
        <div className="flex items-center justify-center gap-6 mb-6 overflow-x-auto">
          <button 
            onClick={() => handleReportTypeChange('performance')}
            className={`flex flex-col items-center p-3 rounded-lg transition-all ${
              activeTab === 'performance' 
                ? 'bg-primary/10 text-primary' 
                : 'hover:bg-muted'
            }`}
          >
            <BarChart className="h-6 w-6 mb-1" />
            <span className="text-sm font-medium">أداء المشاريع</span>
          </button>
          
          <button 
            onClick={() => handleReportTypeChange('financial')}
            className={`flex flex-col items-center p-3 rounded-lg transition-all ${
              activeTab === 'financial' 
                ? 'bg-primary/10 text-primary' 
                : 'hover:bg-muted'
            }`}
          >
            <PieChart className="h-6 w-6 mb-1" />
            <span className="text-sm font-medium">التقارير المالية</span>
          </button>
          
          <button 
            onClick={() => handleReportTypeChange('resource')}
            className={`flex flex-col items-center p-3 rounded-lg transition-all ${
              activeTab === 'resource' 
                ? 'bg-primary/10 text-primary' 
                : 'hover:bg-muted'
            }`}
          >
            <Truck className="h-6 w-6 mb-1" />
            <span className="text-sm font-medium">استخدام الموارد</span>
          </button>
          
          <button 
            onClick={() => handleReportTypeChange('status')}
            className={`flex flex-col items-center p-3 rounded-lg transition-all ${
              activeTab === 'status' 
                ? 'bg-primary/10 text-primary' 
                : 'hover:bg-muted'
            }`}
          >
            <FileBarChart className="h-6 w-6 mb-1" />
            <span className="text-sm font-medium">تقارير الحالة</span>
          </button>
        </div>

        <div>
          {activeTab === 'performance' && (
            <ProjectPerformanceReport />
          )}
          
          {activeTab === 'financial' && (
            <FinancialReport />
          )}
          
          {activeTab === 'resource' && (
            <ResourceUsageReport />
          )}
          
          {activeTab === 'status' && (
            <ProjectStatusReport />
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;