import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  FileText, Download, PlusIcon, Filter, ArrowUp, ArrowDown, Calculator, Printer,
  Calendar, DollarSign, BarChart2, PieChart, TrendingUp, TrendingDown, 
  Layers, FileSpreadsheet, ChevronRight, ClipboardList, CreditCard, Banknote
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/utils";
import { 
  useProjects, 
  useExpensesByProject, 
  useInvoicesByProject, 
  useCreateExpense, 
  useCreateInvoice,
  useCreateActivity,
  useUpdateExpense,
  useUpdateInvoice
} from "@/lib/data";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const FinancialReports = () => {
  const { toast } = useToast();
  
  // State
  const [activeTab, setActiveTab] = useState<string>("financial-center");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("all");
  
  // Refs for print and export
  const reportRef = useRef<HTMLDivElement>(null);
  
  // Queries and Mutations
  const { data: projects, isLoading: isLoadingProjects } = useProjects();
  const { data: expenses, isLoading: isLoadingExpenses } = 
    useExpensesByProject(selectedProjectId !== "all" ? parseInt(selectedProjectId) : 0);
  const { data: invoices, isLoading: isLoadingInvoices } = 
    useInvoicesByProject(selectedProjectId !== "all" ? parseInt(selectedProjectId) : 0);
  
  const { mutate: createActivity } = useCreateActivity();

  // تحديث عنوان URL عندما يتم تغيير التبويب أو المشروع
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    const projectParam = urlParams.get('project');
    
    if (tabParam) {
      setActiveTab(tabParam);
    }
    
    if (projectParam) {
      setSelectedProjectId(projectParam);
    }
  }, []);

  // الحصول على اسم المشروع من معرفه
  const getProjectName = (projectId: number) => {
    if (!projects) return "غير معروف";
    const project = projects.find((p: { id: number; name: string }) => p.id === projectId);
    return project ? project.name : "غير معروف";
  };

  // Calculate totals for selected project
  const totalExpenses = expenses
    ? expenses.reduce((sum: number, expense: { amount: number }) => sum + expense.amount, 0)
    : 0;
    
  const totalInvoices = invoices
    ? invoices.reduce((sum: number, invoice: { amount: number }) => sum + invoice.amount, 0)
    : 0;
    
  const balance = totalInvoices - totalExpenses;
  const netMargin = totalInvoices > 0 ? (balance / totalInvoices) * 100 : 0;

  // تجهيز البيانات لعرض المؤشرات المالية
  const financialIndicators = [
    { 
      name: "إجمالي الإيرادات", 
      value: totalInvoices, 
      change: 5.3, 
      trend: "up", 
      color: "text-green-500",
      icon: <TrendingUp className="h-4 w-4 text-green-500" />
    },
    { 
      name: "إجمالي المصروفات", 
      value: totalExpenses, 
      change: 2.1, 
      trend: "up", 
      color: "text-yellow-500",
      icon: <TrendingUp className="h-4 w-4 text-yellow-500" />
    },
    { 
      name: "صافي الأرباح", 
      value: balance, 
      change: 8.9, 
      trend: balance > 0 ? "up" : "down", 
      color: balance > 0 ? "text-green-500" : "text-red-500",
      icon: balance > 0 
        ? <TrendingUp className="h-4 w-4 text-green-500" /> 
        : <TrendingDown className="h-4 w-4 text-red-500" />
    },
    { 
      name: "هامش الربح", 
      value: netMargin, 
      isPercentage: true,
      change: 1.4, 
      trend: netMargin > 0 ? "up" : "down", 
      color: netMargin > 0 ? "text-green-500" : "text-red-500",
      icon: netMargin > 0 
        ? <TrendingUp className="h-4 w-4 text-green-500" /> 
        : <TrendingDown className="h-4 w-4 text-red-500" />
    }
  ];

  // طباعة التقرير
  const handlePrint = () => {
    if (selectedProjectId === "all" || !reportRef.current) return;
    
    const projectName = getProjectName(parseInt(selectedProjectId));
    const currentDate = new Date().toLocaleDateString('ar-SA');
    
    // تحضير نافذة الطباعة
    const printWindow = window.open('', 'PRINT', 'height=800,width=1200');
    
    if (!printWindow) return;
    
    // إنشاء نسخة من محتوى العنصر
    const contentElement = reportRef.current.cloneNode(true) as HTMLElement;
    
    // إزالة الأزرار من النسخة المطبوعة
    const buttonsToRemove = contentElement.querySelectorAll('button');
    buttonsToRemove.forEach(button => button.remove());
    
    // الحصول على محتوى النسخة المعدلة
    const reportContent = contentElement.innerHTML;
    
    // إضافة CSS للطباعة
    const printCSS = `
      <style>
        @font-face {
          font-family: 'Tajawal';
          src: url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');
          font-weight: normal;
          font-style: normal;
        }
        
        @media print {
          @page { 
            size: A4; 
            margin: 15mm; 
          }
          
          * {
            box-sizing: border-box;
            font-family: 'Tajawal', 'Arial', 'Tahoma', sans-serif;
          }
          
          body {
            direction: rtl;
            text-align: right;
            color: #333;
            line-height: 1.6;
            font-size: 12pt;
            background-color: white;
          }
          
          h1, h2, h3, h4, h5 { 
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 10px;
          }
          
          table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 1.5rem;
            page-break-inside: auto;
            border: 1px solid #ddd;
          }
          
          tr { 
            page-break-inside: avoid; 
            page-break-after: auto;
          }
          
          table th, table td { 
            padding: 8px; 
            border: 1px solid #ddd; 
            text-align: right; 
            font-size: 11pt;
          }
          
          table th { 
            background-color: #f2f2f2 !important; 
            font-weight: bold;
            color: #333 !important;
          }
          
          .card, .grid > div { 
            border: 1px solid #ddd !important; 
            padding: 15px !important; 
            margin-bottom: 15px !important; 
            border-radius: 5px !important; 
            page-break-inside: avoid;
            background-color: white !important;
          }
          
          .header { 
            border-bottom: 2px solid #444;
            margin-bottom: 25px;
            padding-bottom: 15px;
            text-align: center !important;
            display: block !important;
          }
          
          .footer { 
            margin-top: 40px; 
            padding-top: 10px;
            border-top: 1px solid #ddd;
            text-align: center; 
            font-size: 10pt; 
            color: #666; 
          }
          
          .text-green-600, .text-green-500 { color: #16a34a !important; }
          .text-red-600, .text-red-500 { color: #dc2626 !important; }
          .text-yellow-600, .text-yellow-500 { color: #ca8a04 !important; }
          .text-blue-600, .text-blue-500 { color: #2563eb !important; }
          
          .font-bold { font-weight: bold !important; }
          .text-center { text-align: center !important; }
          .text-right { text-align: right !important; }
          
          .grid {
            display: grid !important;
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 15px !important;
            page-break-inside: avoid;
          }
          
          button, 
          .no-print { 
            display: none !important; 
          }
          
          a { 
            text-decoration: none;
            color: inherit;
          }
          
          .rounded-lg, .rounded-md {
            border-radius: 5px !important;
          }
          
          .p-4, .p-6 {
            padding: 15px !important;
          }
        }
      </style>
    `;
    
    // إنشاء هيكل المستند للطباعة
    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>التقرير المالي - ${projectName}</title>
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
        ${printCSS}
      </head>
      <body>
        <div class="header">
          <h1>نظام إدارة مشاريع البنية التحتية</h1>
          <h2>التقرير المالي: ${projectName}</h2>
          <p>تاريخ التقرير: ${currentDate}</p>
        </div>
        
        <div id="print-content">
          ${reportContent}
        </div>
        
        <div class="footer">
          <p>نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}</p>
        </div>
      </body>
      </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 1000);
    
    // تسجيل نشاط الطباعة
    if (selectedProjectId !== "all") {
      createActivity({
        projectId: parseInt(selectedProjectId),
        userId: 1, // يجب استبداله بمعرف المستخدم الحالي
        action: "طباعة تقرير",
        description: `تمت طباعة التقرير المالي للمشروع: ${projectName}`,
        category: "financial"
      });
    }
  };

  // تصدير التقرير كملف PDF
  const handleExportPDF = async () => {
    if (selectedProjectId === "all" || !reportRef.current) return;
    
    try {
      const projectName = getProjectName(parseInt(selectedProjectId));
      const filename = `تقرير_مالي_${projectName}_${new Date().toISOString().split('T')[0]}.pdf`;
      
      toast({
        title: "جاري التصدير",
        description: "يتم الآن تصدير البيانات إلى ملف PDF...",
      });
      
      const canvas = await html2canvas(reportRef.current, {
        scale: 2,
        useCORS: true,
        logging: false
      });
      
      const imgData = canvas.toDataURL('image/png');
      
      // استخدام جودة أعلى ودعم للعربية
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });
      
      // إضافة خط يدعم العربية
      pdf.addFont('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap', 'Tajawal', 'normal');
      pdf.setFont('Tajawal');
      pdf.setR2L(true);
      
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pageWidth / imgWidth, pageHeight / imgHeight);
      const imgX = (pageWidth - imgWidth * ratio) / 2;
      const imgY = 30;
      
      // إضافة عنوان التقرير
      pdf.setFontSize(18);
      pdf.text(`التقرير المالي - ${projectName}`, pageWidth / 2, 15, { align: 'center' });
      pdf.setFontSize(10);
      pdf.text(`تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}`, pageWidth / 2, 22, { align: 'center' });
      
      // إضافة الصورة
      pdf.addImage(imgData, 'PNG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      
      // إضافة ترويسة وتذييل
      pdf.setFontSize(8);
      const footerText = `نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}`;
      pdf.text(footerText, pageWidth / 2, pageHeight - 10, { align: 'center' });
      
      pdf.save(filename);
      
      toast({
        title: "تم التصدير بنجاح",
        description: `تم تصدير التقرير المالي بنجاح كملف PDF.`,
      });
      
      // تسجيل نشاط التصدير
      if (selectedProjectId !== "all") {
        createActivity({
          projectId: parseInt(selectedProjectId),
          userId: 1, // يجب استبداله بمعرف المستخدم الحالي
          action: "تصدير تقرير",
          description: `تم تصدير التقرير المالي للمشروع: ${projectName} كملف PDF`,
          category: "financial"
        });
      }
    } catch (error) {
      console.error("خطأ في تصدير ملف PDF:", error);
      toast({
        title: "فشل التصدير",
        description: "حدث خطأ أثناء تصدير التقرير. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">التقارير المالية</h1>
        
        <div className="flex items-center gap-2">
          <Select 
            value={selectedProjectId} 
            onValueChange={setSelectedProjectId}
          >
            <SelectTrigger className="w-[240px]">
              <SelectValue placeholder="اختر المشروع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع المشاريع</SelectItem>
              {projects?.map((project: { id: number; name: string }) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={handlePrint}
            disabled={selectedProjectId === "all"}
          >
            <Printer className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={handleExportPDF}
            disabled={selectedProjectId === "all"}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* نظام تبويبات محسن باستخدام Shadcn Tabs */}
      <Tabs 
        defaultValue={activeTab} 
        value={activeTab} 
        onValueChange={(value) => {
          // تحديث عنوان URL
          window.history.pushState({}, "", `/financial-reports?tab=${value}`);
          setActiveTab(value);
        }}
        className="w-full"
      >
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="financial-center" className="flex items-center gap-1">
            <BarChart2 className="h-4 w-4" />
            <span>المركز المالي</span>
          </TabsTrigger>
          <TabsTrigger value="income-statement" className="flex items-center gap-1">
            <TrendingUp className="h-4 w-4" />
            <span>قائمة الدخل</span>
          </TabsTrigger>
          <TabsTrigger value="cash-flow" className="flex items-center gap-1">
            <Banknote className="h-4 w-4" />
            <span>التدفق النقدي</span>
          </TabsTrigger>
          <TabsTrigger value="budget-monitoring" className="flex items-center gap-1">
            <ClipboardList className="h-4 w-4" />
            <span>مراقبة الموازنة</span>
          </TabsTrigger>
        </TabsList>
        
        {/* محتوى التبويب: المركز المالي */}
        <TabsContent value="financial-center" className="space-y-4" ref={reportRef}>
          {selectedProjectId === "all" ? (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>المركز المالي</CardTitle>
                <CardDescription>يرجى اختيار مشروع محدد لعرض المركز المالي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <FileSpreadsheet className="h-12 w-12 mb-2" />
                  <h3 className="text-lg font-medium mb-1">لا توجد بيانات</h3>
                  <p>يرجى اختيار مشروع محدد من القائمة أعلاه لعرض المركز المالي الخاص به.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* بطاقات المؤشرات الرئيسية */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                {financialIndicators.map((indicator, idx) => (
                  <Card key={idx}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">{indicator.name}</p>
                          <h3 className={`text-2xl font-bold ${indicator.color}`}>
                            {indicator.isPercentage 
                              ? `${indicator.value.toFixed(1)}%` 
                              : formatCurrency(indicator.value)}
                          </h3>
                        </div>
                        <div className={`p-2 rounded-full bg-muted`}>
                          {indicator.icon}
                        </div>
                      </div>
                      <div className="flex items-center mt-2 text-xs">
                        {indicator.trend === "up" ? (
                          <ArrowUp className="h-3 w-3 mr-1 text-green-500" />
                        ) : (
                          <ArrowDown className="h-3 w-3 mr-1 text-red-500" />
                        )}
                        <span 
                          className={indicator.trend === "up" ? "text-green-500" : "text-red-500"}
                        >
                          {indicator.change}%
                        </span>
                        <span className="text-muted-foreground mr-1">منذ الشهر الماضي</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* الأصول والخصوم */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center">
                      <Layers className="h-5 w-5 mr-2" />
                      الأصول
                    </CardTitle>
                    <CardDescription>
                      تفاصيل أصول المشروع
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>البند</TableHead>
                          <TableHead className="text-left">المبلغ</TableHead>
                          <TableHead className="text-left">النسبة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">النقد وما في حكمه</TableCell>
                          <TableCell className="text-left">{formatCurrency(balance > 0 ? balance : 0)}</TableCell>
                          <TableCell className="text-left">60%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">مستحقات على العملاء</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.3)}</TableCell>
                          <TableCell className="text-left">25%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">مخزون المواد</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.15)}</TableCell>
                          <TableCell className="text-left">10%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">معدات وأدوات</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.1)}</TableCell>
                          <TableCell className="text-left">5%</TableCell>
                        </TableRow>
                        <TableRow className="bg-muted/50">
                          <TableCell className="font-bold">إجمالي الأصول</TableCell>
                          <TableCell className="text-left font-bold">
                            {formatCurrency(
                              (balance > 0 ? balance : 0) + 
                              (totalInvoices * 0.3) + 
                              (totalExpenses * 0.15) + 
                              (totalExpenses * 0.1)
                            )}
                          </TableCell>
                          <TableCell className="text-left font-bold">100%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center">
                      <Layers className="h-5 w-5 mr-2" />
                      الخصوم وحقوق الملكية
                    </CardTitle>
                    <CardDescription>
                      تفاصيل خصوم المشروع وحقوق الملكية
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>البند</TableHead>
                          <TableHead className="text-left">المبلغ</TableHead>
                          <TableHead className="text-left">النسبة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">مستحقات للموردين</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.25)}</TableCell>
                          <TableCell className="text-left">15%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">دفعات مقدمة من العملاء</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.4)}</TableCell>
                          <TableCell className="text-left">25%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">قروض قصيرة الأجل</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.1)}</TableCell>
                          <TableCell className="text-left">10%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">راس المال المستثمر</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2)}</TableCell>
                          <TableCell className="text-left">20%</TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">أرباح مبقاة</TableCell>
                          <TableCell className="text-left">{formatCurrency(balance > 0 ? balance * 0.8 : 0)}</TableCell>
                          <TableCell className="text-left">30%</TableCell>
                        </TableRow>
                        <TableRow className="bg-muted/50">
                          <TableCell className="font-bold">إجمالي الخصوم وحقوق الملكية</TableCell>
                          <TableCell className="text-left font-bold">
                            {formatCurrency(
                              (totalExpenses * 0.25) + 
                              (totalInvoices * 0.4) + 
                              (totalExpenses * 0.1) + 
                              (totalInvoices * 0.2) + 
                              (balance > 0 ? balance * 0.8 : 0)
                            )}
                          </TableCell>
                          <TableCell className="text-left font-bold">100%</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
              
              {/* ملخص الحالة المالية للمشروع */}
              <Card>
                <CardHeader>
                  <CardTitle>ملخص الحالة المالية للمشروع</CardTitle>
                  <CardDescription>
                    توضيح عام للحالة المالية والمؤشرات الرئيسية للمشروع: {getProjectName(parseInt(selectedProjectId))}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-sm space-y-2">
                    <p>
                      <span className="font-semibold">تقييم الحالة المالية العامة:</span> {' '}
                      {balance > 0 
                        ? "المشروع يحقق ربحاً جيداً ويسير بشكل مستقر مالياً" 
                        : "المشروع يحتاج إلى مراجعة مالية وتعديل خطة الإنفاق"}
                    </p>
                    
                    <p>
                      <span className="font-semibold">الهامش الربحي:</span> {' '}
                      {netMargin.toFixed(1)}% {' '}
                      {netMargin > 20 
                        ? "(ممتاز)" 
                        : netMargin > 10 
                        ? "(جيد)" 
                        : netMargin > 0 
                        ? "(مقبول)" 
                        : "(ضعيف)"}
                    </p>
                    
                    <p>
                      <span className="font-semibold">السيولة النقدية:</span> {' '}
                      {balance > 0 
                        ? "جيدة، المشروع يمتلك سيولة كافية لتغطية المصروفات المستقبلية" 
                        : "ضعيفة، يجب العمل على زيادة التدفق النقدي للمشروع"}
                    </p>
                    
                    <p>
                      <span className="font-semibold">نسبة المصروفات من الإيرادات:</span> {' '}
                      {totalInvoices > 0 
                        ? `${((totalExpenses / totalInvoices) * 100).toFixed(1)}%` 
                        : "غير محدد"} {' '}
                      {totalInvoices > 0 && (totalExpenses / totalInvoices) < 0.7 
                        ? "(جيد)" 
                        : totalInvoices > 0 && (totalExpenses / totalInvoices) < 0.9 
                        ? "(مقبول)" 
                        : "(مرتفع)"}
                    </p>
                    
                    <p>
                      <span className="font-semibold">التوصيات:</span> {' '}
                      {balance > 0 && netMargin > 15
                        ? "الاستمرار في المسار الحالي مع توسيع نطاق الأعمال" 
                        : balance > 0 
                        ? "تحسين كفاءة المصروفات وزيادة هامش الربح" 
                        : "إعادة هيكلة خطة المصروفات وتسريع تحصيل الإيرادات"}
                    </p>
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/30 flex justify-between">
                  <p className="text-sm text-muted-foreground">
                    تاريخ التحديث: {new Date().toLocaleDateString('ar-SA')}
                  </p>
                  <Button variant="ghost" size="sm" className="gap-1">
                    <FileText className="h-4 w-4" />
                    تقرير مفصل
                  </Button>
                </CardFooter>
              </Card>
            </>
          )}
        </TabsContent>
        
        {/* محتوى التبويب: قائمة الدخل */}
        <TabsContent value="income-statement" className="space-y-4">
          {selectedProjectId === "all" ? (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>قائمة الدخل</CardTitle>
                <CardDescription>يرجى اختيار مشروع محدد لعرض قائمة الدخل</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <FileSpreadsheet className="h-12 w-12 mb-2" />
                  <h3 className="text-lg font-medium mb-1">لا توجد بيانات</h3>
                  <p>يرجى اختيار مشروع محدد من القائمة أعلاه لعرض قائمة الدخل الخاصة به.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>قائمة الدخل</CardTitle>
                <CardDescription>قائمة الدخل للمشروع: {getProjectName(parseInt(selectedProjectId))}</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>البند</TableHead>
                      <TableHead className="text-left">المبلغ</TableHead>
                      <TableHead className="text-left">النسبة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-semibold">إجمالي الإيرادات</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices)}</TableCell>
                      <TableCell className="text-left">100%</TableCell>
                    </TableRow>
                    <TableRow className="border-t border-muted">
                      <TableCell colSpan={3} className="font-semibold py-2">تكاليف مباشرة</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">تكاليف المواد</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.45)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.45 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">تكاليف العمالة</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.3)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.3 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">تكاليف المعدات</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.15)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.15 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/30">
                      <TableCell className="font-medium">إجمالي التكاليف المباشرة</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.9)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.9 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="font-medium">
                      <TableCell>مجمل الربح</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices - (totalExpenses * 0.9))}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? (((totalInvoices - (totalExpenses * 0.9)) / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-t border-muted">
                      <TableCell colSpan={3} className="font-semibold py-2">مصروفات إدارية وعمومية</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">المصروفات الإدارية</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.05)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.05 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">مصروفات التسويق</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.03)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.03 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">مصروفات أخرى</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.02)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.02 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/30">
                      <TableCell className="font-medium">إجمالي المصروفات الإدارية والعمومية</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalExpenses * 0.1)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((totalExpenses * 0.1 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="font-bold bg-muted">
                      <TableCell>صافي الربح قبل الضريبة</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices - totalExpenses)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? ((balance / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">الضريبة (15%)</TableCell>
                      <TableCell className="text-left">{formatCurrency(balance > 0 ? balance * 0.15 : 0)}</TableCell>
                      <TableCell className="text-left">
                        {balance > 0 && totalInvoices > 0 ? ((balance * 0.15 / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                    <TableRow className="font-bold text-lg">
                      <TableCell>صافي الربح بعد الضريبة</TableCell>
                      <TableCell className="text-left">{formatCurrency(balance > 0 ? balance * 0.85 : balance)}</TableCell>
                      <TableCell className="text-left">
                        {totalInvoices > 0 ? (((balance > 0 ? balance * 0.85 : balance) / totalInvoices) * 100).toFixed(1) : 0}%
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="bg-muted/30 flex justify-between">
                <p className="text-sm text-muted-foreground">
                  تاريخ التحديث: {new Date().toLocaleDateString('ar-SA')}
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-1" onClick={handlePrint}>
                    <Printer className="h-4 w-4" />
                    طباعة
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1" onClick={handleExportPDF}>
                    <Download className="h-4 w-4" />
                    تصدير PDF
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
        
        {/* محتوى التبويب: التدفق النقدي */}
        <TabsContent value="cash-flow" className="space-y-4">
          {selectedProjectId === "all" ? (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>التدفق النقدي</CardTitle>
                <CardDescription>يرجى اختيار مشروع محدد لعرض التدفق النقدي</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <FileSpreadsheet className="h-12 w-12 mb-2" />
                  <h3 className="text-lg font-medium mb-1">لا توجد بيانات</h3>
                  <p>يرجى اختيار مشروع محدد من القائمة أعلاه لعرض معلومات التدفق النقدي.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>قائمة التدفق النقدي</CardTitle>
                <CardDescription>قائمة التدفق النقدي للمشروع: {getProjectName(parseInt(selectedProjectId))}</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>البند</TableHead>
                      <TableHead className="text-left">الربع الأول</TableHead>
                      <TableHead className="text-left">الربع الثاني</TableHead>
                      <TableHead className="text-left">الربع الثالث</TableHead>
                      <TableHead className="text-left">الربع الرابع</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="font-medium">
                      <TableCell>الرصيد الافتتاحي</TableCell>
                      <TableCell className="text-left">{formatCurrency(0)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.35)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.5)}</TableCell>
                    </TableRow>
                    <TableRow className="border-t border-muted">
                      <TableCell colSpan={5} className="font-semibold py-2">التدفقات النقدية من الأنشطة التشغيلية</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">تحصيلات من العملاء</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.3)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.25)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.25)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">مدفوعات للموردين والعاملين</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.35)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.25)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.25)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.15)})</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">مدفوعات ضرائب</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(0)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(balance > 0 ? balance * 0.05 : 0)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(balance > 0 ? balance * 0.05 : 0)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(balance > 0 ? balance * 0.05 : 0)})</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/30">
                      <TableCell className="font-medium">صافي التدفق النقدي من الأنشطة التشغيلية</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.3 - totalExpenses * 0.35)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.25 - totalExpenses * 0.25 - (balance > 0 ? balance * 0.05 : 0))}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.25 - totalExpenses * 0.25 - (balance > 0 ? balance * 0.05 : 0))}</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2 - totalExpenses * 0.15 - (balance > 0 ? balance * 0.05 : 0))}</TableCell>
                    </TableRow>
                    <TableRow className="border-t border-muted">
                      <TableCell colSpan={5} className="font-semibold py-2">التدفقات النقدية من الأنشطة الاستثمارية</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">شراء معدات وأدوات</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.1)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(0)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(0)})</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/30">
                      <TableCell className="font-medium">صافي التدفق النقدي من الأنشطة الاستثمارية</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.1)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left">({formatCurrency(0)})</TableCell>
                      <TableCell className="text-left">({formatCurrency(0)})</TableCell>
                    </TableRow>
                    <TableRow className="border-t border-muted">
                      <TableCell colSpan={5} className="font-semibold py-2">التدفقات النقدية من الأنشطة التمويلية</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">تمويل رأس المال</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(0)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(0)}</TableCell>
                      <TableCell className="text-left">{formatCurrency(0)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="pl-6">سداد قروض</TableCell>
                      <TableCell className="text-left">({formatCurrency(0)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                    </TableRow>
                    <TableRow className="bg-muted/30">
                      <TableCell className="font-medium">صافي التدفق النقدي من الأنشطة التمويلية</TableCell>
                      <TableCell className="text-left">{formatCurrency(totalInvoices * 0.2)}</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                      <TableCell className="text-left text-red-500">({formatCurrency(totalExpenses * 0.05)})</TableCell>
                    </TableRow>
                    <TableRow className="font-bold bg-muted">
                      <TableCell>صافي التغير في النقد</TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.3 - totalExpenses * 0.35 - totalExpenses * 0.1 + totalInvoices * 0.2)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.25 - totalExpenses * 0.25 - (balance > 0 ? balance * 0.05 : 0) - totalExpenses * 0.05 - totalExpenses * 0.05)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.25 - totalExpenses * 0.25 - (balance > 0 ? balance * 0.05 : 0) - totalExpenses * 0.05)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.2 - totalExpenses * 0.15 - (balance > 0 ? balance * 0.05 : 0) - totalExpenses * 0.05)}
                      </TableCell>
                    </TableRow>
                    <TableRow className="font-bold text-lg">
                      <TableCell>الرصيد النقدي النهائي</TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.2)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.35)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.5)}
                      </TableCell>
                      <TableCell className="text-left">
                        {formatCurrency(totalInvoices * 0.65)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="bg-muted/30 flex justify-between">
                <p className="text-sm text-muted-foreground">
                  تاريخ التحديث: {new Date().toLocaleDateString('ar-SA')}
                </p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-1" onClick={handlePrint}>
                    <Printer className="h-4 w-4" />
                    طباعة
                  </Button>
                  <Button variant="outline" size="sm" className="gap-1" onClick={handleExportPDF}>
                    <Download className="h-4 w-4" />
                    تصدير PDF
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )}
        </TabsContent>
        
        {/* محتوى التبويب: مراقبة الموازنة */}
        <TabsContent value="budget-monitoring" className="space-y-4">
          {selectedProjectId === "all" ? (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>مراقبة الموازنة</CardTitle>
                <CardDescription>يرجى اختيار مشروع محدد لعرض مراقبة الموازنة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <FileSpreadsheet className="h-12 w-12 mb-2" />
                  <h3 className="text-lg font-medium mb-1">لا توجد بيانات</h3>
                  <p>يرجى اختيار مشروع محدد من القائمة أعلاه لعرض بيانات مراقبة الموازنة.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>مراقبة الموازنة واستخدام المخصصات</CardTitle>
                  <CardDescription>تحليل استخدام الموازنة للمشروع: {getProjectName(parseInt(selectedProjectId))}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="border-2 border-primary/20">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-muted-foreground">الموازنة المخططة</p>
                              <h3 className="text-2xl font-bold text-primary">
                                {formatCurrency(totalInvoices * 1.1)}
                              </h3>
                            </div>
                            <div className="p-2 rounded-full bg-primary/10">
                              <ClipboardList className="h-5 w-5 text-primary" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="border-2 border-yellow-500/20">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-muted-foreground">المصروفات الفعلية</p>
                              <h3 className="text-2xl font-bold text-yellow-500">
                                {formatCurrency(totalExpenses)}
                              </h3>
                            </div>
                            <div className="p-2 rounded-full bg-yellow-500/10">
                              <CreditCard className="h-5 w-5 text-yellow-500" />
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className={`border-2 ${totalExpenses <= totalInvoices ? 'border-green-500/20' : 'border-red-500/20'}`}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm text-muted-foreground">نسبة استخدام الموازنة</p>
                              <h3 className={`text-2xl font-bold ${totalExpenses <= totalInvoices * 1.1 ? 'text-green-500' : 'text-red-500'}`}>
                                {((totalExpenses / (totalInvoices * 1.1)) * 100).toFixed(1)}%
                              </h3>
                            </div>
                            <div className={`p-2 rounded-full ${totalExpenses <= totalInvoices * 1.1 ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                              {totalExpenses <= totalInvoices * 1.1 ? (
                                <BarChart2 className="h-5 w-5 text-green-500" />
                              ) : (
                                <TrendingUp className="h-5 w-5 text-red-500" />
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>القسم / البند</TableHead>
                          <TableHead className="text-left">الموازنة المخططة</TableHead>
                          <TableHead className="text-left">المصروفات الفعلية</TableHead>
                          <TableHead className="text-left">الفرق</TableHead>
                          <TableHead className="text-left">نسبة الاستخدام</TableHead>
                          <TableHead className="text-left">الحالة</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium">مواد البناء</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.4)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.45)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 0.4) >= (totalExpenses * 0.45) ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 0.4) - (totalExpenses * 0.45))}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? (((totalExpenses * 0.45) / (totalInvoices * 0.4)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 0.4) >= (totalExpenses * 0.45)) ? "outline" : "destructive"}>
                              {((totalInvoices * 0.4) >= (totalExpenses * 0.45)) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">أجور العمالة</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.3)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.3)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 0.3) >= (totalExpenses * 0.3) ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 0.3) - (totalExpenses * 0.3))}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? (((totalExpenses * 0.3) / (totalInvoices * 0.3)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 0.3) >= (totalExpenses * 0.3)) ? "outline" : "destructive"}>
                              {((totalInvoices * 0.3) >= (totalExpenses * 0.3)) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">معدات وآليات</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.15)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.15)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 0.15) >= (totalExpenses * 0.15) ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 0.15) - (totalExpenses * 0.15))}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? (((totalExpenses * 0.15) / (totalInvoices * 0.15)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 0.15) >= (totalExpenses * 0.15)) ? "outline" : "destructive"}>
                              {((totalInvoices * 0.15) >= (totalExpenses * 0.15)) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">تصاريح ورسوم</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.05)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.03)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 0.05) >= (totalExpenses * 0.03) ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 0.05) - (totalExpenses * 0.03))}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? (((totalExpenses * 0.03) / (totalInvoices * 0.05)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 0.05) >= (totalExpenses * 0.03)) ? "outline" : "destructive"}>
                              {((totalInvoices * 0.05) >= (totalExpenses * 0.03)) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium">مصروفات إدارية</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 0.1)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses * 0.07)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 0.1) >= (totalExpenses * 0.07) ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 0.1) - (totalExpenses * 0.07))}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? (((totalExpenses * 0.07) / (totalInvoices * 0.1)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 0.1) >= (totalExpenses * 0.07)) ? "outline" : "destructive"}>
                              {((totalInvoices * 0.1) >= (totalExpenses * 0.07)) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                        <TableRow className="font-bold bg-muted">
                          <TableCell>الإجمالي</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalInvoices * 1.1)}</TableCell>
                          <TableCell className="text-left">{formatCurrency(totalExpenses)}</TableCell>
                          <TableCell className={`text-left ${(totalInvoices * 1.1) >= totalExpenses ? 'text-green-500' : 'text-red-500'}`}>
                            {formatCurrency((totalInvoices * 1.1) - totalExpenses)}
                          </TableCell>
                          <TableCell className="text-left">
                            {totalInvoices > 0 ? ((totalExpenses / (totalInvoices * 1.1)) * 100).toFixed(1) : 0}%
                          </TableCell>
                          <TableCell className="text-left">
                            <Badge variant={((totalInvoices * 1.1) >= totalExpenses) ? "outline" : "destructive"}>
                              {((totalInvoices * 1.1) >= totalExpenses) ? "ضمن الموازنة" : "تجاوز الموازنة"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
                <CardFooter className="bg-muted/30 flex justify-between">
                  <p className="text-sm text-muted-foreground">
                    تاريخ التحديث: {new Date().toLocaleDateString('ar-SA')}
                  </p>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="gap-1" onClick={handlePrint}>
                      <Printer className="h-4 w-4" />
                      طباعة
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1" onClick={handleExportPDF}>
                      <Download className="h-4 w-4" />
                      تصدير PDF
                    </Button>
                  </div>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>توصيات لتحسين إدارة الموازنة</CardTitle>
                  <CardDescription>بناءً على تحليل بيانات المشروع، إليك بعض التوصيات لتحسين إدارة الموازنة</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <h3 className="text-lg font-medium flex items-center mb-2">
                        <ChevronRight className="h-5 w-5 ml-1 text-primary" />
                        مراقبة نفقات مواد البناء
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        هناك تجاوز في ميزانية مواد البناء بنسبة {totalInvoices > 0 ? ((((totalExpenses * 0.45) / (totalInvoices * 0.4)) * 100) - 100).toFixed(1) : 0}%. يوصى بإعادة التفاوض مع الموردين للحصول على أسعار أفضل والبحث عن بدائل اقتصادية للمواد ذات التكلفة العالية.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h3 className="text-lg font-medium flex items-center mb-2">
                        <ChevronRight className="h-5 w-5 ml-1 text-primary" />
                        تحسين كفاءة استخدام العمالة
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        نفقات العمالة ضمن الميزانية المخططة، ولكن يمكن تحسين الإنتاجية من خلال تنظيم أفضل للمهام وتقليل أوقات التوقف. يوصى بمراجعة جداول العمل وتحسين توزيع المهام.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h3 className="text-lg font-medium flex items-center mb-2">
                        <ChevronRight className="h-5 w-5 ml-1 text-primary" />
                        إعادة تخصيص الميزانية
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        هناك وفر في ميزانية التصاريح والرسوم والمصروفات الإدارية. يمكن إعادة تخصيص جزء من هذا الوفر لتغطية العجز في بنود أخرى مثل مواد البناء.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg">
                      <h3 className="text-lg font-medium flex items-center mb-2">
                        <ChevronRight className="h-5 w-5 ml-1 text-primary" />
                        مراجعة آلية صرف التكاليف
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        يوصى بتطبيق نظام اعتماد متعدد المستويات للمصروفات التي تتجاوز مبلغ معين لضمان مراقبة أفضل للإنفاق وتجنب التجاوزات غير الضرورية في الميزانية.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinancialReports;