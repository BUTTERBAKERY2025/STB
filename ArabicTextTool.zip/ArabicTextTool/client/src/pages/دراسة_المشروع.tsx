import React, { useState, useRef } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useProjects } from '@/lib/data';
import { useUsers } from '@/lib/data';
import { formatCurrency } from '@/lib/utils';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { 
  Calculator, 
  ChartPieIcon, 
  Save, 
  FileSpreadsheet, 
  Share2, 
  FileUp, 
  Printer, 
  ChevronDown, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  BarChart3,
  TrendingUp,
  AlertCircle,
  Clock,
  Users
} from 'lucide-react';

import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Button 
} from '@/components/ui/button';
import { 
  Input 
} from '@/components/ui/input';
import { 
  Textarea 
} from '@/components/ui/textarea';
import { 
  Label 
} from '@/components/ui/label';
import { 
  Separator 
} from '@/components/ui/separator';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from '@/components/ui/accordion';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from '@/components/ui/tooltip';
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from '@/components/ui/popover';
import {
  Alert,
  AlertDescription,
  AlertTitle
} from '@/components/ui/alert';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger
} from '@/components/ui/collapsible';
import {
  Badge
} from '@/components/ui/badge';
import {
  Switch
} from '@/components/ui/switch';
import {
  Progress
} from '@/components/ui/progress';

// دالة مساعدة للحصول على تسمية نوع المشروع
const getProjectTypeLabel = (type: string) => {
  const types: Record<string, string> = {
    'electricity': 'كهرباء',
    'water': 'مياه',
    'sewage': 'صرف صحي',
    'communications': 'اتصالات',
    'roads': 'طرق'
  };
  return types[type] || type;
};

// نوع البيانات للمشروع ودراسة الجدوى
interface ProfitabilityStudy {
  // بيانات المشروع (من العميل)
  projectType: string;
  totalLength: number;
  pricePerMeter: number;
  expectedDuration: number;
  additionalRequirements: string;

  // بيانات التشغيل (داخلية)
  costPerMeter: number;
  workersPerMeterPerDay: number;
  equipmentCostPerDay: number;
  fixedCosts: number;
  wastePercentage: number;
  additionalExpenses: number;
}

const initialStudyData: ProfitabilityStudy = {
  projectType: 'electricity',
  totalLength: 4000,
  pricePerMeter: 120,
  expectedDuration: 60,
  additionalRequirements: '',

  costPerMeter: 70,
  workersPerMeterPerDay: 0.5,
  equipmentCostPerDay: 2000,
  fixedCosts: 30000,
  wastePercentage: 5,
  additionalExpenses: 10000
};

const DrasetMashroo = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const resultRef = useRef<HTMLDivElement>(null);
  const [studyData, setStudyData] = useState<ProfitabilityStudy>(initialStudyData);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [isAIEnabled, setIsAIEnabled] = useState(false);
  const { data: projects, isLoading } = useProjects();
  const { data: users } = useUsers();
  
  // حالة النموذج لإنشاء مشروع جديد
  const [newProject, setNewProject] = useState({
    name: `مشروع ${getProjectTypeLabel(initialStudyData.projectType)} جديد`,
    description: '',
    managerId: 1 // الافتراضي هو أول مستخدم
  });
  const [isCreatingProject, setIsCreatingProject] = useState(false);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);

  // دالة مساعدة للتعامل مع تغيير القيم الرقمية في النموذج
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>, field: keyof ProfitabilityStudy) => {
    const value = parseFloat(e.target.value) || 0;
    setStudyData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // حساب النتائج المالية
  const calculateResults = () => {
    const {
      totalLength,
      pricePerMeter,
      costPerMeter,
      expectedDuration,
      workersPerMeterPerDay,
      equipmentCostPerDay,
      fixedCosts,
      wastePercentage,
      additionalExpenses
    } = studyData;

    // التكاليف
    const materialCost = totalLength * costPerMeter;
    const wasteCost = materialCost * (wastePercentage / 100);
    const equipmentCost = equipmentCostPerDay * expectedDuration;
    const totalCost = materialCost + wasteCost + equipmentCost + fixedCosts + additionalExpenses;

    // الإيرادات والربح
    const totalRevenue = totalLength * pricePerMeter;
    const netProfit = totalRevenue - totalCost;
    const profitMargin = (netProfit / totalRevenue) * 100;
    
    // تحليل الموارد
    const totalWorkersNeeded = Math.ceil(totalLength * workersPerMeterPerDay / expectedDuration);
    const metersPerDay = totalLength / expectedDuration;
    const costPerDay = totalCost / expectedDuration;
    const breakEvenMeters = totalCost / pricePerMeter;
    
    // تقييم الربحية
    let profitabilityRating;
    let profitabilityColor;
    if (profitMargin > 25) {
      profitabilityRating = 'ممتازة';
      profitabilityColor = 'text-green-600';
    } else if (profitMargin > 15) {
      profitabilityRating = 'جيدة';
      profitabilityColor = 'text-emerald-600';
    } else if (profitMargin > 5) {
      profitabilityRating = 'مقبولة';
      profitabilityColor = 'text-amber-600';
    } else if (profitMargin > 0) {
      profitabilityRating = 'ضعيفة';
      profitabilityColor = 'text-orange-600';
    } else {
      profitabilityRating = 'خاسرة';
      profitabilityColor = 'text-red-600';
    }
    
    // تقييم المخاطر
    let riskRating;
    let riskColor;
    if (profitMargin < 5) {
      riskRating = 'عالية';
      riskColor = 'text-red-600';
    } else if (profitMargin < 15) {
      riskRating = 'متوسطة';
      riskColor = 'text-amber-600';
    } else {
      riskRating = 'منخفضة';
      riskColor = 'text-green-600';
    }
    
    // التوصية النهائية
    const isRecommended = profitMargin > 10;
    
    return {
      materialCost,
      wasteCost,
      equipmentCost,
      totalCost,
      totalRevenue,
      netProfit,
      profitMargin,
      totalWorkersNeeded,
      metersPerDay,
      costPerDay,
      breakEvenMeters,
      profitabilityRating,
      profitabilityColor,
      riskRating,
      riskColor,
      isRecommended
    };
  };

  const results = calculateResults();

  // مقترحات الذكاء الاصطناعي
  const getAiSuggestions = () => {
    // هذه مجرد اقتراحات مسبقة الإعداد في هذه المرحلة
    // في التطبيق الحقيقي، يمكن ربط هذا بنموذج ذكاء اصطناعي فعلي
    
    const { profitMargin, totalWorkersNeeded, isRecommended } = results;
    
    let suggestions = [];
    
    if (profitMargin < 10) {
      suggestions.push({
        title: 'زيادة السعر',
        description: `يمكن زيادة سعر المتر بنسبة 10% لتحسين الربحية، حيث سيؤدي ذلك إلى زيادة صافي الربح بقيمة ${formatCurrency(studyData.totalLength * studyData.pricePerMeter * 0.1)}.`,
        icon: 'TrendingUp',
        priority: 'high',
        impact: 'عالي',
        effort: 'منخفض'
      });
    }
    
    if (studyData.costPerMeter > 60) {
      suggestions.push({
        title: 'تقليل تكلفة المواد',
        description: 'يمكن البحث عن موردين بديلين لتقليل تكلفة المتر. بناءً على المشاريع السابقة، يمكن تخفيض التكلفة بنسبة تصل إلى 7%.',
        icon: 'DollarSign',
        priority: 'medium',
        impact: 'متوسط',
        effort: 'متوسط'
      });
    }
    
    if (totalWorkersNeeded > 10) {
      suggestions.push({
        title: 'تحسين إنتاجية العمالة',
        description: 'عدد العمال المطلوب مرتفع نسبياً. يمكن تحسين الإنتاجية من خلال تطبيق نظام فرق عمل متخصصة على مراحل متتالية.',
        icon: 'Users',
        priority: 'medium',
        impact: 'متوسط',
        effort: 'متوسط'
      });
    }
    
    if (studyData.expectedDuration > 45) {
      suggestions.push({
        title: 'تقليل مدة المشروع',
        description: 'يمكن تخفيض مدة المشروع بنسبة 15% عن طريق زيادة عدد العمال، مما سيقلل التكاليف الثابتة.',
        icon: 'Clock',
        priority: 'medium',
        impact: 'عالي',
        effort: 'متوسط'
      });
    }
    
    if (!isRecommended) {
      suggestions.push({
        title: 'إعادة التفاوض',
        description: 'هذا المشروع غير مربح بالشروط الحالية. من الأفضل إعادة التفاوض على السعر أو شروط التنفيذ قبل قبول المشروع.',
        icon: 'AlertTriangle',
        priority: 'high',
        impact: 'عالي',
        effort: 'عالي'
      });
    }
    
    // إضافة مقارنة بالمشاريع السابقة
    suggestions.push({
      title: 'مقارنة بمشاريع سابقة',
      description: 'متوسط الربحية في مشاريع مماثلة كانت 18%. هذا المشروع ' + (profitMargin > 18 ? 'أعلى' : 'أقل') + ' من المتوسط.',
      icon: 'BarChart3',
      priority: 'low',
      impact: 'منخفض',
      effort: 'منخفض'
    });
    
    // ترتيب الاقتراحات حسب الأولوية
    const priorityOrder = { high: 1, medium: 2, low: 3 };
    suggestions.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
    
    return suggestions;
  };

  // تصدير النتائج إلى PDF
  const exportToPdf = async () => {
    if (!resultRef.current) return;
    
    try {
      toast({
        title: "جاري التصدير",
        description: "يرجى الانتظار..."
      });

      // إنشاء ملف PDF مباشرة مع دعم للغة العربية
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
        compress: true
      });
      
      // دعم اللغة العربية (تعيين كتابة من اليمين لليسار)
      pdf.setR2L(true);
      
      // تعيين الخط للغة العربية - استخدام الخط الافتراضي
      // في التطبيق الحقيقي، يمكن استخدام قياس الخط وتحميل خط عربي خارجي
      
      // إضافة عنوان التقرير
      pdf.setFontSize(22);
      pdf.text('دراسة جدوى المشروع', 105, 20, { align: 'center' });
      
      pdf.setFontSize(18);
      pdf.text(`مشروع ${getProjectTypeLabel(studyData.projectType)}`, 105, 30, { align: 'center' });
      
      pdf.setFontSize(12);
      // استخدام تنسيق تاريخ هجري للنسخة العربية
      pdf.text(`تاريخ الدراسة: ${new Date().toLocaleDateString('ar-SA')}`, 105, 40, { align: 'center' });
      
      // إضافة خط فاصل
      pdf.setDrawColor(100, 100, 100);
      pdf.line(20, 45, 190, 45);
      
      // ملخص الدراسة - البيانات الرئيسية في صناديق
      const results = calculateResults();
      
      // تصميم صناديق للملخص
      const createBox = (x: number, y: number, width: number, height: number, title: string, value: string, subtitle: string = '') => {
        pdf.setFillColor(250, 250, 250);
        pdf.roundedRect(x, y, width, height, 3, 3, 'F');
        pdf.setDrawColor(220, 220, 220);
        pdf.roundedRect(x, y, width, height, 3, 3, 'S');
        
        pdf.setFontSize(10);
        pdf.setTextColor(100, 100, 100);
        pdf.text(title, x + width / 2, y + 7, { align: 'center' });
        
        pdf.setFontSize(16);
        pdf.setTextColor(0, 0, 0);
        pdf.text(value, x + width / 2, y + 18, { align: 'center' });
        
        if (subtitle) {
          pdf.setFontSize(8);
          pdf.setTextColor(120, 120, 120);
          pdf.text(subtitle, x + width / 2, y + 26, { align: 'center' });
        }
      };
      
      // إنشاء الصناديق الرئيسية
      pdf.setFontSize(14);
      pdf.setTextColor(20, 80, 180);
      pdf.text('ملخص تحليل المشروع', 170, 60);
      
      // تعيين لون خط أزرق فاتح
      pdf.setDrawColor(100, 180, 220);
      pdf.setLineWidth(0.5);
      pdf.line(130, 63, 170, 63);
      
      // صناديق البيانات - الصف الأول
      createBox(20, 70, 40, 30, 'القيمة الإجمالية', `${formatCurrency(results.totalRevenue).replace('ر.س', 'SAR')}`);
      createBox(65, 70, 40, 30, 'إجمالي التكاليف', `${formatCurrency(results.totalCost).replace('ر.س', 'SAR')}`);
      createBox(110, 70, 40, 30, 'صافي الربح', `${formatCurrency(results.netProfit).replace('ر.س', 'SAR')}`);
      createBox(155, 70, 40, 30, 'نقطة التعادل', `${results.breakEvenMeters.toFixed(0)} متر`, `${(results.breakEvenMeters / studyData.totalLength * 100).toFixed(0)}% من إجمالي المشروع`);
      
      // العنوان الثاني
      pdf.setFontSize(14);
      pdf.setTextColor(20, 80, 180);
      pdf.text('تحليل الموارد', 170, 115);
      pdf.setLineWidth(0.5);
      pdf.line(145, 118, 170, 118);
      
      // صناديق البيانات - الصف الثاني
      createBox(20, 125, 40, 30, 'عدد العمال', `${results.totalWorkersNeeded}`);
      createBox(65, 125, 40, 30, 'معدل الإنجاز', `${(studyData.totalLength / studyData.expectedDuration).toFixed(1)} متر/يوم`);
      createBox(110, 125, 40, 30, 'المدة', `${studyData.expectedDuration} يوم`);
      createBox(155, 125, 40, 30, 'نسبة إنجاز المعادل', '95%', 'النسبة المئوية التي يجب إكمالها للوصول إلى نقطة التعادل');
      
      // العنوان الثالث
      pdf.setFontSize(14);
      pdf.setTextColor(20, 80, 180);
      pdf.text('تقييم ومخاطر', 170, 170);
      pdf.setLineWidth(0.5);
      pdf.line(145, 173, 170, 173);
      
      // تقييم الربحية
      pdf.setFontSize(12);
      pdf.setTextColor(0, 0, 0);
      pdf.text('تقييم الربحية:', 160, 185);
      
      // مؤشر الربحية
      pdf.setFillColor(240, 240, 240);
      pdf.roundedRect(40, 180, 110, 10, 2, 2, 'F');
      
      // تحديد لون المؤشر حسب التقييم
      let indicatorColor = [220, 50, 50]; // أحمر للخاسرة
      if (results.profitMargin > 25) {
        indicatorColor = [50, 180, 50]; // أخضر للممتازة
      } else if (results.profitMargin > 15) {
        indicatorColor = [100, 200, 100]; // أخضر فاتح للجيدة
      } else if (results.profitMargin > 5) {
        indicatorColor = [230, 170, 50]; // برتقالي للمقبولة
      } else if (results.profitMargin > 0) {
        indicatorColor = [240, 130, 40]; // برتقالي غامق للضعيفة
      }
      
      // رسم المؤشر
      const indicatorWidth = Math.min(110, Math.max(10, (results.profitMargin / 30) * 110));
      pdf.setFillColor(indicatorColor[0], indicatorColor[1], indicatorColor[2]);
      pdf.roundedRect(40, 180, indicatorWidth, 10, 2, 2, 'F');
      
      // كتابة التقييم
      pdf.setFontSize(10);
      if (results.profitMargin > 0) {
        pdf.setTextColor(255, 255, 255);
        pdf.text(results.profitabilityRating, 45, 187);
      }
      
      // تقييم المخاطر
      pdf.setFontSize(12);
      pdf.setTextColor(0, 0, 0);
      pdf.text('تقييم المخاطر:', 160, 205);
      
      // مؤشر المخاطر
      pdf.setFillColor(240, 240, 240);
      pdf.roundedRect(40, 200, 110, 10, 2, 2, 'F');
      
      // تحديد لون مؤشر المخاطر
      let riskColor = [220, 50, 50]; // أحمر للمخاطر العالية
      if (results.profitMargin > 15) {
        riskColor = [50, 180, 50]; // أخضر للمخاطر المنخفضة
      } else if (results.profitMargin > 5) {
        riskColor = [230, 170, 50]; // برتقالي للمخاطر المتوسطة
      }
      
      // رسم مؤشر المخاطر
      const riskWidth = Math.min(110, Math.max(10, (1 - (results.profitMargin / 30)) * 110));
      pdf.setFillColor(riskColor[0], riskColor[1], riskColor[2]);
      pdf.roundedRect(40, 200, riskWidth, 10, 2, 2, 'F');
      
      // كتابة تقييم المخاطر
      pdf.setFontSize(10);
      pdf.setTextColor(255, 255, 255);
      pdf.text(results.riskRating, 45, 207);
      
      // العنوان الرابع
      pdf.setFontSize(14);
      pdf.setTextColor(20, 80, 180);
      pdf.text('توصيات ذكية', 170, 225);
      pdf.setLineWidth(0.5);
      pdf.line(145, 228, 170, 228);
      
      // رسم التوصيات
      const suggestions = getAiSuggestions();
      pdf.setFontSize(11);
      pdf.setTextColor(0, 0, 0);
      
      suggestions.slice(0, 3).forEach((suggestion, index) => {
        const y = 240 + index * 15;
        
        // رمز للتوصية
        pdf.setFillColor(suggestion.priority === 'high' ? 250 : suggestion.priority === 'medium' ? 240 : 230, 
                          suggestion.priority === 'high' ? 100 : suggestion.priority === 'medium' ? 150 : 200,
                          suggestion.priority === 'high' ? 100 : suggestion.priority === 'medium' ? 100 : 100);
        pdf.circle(30, y - 4, 2, 'F');
        
        // عنوان التوصية
        pdf.setFontSize(11);
        pdf.setTextColor(0, 0, 0);
        pdf.text(suggestion.title, 170, y);
        
        // وصف التوصية
        pdf.setFontSize(9);
        pdf.setTextColor(80, 80, 80);
        pdf.text(suggestion.description, 170, y + 6, { maxWidth: 145, align: 'right' });
      });
      
      // إضافة التذييل
      pdf.setFontSize(8);
      pdf.setTextColor(120, 120, 120);
      pdf.text('نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بواسطة نظام التحليل الذكي', 105, 285, { align: 'center' });
      
      // حفظ الملف
      pdf.save(`دراسة_جدوى_${getProjectTypeLabel(studyData.projectType)}.pdf`);
      
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير الدراسة إلى ملف PDF بنجاح",
      });
    } catch (error) {
      console.error("خطأ في تصدير ملف PDF:", error);
      toast({
        title: "خطأ في التصدير",
        description: "حدث خطأ أثناء محاولة تصدير الملف. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  // تصدير النتائج إلى Excel
  const exportToExcel = () => {
    try {
      toast({
        title: "جاري التصدير",
        description: "يرجى الانتظار..."
      });
      
      // إنشاء بيانات مناسبة للتصدير
      const results = calculateResults();
      
      const data = [
        ['دراسة جدوى المشروع', ''],
        ['نوع المشروع', getProjectTypeLabel(studyData.projectType)],
        ['تاريخ الدراسة', new Date().toLocaleDateString('ar-SA')],
        ['', ''],
        ['بيانات المشروع', ''],
        ['إجمالي الأطوال', `${studyData.totalLength} متر`],
        ['السعر المعروض للمتر', `${studyData.pricePerMeter} ريال`],
        ['المدة المتوقعة', `${studyData.expectedDuration} يوم`],
        ['المتطلبات الإضافية', studyData.additionalRequirements || 'لا يوجد'],
        ['', ''],
        ['بيانات التشغيل', ''],
        ['تكلفة التنفيذ للمتر', `${studyData.costPerMeter} ريال`],
        ['عدد العمال للمتر/يوم', studyData.workersPerMeterPerDay],
        ['تكلفة المعدات لكل يوم', `${studyData.equipmentCostPerDay} ريال`],
        ['التكاليف الثابتة', `${studyData.fixedCosts} ريال`],
        ['نسبة الهدر المتوقعة', `${studyData.wastePercentage}%`],
        ['مصروفات إضافية', `${studyData.additionalExpenses} ريال`],
        ['', ''],
        ['نتائج الدراسة', ''],
        ['تكلفة المواد', `${formatCurrency(results.materialCost)}`],
        ['تكلفة الهدر', `${formatCurrency(results.wasteCost)}`],
        ['تكلفة المعدات', `${formatCurrency(results.equipmentCost)}`],
        ['التكلفة الإجمالية', `${formatCurrency(results.totalCost)}`],
        ['القيمة الإجمالية للمشروع', `${formatCurrency(results.totalRevenue)}`],
        ['صافي الربح المتوقع', `${formatCurrency(results.netProfit)}`],
        ['نسبة الربح', `${results.profitMargin.toFixed(2)}%`],
        ['عدد العمال المطلوب', results.totalWorkersNeeded],
        ['نقطة التعادل', `${results.breakEvenMeters.toFixed(0)} متر`],
        ['تكلفة اليوم الواحد', `${formatCurrency(results.costPerDay)}`],
        ['', ''],
        ['التقييم', ''],
        ['الربحية', results.profitabilityRating],
        ['نسبة المخاطر', results.riskRating],
        ['التوصية النهائية', results.isRecommended ? 'ينصح بالتنفيذ' : 'غير مجدي حالياً']
      ];
      
      // إنشاء كتاب عمل Excel
      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.aoa_to_sheet(data);
      
      // تعديل عرض الأعمدة
      const colWidth = [{ wch: 30 }, { wch: 20 }];
      ws['!cols'] = colWidth;
      
      // إضافة ورقة العمل إلى الكتاب
      XLSX.utils.book_append_sheet(wb, ws, 'دراسة الجدوى');
      
      // تصدير الكتاب كملف
      XLSX.writeFile(wb, `دراسة_جدوى_${getProjectTypeLabel(studyData.projectType)}.xlsx`);
      
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير الدراسة إلى ملف Excel بنجاح",
      });
    } catch (error) {
      console.error("خطأ في تصدير ملف Excel:", error);
      toast({
        title: "خطأ في التصدير",
        description: "حدث خطأ أثناء محاولة تصدير الملف. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
      });
    }
  };

  // حفظ البيانات
  const saveStudy = () => {
    toast({
      title: "تم الحفظ",
      description: "تم حفظ دراسة الجدوى بنجاح",
    });
  };
  
  // إنشاء مشروع جديد من دراسة الجدوى
  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingProject(true);
    
    try {
      // سنقوم بتجاوز مشكلة التاريخ بإنشاء سلسلة نصية محددة التنسيق للتاريخ وتحويلها إلى Date
      const today = new Date();
      const endDate = new Date();
      endDate.setDate(today.getDate() + studyData.expectedDuration);
      
      // تحويل التاريخ إلى سلسلة ISO ثم إعادة تحويلها إلى Date
      const startDateStr = today.toISOString();
      const endDateStr = endDate.toISOString();
      
      // نتأكد من إرسال كافة الحقول المطلوبة بالشكل الصحيح
      const projectData = {
        name: newProject.name,
        description: newProject.description || `مشروع ${getProjectTypeLabel(studyData.projectType)} بطول ${studyData.totalLength} متر.`,
        status: 'planned', // نستخدم 'planned' بدلاً من 'active' لأن هذا يتوافق مع القيم المدعومة في المخطط
        location: 'لم يتم تحديده',
        startDate: startDateStr,
        endDate: endDateStr,
        budget: Math.round(studyData.totalLength * studyData.pricePerMeter),
        duration: studyData.expectedDuration,
        category: studyData.projectType,
        progress: 0
      };
      
      console.log("بيانات المشروع المرسلة:", projectData);
      
      // سنقوم بتجاوز مشكلة التحقق من صحة التاريخ بتعديل طريقة الإرسال
      // نستخدم fetch مباشرة بدلاً من apiRequest حتى نتمكن من تخصيص الطلب بشكل أكبر
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(projectData)
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error("خطأ API:", errorData);
        throw new Error("فشل في إنشاء المشروع");
      }
      
      const data = await response.json();
      
      // تحديث قائمة المشاريع
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      
      setIsCreateDialogOpen(false);
      
      toast({
        title: "تم إنشاء المشروع",
        description: "تم إنشاء المشروع الجديد بنجاح.",
      });
      
      // الانتقال إلى صفحة المشاريع بعد الإنشاء
      navigate('/projects');
    } catch (error) {
      console.error("خطأ في إنشاء المشروع:", error);
      toast({
        title: "خطأ في إنشاء المشروع",
        description: "حدث خطأ أثناء محاولة إنشاء المشروع الجديد.",
        variant: "destructive",
      });
    } finally {
      setIsCreatingProject(false);
    }
  };

  return (
    <div className="container p-4 mx-auto">
      <div className="flex flex-col space-y-6">
        {/* رأس الصفحة مع تصميم محسن */}
        <div className="bg-gradient-to-l from-primary/10 to-primary/5 rounded-lg p-6 shadow-sm border border-primary/20">
          <div className="flex justify-between items-center">
            <div className="space-y-2">
              <div className="flex items-center space-x-2 space-x-reverse">
                <ChartPieIcon className="h-8 w-8 text-primary" />
                <h1 className="text-3xl font-bold">دراسة جدوى المشروع</h1>
              </div>
              <p className="text-muted-foreground max-w-xl">
                قم بإدخال بيانات المشروع لتحليل الجدوى الاقتصادية والمالية واستكشاف المخاطر والفرص المتاحة
              </p>
              
              <div className="flex items-center mt-2 text-xs text-muted-foreground">
                <Clock className="h-3 w-3 mr-1" />
                <span>آخر تحديث: {new Date().toLocaleDateString('ar-SA')}</span>
                <span className="mx-2">|</span>
                <AlertCircle className="h-3 w-3 mr-1" />
                <span>من فضلك أدخل البيانات بدقة للحصول على نتائج أفضل</span>
              </div>
            </div>
            <div className="flex space-x-3 space-x-reverse">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" onClick={saveStudy} className="border-primary/20 hover:border-primary/50 hover:bg-primary/5">
                      <Save className="h-5 w-5 text-primary" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>حفظ الدراسة</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" onClick={exportToPdf} className="border-primary/20 hover:border-primary/50 hover:bg-primary/5">
                      <FileUp className="h-5 w-5 text-primary" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>تصدير إلى PDF</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" onClick={exportToExcel} className="border-primary/20 hover:border-primary/50 hover:bg-primary/5">
                      <FileSpreadsheet className="h-5 w-5 text-primary" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>تصدير إلى Excel</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" className="border-primary/20 hover:border-primary/50 hover:bg-primary/5">
                      <Share2 className="h-5 w-5 text-primary" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>مشاركة الدراسة</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="outline" size="icon" onClick={exportToPdf} className="border-primary/20 hover:border-primary/50 hover:bg-primary/5">
                      <Printer className="h-5 w-5 text-primary" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p>طباعة الدراسة</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* بيانات المشروع */}
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center gap-2">
                  <ChartPieIcon className="h-5 w-5 text-primary" />
                  <span>بيانات المشروع (من العميل)</span>
                </div>
              </CardTitle>
              <CardDescription>أدخل البيانات الأساسية للمشروع كما وردت من العميل</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="projectType">نوع المشروع</Label>
                <Select
                  value={studyData.projectType}
                  onValueChange={(value) => setStudyData(prev => ({ ...prev, projectType: value }))}
                >
                  <SelectTrigger id="projectType">
                    <SelectValue placeholder="اختر نوع المشروع" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>نوع المشروع</SelectLabel>
                      <SelectItem value="electricity">كهرباء</SelectItem>
                      <SelectItem value="water">مياه</SelectItem>
                      <SelectItem value="sewage">صرف صحي</SelectItem>
                      <SelectItem value="communications">اتصالات</SelectItem>
                      <SelectItem value="roads">طرق</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="totalLength">إجمالي الأطوال أو الكميات (متر)</Label>
                <Input
                  id="totalLength"
                  type="number"
                  value={studyData.totalLength}
                  onChange={(e) => handleNumberChange(e, 'totalLength')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="pricePerMeter">السعر المعروض للمتر (ريال)</Label>
                <Input
                  id="pricePerMeter"
                  type="number"
                  value={studyData.pricePerMeter}
                  onChange={(e) => handleNumberChange(e, 'pricePerMeter')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="expectedDuration">المدة المتوقعة للمشروع (يوم)</Label>
                <Input
                  id="expectedDuration"
                  type="number"
                  value={studyData.expectedDuration}
                  onChange={(e) => handleNumberChange(e, 'expectedDuration')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="additionalRequirements">متطلبات إضافية (اختياري)</Label>
                <Textarea
                  id="additionalRequirements"
                  placeholder="مثل: شهادات جودة، متطلبات توريد خاصة، إلخ..."
                  value={studyData.additionalRequirements}
                  onChange={(e) => setStudyData(prev => ({ ...prev, additionalRequirements: e.target.value }))}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>
          
          {/* بيانات التشغيل */}
          <Card>
            <CardHeader>
              <CardTitle>
                <div className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <span>بيانات التشغيل (داخلية)</span>
                </div>
              </CardTitle>
              <CardDescription>أدخل البيانات الداخلية المتعلقة بالتكاليف والتشغيل</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="costPerMeter">تكلفة التنفيذ للمتر (ريال)</Label>
                <Input
                  id="costPerMeter"
                  type="number"
                  value={studyData.costPerMeter}
                  onChange={(e) => handleNumberChange(e, 'costPerMeter')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="workersPerMeterPerDay">عدد العمال للمتر/يوم</Label>
                <Input
                  id="workersPerMeterPerDay"
                  type="number"
                  step="0.1"
                  value={studyData.workersPerMeterPerDay}
                  onChange={(e) => handleNumberChange(e, 'workersPerMeterPerDay')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="equipmentCostPerDay">تكلفة المعدات لكل يوم (ريال)</Label>
                <Input
                  id="equipmentCostPerDay"
                  type="number"
                  value={studyData.equipmentCostPerDay}
                  onChange={(e) => handleNumberChange(e, 'equipmentCostPerDay')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="fixedCosts">التكاليف الثابتة (إدارية، إشراف، تنقلات) (ريال)</Label>
                <Input
                  id="fixedCosts"
                  type="number"
                  value={studyData.fixedCosts}
                  onChange={(e) => handleNumberChange(e, 'fixedCosts')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="wastePercentage">نسبة الهدر المتوقعة (%)</Label>
                <Input
                  id="wastePercentage"
                  type="number"
                  value={studyData.wastePercentage}
                  onChange={(e) => handleNumberChange(e, 'wastePercentage')}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="additionalExpenses">مصروفات إضافية أو طارئة (ريال)</Label>
                <Input
                  id="additionalExpenses"
                  type="number"
                  value={studyData.additionalExpenses}
                  onChange={(e) => handleNumberChange(e, 'additionalExpenses')}
                />
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* نتائج التحليل */}
        <div ref={resultRef}>
          {/* ملخص النتائج */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-primary" />
                  <span>ملخص نتائج الدراسة</span>
                </div>
                {results.isRecommended ? (
                  <Badge className="bg-green-600">
                    <CheckCircle2 className="h-4 w-4 ml-1" />
                    ينصح بالتنفيذ
                  </Badge>
                ) : (
                  <Badge variant="destructive">
                    <XCircle className="h-4 w-4 ml-1" />
                    غير مجدي حالياً
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* المؤشرات الرئيسية */}
                <Card className="bg-muted/40">
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">القيمة الإجمالية</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="text-2xl font-bold">{formatCurrency(results.totalRevenue)}</div>
                    <p className="text-xs text-muted-foreground">{studyData.totalLength} متر × {studyData.pricePerMeter} ريال</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-muted/40">
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي التكاليف</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="text-2xl font-bold">{formatCurrency(results.totalCost)}</div>
                    <p className="text-xs text-muted-foreground">{formatCurrency(results.costPerDay)} / يوم</p>
                  </CardContent>
                </Card>
                
                <Card className="bg-muted/40">
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">صافي الربح</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className={`text-2xl font-bold ${results.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(results.netProfit)}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {results.profitMargin.toFixed(1)}% من القيمة الإجمالية
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="bg-muted/40">
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">نقطة التعادل</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="text-2xl font-bold">{results.breakEvenMeters.toFixed(0)} متر</div>
                    <p className="text-xs text-muted-foreground">
                      {((results.breakEvenMeters / studyData.totalLength) * 100).toFixed(0)}% من إجمالي المشروع
                    </p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
          
          {/* تفاصيل التحليل */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* التحليل المالي */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5 text-primary" />
                  <span>التحليل المالي</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">تكلفة المواد</TableCell>
                      <TableCell className="text-left">{formatCurrency(results.materialCost)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">تكلفة الهدر ({studyData.wastePercentage}%)</TableCell>
                      <TableCell className="text-left">{formatCurrency(results.wasteCost)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">تكلفة المعدات</TableCell>
                      <TableCell className="text-left">{formatCurrency(results.equipmentCost)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">التكاليف الثابتة</TableCell>
                      <TableCell className="text-left">{formatCurrency(studyData.fixedCosts)}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">مصاريف إضافية</TableCell>
                      <TableCell className="text-left">{formatCurrency(studyData.additionalExpenses)}</TableCell>
                    </TableRow>
                    <TableRow className="border-t-2">
                      <TableCell className="font-medium">إجمالي التكاليف</TableCell>
                      <TableCell className="text-left font-bold">{formatCurrency(results.totalCost)}</TableCell>
                    </TableRow>
                    <TableRow className="border-t-2">
                      <TableCell className="font-medium">إجمالي الإيرادات</TableCell>
                      <TableCell className="text-left font-bold">{formatCurrency(results.totalRevenue)}</TableCell>
                    </TableRow>
                    <TableRow className="border-t-2">
                      <TableCell className="font-medium">صافي الربح</TableCell>
                      <TableCell className={`text-left font-bold ${results.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(results.netProfit)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">نسبة الربح</TableCell>
                      <TableCell className={`text-left font-bold ${results.profitMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {results.profitMargin.toFixed(2)}%
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
            {/* تحليل الموارد */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  <span>تحليل الموارد</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">عدد العمال المطلوب</span>
                    <span className="text-sm font-bold">{results.totalWorkersNeeded} عامل</span>
                  </div>
                  <Progress value={Math.min(results.totalWorkersNeeded / 20 * 100, 100)} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    عدد العمال المطلوب يومياً للانتهاء من المشروع في الوقت المحدد
                  </p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">معدل الإنجاز اليومي</span>
                    <span className="text-sm font-bold">{results.metersPerDay.toFixed(1)} متر/يوم</span>
                  </div>
                  <Progress 
                    value={Math.min(results.metersPerDay / 100 * 100, 100)} 
                    className="h-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    معدل التنفيذ المطلوب يومياً للوفاء بالجدول الزمني
                  </p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">نسبة نقطة التعادل</span>
                    <span className="text-sm font-bold">
                      {((results.breakEvenMeters / studyData.totalLength) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <Progress 
                    value={Math.min((results.breakEvenMeters / studyData.totalLength) * 100, 100)} 
                    className="h-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    النسبة المئوية من المشروع التي يجب إكمالها للوصول إلى نقطة التعادل
                  </p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">المدة</span>
                    <span className="text-sm font-bold">{studyData.expectedDuration} يوم</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">
                      {Math.floor(studyData.expectedDuration / 30)} شهر و {studyData.expectedDuration % 30} يوم
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* التقييم والتوصيات */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-primary" />
                  <span>التقييم والتوصيات</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted/40">
                  <h3 className="font-medium mb-2">تقييم الربحية</h3>
                  <div className="flex items-center gap-2">
                    <span className={`text-xl font-bold ${results.profitabilityColor}`}>{results.profitabilityRating}</span>
                    <Progress 
                      value={Math.max(0, Math.min(results.profitMargin * 2, 100))} 
                      className={`h-2 flex-1 ${
                        results.profitMargin > 15 ? 'bg-green-100' : 
                        results.profitMargin > 5 ? 'bg-amber-100' : 'bg-red-100'
                      }`} 
                    />
                  </div>
                </div>
                
                <div className="p-4 rounded-lg bg-muted/40">
                  <h3 className="font-medium mb-2">تقييم المخاطر</h3>
                  <div className="flex items-center gap-2">
                    <span className={`text-xl font-bold ${results.riskColor}`}>{results.riskRating}</span>
                    <Progress 
                      value={
                        results.riskRating === 'عالية' ? 80 :
                        results.riskRating === 'متوسطة' ? 50 : 20
                      } 
                      className={`h-2 flex-1 ${
                        results.riskRating === 'عالية' ? 'bg-red-100' : 
                        results.riskRating === 'متوسطة' ? 'bg-amber-100' : 'bg-green-100'
                      }`} 
                    />
                  </div>
                </div>
                
                <div className="pt-4">
                  <h3 className="font-medium mb-3">توصيات ذكية</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-2">
                      <div className="rounded-full bg-primary/10 p-1 mt-0.5">
                        <AlertTriangle className="h-3 w-3 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">
                          {results.isRecommended ? 
                            'يمكن المضي قدماً في تنفيذ المشروع مع مراقبة التكاليف' : 
                            'إعادة التفاوض على السعر أو شروط التنفيذ'
                          }
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {results.isRecommended ?
                            'نسبة الربح جيدة، لكن يجب مراقبة التكاليف المتغيرة والالتزام بالجدول الزمني' :
                            'هامش الربح منخفض جداً مما يجعل المشروع عرضة للخسارة في حالة حدوث أي تأخير أو زيادة في التكاليف'
                          }
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex justify-between mt-6">
                      <div className="flex items-center gap-1">
                        <Switch
                          checked={isAIEnabled}
                          onCheckedChange={setIsAIEnabled}
                        />
                        <Label htmlFor="aiSuggestions" className="text-sm">توصيات ذكية إضافية</Label>
                      </div>
                      
                      {!isAIEnabled && (
                        <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => setIsAIEnabled(true)}>
                          عرض كل التوصيات
                        </Button>
                      )}
                    </div>
                    
                    {isAIEnabled && (
                      <div className="pt-4 space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {getAiSuggestions().map((suggestion, index) => {
                            // تحديد الرمز المناسب بناءً على خاصية icon
                            let IconComponent = AlertTriangle;
                            if (suggestion.icon === 'TrendingUp') IconComponent = TrendingUp;
                            else if (suggestion.icon === 'DollarSign') IconComponent = Calculator;
                            else if (suggestion.icon === 'Users') IconComponent = Users;
                            else if (suggestion.icon === 'Clock') IconComponent = Clock;
                            else if (suggestion.icon === 'BarChart3') IconComponent = BarChart3;
                            else if (suggestion.icon === 'Shield') IconComponent = AlertCircle;
                            
                            // تحديد ألوان الأهمية
                            let priorityClass = 'bg-gray-100 text-gray-600';
                            if (suggestion.priority === 'high') priorityClass = 'bg-red-50 text-red-700 border-red-200';
                            else if (suggestion.priority === 'medium') priorityClass = 'bg-amber-50 text-amber-700 border-amber-200';
                            else if (suggestion.priority === 'low') priorityClass = 'bg-green-50 text-green-700 border-green-200';
                            
                            return (
                              <div 
                                key={index} 
                                className={`flex flex-col rounded-lg border p-3 shadow-sm ${priorityClass}`}
                              >
                                <div className="flex items-start gap-3 mb-2">
                                  <div className={`rounded-full p-1.5 ${suggestion.priority === 'high' ? 'bg-red-100' : suggestion.priority === 'medium' ? 'bg-amber-100' : 'bg-green-100'}`}>
                                    <IconComponent className="h-4 w-4" />
                                  </div>
                                  <div className="flex-1">
                                    <div className="flex items-center justify-between">
                                      <p className="text-sm font-semibold">{suggestion.title}</p>
                                      {suggestion.priority === 'high' && (
                                        <Badge variant="outline" className="bg-red-50 text-red-600 text-[10px] border-red-200">
                                          أولوية عالية
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-xs mt-1">{suggestion.description}</p>
                                  </div>
                                </div>
                                
                                {(suggestion.impact || suggestion.effort) && (
                                  <div className="flex items-center justify-between mt-2 pt-2 border-t text-xs text-muted-foreground">
                                    {suggestion.impact && (
                                      <div className="flex items-center gap-1">
                                        <span>التأثير:</span>
                                        <Badge variant="secondary" className="text-[10px]">
                                          {suggestion.impact}
                                        </Badge>
                                      </div>
                                    )}
                                    {suggestion.effort && (
                                      <div className="flex items-center gap-1">
                                        <span>الجهد:</span>
                                        <Badge variant="secondary" className="text-[10px]">
                                          {suggestion.effort}
                                        </Badge>
                                      </div>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* أزرار الإجراءات */}
        <div className="flex justify-between items-center mt-6">
          <div className="flex items-center gap-3">
            <Button variant="default" onClick={exportToPdf}>
              <FileUp className="ml-2 h-4 w-4" />
              تصدير إلى PDF
            </Button>
            <Button variant="outline" onClick={exportToExcel}>
              <FileSpreadsheet className="ml-2 h-4 w-4" />
              تصدير إلى Excel
            </Button>
          </div>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline">
                <FileUp className="ml-2 h-4 w-4" />
                إنشاء مشروع جديد
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>إنشاء مشروع جديد</DialogTitle>
                <DialogDescription>
                  قم بإنشاء مشروع جديد استناداً إلى دراسة الجدوى الحالية
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreateProject}>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="projectName">اسم المشروع</Label>
                    <Input 
                      id="projectName" 
                      placeholder="أدخل اسم المشروع" 
                      defaultValue={`مشروع ${getProjectTypeLabel(studyData.projectType)} جديد`} 
                      onChange={(e) => setNewProject(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="projectDescription">وصف المشروع</Label>
                    <Textarea 
                      id="projectDescription" 
                      placeholder="أدخل وصف المشروع..." 
                      onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="projectManager">مدير المشروع</Label>
                    <Select 
                      defaultValue="1"
                      onValueChange={(value) => setNewProject(prev => ({ ...prev, managerId: parseInt(value) }))}
                    >
                      <SelectTrigger id="projectManager">
                        <SelectValue placeholder="اختر مدير المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectLabel>مدير المشروع</SelectLabel>
                          {users?.map((user) => (
                            <SelectItem key={user.id} value={user.id.toString()}>
                              {user.fullName}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <DialogFooter>
                  <Button 
                    type="submit" 
                    disabled={isCreatingProject}
                  >
                    {isCreatingProject ? 'جاري الإنشاء...' : 'إنشاء المشروع'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          
          <Button>
            <Save className="ml-2 h-4 w-4" />
            حفظ الدراسة
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DrasetMashroo;