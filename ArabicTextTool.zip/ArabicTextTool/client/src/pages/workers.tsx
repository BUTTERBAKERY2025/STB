import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WorkerCard } from "@/components/workers/worker-card";
import { WorkerForm } from "@/components/workers/worker-form";
import { AttendanceForm } from "@/components/workers/attendance-form";
import { AttendanceTable } from "@/components/workers/attendance-table";
import { useQuery } from "@tanstack/react-query";
import { Worker, WorkerAttendance } from "@shared/schema";
import { useState } from "react";
import { Loader2, Plus, Search } from "lucide-react";

export default function WorkersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [attendanceDialogOpen, setAttendanceDialogOpen] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [selectedTab, setSelectedTab] = useState<"all" | "active" | "inactive">("all");

  // استعلام قائمة العمال
  const {
    data: workers = [],
    isLoading: isLoadingWorkers,
  } = useQuery<Worker[]>({
    queryKey: ["/api/workers"],
  });

  // استعلام قائمة المشاريع
  const { data: projects = [] } = useQuery({
    queryKey: ["/api/projects"],
  });

  // استعلام سجلات الحضور للعامل المحدد
  const {
    data: attendanceRecords = [],
    isLoading: isLoadingAttendance,
  } = useQuery<WorkerAttendance[]>({
    queryKey: ["/api/workers", selectedWorker?.id, "attendance"],
    enabled: !!selectedWorker && attendanceDialogOpen,
  });

  // تحويل قائمة المشاريع إلى كائن للبحث السريع
  const projectNames = projects.reduce((acc: Record<number, string>, project: any) => {
    acc[project.id] = project.name;
    return acc;
  }, {});

  // تصفية العمال حسب علامة التبويب المحددة
  const filteredByTab = workers.filter((worker) => {
    if (selectedTab === "all") return true;
    if (selectedTab === "active") return worker.status === "active";
    if (selectedTab === "inactive") return worker.status !== "active";
    return true;
  });

  // تصفية العمال حسب مصطلح البحث
  const filteredWorkers = filteredByTab.filter((worker) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      worker.name.toLowerCase().includes(searchLower) ||
      worker.specialization.toLowerCase().includes(searchLower) ||
      worker.nationality.toLowerCase().includes(searchLower) ||
      worker.identityNumber.toLowerCase().includes(searchLower)
    );
  });

  // معالجة تحرير بيانات العامل
  const handleEditWorker = (worker: Worker) => {
    setSelectedWorker(worker);
    setEditDialogOpen(true);
  };

  // معالجة عرض سجل الحضور
  const handleViewAttendance = (worker: Worker) => {
    setSelectedWorker(worker);
    setAttendanceDialogOpen(true);
  };

  return (
    <div className="container mx-auto py-6 space-y-6 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">إدارة العمال</h1>
          <p className="text-muted-foreground mt-1">
            إدارة القوى العاملة ومتابعة سجلات الحضور والانصراف
          </p>
        </div>
        <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-1">
              <Plus className="h-4 w-4" />
              إضافة عامل
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle>إضافة عامل جديد</DialogTitle>
              <DialogDescription>
                أدخل بيانات العامل الجديد. اضغط زر الإرسال عند الانتهاء.
              </DialogDescription>
            </DialogHeader>
            <WorkerForm onSuccess={() => setAddDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
        <div className="relative w-full sm:w-auto">
          <Search className="absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="بحث عن عامل..."
            className="w-full sm:w-[300px] pr-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Tabs
          value={selectedTab}
          onValueChange={(value) => setSelectedTab(value as "all" | "active" | "inactive")}
          className="w-full sm:w-auto"
        >
          <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
            <TabsTrigger value="all">جميع العمال</TabsTrigger>
            <TabsTrigger value="active">النشطون</TabsTrigger>
            <TabsTrigger value="inactive">المنقطعون/المجازون</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {isLoadingWorkers ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredWorkers.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-[400px] border rounded-lg p-8 bg-muted/30">
          <p className="text-muted-foreground text-center mb-4">
            {searchTerm ? "لا توجد نتائج مطابقة لبحثك" : "لا يوجد عمال بعد"}
          </p>
          {searchTerm ? (
            <Button variant="outline" onClick={() => setSearchTerm("")}>
              مسح البحث
            </Button>
          ) : (
            <Button onClick={() => setAddDialogOpen(true)}>إضافة عامل جديد</Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWorkers.map((worker) => (
            <WorkerCard
              key={worker.id}
              worker={worker}
              onEdit={handleEditWorker}
              onViewAttendance={handleViewAttendance}
            />
          ))}
        </div>
      )}

      {/* حوار تعديل بيانات العامل */}
      {selectedWorker && (
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle>تعديل بيانات العامل</DialogTitle>
              <DialogDescription>
                عدّل بيانات العامل. اضغط زر التحديث عند الانتهاء.
              </DialogDescription>
            </DialogHeader>
            <WorkerForm
              worker={selectedWorker}
              onSuccess={() => setEditDialogOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* حوار تسجيل الحضور وعرض سجلات الحضور */}
      {selectedWorker && (
        <Dialog
          open={attendanceDialogOpen}
          onOpenChange={setAttendanceDialogOpen}
        >
          <DialogContent className="sm:max-w-[750px]">
            <DialogHeader>
              <DialogTitle>سجل حضور العامل - {selectedWorker.name}</DialogTitle>
              <DialogDescription>تسجيل حضور جديد وعرض سجلات الحضور السابقة</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="register">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="register">تسجيل حضور</TabsTrigger>
                <TabsTrigger value="view">سجلات الحضور</TabsTrigger>
              </TabsList>
              <TabsContent value="register" className="mt-4">
                <AttendanceForm
                  worker={selectedWorker}
                  onSuccess={() => {}}
                />
              </TabsContent>
              <TabsContent value="view" className="mt-4">
                {isLoadingAttendance ? (
                  <div className="flex items-center justify-center h-40">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <AttendanceTable
                    attendanceRecords={attendanceRecords}
                    projectNames={projectNames}
                  />
                )}
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}