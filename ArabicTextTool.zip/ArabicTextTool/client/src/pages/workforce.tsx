import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { WorkerCard } from "@/components/workers/worker-card";
import { WorkerForm } from "@/components/workers/worker-form";
import { AttendanceForm } from "@/components/workers/attendance-form";
import { AttendanceTable } from "@/components/workers/attendance-table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Worker, WorkerAttendance, Project } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  CalendarRange, 
  Briefcase, 
  HardHat, 
  ChevronRight, 
  User, 
  Phone, 
  Mail, 
  Loader2, 
  CheckCircle2, 
  Clock, 
  XCircle,
  Building2,
  MessageSquare,
  FileText,
  Link,
  PersonStanding,
  GraduationCap,
  Target
} from "lucide-react";

// مكون لعرض البطاقات الإحصائية
const StatCard = ({ 
  title, 
  value, 
  icon, 
  description = "", 
  color = "bg-primary" 
}: { 
  title: string; 
  value: number; 
  icon: React.ReactNode; 
  description?: string; 
  color?: string; 
}) => (
  <Card>
    <CardContent className="p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="text-2xl font-bold mt-2">{value}</h3>
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className={`${color} p-3 rounded-full`}>
          {icon}
        </div>
      </div>
    </CardContent>
  </Card>
);

// مكون لعرض بطاقة عضو الفريق
const TeamMemberCard = ({ 
  member, 
  onEdit 
}: { 
  member: { 
    id: number; 
    fullName: string; 
    role: string; 
    email: string; 
    phone: string; 
    skills: string[]; 
    avatar: string; 
    projectsCount: number; 
    active: boolean 
  }; 
  onEdit: (member: any) => void 
}) => {
  const getRoleBadge = (role: string) => {
    switch (role) {
      case "admin":
        return <Badge className="bg-purple-500 hover:bg-purple-600">مدير</Badge>;
      case "engineer":
        return <Badge className="bg-primary hover:bg-primary/90">مهندس</Badge>;
      case "supervisor":
        return <Badge className="bg-green-500 hover:bg-green-600">مشرف</Badge>;
      case "worker":
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">عامل</Badge>;
      default:
        return <Badge className="bg-gray-500 hover:bg-gray-600">{role}</Badge>;
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(part => part.charAt(0)).join('');
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <CardHeader className="p-4 pb-2">
        <div className="flex items-center">
          <Avatar className="h-12 w-12 ml-4 border-2 border-primary">
            <AvatarImage src={member.avatar} alt={member.fullName} />
            <AvatarFallback className="bg-primary/10 text-primary">{getInitials(member.fullName)}</AvatarFallback>
          </Avatar>
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              {member.fullName}
              <div className="flex items-center gap-1 ms-auto">
                {getRoleBadge(member.role)}
                <span className={`mr-1 flex items-center text-xs ${member.active ? 'text-green-500' : 'text-gray-400'}`}>
                  {member.active ? <CheckCircle2 className="h-3 w-3 ml-1" /> : <XCircle className="h-3 w-3 ml-1" />}
                  {member.active ? 'نشط' : 'غير نشط'}
                </span>
              </div>
            </CardTitle>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-2">
        <div className="space-y-3 text-sm">
          <div className="flex items-center">
            <Mail className="h-4 w-4 ml-2 text-gray-500" />
            <span>{member.email}</span>
          </div>
          <div className="flex items-center">
            <Phone className="h-4 w-4 ml-2 text-gray-500" />
            <span dir="ltr">{member.phone}</span>
          </div>
          <div className="pt-1">
            <span className="text-gray-500 mb-1 block">المهارات:</span>
            <div className="flex flex-wrap gap-1">
              {member.skills.map((skill, index) => (
                <Badge key={index} variant="outline" className="font-normal">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
          <div className="pt-1">
            <span className="text-gray-500 mb-1 block">
              المشاركة في {member.projectsCount} مشاريع
            </span>
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <Button 
            variant="outline"
            size="sm" 
            className="w-full" 
            onClick={() => onEdit(member)}
          >
            إدارة المهام <ChevronRight className="h-4 w-4 mr-1" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default function WorkforcePage() {
  // حالة التبويبات والبحث
  const [activeTab, setActiveTab] = useState("dashboard");
  const [workersTab, setWorkersTab] = useState<"all" | "active" | "inactive">("all");
  const [teamTab, setTeamTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [selectedSpecialization, setSelectedSpecialization] = useState<string | null>(null);

  // حالة الحوارات
  const [addWorkerDialog, setAddWorkerDialog] = useState(false);
  const [editWorkerDialog, setEditWorkerDialog] = useState(false);
  const [attendanceDialog, setAttendanceDialog] = useState(false);
  const [addTeamMemberDialog, setAddTeamMemberDialog] = useState(false);
  const [editTeamMemberDialog, setEditTeamMemberDialog] = useState(false);
  const [selectedWorker, setSelectedWorker] = useState<Worker | null>(null);
  const [selectedTeamMember, setSelectedTeamMember] = useState<any | null>(null);

  // استعلامات البيانات
  const {
    data: workers = [],
    isLoading: isLoadingWorkers,
  } = useQuery<Worker[]>({
    queryKey: ["/api/workers"],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["/api/projects"],
  });

  const {
    data: attendanceRecords = [],
    isLoading: isLoadingAttendance,
  } = useQuery<WorkerAttendance[]>({
    queryKey: ["/api/workers", selectedWorker?.id, "attendance"],
    enabled: !!selectedWorker && attendanceDialog,
  });

  // بيانات الفريق (يمكن استبدالها بالبيانات الحقيقية عند توفرها)
  const teamMembers = [
    {
      id: 1,
      fullName: "عبدالله العتيبي",
      role: "admin",
      email: "abdullah@stb.com",
      phone: "+966 50 123 4567",
      skills: ["إدارة", "تخطيط", "مالية"],
      avatar: "",
      projectsCount: 12,
      active: true
    },
    {
      id: 2,
      fullName: "أحمد محمد",
      role: "engineer",
      email: "ahmed@stb.com",
      phone: "+966 55 765 4321",
      skills: ["كهرباء", "تخطيط", "تصميم"],
      avatar: "",
      projectsCount: 5,
      active: true
    },
    {
      id: 3,
      fullName: "سارة العلي",
      role: "supervisor",
      email: "sara@stb.com",
      phone: "+966 54 321 7654",
      skills: ["إشراف", "تقارير", "جودة"],
      avatar: "",
      projectsCount: 8,
      active: true
    },
    {
      id: 4,
      fullName: "خالد عبدالله",
      role: "worker",
      email: "khalid@stb.com",
      phone: "+966 58 987 6543",
      skills: ["إنشاءات", "حفر", "تركيبات"],
      avatar: "",
      projectsCount: 3,
      active: true
    },
    {
      id: 5,
      fullName: "نورة الغامدي",
      role: "engineer",
      email: "noura@stb.com",
      phone: "+966 52 345 6789",
      skills: ["اتصالات", "تصميم", "تطوير"],
      avatar: "",
      projectsCount: 4,
      active: false
    }
  ];

  // استخدام نوع المشروع المستورد من schema.ts

  // تحويل قائمة المشاريع إلى كائن للبحث السريع
  const projectNames = Array.isArray(projects) 
    ? projects.reduce((acc: Record<number, string>, project: Project) => {
        acc[project.id] = project.name;
        return acc;
      }, {}) 
    : {};

  // تصفية العمال حسب التبويب والبحث والمرشحات
  const filteredWorkers = workers.filter((worker) => {
    // تصفية حسب التبويب
    if (workersTab === "active" && worker.status !== "active") return false;
    if (workersTab === "inactive" && worker.status === "active") return false;
    
    // تصفية حسب المشروع المحدد
    if (selectedProject && worker.currentProjectId !== parseInt(selectedProject)) return false;
    
    // تصفية حسب التخصص
    if (selectedSpecialization && worker.specialization !== selectedSpecialization) return false;
    
    // تصفية حسب البحث
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        worker.name.toLowerCase().includes(searchLower) ||
        worker.specialization.toLowerCase().includes(searchLower) ||
        worker.nationality.toLowerCase().includes(searchLower) ||
        worker.identityNumber.toLowerCase().includes(searchLower)
      );
    }
    
    return true;
  });

  // تصفية أعضاء الفريق حسب البحث
  const filteredTeamMembers = teamMembers.filter(member => {
    // تصفية حسب التبويب
    if (teamTab !== "all") {
      if (teamTab === "active" && !member.active) return false;
      if (teamTab === "inactive" && member.active) return false;
      if (teamTab !== "all" && teamTab !== "active" && teamTab !== "inactive" && member.role !== teamTab) return false;
    }
    
    // تصفية حسب البحث
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        member.fullName.toLowerCase().includes(searchLower) ||
        member.role.toLowerCase().includes(searchLower) ||
        member.email.toLowerCase().includes(searchLower) ||
        member.skills.some(skill => skill.toLowerCase().includes(searchLower))
      );
    }
    
    return true;
  });

  // معالجة تحرير بيانات العامل
  const handleEditWorker = (worker: Worker) => {
    setSelectedWorker(worker);
    setEditWorkerDialog(true);
  };

  // معالجة عرض سجل الحضور
  const handleViewAttendance = (worker: Worker) => {
    setSelectedWorker(worker);
    setAttendanceDialog(true);
  };

  // معالجة تحرير بيانات عضو الفريق
  const handleEditTeamMember = (member: any) => {
    setSelectedTeamMember(member);
    setEditTeamMemberDialog(true);
  };

  // حساب الإحصائيات
  const totalWorkers = workers.length;
  const activeWorkers = workers.filter(w => w.status === "active").length;
  const totalTeamMembers = teamMembers.length;
  const activeTeamMembers = teamMembers.filter(t => t.active).length;

  // قائمة التخصصات المتاحة
  const specializations = [
    { value: "site_engineer", label: "مهندس موقع" },
    { value: "execution_supervisor", label: "مشرف تنفيذ" },
    { value: "project_manager", label: "مدير مشروع" },
    { value: "excavation_worker", label: "عامل حفريات" },
    { value: "electrician", label: "عامل كهرباء" },
    { value: "plumber", label: "سباك" },
    { value: "form_carpenter", label: "نجار قالب" },
    { value: "reinforcement_blacksmith", label: "حداد تسليح" },
    { value: "general_worker", label: "عامل عام أو مساعد" },
    { value: "equipment_driver", label: "سائق معدة أو شاحنة" },
  ];

  // الشاشة الرئيسية
  return (
    <div className="container mx-auto py-6 space-y-6 max-w-7xl">
      {/* عنوان الصفحة والأزرار الرئيسية */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">القوى العاملة</h1>
          <p className="text-muted-foreground mt-1">
            إدارة الموارد البشرية والفِرَق والعمال في المشاريع
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Dialog open={addWorkerDialog} onOpenChange={setAddWorkerDialog}>
            <DialogTrigger asChild>
              <Button className="gap-1">
                {activeTab === "team" ? (
                  <UserPlus className="h-4 w-4" />
                ) : (
                  <HardHat className="h-4 w-4" />
                )}
                {activeTab === "team" ? "إضافة عضو فريق" : "إضافة عامل"}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[650px]">
              <DialogHeader>
                <DialogTitle>
                  {activeTab === "team" ? "إضافة عضو فريق جديد" : "إضافة عامل جديد"}
                </DialogTitle>
                <DialogDescription>
                  {activeTab === "team" 
                    ? "أدخل بيانات عضو الفريق الجديد. اضغط زر الإرسال عند الانتهاء."
                    : "أدخل بيانات العامل الجديد. اضغط زر الإرسال عند الانتهاء."}
                </DialogDescription>
              </DialogHeader>
              
              {activeTab === "team" ? (
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      الاسم الكامل
                    </Label>
                    <Input id="name" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="role" className="text-right">
                      الدور
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الدور" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">مدير</SelectItem>
                        <SelectItem value="engineer">مهندس</SelectItem>
                        <SelectItem value="supervisor">مشرف</SelectItem>
                        <SelectItem value="worker">عامل</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="email" className="text-right">
                      البريد الإلكتروني
                    </Label>
                    <Input id="email" type="email" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="phone" className="text-right">
                      رقم الهاتف
                    </Label>
                    <Input id="phone" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="skills" className="text-right">
                      المهارات
                    </Label>
                    <Input id="skills" placeholder="فصل بفواصل" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="avatar" className="text-right">
                      الصورة
                    </Label>
                    <Input id="avatar" type="file" className="col-span-3" />
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setAddWorkerDialog(false)}>إلغاء</Button>
                    <Button type="submit" onClick={() => setAddWorkerDialog(false)}>حفظ</Button>
                  </div>
                </div>
              ) : (
                <WorkerForm onSuccess={() => setAddWorkerDialog(false)} />
              )}
            </DialogContent>
          </Dialog>

          <Button 
            variant="outline" 
            size="icon"
            onClick={() => setShowFilters(!showFilters)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* شريط الفلترة عند تفعيله */}
      {showFilters && (
        <Card className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="project-filter">المشروع</Label>
              <Select 
                value={selectedProject || ""} 
                onValueChange={(value) => setSelectedProject(value === "" ? null : value)}
              >
                <SelectTrigger id="project-filter">
                  <SelectValue placeholder="جميع المشاريع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-projects">جميع المشاريع</SelectItem>
                  {Array.isArray(projects) && projects.map((project: Project) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="specialization-filter">التخصص</Label>
              <Select 
                value={selectedSpecialization || ""}
                onValueChange={(value) => setSelectedSpecialization(value === "" ? null : value)}
              >
                <SelectTrigger id="specialization-filter">
                  <SelectValue placeholder="جميع التخصصات" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-specializations">جميع التخصصات</SelectItem>
                  {specializations.map((spec) => (
                    <SelectItem key={spec.value} value={spec.value}>
                      {spec.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button 
                variant="ghost" 
                onClick={() => {
                  setSelectedProject(null);
                  setSelectedSpecialization(null);
                }}
                className="ml-auto"
              >
                إعادة ضبط
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* شريط التبويب الرئيسي */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard" className="flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            <span className="hidden sm:inline">لوحة المعلومات</span>
            <span className="sm:hidden">المعلومات</span>
          </TabsTrigger>
          <TabsTrigger value="workers" className="flex items-center gap-2">
            <HardHat className="w-4 h-4" />
            <span>العمال</span>
          </TabsTrigger>
          <TabsTrigger value="team" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>الفريق الإداري</span>
          </TabsTrigger>
          <TabsTrigger value="attendance" className="flex items-center gap-2">
            <CalendarRange className="w-4 h-4" />
            <span>الحضور</span>
          </TabsTrigger>
        </TabsList>

        {/* محتوى التبويبات */}
        
        {/* تبويب الحضور */}
        <TabsContent value="attendance" className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="بحث عن عامل أو مشروع..."
                className="w-full sm:w-[300px] pr-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="date-filter" className="whitespace-nowrap">التاريخ:</Label>
              <Input 
                type="date" 
                id="date-filter"
                className="w-40"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-1">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <PersonStanding className="h-5 w-5" />
                    تسجيل حضور جديد
                  </CardTitle>
                  <CardDescription>
                    سجل حضور العمال للمشاريع المختلفة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label>العامل</Label>
                      <Select>
                        <SelectTrigger className="mt-1.5">
                          <SelectValue placeholder="اختر العامل" />
                        </SelectTrigger>
                        <SelectContent>
                          {workers.map((worker) => (
                            <SelectItem key={worker.id} value={worker.id.toString()}>
                              {worker.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>المشروع</Label>
                      <Select>
                        <SelectTrigger className="mt-1.5">
                          <SelectValue placeholder="اختر المشروع" />
                        </SelectTrigger>
                        <SelectContent>
                          {Array.isArray(projects) && projects.map((project: Project) => (
                            <SelectItem key={project.id} value={project.id.toString()}>
                              {project.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>التاريخ</Label>
                      <Input type="date" className="mt-1.5" />
                    </div>
                    <div>
                      <Label>الحالة</Label>
                      <Select defaultValue="present">
                        <SelectTrigger className="mt-1.5">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="present">حاضر</SelectItem>
                          <SelectItem value="absent">غائب</SelectItem>
                          <SelectItem value="leave">إجازة</SelectItem>
                          <SelectItem value="sick">مرضي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>ساعات العمل</Label>
                      <Input type="number" className="mt-1.5" min="0" max="24" step="0.5" defaultValue="8" />
                    </div>
                    <div>
                      <Label>ملاحظات</Label>
                      <Input className="mt-1.5" />
                    </div>
                    <Button className="w-full mt-2">تسجيل الحضور</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="lg:col-span-3">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <CalendarRange className="h-5 w-5" />
                    سجلات الحضور
                  </CardTitle>
                  <CardDescription>
                    سجلات الحضور الأخيرة للعمال في المشاريع
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingAttendance ? (
                    <div className="flex items-center justify-center h-60">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  ) : attendanceRecords.length > 0 ? (
                    <AttendanceTable
                      attendanceRecords={attendanceRecords}
                      projectNames={projectNames}
                    />
                  ) : (
                    <div className="text-center py-16 text-muted-foreground">
                      لا توجد سجلات حضور مطابقة للبحث
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        {/* لوحة المعلومات */}
        <TabsContent value="dashboard" className="space-y-6">
          {/* إحصائيات سريعة */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
              title="إجمالي العمال" 
              value={totalWorkers}
              icon={<HardHat className="w-5 h-5 text-white" />}
              color="bg-primary"
              description="العدد الكلي للعمال"
            />
            <StatCard 
              title="العمال النشطون" 
              value={activeWorkers}
              icon={<CheckCircle2 className="w-5 h-5 text-white" />}
              description={`نسبة النشاط: ${totalWorkers ? Math.round((activeWorkers / totalWorkers) * 100) : 0}%`}
              color="bg-green-500"
            />
            <StatCard 
              title="أعضاء الفريق" 
              value={totalTeamMembers}
              icon={<Users className="w-5 h-5 text-white" />}
              color="bg-blue-500"
              description="عدد أعضاء الفريق الإداري"
            />
            <StatCard 
              title="سجلات الحضور الأخيرة" 
              value={attendanceRecords.length}
              icon={<CalendarRange className="w-5 h-5 text-white" />}
              color="bg-orange-500"
              description="عدد سجلات الحضور"
            />
          </div>
          
          {/* الأقسام المختلفة */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* قسم آخر سجلات الحضور */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 ml-2" />
                  آخر سجلات الحضور
                </CardTitle>
                <CardDescription>سجلات الحضور والانصراف الأخيرة للعمال</CardDescription>
              </CardHeader>
              <CardContent>
                {attendanceRecords.length > 0 ? (
                  <AttendanceTable 
                    attendanceRecords={attendanceRecords.slice(0, 5)} 
                    projectNames={projectNames}
                  />
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    لا توجد سجلات حضور مسجلة حتى الآن
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* قسم الأنشطة الأخيرة */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-5 h-5 ml-2" />
                  آخر الأنشطة
                </CardTitle>
                <CardDescription>الأنشطة الأخيرة المتعلقة بالقوى العاملة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-2 rounded-full">
                      <User className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">تم إضافة عامل جديد</p>
                      <p className="text-xs text-muted-foreground">تم إضافة أحمد محمد كمهندس موقع</p>
                      <p className="text-xs text-muted-foreground mt-1">منذ 3 ساعات</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start gap-4">
                    <div className="bg-green-500/10 p-2 rounded-full">
                      <FileText className="w-4 h-4 text-green-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">تم تسجيل حضور 5 عمال</p>
                      <p className="text-xs text-muted-foreground">تم تسجيل الحضور لمشروع تمديدات كهرباء المدينة الصناعية</p>
                      <p className="text-xs text-muted-foreground mt-1">منذ 5 ساعات</p>
                    </div>
                  </div>
                  <Separator />
                  <div className="flex items-start gap-4">
                    <div className="bg-orange-500/10 p-2 rounded-full">
                      <Briefcase className="w-4 h-4 text-orange-500" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">تم تعيين مهام جديدة</p>
                      <p className="text-xs text-muted-foreground">تم تعيين خالد عبدالله لمشروع جديد</p>
                      <p className="text-xs text-muted-foreground mt-1">منذ يوم واحد</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* تبويب العمال */}
        <TabsContent value="workers" className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="بحث عن عامل..."
                className="w-full sm:w-[300px] pr-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Tabs
              value={workersTab}
              onValueChange={(value) => setWorkersTab(value as "all" | "active" | "inactive")}
              className="w-full sm:w-auto"
            >
              <TabsList className="grid w-full grid-cols-3 lg:w-[400px]">
                <TabsTrigger value="all">جميع العمال</TabsTrigger>
                <TabsTrigger value="active">النشطون</TabsTrigger>
                <TabsTrigger value="inactive">المنقطعون/المجازون</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {isLoadingWorkers ? (
            <div className="flex items-center justify-center min-h-[400px]">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : filteredWorkers.length === 0 ? (
            <div className="flex flex-col items-center justify-center min-h-[400px] border rounded-lg p-8 bg-muted/30">
              <p className="text-muted-foreground text-center mb-4">
                {searchTerm || selectedProject || selectedSpecialization ? "لا توجد نتائج مطابقة لبحثك" : "لا يوجد عمال بعد"}
              </p>
              {searchTerm || selectedProject || selectedSpecialization ? (
                <Button variant="outline" onClick={() => {
                  setSearchTerm("");
                  setSelectedProject(null);
                  setSelectedSpecialization(null);
                }}>
                  مسح البحث
                </Button>
              ) : (
                <Button onClick={() => setAddWorkerDialog(true)}>إضافة عامل جديد</Button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredWorkers.map((worker) => (
                <WorkerCard
                  key={worker.id}
                  worker={worker}
                  onEdit={handleEditWorker}
                  onViewAttendance={handleViewAttendance}
                />
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* تبويب الفريق */}
        <TabsContent value="team" className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="ابحث عن اسم العضو أو الدور أو المهارات..."
                className="pr-10 w-full sm:w-[300px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Tabs 
              value={teamTab} 
              onValueChange={setTeamTab}
              className="w-full sm:w-auto"
            >
              <TabsList className="grid w-full sm:grid-cols-5">
                <TabsTrigger value="all">الكل</TabsTrigger>
                <TabsTrigger value="admin">مدراء</TabsTrigger>
                <TabsTrigger value="engineer">مهندسون</TabsTrigger>
                <TabsTrigger value="supervisor">مشرفون</TabsTrigger>
                <TabsTrigger value="active">نشطون</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* عرض أعضاء الفريق */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTeamMembers.map(member => (
              <TeamMemberCard 
                key={member.id} 
                member={member} 
                onEdit={handleEditTeamMember}
              />
            ))}
          </div>

          {/* حالة عدم وجود نتائج */}
          {filteredTeamMembers.length === 0 && (
            <div className="text-center py-12 border rounded-lg bg-muted/30">
              <h3 className="text-xl font-medium text-gray-600">لا يوجد أعضاء فريق مطابقين للبحث</h3>
              <p className="text-gray-500 mt-2">حاول تغيير معايير البحث أو إضافة عضو جديد</p>
              <Button className="mt-4" onClick={() => setAddTeamMemberDialog(true)}>
                <UserPlus className="h-4 w-4 ml-2" />
                إضافة عضو فريق
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* حوارات منبثقة */}
      
      {/* حوار تعديل بيانات العامل */}
      {selectedWorker && (
        <Dialog open={editWorkerDialog} onOpenChange={setEditWorkerDialog}>
          <DialogContent className="sm:max-w-[650px]">
            <DialogHeader>
              <DialogTitle>تعديل بيانات العامل</DialogTitle>
              <DialogDescription>
                عدّل بيانات العامل. اضغط زر التحديث عند الانتهاء.
              </DialogDescription>
            </DialogHeader>
            <WorkerForm
              worker={selectedWorker}
              onSuccess={() => setEditWorkerDialog(false)}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* حوار تسجيل الحضور وعرض سجلات الحضور */}
      {selectedWorker && (
        <Dialog
          open={attendanceDialog}
          onOpenChange={setAttendanceDialog}
        >
          <DialogContent className="sm:max-w-[750px]">
            <DialogHeader>
              <DialogTitle>سجل حضور العامل - {selectedWorker.name}</DialogTitle>
              <DialogDescription>تسجيل حضور جديد وعرض سجلات الحضور السابقة</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="register">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="register">تسجيل حضور</TabsTrigger>
                <TabsTrigger value="view">سجلات الحضور</TabsTrigger>
              </TabsList>
              <TabsContent value="register" className="mt-4">
                <AttendanceForm
                  worker={selectedWorker}
                  onSuccess={() => {}}
                />
              </TabsContent>
              <TabsContent value="view" className="mt-4">
                {isLoadingAttendance ? (
                  <div className="flex items-center justify-center h-40">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <AttendanceTable
                    attendanceRecords={attendanceRecords}
                    projectNames={projectNames}
                  />
                )}
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {/* حوار تعديل بيانات عضو الفريق */}
      {selectedTeamMember && (
        <Dialog open={editTeamMemberDialog} onOpenChange={setEditTeamMemberDialog}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>تعديل بيانات عضو الفريق</DialogTitle>
              <DialogDescription>
                عدّل بيانات عضو الفريق {selectedTeamMember.fullName}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-name" className="text-right">
                  الاسم الكامل
                </Label>
                <Input 
                  id="edit-name" 
                  defaultValue={selectedTeamMember.fullName} 
                  className="col-span-3" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-role" className="text-right">
                  الدور
                </Label>
                <Select defaultValue={selectedTeamMember.role}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">مدير</SelectItem>
                    <SelectItem value="engineer">مهندس</SelectItem>
                    <SelectItem value="supervisor">مشرف</SelectItem>
                    <SelectItem value="worker">عامل</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-email" className="text-right">
                  البريد الإلكتروني
                </Label>
                <Input 
                  id="edit-email" 
                  type="email" 
                  defaultValue={selectedTeamMember.email}
                  className="col-span-3" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-phone" className="text-right">
                  رقم الهاتف
                </Label>
                <Input 
                  id="edit-phone" 
                  defaultValue={selectedTeamMember.phone}
                  className="col-span-3" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-skills" className="text-right">
                  المهارات
                </Label>
                <Input 
                  id="edit-skills" 
                  defaultValue={selectedTeamMember.skills.join(', ')}
                  className="col-span-3" 
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label className="text-right">
                  الحالة
                </Label>
                <div className="col-span-3 flex items-center space-x-2 space-x-reverse">
                  <Select defaultValue={selectedTeamMember.active ? "active" : "inactive"}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">نشط</SelectItem>
                      <SelectItem value="inactive">غير نشط</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setEditTeamMemberDialog(false)}>إلغاء</Button>
              <Button onClick={() => setEditTeamMemberDialog(false)}>حفظ التغييرات</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}