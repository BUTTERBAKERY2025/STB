import { useState } from "react";
import { 
  AlertTriangle, 
  PlusIcon, 
  Filter, 
  ChevronDown, 
  Loader2,
  FileText,
  Lightbulb,
  ClipboardList
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { useProjects } from "@/lib/data";

const RiskPrediction = () => {
  const { data: projects, isLoading } = useProjects();
  const [selectedProjectId, setSelectedProjectId] = useState<string | undefined>(undefined);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showAddRiskDialog, setShowAddRiskDialog] = useState(false);
  const [riskFactor, setRiskFactor] = useState(50); // Default risk factor for new risks
  
  // Sample risk analysis data
  const riskAnalysis = {
    overallRisk: 63,
    recommendation: "يجب إجراء مراجعة شاملة لجدول المشروع والموارد المخصصة له، وتحديد خطة بديلة للتعامل مع التأخير المحتمل في التوريدات.",
    topRisks: [
      {
        id: 1,
        title: "تأخر توريد المعدات",
        description: "احتمالية تأخر وصول المعدات الرئيسية من المورد الخارجي مما قد يؤثر على موعد الإنجاز",
        probability: 70,
        impact: 80,
        category: "توريدات",
        mitigation: "التواصل مع موردين بدلاء والبحث عن خيارات محلية بديلة"
      },
      {
        id: 2,
        title: "نقص العمالة الماهرة",
        description: "صعوبة توفير العدد الكافي من العمال المهرة خلال فترة الذروة للمشروع",
        probability: 65,
        impact: 60,
        category: "موارد بشرية",
        mitigation: "بدء عملية التوظيف مبكراً وتوفير برامج تدريب سريعة"
      },
      {
        id: 3,
        title: "تغييرات في نطاق المشروع",
        description: "احتمالية طلب العميل لتغييرات إضافية في نطاق المشروع بعد بدء التنفيذ",
        probability: 55,
        impact: 75,
        category: "إدارة",
        mitigation: "توثيق نطاق العمل بشكل دقيق واعتماد إجراءات واضحة لإدارة التغيير"
      }
    ],
    riskByCategory: [
      { name: "توريدات", value: 75 },
      { name: "موارد بشرية", value: 62 },
      { name: "مالية", value: 45 },
      { name: "تقنية", value: 38 },
      { name: "إدارة", value: 65 }
    ],
    riskTrend: [
      { month: "يناير", risk: 45 },
      { month: "فبراير", risk: 48 },
      { month: "مارس", risk: 52 },
      { month: "أبريل", risk: 58 },
      { month: "مايو", risk: 63 },
      { month: "يونيو", risk: 67 }
    ]
  };

  const getRiskLevel = (value: number) => {
    if (value >= 75) return { text: "مرتفع", color: "text-red-600", bg: "bg-red-600" };
    if (value >= 50) return { text: "متوسط", color: "text-yellow-600", bg: "bg-yellow-600" };
    return { text: "منخفض", color: "text-green-600", bg: "bg-green-600" };
  };
  
  const handleAnalyzeRisks = () => {
    if (!selectedProjectId) return;
    
    setIsAnalyzing(true);
    
    // Simulate API call to AI risk prediction service
    setTimeout(() => {
      setIsAnalyzing(false);
    }, 2000);
  };

  const getRiskCategoryBadge = (category: string) => {
    switch (category) {
      case "توريدات":
        return <Badge className="bg-blue-500">توريدات</Badge>;
      case "موارد بشرية":
        return <Badge className="bg-green-500">موارد بشرية</Badge>;
      case "إدارة":
        return <Badge className="bg-purple-500">إدارة</Badge>;
      case "مالية":
        return <Badge className="bg-yellow-500">مالية</Badge>;
      case "تقنية":
        return <Badge className="bg-pink-500">تقنية</Badge>;
      default:
        return <Badge className="bg-gray-500">{category}</Badge>;
    }
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <>
      <div className="flex flex-col space-y-6">
        {/* Header with title and actions */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold dark:text-white">تنبؤ المخاطر</h1>
          <div className="flex space-x-2 space-x-reverse">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Filter size={16} />
              <span>تصفية</span>
            </Button>
            <Dialog open={showAddRiskDialog} onOpenChange={setShowAddRiskDialog}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-1">
                  <PlusIcon size={16} />
                  <span>مخاطرة جديدة</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>إضافة مخاطرة جديدة</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskProject" className="text-right">
                      المشروع
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskTitle" className="text-right">
                      عنوان المخاطرة
                    </Label>
                    <Input id="riskTitle" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskDescription" className="text-right">
                      الوصف
                    </Label>
                    <Textarea id="riskDescription" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskCategory" className="text-right">
                      الفئة
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="توريدات">توريدات</SelectItem>
                        <SelectItem value="موارد بشرية">موارد بشرية</SelectItem>
                        <SelectItem value="إدارة">إدارة</SelectItem>
                        <SelectItem value="مالية">مالية</SelectItem>
                        <SelectItem value="تقنية">تقنية</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskFactor" className="text-right">
                      درجة المخاطرة: {riskFactor}
                    </Label>
                    <div className="col-span-3">
                      <Slider
                        id="riskFactor"
                        min={0}
                        max={100}
                        step={1}
                        value={[riskFactor]}
                        onValueChange={(value) => setRiskFactor(value[0])}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="riskMitigation" className="text-right">
                      خطة التخفيف
                    </Label>
                    <Textarea id="riskMitigation" className="col-span-3" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowAddRiskDialog(false)}>إلغاء</Button>
                  <Button type="submit" onClick={() => setShowAddRiskDialog(false)}>حفظ المخاطرة</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Project selection and Risk Analysis */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="w-full md:w-1/3 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>تحليل مخاطر المشروع</CardTitle>
                <CardDescription>
                  اختر مشروعاً لتحليل المخاطر المحتملة باستخدام الذكاء الاصطناعي
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="projectSelect">المشروع</Label>
                  <Select
                    value={selectedProjectId}
                    onValueChange={setSelectedProjectId}
                  >
                    <SelectTrigger id="projectSelect">
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects?.map(project => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="w-full"
                  onClick={handleAnalyzeRisks}
                  disabled={isAnalyzing || !selectedProjectId}
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="ml-2 h-4 w-4 animate-spin" />
                      جاري التحليل...
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="ml-2 h-4 w-4" />
                      تحليل المخاطر
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>درجة المخاطرة الإجمالية</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="text-center py-4">
                  <div className="inline-flex items-center justify-center h-32 w-32 rounded-full border-8 border-gray-100 dark:border-gray-800">
                    <div 
                      className={`text-4xl font-bold ${getRiskLevel(riskAnalysis.overallRisk).color}`}
                    >
                      {riskAnalysis.overallRisk}
                    </div>
                  </div>
                  <div className="mt-4">
                    <Badge className={`${getRiskLevel(riskAnalysis.overallRisk).bg} text-white`}>
                      {getRiskLevel(riskAnalysis.overallRisk).text}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>المخاطر حسب الفئة</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  {riskAnalysis.riskByCategory.map((category, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium dark:text-white">{category.name}</span>
                        <span className={getRiskLevel(category.value).color}>{category.value}%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                        <div 
                          className={`${getRiskLevel(category.value).bg} h-2.5 rounded-full`} 
                          style={{ width: `${category.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="w-full md:w-2/3 space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>توصية الذكاء الاصطناعي</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-primary/10 dark:bg-primary/20 p-4 rounded-md border border-primary/20 dark:border-primary/30">
                  <div className="flex items-start">
                    <Lightbulb className="h-6 w-6 text-primary ml-3 mt-1 flex-shrink-0" />
                    <p className="text-gray-700 dark:text-gray-300">{riskAnalysis.recommendation}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>اتجاه المخاطر</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={riskAnalysis.riskTrend}
                      margin={{
                        top: 5,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="risk" fill="hsl(var(--primary))" name="درجة المخاطرة" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle>أهم المخاطر المحتملة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {riskAnalysis.topRisks.map((risk, index) => (
                    <Card key={risk.id} className="bg-gray-50 dark:bg-gray-800/50">
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium text-lg dark:text-white flex items-center">
                              <AlertTriangle className="h-5 w-5 ml-2 text-yellow-500" />
                              {risk.title}
                            </h4>
                            <div className="flex items-center mt-1">
                              {getRiskCategoryBadge(risk.category)}
                              <div className="mr-2 flex items-center">
                                <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">احتمالية:</span>
                                <span className={`text-sm ${getRiskLevel(risk.probability).color}`}>{risk.probability}%</span>
                              </div>
                              <div className="mr-2 flex items-center">
                                <span className="text-sm text-gray-500 dark:text-gray-400 ml-1">تأثير:</span>
                                <span className={`text-sm ${getRiskLevel(risk.impact).color}`}>{risk.impact}%</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <p className="text-gray-600 dark:text-gray-300 mt-2 text-sm">{risk.description}</p>
                        <div className="mt-3">
                          <span className="text-sm font-medium dark:text-gray-300">خطة التخفيف:</span>
                          <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">{risk.mitigation}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
};

export default RiskPrediction;