import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calculator,
  FileText,
  LayoutDashboard,
  BookOpen,
  CircleDollarSign,
  BarChart3,
  Building,
  Network,
  Filter,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

import ChartOfAccountsManager from "@/components/financial/ChartOfAccountsManager";
import JournalEntryManager from "@/components/financial/JournalEntryManager";
import FinancialReportsViewer from "@/components/financial/FinancialReportsViewer";
import ProjectFinancialCenter from "@/components/financial/ProjectFinancialCenter";

export default function FinancialSystem() {
  const [activeTab, setActiveTab] = useState("chart-of-accounts");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="h-screen flex flex-col bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto py-3 px-4 flex justify-between items-center">
          <div className="flex items-center">
            <Calculator className="h-6 w-6 mr-2" />
            <h1 className="text-xl font-bold">النظام المالي والمحاسبي</h1>
          </div>
          <div className="flex space-x-2 rtl:space-x-reverse">
            <Button variant="outline" size="sm">
              <FileText className="h-4 w-4 ml-1 rtl:mr-1" /> الأدلة والمساعدة
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* الشريط الجانبي */}
        <aside
          className={`bg-card border-l transition-all duration-300 ${
            sidebarCollapsed ? "w-16" : "w-64"
          }`}
        >
          <div className="flex justify-end p-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            >
              {sidebarCollapsed ? (
                <ChevronLeft className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          </div>
          <div className="p-2">
            <nav className="space-y-1">
              <Button
                variant={activeTab === "chart-of-accounts" ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  sidebarCollapsed ? "px-2" : "px-3"
                }`}
                onClick={() => setActiveTab("chart-of-accounts")}
              >
                <Network className="h-5 w-5 ml-2 rtl:mr-2 flex-shrink-0" />
                {!sidebarCollapsed && <span>شجرة الحسابات</span>}
              </Button>
              <Button
                variant={activeTab === "journal-entries" ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  sidebarCollapsed ? "px-2" : "px-3"
                }`}
                onClick={() => setActiveTab("journal-entries")}
              >
                <BookOpen className="h-5 w-5 ml-2 rtl:mr-2 flex-shrink-0" />
                {!sidebarCollapsed && <span>دفتر اليومية</span>}
              </Button>
              <Button
                variant={activeTab === "financial-reports" ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  sidebarCollapsed ? "px-2" : "px-3"
                }`}
                onClick={() => setActiveTab("financial-reports")}
              >
                <FileText className="h-5 w-5 ml-2 rtl:mr-2 flex-shrink-0" />
                {!sidebarCollapsed && <span>التقارير المالية</span>}
              </Button>
              <Button
                variant={activeTab === "project-financial-center" ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  sidebarCollapsed ? "px-2" : "px-3"
                }`}
                onClick={() => setActiveTab("project-financial-center")}
              >
                <Building className="h-5 w-5 ml-2 rtl:mr-2 flex-shrink-0" />
                {!sidebarCollapsed && <span>المراكز المالية للمشاريع</span>}
              </Button>
              <Button
                variant={activeTab === "dashboard" ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  sidebarCollapsed ? "px-2" : "px-3"
                }`}
                onClick={() => setActiveTab("dashboard")}
              >
                <LayoutDashboard className="h-5 w-5 ml-2 rtl:mr-2 flex-shrink-0" />
                {!sidebarCollapsed && <span>لوحة القيادة</span>}
              </Button>
            </nav>
          </div>
        </aside>

        {/* المحتوى الرئيسي */}
        <main className="flex-1 overflow-hidden">
          <div className="h-full">
            {activeTab === "chart-of-accounts" && <ChartOfAccountsManager />}
            {activeTab === "journal-entries" && <JournalEntryManager />}
            {activeTab === "financial-reports" && <FinancialReportsViewer />}
            {activeTab === "project-financial-center" && <ProjectFinancialCenter />}
            {activeTab === "dashboard" && (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="h-20 w-20 mx-auto mb-6 text-muted-foreground" />
                  <h2 className="text-2xl font-bold mb-2">لوحة القيادة المالية</h2>
                  <p className="text-muted-foreground max-w-md">
                    سيتم تطوير لوحة القيادة المالية لاحقًا لعرض المؤشرات الرئيسية والرسوم البيانية للأداء المالي.
                  </p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}