import { useState, useCallback, useRef, useEffect } from 'react';
import { useProjects, useGeoLocations, useCreateGeoLocation, useUpdateGeoLocation, useDeleteGeoLocation } from '@/lib/data';
import { GoogleMap, useLoadScript, MarkerF, InfoWindowF, CircleF } from '@react-google-maps/api';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { useToast } from '@/hooks/use-toast';
import { MapPin, Users, Truck, Construction, RefreshCw, PlusCircle, Info, AlertCircle, Edit, Layers, Route, Trash2 } from 'lucide-react';
import { InsertGeoLocation, GeoLocation, Project } from '@shared/schema';
import { formatDate, formatCurrency } from '@/lib/utils';

// كود لتحميل الخريطة
const libraries: ["places"] = ["places"];

const mapContainerStyle = {
  width: '100%',
  height: '70vh',
};

// موقع افتراضي (الرياض)
const defaultCenter = {
  lat: 24.7136,
  lng: 46.6753,
};

const GeoTracking = () => {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
    libraries,
  });

  const [selectedProject, setSelectedProject] = useState<number | null>(null);
  const [selectedTab, setSelectedTab] = useState('map');
  const [selectedMarker, setSelectedMarker] = useState<GeoLocation | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [mapCenter, setMapCenter] = useState(defaultCenter);
  const [filterEntityType, setFilterEntityType] = useState<string | null>(null);
  const [locationForm, setLocationForm] = useState<Partial<InsertGeoLocation>>({
    name: '',
    latitude: 0,
    longitude: 0,
    entityType: 'site',
    entityId: undefined,
    description: '',
    status: 'active',
    radius: 100,
    projectId: undefined,
  });

  const { data: projects = [], isLoading: isLoadingProjects } = useProjects();
  const { data: locations = [], isLoading: isLoadingLocations } = useGeoLocations(
    selectedProject || undefined
  );
  const { mutate: createLocation, isPending: isCreating } = useCreateGeoLocation();
  const { mutate: updateLocation, isPending: isUpdating } = useUpdateGeoLocation();
  const { mutate: deleteLocation, isPending: isDeleting } = useDeleteGeoLocation();
  const { toast } = useToast();
  
  const mapRef = useRef<google.maps.Map | null>(null);
  
  // تحديث البيانات عند تغيير المشروع
  useEffect(() => {
    if (selectedProject && locations.length > 0) {
      // تحديث مركز الخريطة إلى أول موقع للمشروع
      const firstLocation = locations[0];
      setMapCenter({
        lat: firstLocation.latitude,
        lng: firstLocation.longitude,
      });
    }
  }, [selectedProject, locations]);
  
  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
  }, []);
  
  const onMapClick = useCallback((event: google.maps.MapMouseEvent) => {
    if (isAddDialogOpen && event.latLng) {
      setLocationForm(prev => ({
        ...prev,
        latitude: event.latLng?.lat() || 0,
        longitude: event.latLng?.lng() || 0,
      }));
    }
  }, [isAddDialogOpen]);
  
  const handleAddLocation = () => {
    if (!selectedProject) {
      toast({
        title: "خطأ",
        description: "يرجى اختيار مشروع أولاً",
        variant: "destructive",
      });
      return;
    }
    
    const newLocation: InsertGeoLocation = {
      ...locationForm as InsertGeoLocation,
      projectId: selectedProject,
    };
    
    createLocation(newLocation, {
      onSuccess: () => {
        toast({
          title: "تم إضافة الموقع بنجاح",
          description: "تم إضافة الموقع الجغرافي بنجاح للمشروع",
        });
        setIsAddDialogOpen(false);
        setLocationForm({
          name: '',
          latitude: 0,
          longitude: 0,
          entityType: 'site',
          entityId: undefined,
          description: '',
          status: 'active',
          radius: 100,
          projectId: selectedProject,
        });
      },
      onError: (error) => {
        toast({
          title: "فشل في إضافة الموقع",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleUpdateLocation = () => {
    if (!selectedMarker) return;
    
    const updatedLocation: Partial<InsertGeoLocation> = {
      ...locationForm,
    };
    
    updateLocation({ 
      id: selectedMarker.id, 
      location: updatedLocation 
    }, {
      onSuccess: () => {
        toast({
          title: "تم تحديث الموقع بنجاح",
          description: "تم تحديث الموقع الجغرافي بنجاح",
        });
        setIsEditDialogOpen(false);
        setSelectedMarker(null);
      },
      onError: (error) => {
        toast({
          title: "فشل في تحديث الموقع",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };
  
  const handleEditLocation = (location: GeoLocation) => {
    setSelectedMarker(location);
    setLocationForm({
      name: location.name,
      latitude: location.latitude,
      longitude: location.longitude,
      entityType: location.entityType,
      entityId: location.entityId,
      description: location.description || '',
      status: location.status,
      radius: location.radius,
      projectId: location.projectId,
    });
    setIsEditDialogOpen(true);
  };
  
  const handleDeleteLocation = (location: GeoLocation) => {
    if (!location) return;
    
    // تأكيد الحذف
    if (confirm(`هل أنت متأكد من حذف الموقع ${location.name}؟`)) {
      deleteLocation({ 
        id: location.id, 
        projectId: location.projectId 
      }, {
        onSuccess: () => {
          toast({
            title: "تم حذف الموقع بنجاح",
            description: "تم حذف الموقع الجغرافي بنجاح",
          });
          setSelectedMarker(null);
        },
        onError: (error) => {
          toast({
            title: "فشل في حذف الموقع",
            description: error.message,
            variant: "destructive",
          });
        }
      });
    }
  };
  
  const getMarkerIcon = (entityType: string, status: string) => {
    // يمكن استخدام أيقونات مختلفة لأنواع المواقع المختلفة
    if (status === 'inactive') {
      return { url: 'http://maps.google.com/mapfiles/ms/icons/grey-dot.png' };
    }
    
    switch (entityType) {
      case 'site':
        return { url: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png' };
      case 'equipment':
        return { url: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png' };
      case 'worker':
        return { url: 'http://maps.google.com/mapfiles/ms/icons/green-dot.png' };
      case 'warehouse':
        return { url: 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png' };
      default:
        return { url: 'http://maps.google.com/mapfiles/ms/icons/purple-dot.png' };
    }
  };
  
  const getFilteredLocations = () => {
    if (!filterEntityType) return locations;
    return locations.filter(location => location.entityType === filterEntityType);
  };
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'inactive': return 'bg-gray-500';
      case 'warning': return 'bg-yellow-500';
      case 'alert': return 'bg-red-500';
      default: return 'bg-blue-500';
    }
  };
  
  const getEntityTypeLabel = (type: string) => {
    switch (type) {
      case 'site': return 'موقع عمل';
      case 'equipment': return 'معدات';
      case 'worker': return 'عامل';
      case 'warehouse': return 'مستودع';
      case 'office': return 'مكتب';
      default: return type;
    }
  };
  
  const getEntityIcon = (type: string) => {
    switch (type) {
      case 'site': return <Construction className="h-4 w-4" />;
      case 'equipment': return <Truck className="h-4 w-4" />;
      case 'worker': return <Users className="h-4 w-4" />;
      case 'warehouse': return <Layers className="h-4 w-4" />;
      case 'office': return <MapPin className="h-4 w-4" />;
      default: return <MapPin className="h-4 w-4" />;
    }
  };
  
  if (loadError) {
    return (
      <div className="flex-1 p-4">
        <Card>
          <CardHeader>
            <CardTitle>خطأ في تحميل الخريطة</CardTitle>
          </CardHeader>
          <CardContent>
            <p>حدث خطأ أثناء تحميل الخريطة: {loadError.message}</p>
            <p className="text-sm text-muted-foreground mt-2">
              تأكد من إضافة مفتاح API صحيح لخرائط Google.
              يمكنك الحصول على مفتاح من{' '}
              <a 
                href="https://developers.google.com/maps/documentation/javascript/get-api-key"
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary underline"
              >
                هنا
              </a>.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="flex-1 p-4 space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">تتبع المواقع الجغرافية</h2>
          <p className="text-muted-foreground">تتبع مواقع المشاريع والمعدات والعمال على الخريطة</p>
        </div>
        
        <div className="flex items-center space-x-2 space-x-reverse">
          <Select
            value={selectedProject?.toString() || ''}
            onValueChange={(value) => setSelectedProject(value ? parseInt(value) : null)}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="اختر المشروع" />
            </SelectTrigger>
            <SelectContent>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select
            value={filterEntityType || ''}
            onValueChange={(value) => setFilterEntityType(value || null)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="نوع الموقع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع الأنواع</SelectItem>
              <SelectItem value="site">مواقع العمل</SelectItem>
              <SelectItem value="equipment">المعدات</SelectItem>
              <SelectItem value="worker">العمال</SelectItem>
              <SelectItem value="warehouse">المستودعات</SelectItem>
              <SelectItem value="office">المكاتب</SelectItem>
            </SelectContent>
          </Select>
          
          <DialogTrigger asChild onClick={() => setIsAddDialogOpen(true)}>
            <Button disabled={!selectedProject}>
              <PlusCircle className="ml-2 h-4 w-4" />
              إضافة موقع
            </Button>
          </DialogTrigger>
        </div>
      </div>
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList>
          <TabsTrigger value="map">
            <MapPin className="h-4 w-4 ml-1" />
            الخريطة
          </TabsTrigger>
          <TabsTrigger value="list">
            <Layers className="h-4 w-4 ml-1" />
            قائمة المواقع
          </TabsTrigger>
          <TabsTrigger value="routes">
            <Route className="h-4 w-4 ml-1" />
            المسارات
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="map" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              {!isLoaded ? (
                <div className="h-[70vh] flex items-center justify-center">
                  <Skeleton className="w-full h-full" />
                </div>
              ) : (
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={mapCenter}
                  zoom={12}
                  onClick={onMapClick}
                  onLoad={onMapLoad}
                  options={{
                    fullscreenControl: true,
                    streetViewControl: false,
                    mapTypeControl: true,
                    zoomControl: true,
                  }}
                >
                  {getFilteredLocations().map((location) => (
                    <div key={location.id}>
                      <MarkerF
                        position={{ lat: location.latitude, lng: location.longitude }}
                        icon={getMarkerIcon(location.entityType, location.status || 'active')}
                        onClick={() => setSelectedMarker(location)}
                      />
                      
                      {location.radius && location.radius > 0 && (
                        <CircleF
                          center={{ lat: location.latitude, lng: location.longitude }}
                          radius={location.radius}
                          options={{
                            fillColor: location.status === 'active' ? '#4caf5033' : '#9e9e9e33',
                            fillOpacity: 0.35,
                            strokeColor: location.status === 'active' ? '#4caf50' : '#9e9e9e',
                            strokeOpacity: 0.8,
                            strokeWeight: 1,
                          }}
                        />
                      )}
                      
                      {selectedMarker && selectedMarker.id === location.id && (
                        <InfoWindowF
                          position={{ lat: location.latitude, lng: location.longitude }}
                          onCloseClick={() => setSelectedMarker(null)}
                        >
                          <div className="p-2 max-w-xs">
                            <h3 className="font-medium text-lg">{location.name}</h3>
                            
                            <div className="flex items-center mt-1">
                              <Badge className={`${getStatusColor(location.status || 'active')} text-white`}>
                                {location.status === 'active' ? 'نشط' : 'غير نشط'}
                              </Badge>
                              <Badge variant="outline" className="ml-2">
                                {getEntityTypeLabel(location.entityType)}
                              </Badge>
                            </div>
                            
                            {location.description && (
                              <p className="mt-2 text-sm text-gray-700">{location.description}</p>
                            )}
                            
                            <div className="mt-3 pt-2 border-t border-gray-200">
                              <div className="text-xs text-gray-500">
                                <div>خط العرض: {location.latitude.toFixed(6)}</div>
                                <div>خط الطول: {location.longitude.toFixed(6)}</div>
                                {location.radius && <div>نطاق: {location.radius} متر</div>}
                              </div>
                            </div>
                            
                            <div className="flex gap-2 mt-2">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="flex-1"
                                onClick={() => handleEditLocation(location)}
                              >
                                <Edit className="h-3 w-3 ml-1" />
                                تعديل
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="flex-1 text-red-500 hover:text-red-600 hover:bg-red-100 border-red-200"
                                onClick={() => handleDeleteLocation(location)}
                                disabled={isDeleting}
                              >
                                <Trash2 className="h-3 w-3 ml-1" />
                                حذف
                              </Button>
                            </div>
                          </div>
                        </InfoWindowF>
                      )}
                    </div>
                  ))}
                </GoogleMap>
              )}
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Construction className="h-4 w-4 ml-2 text-red-500" />
                  <CardTitle className="text-sm">مواقع العمل</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {locations.filter(l => l.entityType === 'site').length}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Truck className="h-4 w-4 ml-2 text-blue-500" />
                  <CardTitle className="text-sm">المعدات</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {locations.filter(l => l.entityType === 'equipment').length}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Users className="h-4 w-4 ml-2 text-green-500" />
                  <CardTitle className="text-sm">العمال</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {locations.filter(l => l.entityType === 'worker').length}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center">
                  <Layers className="h-4 w-4 ml-2 text-yellow-500" />
                  <CardTitle className="text-sm">المستودعات</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {locations.filter(l => l.entityType === 'warehouse').length}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>قائمة المواقع الجغرافية</CardTitle>
              <CardDescription>
                عرض جميع المواقع المسجلة للمشروع المحدد
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingLocations ? (
                <div className="space-y-2">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="w-full h-12" />
                  ))}
                </div>
              ) : locations.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {selectedProject 
                    ? "لا توجد مواقع مسجلة لهذا المشروع. قم بإضافة موقع جديد."
                    : "يرجى اختيار مشروع لعرض المواقع الجغرافية."
                  }
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-muted/50">
                        <th className="px-4 py-2 text-right">الاسم</th>
                        <th className="px-4 py-2 text-right">النوع</th>
                        <th className="px-4 py-2 text-right">الحالة</th>
                        <th className="px-4 py-2 text-right">الإحداثيات</th>
                        <th className="px-4 py-2 text-right">النطاق</th>
                        <th className="px-4 py-2 text-right">التاريخ</th>
                        <th className="px-4 py-2 text-right">الإجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {getFilteredLocations().map((location) => (
                        <tr key={location.id} className="border-t hover:bg-muted/20">
                          <td className="px-4 py-2">{location.name}</td>
                          <td className="px-4 py-2">
                            <div className="flex items-center">
                              {getEntityIcon(location.entityType)}
                              <span className="mr-1">{getEntityTypeLabel(location.entityType)}</span>
                            </div>
                          </td>
                          <td className="px-4 py-2">
                            <Badge className={`${getStatusColor(location.status || 'active')} text-white`}>
                              {location.status === 'active' ? 'نشط' : 'غير نشط'}
                            </Badge>
                          </td>
                          <td className="px-4 py-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <div className="flex items-center text-xs">
                                    <MapPin className="h-3 w-3 ml-1 text-gray-500" />
                                    <span>{location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}</span>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">خط العرض: {location.latitude}</p>
                                  <p className="text-xs">خط الطول: {location.longitude}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </td>
                          <td className="px-4 py-2">
                            {location.radius ? `${location.radius} متر` : '-'}
                          </td>
                          <td className="px-4 py-2 text-xs">
                            {location.updatedAt ? formatDate(new Date(location.updatedAt)) : '-'}
                          </td>
                          <td className="px-4 py-2">
                            <div className="flex gap-1">
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                onClick={() => {
                                  setSelectedMarker(location);
                                  setMapCenter({
                                    lat: location.latitude,
                                    lng: location.longitude,
                                  });
                                  setSelectedTab('map');
                                }}
                              >
                                <MapPin className="h-3 w-3 ml-1" />
                                عرض
                              </Button>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                onClick={() => handleEditLocation(location)}
                              >
                                <Edit className="h-3 w-3 ml-1" />
                                تعديل
                              </Button>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="text-red-500 hover:text-red-600 hover:bg-red-100"
                                onClick={() => handleDeleteLocation(location)}
                                disabled={isDeleting}
                              >
                                <Trash2 className="h-3 w-3 ml-1" />
                                حذف
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="routes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>المسارات</CardTitle>
              <CardDescription>
                عرض مسارات التنقل بين المواقع المختلفة
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[400px] flex items-center justify-center">
              <div className="text-center">
                <Route className="h-10 w-10 text-muted-foreground mb-2 mx-auto" />
                <h3 className="text-lg font-medium">ميزة المسارات قيد التطوير</h3>
                <p className="text-muted-foreground">
                  سيتم إضافة ميزة تتبع المسارات وتخطيط الطرق قريباً
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* نافذة حوار إضافة موقع جديد */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة موقع جديد</DialogTitle>
            <DialogDescription>
              حدد موقعاً على الخريطة أو أدخل إحداثيات الموقع يدوياً
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">اسم الموقع</Label>
              <Input
                id="name"
                value={locationForm.name}
                onChange={(e) => setLocationForm({...locationForm, name: e.target.value})}
                placeholder="اسم الموقع"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="latitude">خط العرض</Label>
                <Input
                  id="latitude"
                  type="number"
                  step="0.000001"
                  value={locationForm.latitude}
                  onChange={(e) => setLocationForm({...locationForm, latitude: parseFloat(e.target.value)})}
                  placeholder="خط العرض"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="longitude">خط الطول</Label>
                <Input
                  id="longitude"
                  type="number"
                  step="0.000001"
                  value={locationForm.longitude}
                  onChange={(e) => setLocationForm({...locationForm, longitude: parseFloat(e.target.value)})}
                  placeholder="خط الطول"
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="entityType">نوع الموقع</Label>
              <Select
                value={locationForm.entityType}
                onValueChange={(value) => setLocationForm({...locationForm, entityType: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع الموقع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="site">موقع عمل</SelectItem>
                  <SelectItem value="equipment">معدات</SelectItem>
                  <SelectItem value="worker">عامل</SelectItem>
                  <SelectItem value="warehouse">مستودع</SelectItem>
                  <SelectItem value="office">مكتب</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="radius">نطاق الموقع (بالمتر)</Label>
              <Input
                id="radius"
                type="number"
                value={locationForm.radius || ""}
                onChange={(e) => setLocationForm({...locationForm, radius: e.target.value ? parseInt(e.target.value) : null})}
                placeholder="نطاق الموقع بالمتر"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">وصف الموقع</Label>
              <Textarea
                id="description"
                value={locationForm.description}
                onChange={(e) => setLocationForm({...locationForm, description: e.target.value})}
                placeholder="وصف الموقع (اختياري)"
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2 space-x-reverse">
              <Label htmlFor="status" className="ml-2">الحالة: نشط</Label>
              <Switch
                id="status"
                checked={locationForm.status === 'active'}
                onCheckedChange={(checked) => 
                  setLocationForm({...locationForm, status: checked ? 'active' : 'inactive'})
                }
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              إلغاء
            </Button>
            <Button onClick={handleAddLocation} disabled={isCreating}>
              {isCreating ? 'جاري الإضافة...' : 'إضافة الموقع'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* نافذة حوار تعديل موقع */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>تعديل موقع</DialogTitle>
            <DialogDescription>
              تعديل بيانات الموقع الجغرافي
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">اسم الموقع</Label>
              <Input
                id="edit-name"
                value={locationForm.name}
                onChange={(e) => setLocationForm({...locationForm, name: e.target.value})}
                placeholder="اسم الموقع"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-latitude">خط العرض</Label>
                <Input
                  id="edit-latitude"
                  type="number"
                  step="0.000001"
                  value={locationForm.latitude}
                  onChange={(e) => setLocationForm({...locationForm, latitude: parseFloat(e.target.value)})}
                  placeholder="خط العرض"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-longitude">خط الطول</Label>
                <Input
                  id="edit-longitude"
                  type="number"
                  step="0.000001"
                  value={locationForm.longitude}
                  onChange={(e) => setLocationForm({...locationForm, longitude: parseFloat(e.target.value)})}
                  placeholder="خط الطول"
                />
              </div>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-entityType">نوع الموقع</Label>
              <Select
                value={locationForm.entityType}
                onValueChange={(value) => setLocationForm({...locationForm, entityType: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر نوع الموقع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="site">موقع عمل</SelectItem>
                  <SelectItem value="equipment">معدات</SelectItem>
                  <SelectItem value="worker">عامل</SelectItem>
                  <SelectItem value="warehouse">مستودع</SelectItem>
                  <SelectItem value="office">مكتب</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-radius">نطاق الموقع (بالمتر)</Label>
              <Input
                id="edit-radius"
                type="number"
                value={locationForm.radius || ""}
                onChange={(e) => setLocationForm({...locationForm, radius: e.target.value ? parseInt(e.target.value) : null})}
                placeholder="نطاق الموقع بالمتر"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-description">وصف الموقع</Label>
              <Textarea
                id="edit-description"
                value={locationForm.description}
                onChange={(e) => setLocationForm({...locationForm, description: e.target.value})}
                placeholder="وصف الموقع (اختياري)"
                rows={2}
              />
            </div>
            
            <div className="flex items-center space-x-2 space-x-reverse">
              <Label htmlFor="edit-status" className="ml-2">الحالة: نشط</Label>
              <Switch
                id="edit-status"
                checked={locationForm.status === 'active'}
                onCheckedChange={(checked) => 
                  setLocationForm({...locationForm, status: checked ? 'active' : 'inactive'})
                }
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              إلغاء
            </Button>
            <Button onClick={handleUpdateLocation} disabled={isUpdating}>
              {isUpdating ? 'جاري التحديث...' : 'تحديث الموقع'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GeoTracking;