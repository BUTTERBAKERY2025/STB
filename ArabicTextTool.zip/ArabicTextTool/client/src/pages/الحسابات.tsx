import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet-async';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  BookOpen, 
  FileText, 
  Printer, 
  Download,
  CalendarIcon,
} from 'lucide-react';

import AccountTreeManager from '@/components/financial/AccountTreeManager';
import AccountBalancesView from '@/components/financial/AccountBalancesView';
import JournalEntryManager from '@/components/financial/JournalEntryManager';

/**
 * صفحة إدارة الحسابات
 * 
 * تقدم واجهة لإدارة:
 * - دليل الحسابات (شجرة الحسابات)
 * - أرصدة الحسابات وكشف الحركة
 * - القيود المحاسبية
 */

const AccountsPage: React.FC = () => {
  // حالة المكون
  const [activeTab, setActiveTab] = useState('chart');
  const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);

  // استعلام دليل الحسابات
  const { data: chartOfAccounts = [] } = useQuery({
    queryKey: ['/api/financial/accounts'],
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // استعلام القيود المحاسبية
  const { data: journalEntries = [] } = useQuery({
    queryKey: ['/api/journal-entries'],
    staleTime: 60 * 1000, // دقيقة واحدة
  });

  // إظهار تفاصيل حساب محدد
  const handleAccountSelected = (accountId: number) => {
    setSelectedAccountId(accountId);
    setActiveTab('balances');
  };

  // تصدير دليل الحسابات كملف
  const handleExportChartOfAccounts = () => {
    window.open('/api/financial/accounts-export?format=pdf');
  };

  // طباعة الصفحة الحالية
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <Helmet>
        <title>إدارة الحسابات</title>
      </Helmet>

      {/* رأس الصفحة */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">إدارة الحسابات</h1>
          <p className="text-muted-foreground">
            إدارة دليل الحسابات، الأرصدة، والقيود المحاسبية
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={handleExportChartOfAccounts} title="تصدير دليل الحسابات">
            <Download className="h-4 w-4" />
          </Button>

          <Button variant="outline" size="icon" onClick={handlePrint} title="طباعة">
            <Printer className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* علامات التبويب */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="chart" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            <span>دليل الحسابات</span>
          </TabsTrigger>
          <TabsTrigger value="balances" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span>أرصدة الحسابات</span>
          </TabsTrigger>
          <TabsTrigger value="entries" className="flex items-center gap-2">
            <CalendarIcon className="h-4 w-4" />
            <span>القيود المحاسبية</span>
          </TabsTrigger>
        </TabsList>

        {/* محتوى دليل الحسابات */}
        <TabsContent value="chart">
          <Card>
            <CardHeader>
              <CardTitle>دليل الحسابات</CardTitle>
              <CardDescription>
                إدارة شجرة الحسابات وهيكلها التنظيمي
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <AccountTreeManager 
                onAccountSelected={handleAccountSelected} 
                showSelector={true} 
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* محتوى أرصدة الحسابات */}
        <TabsContent value="balances">
          <Card>
            <CardHeader>
              <CardTitle>أرصدة الحسابات وكشوف الحركة</CardTitle>
              <CardDescription>
                عرض أرصدة الحسابات وتفاصيل حركتها خلال الفترة المالية
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <AccountBalancesView />
            </CardContent>
          </Card>
        </TabsContent>

        {/* محتوى القيود المحاسبية */}
        <TabsContent value="entries">
          <Card>
            <CardHeader>
              <CardTitle>القيود المحاسبية</CardTitle>
              <CardDescription>
                إدارة وإنشاء القيود المحاسبية
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <JournalEntryManager />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* إحصائيات وتحليلات */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">إجمالي الحسابات</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{chartOfAccounts.length}</p>
            <p className="text-muted-foreground text-sm">حساب في دليل الحسابات</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">حسابات نشطة</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{chartOfAccounts.filter((account: any) => account.isActive).length}</p>
            <p className="text-muted-foreground text-sm">حساب قيد الاستخدام</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">القيود المحاسبية</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{journalEntries.length}</p>
            <p className="text-muted-foreground text-sm">قيد محاسبي مسجل</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">حسابات الأصول</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{chartOfAccounts.filter((account: any) => account.type === 'asset').length}</p>
            <p className="text-muted-foreground text-sm">حساب أصول في النظام</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AccountsPage;