import React, { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '../lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { formatDate } from '@/lib/utils';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import PaymentStatusTracker from '../components/payment/PaymentStatusTracker';
import ProjectFinancialInsights from '../components/payment/ProjectFinancialInsights';
import PaymentRequestToPdfTemplate from '../components/payment/PaymentRequestToPdfTemplate';
import IntelligentItemsTable from '../components/payment/IntelligentItemsTable';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow,
  TableFooter
} from '@/components/ui/table';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  AlertCircle, 
  CheckCircle, 
  Plus, 
  FileText, 
  Download, 
  Printer, 
  Save, 
  BarChart3, 
  Link, 
  History,
  BookOpen,
  ChevronDown,
  PanelLeft,
  AlignJustify,
  Check,
  Pencil,
  XCircle,
  Clock,
  ChartBar,
  UploadCloud, 
  FileSpreadsheet, 
  CalendarDays, 
  FileImage
} from 'lucide-react';

import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';

// نوع المستخلص المالي
interface PaymentRequest {
  id: number;
  projectId: number;
  requestNumber: string;
  title: string;
  type: string;
  startDate: string;
  endDate: string;
  status: string;
  totalAmount: number;
  previousPaymentsAmount: number;
  currentPaymentAmount: number;
  totalCompletionPercentage: number;
  notes: string | null;
  approvedBy: number | null;
  approvalDate: string | null;
  paymentDate: string | null;
  issueDate: string;
  createdBy: number;
  createdAt: string;
  attachments: string[];
}

// نوع بند المستخلص المالي
interface PaymentRequestItem {
  id: number;
  paymentRequestId: number;
  itemName: string;
  itemDescription: string | null;
  unit: string;
  unitPrice: number;
  plannedQuantity: number;
  completedQuantity: number;
  completionPercentage: number;
  previousPaymentPercentage: number;
  currentPaymentAmount: number;
  notes: string | null;
}

// نوع المشروع المختصر
interface Project {
  id: number;
  name: string;
  status: string;
}

// نوع تقرير الإنجاز اليومي
interface DailyReport {
  id: number;
  projectId: number;
  reportDate: string;
  workCompleted: string;
  issues: string | null;
  workersPresent: number;
  equipmentUsed: any;
  weatherConditions: string | null;
  hoursWorked: number;
  submittedBy: number;
  submittedAt: string;
}

// نوع المستند
interface Document {
  id: number;
  projectId: number | null;
  name: string;
  fileUrl: string;
  fileType: string;
  uploadedBy: number;
  uploadedAt: string;
  category: string;
}

// إضافة نموذج بند المستخلص
interface ItemFormData {
  paymentRequestId: number;
  itemName: string;
  itemDescription: string | null;
  unit: string;
  unitPrice: number;
  plannedQuantity: number;
  completedQuantity: number;
  completionPercentage: number;
  previousPaymentPercentage: number;
  currentPaymentAmount: number | null;
  notes: string | null;
}

// نموذج تحميل المستند
interface AttachmentFormData {
  file: File | null;
  name: string;
  category: string;
}

const PaymentRequestGenerator: React.FC = () => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [currentRequestId, setCurrentRequestId] = useState<number | null>(null);
  const [showAddItemForm, setShowAddItemForm] = useState(false);
  const [showDailyReportsModal, setShowDailyReportsModal] = useState(false);
  const [showAttachmentsModal, setShowAttachmentsModal] = useState(false);
  const [selectedDateRange, setSelectedDateRange] = useState<{from: Date | undefined, to: Date | undefined}>({from: undefined, to: undefined});
  
  // حالة نموذج الملفات المرفقة
  const [attachmentFormData, setAttachmentFormData] = useState<AttachmentFormData>({
    file: null,
    name: '',
    category: 'invoice'
  });
  
  const [itemFormData, setItemFormData] = useState<ItemFormData>({
    paymentRequestId: 0,
    itemName: '',
    itemDescription: '',
    unit: '',
    unitPrice: 0,
    plannedQuantity: 0,
    completedQuantity: 0,
    completionPercentage: 0,
    previousPaymentPercentage: 0,
    currentPaymentAmount: null,
    notes: ''
  });
  
  // الحصول على التاريخ الحالي بتنسيق YYYY-MM-DD
  const currentDate = new Date().toISOString().split('T')[0];
  
  const [newRequestData, setNewRequestData] = useState({
    projectId: 0,
    requestNumber: '',
    title: '',
    type: 'interim', // افتراضي: مستخلص مرحلي
    startDate: currentDate,
    endDate: currentDate,
    notes: '',
    issueDate: currentDate,
    createdBy: 1, // المستخدم الحالي
  });
  
  // استعلام المشاريع
  const { data: projects } = useQuery<Project[]>({ 
    queryKey: ['/api/projects'], 
  });
  
  // استعلام المستخلصات المالية للمشروع المحدد
  const { data: paymentRequests, isLoading: isLoadingRequests } = useQuery<PaymentRequest[]>({
    queryKey: ['/api/projects', selectedProjectId, 'payment-requests'],
    queryFn: () => 
      fetch(`/api/projects/${selectedProjectId}/payment-requests`).then(res => 
        res.json()
      ),
    enabled: !!selectedProjectId
  });
  
  // توليد رقم المستخلص تلقائيًا عند اختيار المشروع
  useEffect(() => {
    if (selectedProjectId && projects) {
      const project = projects.find(p => p.id === selectedProjectId);
      if (project) {
        // استخدام رقم المشروع بدلاً من الأحرف العربية
        const projectCode = selectedProjectId.toString().padStart(2, '0');
        
        // الحصول على أعلى رقم تسلسلي للمستخلصات الحالية لهذا المشروع
        let sequenceNumber = 1;
        
        if (paymentRequests && paymentRequests.length > 0) {
          // فرز المستخلصات وأخذ آخر رقم تسلسلي
          const existingNumbers = paymentRequests
            .map(req => {
              const parts = req.requestNumber.split('-');
              if (parts.length === 2) {
                return parseInt(parts[1], 10);
              }
              return 0;
            })
            .filter(num => !isNaN(num));
          
          if (existingNumbers.length > 0) {
            // الحصول على أعلى رقم وإضافة 1
            sequenceNumber = Math.max(...existingNumbers) + 1;
          }
        }
        
        // تنسيق رقم المستخلص: رقم المشروع-رقم تسلسلي (مثل 01-001)
        const formattedSequence = String(sequenceNumber).padStart(3, '0');
        const generatedNumber = `${projectCode}-${formattedSequence}`;
        
        setNewRequestData(prev => ({
          ...prev,
          requestNumber: generatedNumber
        }));
      }
    }
  }, [selectedProjectId, projects, paymentRequests]);
  
  // استعلام بنود المستخلص المالي المحدد
  const { data: paymentRequestItems, isLoading: isLoadingItems } = useQuery<PaymentRequestItem[]>({
    queryKey: ['/api/payment-requests', currentRequestId, 'items'],
    queryFn: () => 
      fetch(`/api/payment-requests/${currentRequestId}/items`).then(res => 
        res.json()
      ),
    enabled: !!currentRequestId
  });
  
  // استعلام المستخلص المالي المحدد
  const { data: currentRequest } = useQuery<PaymentRequest>({
    queryKey: ['/api/payment-requests', currentRequestId],
    queryFn: () => 
      fetch(`/api/payment-requests/${currentRequestId}`).then(res => 
        res.json()
      ),
    enabled: !!currentRequestId
  });
  
  // استعلام تقارير الإنجاز اليومية للمشروع المحدد
  const { data: dailyReports, isLoading: isLoadingReports } = useQuery<DailyReport[]>({
    queryKey: ['/api/projects', selectedProjectId, 'daily-reports'],
    queryFn: () => 
      fetch(`/api/projects/${selectedProjectId}/daily-reports`).then(res => 
        res.json()
      ),
    enabled: !!selectedProjectId && showDailyReportsModal
  });
  
  // استعلام المستندات المرفقة للمستخلص
  const { data: attachments, isLoading: isLoadingAttachments } = useQuery<Document[]>({
    queryKey: ['/api/projects', selectedProjectId, 'documents'],
    queryFn: () => 
      fetch(`/api/projects/${selectedProjectId}/documents`).then(res => 
        res.json()
      ),
    enabled: !!selectedProjectId && showAttachmentsModal
  });
  
  // إنشاء مستخلص مالي جديد
  const createPaymentRequestMutation = useMutation({
    mutationFn: (data: Omit<PaymentRequest, 'id' | 'createdAt'>) => 
      fetch('/api/payment-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(res => res.json()),
    onSuccess: (data) => {
      toast({
        title: "تم الإنشاء بنجاح",
        description: "تم إنشاء المستخلص المالي بنجاح",
      });
      setCurrentRequestId(data.id);
      queryClient.invalidateQueries({ queryKey: ['/api/projects', selectedProjectId, 'payment-requests'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء إنشاء المستخلص المالي",
        variant: "destructive"
      });
    }
  });
  
  // إضافة بند للمستخلص المالي
  const addItemMutation = useMutation({
    mutationFn: (data: Omit<PaymentRequestItem, 'id'>) => 
      fetch('/api/payment-request-items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "تم الإضافة بنجاح",
        description: "تم إضافة البند إلى المستخلص المالي",
      });
      setShowAddItemForm(false);
      setItemFormData({
        paymentRequestId: currentRequestId || 0,
        itemName: '',
        itemDescription: '',
        unit: '',
        unitPrice: 0,
        plannedQuantity: 0,
        completedQuantity: 0,
        completionPercentage: 0,
        previousPaymentPercentage: 0,
        currentPaymentAmount: null,
        notes: ''
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payment-requests', currentRequestId, 'items'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payment-requests', currentRequestId] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء إضافة البند",
        variant: "destructive"
      });
    }
  });
  
  // تحديث حالة المستخلص المالي
  const updatePaymentRequestMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Partial<PaymentRequest> }) => 
      fetch(`/api/payment-requests/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).then(res => res.json()),
    onSuccess: () => {
      toast({
        title: "تم التحديث بنجاح",
        description: "تم تحديث حالة المستخلص المالي",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/payment-requests', currentRequestId] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تحديث حالة المستخلص",
        variant: "destructive"
      });
    }
  });
  
  // معالجة إنشاء مستخلص جديد
  const handleCreateRequest = () => {
    if (!selectedProjectId || !newRequestData.title) {
      toast({
        title: "معلومات غير مكتملة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }
    
    // التأكد من وجود رقم المستخلص (سيتم توليده تلقائياً إذا لم يوجد)
    if (!newRequestData.requestNumber) {
      if (projects) {
        // استخدام رقم المشروع كرمز للمستخلص
        const projectCode = selectedProjectId.toString().padStart(2, '0');
        
        // تنسيق رقم المستخلص: رقم مشروع-رقم تسلسلي (مثل 01-001)
        const formattedRequestNumber = `${projectCode}-001`;
        setNewRequestData(prev => ({
          ...prev,
          requestNumber: formattedRequestNumber
        }));
      }
    }
    
    createPaymentRequestMutation.mutate({
      ...newRequestData,
      projectId: selectedProjectId,
      status: 'draft',
      totalAmount: 0,
      previousPaymentsAmount: 0,
      currentPaymentAmount: 0,
      totalCompletionPercentage: 0, // حقل إلزامي مطلوب من المخطط
      approvedBy: null,
      approvalDate: null,
      paymentDate: null,
      attachments: []
    });
  };
  
  // معالجة إضافة بند للمستخلص
  const handleAddItem = () => {
    if (!currentRequestId) return;
    
    const { 
      itemName, unit, unitPrice, plannedQuantity, completedQuantity,
      completionPercentage, previousPaymentPercentage 
    } = itemFormData;
    
    if (!itemName || !unit || unitPrice <= 0 || plannedQuantity <= 0) {
      toast({
        title: "معلومات غير مكتملة",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }
    
    // حساب المبلغ الحالي للدفع إذا لم يتم تحديده
    const calculatedAmount = itemFormData.currentPaymentAmount !== null 
      ? itemFormData.currentPaymentAmount 
      : (unitPrice * completedQuantity * (completionPercentage - previousPaymentPercentage) / 100);
    
    addItemMutation.mutate({
      ...itemFormData,
      paymentRequestId: currentRequestId,
      currentPaymentAmount: calculatedAmount
    });
  };
  
  // إنشاء مستخلص جديد بناء على المستخلص السابق
  const createFromPrevious = (previousRequest: PaymentRequest) => {
    if (!selectedProjectId) return;
    
    // إنشاء مستخلص جديد بنفس بيانات المستخلص السابق مع تحديثات
    const requestNumber = `${previousRequest.requestNumber.split('-')[0]}-${parseInt(previousRequest.requestNumber.split('-')[1]) + 1}`;
    
    const newRequest = {
      projectId: selectedProjectId,
      requestNumber,
      title: `${previousRequest.title} - متابعة`,
      type: previousRequest.type,
      startDate: previousRequest.endDate, // تاريخ البداية هو تاريخ نهاية المستخلص السابق
      endDate: new Date().toISOString().split('T')[0], // تاريخ النهاية هو اليوم
      notes: `مستخلص متابعة للمستخلص رقم ${previousRequest.requestNumber}`,
      issueDate: new Date().toISOString().split('T')[0],
      createdBy: 1, // المستخدم الحالي
      status: 'draft',
      totalAmount: 0,
      previousPaymentsAmount: previousRequest.previousPaymentsAmount + previousRequest.currentPaymentAmount,
      currentPaymentAmount: 0,
      totalCompletionPercentage: 0,
      approvedBy: null,
      approvalDate: null,
      paymentDate: null,
      attachments: []
    };
    
    createPaymentRequestMutation.mutate(newRequest, {
      onSuccess: (data) => {
        // بعد إنشاء المستخلص الجديد، نسخ بنود المستخلص السابق مع تحديث نسب الدفع السابق
        if (previousRequest.id && paymentRequestItems) {
          fetchPaymentRequestItems(previousRequest.id).then(previousItems => {
            if (previousItems && previousItems.length > 0) {
              // معالجة كل بند على حدة
              previousItems.forEach(prevItem => {
                const newItem = {
                  paymentRequestId: data.id,
                  itemName: prevItem.itemName,
                  itemDescription: prevItem.itemDescription,
                  unit: prevItem.unit,
                  unitPrice: prevItem.unitPrice,
                  plannedQuantity: prevItem.plannedQuantity,
                  completedQuantity: prevItem.completedQuantity,
                  completionPercentage: prevItem.completionPercentage,
                  previousPaymentPercentage: prevItem.completionPercentage, // تحديث النسبة السابقة
                  currentPaymentAmount: 0, // صفر في البداية حتى يتم تحديثها
                  notes: prevItem.notes
                };
                
                addItemMutation.mutate(newItem);
              });
            }
          });
        }
        
        setCurrentRequestId(data.id);
      }
    });
  };
  
  // الحصول على بنود مستخلص سابق
  const fetchPaymentRequestItems = async (requestId: number): Promise<PaymentRequestItem[] | null> => {
    try {
      const response = await fetch(`/api/payment-requests/${requestId}/items`);
      if (!response.ok) throw new Error("Failed to fetch items");
      return await response.json();
    } catch (error) {
      console.error("Error fetching previous items:", error);
      return null;
    }
  };
  
  // معالجة تغيير حالة المستخلص
  const handleStatusChange = (status: string) => {
    if (!currentRequestId) return;
    
    updatePaymentRequestMutation.mutate({
      id: currentRequestId,
      data: { status }
    });
  };
  
  // تصدير المستخلص كملف PDF
  const exportToPdf = async () => {
    if (!currentRequestId || !currentRequest) return;
    
    const element = document.getElementById('payment-request-print');
    if (!element) return;
    
    try {
      toast({
        title: "جاري التصدير",
        description: "يرجى الانتظار...",
      });
      
      // تحويل المحتوى إلى صورة أولاً
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#FFFFFF',
        logging: true
      });
      
      // صنع ملف PDF من الصورة
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
        putOnlyUsedFonts: true
      });
      
      // إعداد أبعاد الصفحة
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;
      const imgY = 10;
      
      // إضافة الصورة إلى PDF
      pdf.addImage(imgData, 'JPEG', imgX, imgY, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`مستخلص_${currentRequest.requestNumber}.pdf`);
      
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير المستخلص كملف PDF",
      });
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تصدير المستخلص: " + (error as Error).message,
        variant: "destructive"
      });
    }
  };
  
  // تصدير المستخلص كملف Excel
  const exportToExcel = () => {
    if (!currentRequestId || !currentRequest || !paymentRequestItems) return;
    
    try {
      toast({
        title: "جاري التصدير",
        description: "يرجى الانتظار...",
      });
      
      // إنشاء بيانات Excel
      const workbook = XLSX.utils.book_new();
      
      // البيانات الرئيسية للمستخلص
      const mainData = [
        [`مستخلص مالي رقم: ${currentRequest.requestNumber}`],
        [`عنوان المستخلص: ${currentRequest.title}`],
        [`نوع المستخلص: ${currentRequest.type === 'interim' ? 'مرحلي' : 'ختامي'}`],
        [`المشروع: ${projects?.find(p => p.id === currentRequest.projectId)?.name}`],
        [`الفترة: من ${formatDate(currentRequest.startDate)} إلى ${formatDate(currentRequest.endDate)}`],
        [`تاريخ الإصدار: ${formatDate(currentRequest.issueDate)}`],
        [`حالة المستخلص: ${
          currentRequest.status === 'approved' ? 'معتمد' : 
          currentRequest.status === 'draft' ? 'مسودة' : 
          currentRequest.status === 'pending' ? 'قيد المراجعة' : 
          currentRequest.status === 'rejected' ? 'مرفوض' : 
          currentRequest.status === 'paid' ? 'مدفوع' : currentRequest.status
        }`],
        []
      ];
      
      // جدول البنود
      const headers = ['#', 'البند', 'الوصف', 'الوحدة', 'سعر الوحدة', 'الكمية المخططة', 'الكمية المنجزة', 'نسبة الإنجاز', 'المبلغ الحالي'];
      const items = paymentRequestItems.map((item, index) => [
        index + 1,
        item.itemName,
        item.itemDescription || '',
        item.unit,
        item.unitPrice,
        item.plannedQuantity,
        item.completedQuantity,
        `${item.completionPercentage}%`,
        item.currentPaymentAmount
      ]);
      
      // إضافة إجماليات
      const summary = [
        [],
        ['ملخص المدفوعات'],
        ['إجمالي قيمة المشروع', currentRequest.totalAmount],
        ['المدفوعات السابقة', currentRequest.previousPaymentsAmount],
        ['المبلغ الحالي', currentRequest.currentPaymentAmount]
      ];
      
      // دمج البيانات
      const sheetData = [
        ...mainData,
        headers,
        ...items,
        ...summary
      ];
      
      // إنشاء ورقة العمل وتصديرها
      const worksheet = XLSX.utils.aoa_to_sheet(sheetData);
      
      // تحديد عرض الأعمدة
      const colWidths = [
        { wch: 5 }, // #
        { wch: 30 }, // البند
        { wch: 30 }, // الوصف
        { wch: 10 }, // الوحدة
        { wch: 15 }, // سعر الوحدة
        { wch: 15 }, // الكمية المخططة
        { wch: 15 }, // الكمية المنجزة
        { wch: 15 }, // نسبة الإنجاز
        { wch: 15 }, // المبلغ الحالي
      ];
      worksheet['!cols'] = colWidths;
      
      XLSX.utils.book_append_sheet(workbook, worksheet, "مستخلص مالي");
      XLSX.writeFile(workbook, `مستخلص_${currentRequest.requestNumber}.xlsx`);
      
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير المستخلص كملف Excel",
      });
    } catch (error) {
      console.error('Error exporting to Excel:', error);
      toast({
        title: "خطأ",
        description: "حدث خطأ أثناء تصدير المستخلص: " + (error as Error).message,
        variant: "destructive"
      });
    }
  };
  
  // توليد اقتراحات للبنود من تقارير الإنجاز اليومية
  const generateItemSuggestions = () => {
    if (!dailyReports || dailyReports.length === 0) {
      toast({
        title: "لا توجد تقارير",
        description: "لا توجد تقارير إنجاز يومية لاستخلاص البنود منها",
        variant: "destructive"
      });
      return;
    }

    // استخراج العمل المنجز من التقارير وتحويله إلى اقتراحات للبنود
    const completedWorkList = dailyReports
      .filter(report => new Date(report.reportDate) >= new Date(currentRequest?.startDate || '') && 
               new Date(report.reportDate) <= new Date(currentRequest?.endDate || ''))
      .map(report => report.workCompleted)
      .join('\n')
      .split('\n')
      .filter(item => item.trim().length > 0);
    
    // إنشاء قائمة فريدة من البنود المقترحة
    const uniqueItems = [...new Set(completedWorkList)];
    
    // عرض القائمة في شكل اقتراحات للبنود
    if (uniqueItems.length === 0) {
      toast({
        title: "لا توجد اقتراحات",
        description: "لم يتم العثور على بنود مقترحة من تقارير الإنجاز في الفترة المحددة",
        variant: "warning"
      });
    } else {
      setShowDailyReportsModal(true);
    }
  };
  
  // تحديث حقول نموذج البند تلقائيًا عند تغيير الكميات
  useEffect(() => {
    if (itemFormData.completedQuantity > 0 && itemFormData.plannedQuantity > 0) {
      const calculatedPercentage = (itemFormData.completedQuantity / itemFormData.plannedQuantity) * 100;
      setItemFormData(prev => ({
        ...prev,
        completionPercentage: Math.min(Math.round(calculatedPercentage), 100)
      }));
    }
  }, [itemFormData.completedQuantity, itemFormData.plannedQuantity]);

  // حساب المبلغ الحالي تلقائيًا عند تغيير نسب الإنجاز
  useEffect(() => {
    if (itemFormData.unitPrice > 0 && itemFormData.completedQuantity > 0 && 
        itemFormData.completionPercentage > itemFormData.previousPaymentPercentage) {
      const calculatedAmount = 
        itemFormData.unitPrice * 
        itemFormData.completedQuantity * 
        (itemFormData.completionPercentage - itemFormData.previousPaymentPercentage) / 100;
      
      setItemFormData(prev => ({
        ...prev,
        currentPaymentAmount: Math.round(calculatedAmount * 100) / 100
      }));
    }
  }, [itemFormData.completionPercentage, itemFormData.previousPaymentPercentage, 
      itemFormData.unitPrice, itemFormData.completedQuantity]);

  return (
    <div className="container mx-auto py-6 min-h-screen" dir="rtl">
      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6 p-1 bg-muted/30 rounded-xl">
          <TabsTrigger value="create" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
            <FileText className="h-4 w-4 ml-2" />
            إنشاء مستخلص
          </TabsTrigger>
          <TabsTrigger value="view" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">
            <BookOpen className="h-4 w-4 ml-2" />
            عرض المستخلصات
          </TabsTrigger>
          <TabsTrigger value="print" disabled={!currentRequestId} className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm" data-value="print">
            <Printer className="h-4 w-4 ml-2" />
            طباعة وتصدير
          </TabsTrigger>
        </TabsList>
        
        {/* قسم إنشاء مستخلص جديد */}
        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle>إنشاء مستخلص مالي جديد</CardTitle>
              <CardDescription>
                قم بإدخال بيانات المستخلص المالي الجديد
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="project">المشروع</Label>
                    <Select 
                      value={selectedProjectId?.toString() || ''} 
                      onValueChange={(value) => setSelectedProjectId(parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name} ({project.status})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="requestNumber">رقم المستخلص</Label>
                    <Input 
                      id="requestNumber" 
                      placeholder="مثال: PRJ-001" 
                      value={newRequestData.requestNumber}
                      onChange={(e) => setNewRequestData({...newRequestData, requestNumber: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="title">عنوان المستخلص</Label>
                  <Input 
                    id="title" 
                    placeholder="أدخل عنوان المستخلص" 
                    value={newRequestData.title}
                    onChange={(e) => setNewRequestData({...newRequestData, title: e.target.value})}
                  />
                </div>
                
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="type">نوع المستخلص</Label>
                    <Select 
                      value={newRequestData.type} 
                      onValueChange={(value) => setNewRequestData({...newRequestData, type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر نوع المستخلص" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="interim">مستخلص مرحلي</SelectItem>
                        <SelectItem value="final">مستخلص ختامي</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="issueDate">تاريخ الإصدار</Label>
                    <Input 
                      id="issueDate" 
                      type="date" 
                      value={newRequestData.issueDate}
                      onChange={(e) => setNewRequestData({...newRequestData, issueDate: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">تاريخ البداية</Label>
                    <Input 
                      id="startDate" 
                      type="date" 
                      value={newRequestData.startDate}
                      onChange={(e) => setNewRequestData({...newRequestData, startDate: e.target.value})}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="endDate">تاريخ النهاية</Label>
                    <Input 
                      id="endDate" 
                      type="date" 
                      value={newRequestData.endDate}
                      onChange={(e) => setNewRequestData({...newRequestData, endDate: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notes">ملاحظات</Label>
                  <Textarea 
                    id="notes" 
                    placeholder="أدخل أي ملاحظات إضافية حول المستخلص" 
                    value={newRequestData.notes}
                    onChange={(e) => setNewRequestData({...newRequestData, notes: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => {
                  setNewRequestData({
                    projectId: 0,
                    requestNumber: '',
                    title: '',
                    type: 'interim',
                    startDate: '',
                    endDate: '',
                    notes: '',
                    issueDate: new Date().toISOString().split('T')[0],
                    createdBy: 1
                  });
                }}
              >
                إلغاء
              </Button>
              <Button onClick={handleCreateRequest}>
                إنشاء المستخلص
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* قسم عرض المستخلصات */}
        <TabsContent value="view">
          <Card>
            <CardHeader>
              <CardTitle>عرض المستخلصات المالية</CardTitle>
              <CardDescription>
                عرض وإدارة المستخلصات المالية للمشاريع
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="projectFilter">تصفية حسب المشروع</Label>
                    <Select 
                      value={selectedProjectId?.toString() || ''} 
                      onValueChange={(value) => setSelectedProjectId(parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name} ({project.status})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {isLoadingRequests ? (
                  <div className="text-center py-4">
                    <p className="text-muted-foreground">جاري تحميل المستخلصات...</p>
                  </div>
                ) : paymentRequests && paymentRequests.length > 0 ? (
                  <div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[80px]">#</TableHead>
                          <TableHead>رقم المستخلص</TableHead>
                          <TableHead>العنوان</TableHead>
                          <TableHead>النوع</TableHead>
                          <TableHead>الفترة</TableHead>
                          <TableHead>الحالة</TableHead>
                          <TableHead>المبلغ</TableHead>
                          <TableHead>تاريخ الإصدار</TableHead>
                          <TableHead className="text-left">إجراءات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paymentRequests.map((request, index) => (
                          <TableRow key={request.id}>
                            <TableCell>{index + 1}</TableCell>
                            <TableCell>{request.requestNumber}</TableCell>
                            <TableCell>{request.title}</TableCell>
                            <TableCell>{request.type === 'interim' ? 'مرحلي' : 'ختامي'}</TableCell>
                            <TableCell>{formatDate(request.startDate)} - {formatDate(request.endDate)}</TableCell>
                            <TableCell>
                              <Badge 
                                variant={
                                  request.status === 'approved' ? 'success' : 
                                  request.status === 'draft' ? 'outline' : 
                                  request.status === 'pending' ? 'warning' : 
                                  request.status === 'rejected' ? 'destructive' : 
                                  request.status === 'paid' ? 'default' : 'outline'
                                }
                              >
                                {
                                  request.status === 'approved' ? 'معتمد' : 
                                  request.status === 'draft' ? 'مسودة' : 
                                  request.status === 'pending' ? 'قيد المراجعة' : 
                                  request.status === 'rejected' ? 'مرفوض' : 
                                  request.status === 'paid' ? 'مدفوع' : request.status
                                }
                              </Badge>
                            </TableCell>
                            <TableCell>{request.currentPaymentAmount.toLocaleString()} ر.س</TableCell>
                            <TableCell>{formatDate(request.issueDate)}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  onClick={() => {
                                    setCurrentRequestId(request.id);
                                    document.querySelector('[data-value="print"]')?.click();
                                  }}
                                >
                                  <FileText className="h-4 w-4" />
                                </Button>
                                
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="outline" size="sm">
                                      <Plus className="h-4 w-4" />
                                    </Button>
                                  </DialogTrigger>
                                  <DialogContent className="sm:max-w-[425px]">
                                    <DialogHeader>
                                      <DialogTitle>إضافة بند للمستخلص</DialogTitle>
                                      <DialogDescription>
                                        أضف بندًا جديدًا للمستخلص المالي رقم {request.requestNumber}
                                      </DialogDescription>
                                    </DialogHeader>
                                    <div className="grid gap-4 py-4">
                                      <div className="space-y-2">
                                        <Label htmlFor="itemName">اسم البند</Label>
                                        <Input 
                                          id="itemName" 
                                          placeholder="أدخل اسم البند" 
                                          value={itemFormData.itemName}
                                          onChange={(e) => setItemFormData({...itemFormData, itemName: e.target.value, paymentRequestId: request.id})}
                                        />
                                      </div>
                                      <div className="space-y-2">
                                        <Label htmlFor="itemDescription">وصف البند (اختياري)</Label>
                                        <Input 
                                          id="itemDescription" 
                                          placeholder="أضف وصفًا للبند" 
                                          value={itemFormData.itemDescription || ''}
                                          onChange={(e) => setItemFormData({...itemFormData, itemDescription: e.target.value, paymentRequestId: request.id})}
                                        />
                                      </div>
                                      <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                          <Label htmlFor="unit">الوحدة</Label>
                                          <Input 
                                            id="unit" 
                                            placeholder="مثال: متر" 
                                            value={itemFormData.unit}
                                            onChange={(e) => setItemFormData({...itemFormData, unit: e.target.value, paymentRequestId: request.id})}
                                          />
                                        </div>
                                        <div className="space-y-2">
                                          <Label htmlFor="unitPrice">سعر الوحدة</Label>
                                          <Input 
                                            id="unitPrice" 
                                            type="number" 
                                            placeholder="السعر" 
                                            value={itemFormData.unitPrice || ''}
                                            onChange={(e) => setItemFormData({...itemFormData, unitPrice: parseFloat(e.target.value), paymentRequestId: request.id})}
                                          />
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                          <Label htmlFor="plannedQuantity">الكمية المخططة</Label>
                                          <Input 
                                            id="plannedQuantity" 
                                            type="number" 
                                            placeholder="الكمية المخططة" 
                                            value={itemFormData.plannedQuantity || ''}
                                            onChange={(e) => setItemFormData({...itemFormData, plannedQuantity: parseFloat(e.target.value), paymentRequestId: request.id})}
                                          />
                                        </div>
                                        <div className="space-y-2">
                                          <Label htmlFor="completedQuantity">الكمية المنجزة</Label>
                                          <Input 
                                            id="completedQuantity" 
                                            type="number" 
                                            placeholder="الكمية المنجزة" 
                                            value={itemFormData.completedQuantity || ''}
                                            onChange={(e) => setItemFormData({...itemFormData, completedQuantity: parseFloat(e.target.value), paymentRequestId: request.id})}
                                          />
                                        </div>
                                      </div>
                                      <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                          <Label htmlFor="completionPercentage">نسبة الإنجاز (%)</Label>
                                          <Input 
                                            id="completionPercentage" 
                                            type="number" 
                                            placeholder="نسبة الإنجاز" 
                                            value={itemFormData.completionPercentage || ''}
                                            onChange={(e) => setItemFormData({
                                              ...itemFormData, 
                                              completionPercentage: parseFloat(e.target.value), 
                                              paymentRequestId: request.id
                                            })}
                                          />
                                        </div>
                                        <div className="space-y-2">
                                          <Label htmlFor="previousPaymentPercentage">نسبة الدفع السابق (%)</Label>
                                          <Input 
                                            id="previousPaymentPercentage" 
                                            type="number" 
                                            placeholder="نسبة الدفع السابق" 
                                            value={itemFormData.previousPaymentPercentage || ''}
                                            onChange={(e) => setItemFormData({
                                              ...itemFormData, 
                                              previousPaymentPercentage: parseFloat(e.target.value), 
                                              paymentRequestId: request.id
                                            })}
                                          />
                                        </div>
                                      </div>
                                      <div className="space-y-2">
                                        <Label htmlFor="currentPaymentAmount">المبلغ الحالي (ر.س)</Label>
                                        <Input 
                                          id="currentPaymentAmount" 
                                          type="number" 
                                          placeholder="المبلغ الحالي" 
                                          value={itemFormData.currentPaymentAmount || ''}
                                          onChange={(e) => setItemFormData({
                                            ...itemFormData, 
                                            currentPaymentAmount: parseFloat(e.target.value), 
                                            paymentRequestId: request.id
                                          })}
                                        />
                                        <p className="text-xs text-muted-foreground">
                                          يمكن تعديل المبلغ يدوياً أو سيتم حسابه تلقائياً بناءً على نسب الإنجاز
                                        </p>
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button type="submit" onClick={() => {
                                        setCurrentRequestId(request.id);
                                        handleAddItem();
                                      }}>إضافة البند</Button>
                                    </DialogFooter>
                                  </DialogContent>
                                </Dialog>
                                
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => createFromPrevious(request)}
                                >
                                  <History className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center p-4 bg-muted/20 rounded">
                    <p className="text-muted-foreground">
                      {selectedProjectId 
                        ? "لا توجد مستخلصات مالية لهذا المشروع" 
                        : "يرجى اختيار مشروع لعرض المستخلصات المالية"}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* قسم الطباعة والتصدير */}
        <TabsContent value="print">
          {currentRequestId && currentRequest ? (
            <div className="space-y-6">
              <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
                <Card className="md:col-span-1">
                  <CardHeader>
                    <CardTitle className="text-xl">خيارات التصدير</CardTitle>
                    <CardDescription>تصدير المستخلص بصيغ مختلفة</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-lg bg-muted/50 p-4">
                        <h3 className="font-medium mb-2 flex items-center">
                          <Download className="h-4 w-4 ml-2 text-primary" />
                          تصدير المستخلص
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          اختر تنسيق التصدير المناسب لمستخلصك
                        </p>
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm" 
                            className="w-full justify-start" 
                            variant="outline"
                            onClick={() => exportToPdf()}
                          >
                            <FileText className="h-4 w-4 ml-2 text-primary" />
                            تصدير PDF
                          </Button>
                          <Button 
                            size="sm" 
                            className="w-full justify-start" 
                            variant="outline"
                            onClick={() => exportToExcel()}
                          >
                            <FileSpreadsheet className="h-4 w-4 ml-2 text-green-600" />
                            تصدير Excel
                          </Button>
                        </div>
                      </div>
                      
                      <div className="rounded-lg bg-muted/50 p-4">
                        <h3 className="font-medium mb-2 flex items-center">
                          <Printer className="h-4 w-4 ml-2 text-primary" />
                          طباعة المستخلص
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          طباعة نموذج المستخلص المالي
                        </p>
                        <Button 
                          size="sm" 
                          className="w-full justify-start" 
                          variant="outline"
                          onClick={() => window.print()}
                        >
                          <Printer className="h-4 w-4 ml-2 text-primary" />
                          طباعة النموذج
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle className="text-xl">نموذج المستخلص</CardTitle>
                    <CardDescription>
                      اختر نوع النموذج المناسب للمستخلص
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="standard" className="w-full">
                      <TabsList className="grid grid-cols-2 w-[240px]">
                        <TabsTrigger value="standard">النموذج القياسي</TabsTrigger>
                        <TabsTrigger value="advanced">النموذج المتقدم</TabsTrigger>
                      </TabsList>
                    
                      <TabsContent value="standard">
                        <div id="payment-request-print" className="bg-white p-4 rounded-md my-4 print:p-0">
                          <div className="text-center border-b pb-4 mb-6">
                            <h1 className="text-2xl font-bold">مستخلص مالي</h1>
                            <p className="text-muted-foreground">
                              مستخلص {currentRequest.type === 'interim' ? 'مرحلي' : 'ختامي'} رقم {currentRequest.requestNumber} 
                            </p>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-6 mb-6">
                            <div>
                              <h3 className="font-medium mb-2">معلومات المشروع</h3>
                              <div className="text-sm space-y-1">
                                <p><strong>اسم المشروع:</strong> {projects?.find(p => p.id === currentRequest.projectId)?.name}</p>
                                <p><strong>حالة المشروع:</strong> {projects?.find(p => p.id === currentRequest.projectId)?.status}</p>
                                <p><strong>الفترة:</strong> من {formatDate(currentRequest.startDate)} إلى {formatDate(currentRequest.endDate)}</p>
                                <p><strong>نسبة الإنجاز الكلية:</strong> {currentRequest.totalCompletionPercentage}%</p>
                              </div>
                            </div>
                            <div>
                              <h3 className="font-medium mb-2">معلومات المستخلص</h3>
                              <div className="text-sm space-y-1">
                                <p><strong>رقم المستخلص:</strong> {currentRequest.requestNumber}</p>
                                <p><strong>عنوان المستخلص:</strong> {currentRequest.title}</p>
                                <p><strong>تاريخ الإصدار:</strong> {formatDate(currentRequest.issueDate)}</p>
                                <p><strong>حالة المستخلص:</strong> 
                                  <Badge 
                                    className="mr-2"
                                    variant={
                                      currentRequest.status === 'approved' ? 'success' : 
                                      currentRequest.status === 'draft' ? 'outline' : 
                                      currentRequest.status === 'pending' ? 'warning' : 
                                      currentRequest.status === 'rejected' ? 'destructive' : 
                                      currentRequest.status === 'paid' ? 'default' : 'outline'
                                    }
                                  >
                                    {
                                      currentRequest.status === 'approved' ? 'معتمد' : 
                                      currentRequest.status === 'draft' ? 'مسودة' : 
                                      currentRequest.status === 'pending' ? 'قيد المراجعة' : 
                                      currentRequest.status === 'rejected' ? 'مرفوض' : 
                                      currentRequest.status === 'paid' ? 'مدفوع' : currentRequest.status
                                    }
                                  </Badge>
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="mb-6">
                            <h3 className="font-medium mb-2">بنود المستخلص</h3>
                            {paymentRequestItems && paymentRequestItems.length > 0 ? (
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="w-[50px]">#</TableHead>
                                    <TableHead>البند</TableHead>
                                    <TableHead>الوحدة</TableHead>
                                    <TableHead>سعر الوحدة</TableHead>
                                    <TableHead>الكمية المخططة</TableHead>
                                    <TableHead>الكمية المنجزة</TableHead>
                                    <TableHead>نسبة الإنجاز</TableHead>
                                    <TableHead>المبلغ الحالي</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {paymentRequestItems.map((item, index) => (
                                    <TableRow key={item.id}>
                                      <TableCell>{index + 1}</TableCell>
                                      <TableCell>
                                        {item.itemName}
                                        {item.itemDescription && <div className="text-xs text-muted-foreground">{item.itemDescription}</div>}
                                      </TableCell>
                                      <TableCell>{item.unit}</TableCell>
                                      <TableCell>{item.unitPrice.toLocaleString()} ر.س</TableCell>
                                      <TableCell>{item.plannedQuantity}</TableCell>
                                      <TableCell>{item.completedQuantity}</TableCell>
                                      <TableCell>
                                        <div className="flex items-center gap-2">
                                          <Progress value={item.completionPercentage} className="h-2 w-[60px]" />
                                          {item.completionPercentage}%
                                        </div>
                                      </TableCell>
                                      <TableCell>{item.currentPaymentAmount.toLocaleString()} ر.س</TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                                <TableFooter>
                                  <TableRow>
                                    <TableCell colSpan={7} className="text-left">الإجمالي</TableCell>
                                    <TableCell>{currentRequest.currentPaymentAmount.toLocaleString()} ر.س</TableCell>
                                  </TableRow>
                                </TableFooter>
                              </Table>
                            ) : (
                              <div className="text-center p-4 bg-muted/20 rounded">
                                <p className="text-muted-foreground">لا توجد بنود مضافة لهذا المستخلص</p>
                              </div>
                            )}
                          </div>
                          
                          <div className="mb-6">
                            <h3 className="font-medium mb-2">ملخص المدفوعات</h3>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="border rounded-md p-3 text-center">
                                <p className="text-sm text-muted-foreground">إجمالي قيمة المشروع</p>
                                <p className="text-xl font-semibold mt-1">{currentRequest.totalAmount.toLocaleString()} ر.س</p>
                              </div>
                              <div className="border rounded-md p-3 text-center">
                                <p className="text-sm text-muted-foreground">المدفوعات السابقة</p>
                                <p className="text-xl font-semibold mt-1">{currentRequest.previousPaymentsAmount.toLocaleString()} ر.س</p>
                              </div>
                              <div className="border rounded-md p-3 text-center bg-muted/20">
                                <p className="text-sm text-muted-foreground">المبلغ الحالي</p>
                                <p className="text-xl font-semibold mt-1">{currentRequest.currentPaymentAmount.toLocaleString()} ر.س</p>
                              </div>
                            </div>
                          </div>

                          {currentRequest.notes && (
                            <div className="mb-6">
                              <h3 className="font-medium mb-2">ملاحظات</h3>
                              <div className="border rounded-md p-3 text-sm">
                                {currentRequest.notes}
                              </div>
                            </div>
                          )}
                          
                          <div className="grid grid-cols-3 gap-16 pt-8">
                            <div className="text-center">
                              <p className="text-sm mb-8">المقاول</p>
                              <div className="border-t pt-1 border-black">
                                <p className="text-sm">التوقيع والختم</p>
                              </div>
                            </div>
                            <div className="text-center">
                              <p className="text-sm mb-8">المشرف</p>
                              <div className="border-t pt-1 border-black">
                                <p className="text-sm">التوقيع والختم</p>
                              </div>
                            </div>
                            <div className="text-center">
                              <p className="text-sm mb-8">المالك</p>
                              <div className="border-t pt-1 border-black">
                                <p className="text-sm">التوقيع والختم</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="advanced">
                        {/* استخدام مكون النموذج المتقدم للطباعة */}
                        <div id="advanced-template">
                          <PaymentRequestToPdfTemplate
                            paymentRequest={currentRequest}
                            paymentRequestItems={paymentRequestItems || []}
                            project={projects?.find(p => p.id === currentRequest.projectId) || { id: 0, name: "", status: "" }}
                            company={{
                              name: "شركة البناء المتقدم",
                              logo: "",
                              address: "الرياض - المملكة العربية السعودية",
                              phone: "+966000000000",
                              email: "info@construction.sa",
                              website: "www.construction.sa"
                            }}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              </div>
              
              {/* حالة المستخلص ونظام التتبع */}
              <Card>
                <CardHeader>
                  <CardTitle>حالة المستخلص ونظام التتبع</CardTitle>
                </CardHeader>
                <CardContent>
                  <PaymentStatusTracker
                    paymentRequest={currentRequest}
                    currentUser={{ id: 1, username: "admin", fullName: "مستخدم النظام", role: "مدير" }}
                    canApprove={true}
                    canReject={true}
                    canPay={true}
                    onStatusChange={(status) => handleStatusChange(status)}
                  />
                </CardContent>
              </Card>
              
              {/* تحليلات المستخلص المالي */}
              {projects?.find(p => p.id === currentRequest.projectId) && (
                <Card>
                  <CardHeader>
                    <CardTitle>التحليلات المالية للمستخلص</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ProjectFinancialInsights
                      project={{
                        id: projects.find(p => p.id === currentRequest.projectId)!.id,
                        name: projects.find(p => p.id === currentRequest.projectId)!.name,
                        budget: 1000000, // نفترض قيمة للميزانية
                        startDate: new Date(currentRequest.startDate),
                        endDate: new Date(currentRequest.endDate),
                        status: projects.find(p => p.id === currentRequest.projectId)!.status,
                        progress: currentRequest.totalCompletionPercentage
                      }}
                      paymentRequests={paymentRequests?.filter(r => r.projectId === currentRequest.projectId) || []}
                    />
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center p-8 bg-gray-50 rounded-md">
              <p className="text-gray-500">يرجى اختيار مستخلص مالي من قسم "عرض المستخلصات" أولاً</p>
              <Button 
                onClick={() => document.querySelector('[data-value="view"]')?.click()}
                className="mt-4"
              >
                الانتقال إلى عرض المستخلصات
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PaymentRequestGenerator;