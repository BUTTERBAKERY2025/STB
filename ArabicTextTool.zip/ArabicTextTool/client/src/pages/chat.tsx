import { useState, useRef, useEffect } from "react";
import { Send, Search, Phone, Video, MoreVertical, Paperclip, Image } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useUsers } from "@/lib/data";

const Chat = () => {
  const { data: users, isLoading } = useUsers();
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [messageText, setMessageText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  // Sample chat data
  const chatUsers = [
    {
      id: 1,
      fullName: "أحمد محمد",
      avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=50&h=50&fit=crop",
      lastMessage: "متى سيتم توريد المعدات المطلوبة؟",
      timestamp: new Date(2023, 11, 10, 14, 25),
      unreadCount: 2,
      isOnline: true
    },
    {
      id: 2,
      fullName: "سارة العلي",
      avatar: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=50&h=50&fit=crop",
      lastMessage: "تم الانتهاء من تقرير المرحلة الأولى",
      timestamp: new Date(2023, 11, 10, 11, 15),
      unreadCount: 0,
      isOnline: true
    },
    {
      id: 3,
      fullName: "خالد عبدالله",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=50&h=50&fit=crop",
      lastMessage: "سأكون في الموقع غداً في الصباح",
      timestamp: new Date(2023, 11, 9, 17, 30),
      unreadCount: 0,
      isOnline: false
    },
    {
      id: 4,
      fullName: "نورة الغامدي",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=50&h=50&fit=crop",
      lastMessage: "هل تم مراجعة المخططات الجديدة؟",
      timestamp: new Date(2023, 11, 8, 13, 45),
      unreadCount: 0,
      isOnline: true
    },
    {
      id: 5,
      fullName: "فهد القحطاني",
      avatar: "https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?w=50&h=50&fit=crop",
      lastMessage: "أرسلت لك جدول الزيارات للأسبوع القادم",
      timestamp: new Date(2023, 11, 7, 10, 20),
      unreadCount: 1,
      isOnline: false
    }
  ];

  // Sample messages for selected chat
  const messages = [
    {
      id: 1,
      senderId: 1,
      receiverId: 0, // Current user
      text: "السلام عليكم، كيف حال العمل في المشروع؟",
      timestamp: new Date(2023, 11, 10, 10, 0)
    },
    {
      id: 2,
      senderId: 0, // Current user
      receiverId: 1,
      text: "وعليكم السلام، العمل يسير بشكل جيد. أنجزنا حوالي 70% من المرحلة الأولى.",
      timestamp: new Date(2023, 11, 10, 10, 5)
    },
    {
      id: 3,
      senderId: 1,
      receiverId: 0,
      text: "ممتاز! متى تتوقع الانتهاء من المرحلة الأولى بالكامل؟",
      timestamp: new Date(2023, 11, 10, 10, 8)
    },
    {
      id: 4,
      senderId: 0,
      receiverId: 1,
      text: "نتوقع الانتهاء خلال الأسبوع القادم إن لم تكن هناك أي عوائق.",
      timestamp: new Date(2023, 11, 10, 10, 12)
    },
    {
      id: 5,
      senderId: 1,
      receiverId: 0,
      text: "هل هناك أي معدات إضافية تحتاجونها؟",
      timestamp: new Date(2023, 11, 10, 14, 20)
    },
    {
      id: 6,
      senderId: 1,
      receiverId: 0,
      text: "متى سيتم توريد المعدات المطلوبة؟",
      timestamp: new Date(2023, 11, 10, 14, 25)
    }
  ];

  // Filtered chat users based on search query
  const filteredChatUsers = chatUsers.filter(user => 
    user.fullName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Auto scroll to bottom of chat on new message or chat selection
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [selectedUserId, messages]);

  const handleSendMessage = () => {
    if (messageText.trim() && selectedUserId) {
      // In a real app, this would send the message to the API
      console.log(`Sending message to user ${selectedUserId}: ${messageText}`);
      setMessageText("");
    }
  };

  const formatMessageTime = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(date);
  };

  const formatChatTime = (date: Date) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date >= today) {
      return formatMessageTime(date);
    } else if (date >= yesterday) {
      return "أمس";
    } else {
      return new Intl.DateTimeFormat('ar-SA', {
        month: 'short',
        day: 'numeric',
      }).format(date);
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(part => part.charAt(0)).join('');
  };

  const getSelectedUser = () => {
    return chatUsers.find(user => user.id === selectedUserId);
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
      <div className="flex h-full">
        {/* Chat sidebar */}
        <div className="w-full md:w-80 border-l border-gray-200 dark:border-gray-700 flex flex-col">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold dark:text-white mb-3">المحادثات</h2>
            <div className="relative">
              <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="بحث..." 
                className="pr-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredChatUsers.map(user => (
                <div 
                  key={user.id}
                  className={`flex items-center p-3 rounded-lg cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 ${selectedUserId === user.id ? 'bg-gray-100 dark:bg-gray-700' : ''}`}
                  onClick={() => setSelectedUserId(user.id)}
                >
                  <div className="relative">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={user.avatar} alt={user.fullName} />
                      <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                    </Avatar>
                    {user.isOnline && (
                      <span className="absolute bottom-0 left-0 h-3 w-3 rounded-full bg-green-500 border-2 border-white dark:border-gray-800"></span>
                    )}
                  </div>
                  <div className="mr-3 flex-1 min-w-0">
                    <div className="flex justify-between">
                      <h3 className="font-medium text-gray-900 dark:text-white truncate">{user.fullName}</h3>
                      <span className="text-xs text-gray-500">{formatChatTime(user.timestamp)}</span>
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{user.lastMessage}</p>
                  </div>
                  {user.unreadCount > 0 && (
                    <Badge className="ml-2 bg-primary">{user.unreadCount}</Badge>
                  )}
                </div>
              ))}

              {filteredChatUsers.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">لا توجد محادثات تطابق البحث</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Chat main area */}
        <div className="hidden md:flex flex-col flex-1">
          {!selectedUserId ? (
            <div className="flex-1 flex items-center justify-center p-8 bg-gray-50 dark:bg-gray-800">
              <div className="text-center">
                <h3 className="text-xl font-medium text-gray-600 dark:text-gray-300 mb-2">لم يتم اختيار محادثة</h3>
                <p className="text-gray-500 dark:text-gray-400">اختر محادثة من القائمة للبدء في الدردشة</p>
              </div>
            </div>
          ) : (
            <>
              {/* Chat header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 ml-3">
                    <AvatarImage src={getSelectedUser()?.avatar} alt={getSelectedUser()?.fullName} />
                    <AvatarFallback>{getInitials(getSelectedUser()?.fullName || "")}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium dark:text-white">{getSelectedUser()?.fullName}</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {getSelectedUser()?.isOnline ? 'متصل الآن' : 'غير متصل'}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2 space-x-reverse">
                  <Button variant="ghost" size="icon">
                    <Phone className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Chat messages */}
              <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                <div className="space-y-4">
                  {messages.map(message => (
                    <div 
                      key={message.id}
                      className={`flex ${message.senderId === 0 ? 'justify-end' : 'justify-start'}`}
                    >
                      {message.senderId !== 0 && (
                        <Avatar className="h-8 w-8 mt-1 ml-2">
                          <AvatarImage src={getSelectedUser()?.avatar} alt={getSelectedUser()?.fullName} />
                          <AvatarFallback>{getInitials(getSelectedUser()?.fullName || "")}</AvatarFallback>
                        </Avatar>
                      )}
                      <div className={`max-w-[70%]`}>
                        <Card className={`${message.senderId === 0 ? 'bg-primary/10 dark:bg-primary/20 border-primary/10' : 'bg-gray-100 dark:bg-gray-700'}`}>
                          <CardContent className="p-3 text-sm">
                            {message.text}
                          </CardContent>
                        </Card>
                        <div className={`text-xs text-gray-500 mt-1 ${message.senderId === 0 ? 'text-left' : 'text-right'}`}>
                          {formatMessageTime(message.timestamp)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Chat input */}
              <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center">
                  <Button variant="ghost" size="icon">
                    <Paperclip className="h-5 w-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Image className="h-5 w-5" />
                  </Button>
                  <Input 
                    placeholder="اكتب رسالتك هنا..." 
                    className="mx-2"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleSendMessage();
                      }
                    }}
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!messageText.trim()}
                    size="icon"
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Chat;
