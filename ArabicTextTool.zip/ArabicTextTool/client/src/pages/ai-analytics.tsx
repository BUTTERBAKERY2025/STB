import { useState, useEffect } from "react";
import { 
  Brain, 
  TrendingUp, 
  AlertCircle, 
  Calendar, 
  BarChart3, 
  LineChart, 
  PieChart, 
  Zap,
  Clock,
  ArrowRightLeft,
  AlertTriangle,
  Check,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatDate } from "@/lib/utils";
import { useProjects } from "@/lib/data";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart as LineChartRecharts,
  Line,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";

// تعريف أنواع البيانات
interface ProjectPrediction {
  id: number;
  name: string;
  riskScore: number;
  profitabilityScore: number;
  timelineRisk: number;
  budgetRisk: number;
  qualityRisk: number;
  suggestedActions: string[];
  potentialDelays: number;
  costOverrunPercentage: number;
}

interface IndustryComparison {
  category: string;
  averageDelay: number;
  yourAvgDelay: number;
  averageCostOverrun: number;
  yourAvgCostOverrun: number;
  averageQualityIssues: number;
  yourAvgQualityIssues: number;
}

const AIAnalytics = () => {
  const { data: projects, isLoading } = useProjects();
  const [selectedProjectId, setSelectedProjectId] = useState<string>('all');
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [activeTab, setActiveTab] = useState('predictions');

  // بيانات مؤقتة للتحليلات - سيتم استبدالها بالاتصال بواجهة برمجة التطبيقات في المستقبل
  const [projectPredictions, setProjectPredictions] = useState<ProjectPrediction[]>([]);
  const [industryComparison, setIndustryComparison] = useState<IndustryComparison[]>([]);
  const [historicalTrends, setHistoricalTrends] = useState<any[]>([]);
  const [correlationData, setCorrelationData] = useState<any[]>([]);

  // تهيئة بيانات التحليلات
  useEffect(() => {
    if (projects) {
      // توليد تنبؤات المشروع
      const predictions = generateProjectPredictions(projects);
      setProjectPredictions(predictions);

      // توليد مقارنات القطاع
      const comparisons = generateIndustryComparisons(projects);
      setIndustryComparison(comparisons);

      // توليد اتجاهات تاريخية
      const trends = generateHistoricalTrends(projects);
      setHistoricalTrends(trends);

      // توليد بيانات العلاقات
      const correlations = generateCorrelationData(projects);
      setCorrelationData(correlations);
    }
  }, [projects]);

  // محاكاة تحميل تحليلات الذكاء الاصطناعي
  const loadAIAnalysis = () => {
    setIsLoadingAI(true);
    setTimeout(() => {
      setIsLoadingAI(false);
    }, 1500);
  };

  useEffect(() => {
    loadAIAnalysis();
  }, [activeTab]);

  const getProjectById = (id: number) => {
    return projects?.find(p => p.id === id);
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <>
      {/* عنوان الصفحة والإجراءات */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold dark:text-white">تحليلات الذكاء الاصطناعي</h1>
          <p className="text-muted-foreground">تحليلات متقدمة لمشاريعك باستخدام الذكاء الاصطناعي</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
            <SelectTrigger className="w-[220px]">
              <SelectValue placeholder="اختر مشروعاً" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع المشاريع</SelectItem>
              {projects?.map(project => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="default" onClick={loadAIAnalysis} className="flex items-center gap-1">
            <Brain size={16} />
            <span>تحليل جديد</span>
          </Button>
        </div>
      </div>

      {isLoadingAI ? (
        <AIAnalyticsLoadingState />
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="predictions" className="flex items-center gap-1">
              <TrendingUp size={16} />
              <span>التنبؤات والمخاطر</span>
            </TabsTrigger>
            <TabsTrigger value="comparisons" className="flex items-center gap-1">
              <BarChart3 size={16} />
              <span>المقارنات القطاعية</span>
            </TabsTrigger>
            <TabsTrigger value="trends" className="flex items-center gap-1">
              <LineChart size={16} />
              <span>الاتجاهات التاريخية</span>
            </TabsTrigger>
            <TabsTrigger value="correlations" className="flex items-center gap-1">
              <ArrowRightLeft size={16} />
              <span>العلاقات والتأثيرات</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="predictions">
            <PredictionsTab 
              predictions={
                selectedProjectId === 'all' 
                  ? projectPredictions 
                  : projectPredictions.filter(p => p.id === parseInt(selectedProjectId))
              } 
              getProjectById={getProjectById}
            />
          </TabsContent>

          <TabsContent value="comparisons">
            <ComparisonsTab 
              comparisons={industryComparison} 
              selectedCategory={
                selectedProjectId === 'all' 
                  ? undefined 
                  : getProjectById(parseInt(selectedProjectId))?.category
              }
            />
          </TabsContent>

          <TabsContent value="trends">
            <TrendsTab 
              trends={historicalTrends} 
              selectedProjectId={selectedProjectId === 'all' ? undefined : parseInt(selectedProjectId)} 
            />
          </TabsContent>

          <TabsContent value="correlations">
            <CorrelationsTab 
              correlations={correlationData} 
              selectedProjectId={selectedProjectId === 'all' ? undefined : parseInt(selectedProjectId)} 
            />
          </TabsContent>
        </Tabs>
      )}
    </>
  );
};

// مكون حالة التحميل
const AIAnalyticsLoadingState = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-2/3 mb-2" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-4/5 mt-1" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-1/3" />
          </CardHeader>
          <CardContent className="h-80">
            <div className="h-full w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-md animate-pulse">
              <Brain className="h-12 w-12 text-gray-400" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-1/3" />
          </CardHeader>
          <CardContent className="h-80">
            <div className="h-full w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-md animate-pulse">
              <LineChart className="h-12 w-12 text-gray-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-1/4" />
        </CardHeader>
        <CardContent className="space-y-2">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-start gap-2">
              <Skeleton className="h-6 w-6 rounded-full" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-full" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};

// تاب التنبؤات والمخاطر
const PredictionsTab = ({ predictions, getProjectById }: { 
  predictions: ProjectPrediction[], 
  getProjectById: (id: number) => any
}) => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {predictions.map(prediction => {
          const project = getProjectById(prediction.id);
          if (!project) return null;

          const riskLevel = getRiskLevel(prediction.riskScore);
          const profitabilityLevel = getProfitabilityLevel(prediction.profitabilityScore);

          return (
            <Card key={prediction.id} className="overflow-hidden border-t-4" style={{ borderTopColor: getRiskColorHex(prediction.riskScore) }}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl">{project.name}</CardTitle>
                    <CardDescription>
                      {project.category} | بدأ في {formatDate(project.startDate)}
                    </CardDescription>
                  </div>
                  <Badge variant={riskLevel.variant as "default" | "destructive" | "outline" | "secondary"}>
                    مستوى الخطر: {riskLevel.label}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* تحليل المخاطر الرئيسية */}
                <div>
                  <h4 className="text-sm font-semibold mb-2">تحليل المخاطر الرئيسية:</h4>
                  <div className="grid grid-cols-3 gap-2">
                    <RiskIndicator 
                      title="الجدول الزمني" 
                      value={prediction.timelineRisk} 
                      icon={<Clock className="h-4 w-4" />} 
                    />
                    <RiskIndicator 
                      title="الميزانية" 
                      value={prediction.budgetRisk} 
                      icon={<BarChart3 className="h-4 w-4" />} 
                    />
                    <RiskIndicator 
                      title="الجودة" 
                      value={prediction.qualityRisk} 
                      icon={<Check className="h-4 w-4" />} 
                    />
                  </div>
                </div>

                {/* التنبؤات الرئيسية */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2">
                  <div className="bg-primary/5 p-3 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">التأخير المتوقع</span>
                    </div>
                    <p className="text-xl font-bold mt-1">{prediction.potentialDelays} يوم</p>
                  </div>
                  <div className="bg-primary/5 p-3 rounded-lg">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">احتمال تجاوز الميزانية</span>
                    </div>
                    <p className="text-xl font-bold mt-1">{prediction.costOverrunPercentage}%</p>
                  </div>
                </div>

                {/* نصائح وإجراءات */}
                <div className="pt-3">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-1">
                    <Zap className="h-4 w-4 text-amber-500" />
                    <span>الإجراءات المقترحة:</span>
                  </h4>
                  <ul className="space-y-1">
                    {prediction.suggestedActions.map((action, idx) => (
                      <li key={idx} className="text-sm flex items-start gap-2">
                        <Info className="h-3.5 w-3.5 text-primary mt-0.5" />
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/30 pb-2 pt-2">
                <div className="flex justify-between items-center w-full text-xs text-muted-foreground">
                  <span>تم التحليل: {formatDate(new Date().toISOString())}</span>
                  <Button variant="ghost" size="sm" className="h-7 px-2">
                    عرض التفاصيل الكاملة
                  </Button>
                </div>
              </CardFooter>
            </Card>
          );
        })}
      </div>

      {/* قسم ملخص المخاطر */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">تحليل مخاطر المشاريع</CardTitle>
          <CardDescription>
            تحليل شامل للمخاطر الرئيسية عبر جميع المشاريع
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={generateRiskRadarData(predictions)}>
                <PolarGrid />
                <PolarAngleAxis 
                  dataKey="subject" 
                  tick={{ fill: '#888', fontSize: 12 }}
                />
                <PolarRadiusAxis domain={[0, 100]} />
                <Radar
                  name="المتوسط"
                  dataKey="average"
                  stroke="#8884d8"
                  fill="#8884d8"
                  fillOpacity={0.6}
                />
                <Radar
                  name="القيمة القصوى"
                  dataKey="max"
                  stroke="#82ca9d"
                  fill="#82ca9d"
                  fillOpacity={0.6}
                />
                <Legend />
                <Tooltip contentStyle={{ direction: 'rtl' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// تاب المقارنات القطاعية
const ComparisonsTab = ({ comparisons, selectedCategory }: { 
  comparisons: IndustryComparison[], 
  selectedCategory?: string 
}) => {
  const filteredComparisons = selectedCategory 
    ? comparisons.filter(c => c.category === selectedCategory) 
    : comparisons;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* تأخيرات المشاريع حسب القطاع */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="text-lg">مقارنة الأداء مع متوسطات القطاع</CardTitle>
            <CardDescription>
              مقارنة أداء مشاريعك مع متوسطات القطاع في المجالات الرئيسية
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={filteredComparisons}
                  margin={{ top: 20, right: 30, left: 20, bottom: 30 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="category" 
                    tick={{ fill: '#888', fontSize: 12 }}
                    interval={0}
                  />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip contentStyle={{ direction: 'rtl' }} />
                  <Legend />
                  <Bar yAxisId="left" dataKey="averageDelay" name="متوسط التأخير (القطاع)" fill="#8884d8" />
                  <Bar yAxisId="left" dataKey="yourAvgDelay" name="متوسط التأخير (مشاريعك)" fill="#aaa6f2" />
                  <Bar yAxisId="right" dataKey="averageCostOverrun" name="تجاوز الميزانية (القطاع)" fill="#82ca9d" />
                  <Bar yAxisId="right" dataKey="yourAvgCostOverrun" name="تجاوز الميزانية (مشاريعك)" fill="#a8dfbd" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* بطاقات المقارنة - جودة المشروع */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">مقارنة جودة المشاريع</CardTitle>
            <CardDescription>
              مقارنة مستوى جودة المشاريع مع معايير القطاع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {filteredComparisons.map((comparison, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium">{comparison.category}</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">مشاكل الجودة:</span>
                      <Badge variant="outline">
                        {comparison.yourAvgQualityIssues} / {comparison.averageQualityIssues}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>مشاريعك</span>
                      <span>متوسط القطاع</span>
                    </div>
                    <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div className="absolute top-0 left-0 h-full bg-primary rounded-full" 
                        style={{ width: `${(comparison.yourAvgQualityIssues / Math.max(comparison.averageQualityIssues, 1)) * 100}%` }} 
                      />
                      <div className="absolute top-0 h-full w-px bg-gray-500" 
                        style={{ left: `${100 - 0}%` }} 
                      />
                    </div>
                    
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>{getQualityRating(comparison.yourAvgQualityIssues, comparison.averageQualityIssues)}</span>
                      <span>{getQualityIndicator(comparison.yourAvgQualityIssues, comparison.averageQualityIssues)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* بطاقة نصائح تحسين الأداء */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">نصائح لتحسين الأداء</CardTitle>
            <CardDescription>
              توصيات مخصصة بناءً على تحليل المقارنة مع القطاع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <ImprovementSuggestion 
                title="خفض متوسط التأخير في المشاريع"
                description="تأخر مشاريعك بنسبة 15% أعلى من متوسط القطاع. يمكن تحسين ذلك من خلال استخدام تقنيات إدارة المشاريع الرشيقة وزيادة مرونة فرق العمل."
                impact="عالي"
                effort="متوسط"
                icon={<Clock className="h-5 w-5 text-amber-500" />}
              />
              
              <Separator />
              
              <ImprovementSuggestion 
                title="تحسين دقة تقدير الميزانية"
                description="ميزانيات مشاريعك تتجاوز التقديرات بنسبة 12%. استخدم البيانات التاريخية من المشاريع السابقة لتحسين تقديرات الميزانية المستقبلية."
                impact="عالي"
                effort="منخفض"
                icon={<BarChart3 className="h-5 w-5 text-primary" />}
              />
              
              <Separator />
              
              <ImprovementSuggestion 
                title="تعزيز آليات ضبط الجودة"
                description="مشاريعك تعاني من مشاكل جودة أقل من متوسط القطاع. واصل تطبيق أفضل الممارسات واستخدم مراجعات الجودة الدورية للحفاظ على هذا المستوى."
                impact="متوسط"
                effort="منخفض"
                icon={<Check className="h-5 w-5 text-green-500" />}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// تاب الاتجاهات التاريخية
const TrendsTab = ({ trends, selectedProjectId }: { 
  trends: any[], 
  selectedProjectId?: number 
}) => {
  const filteredTrends = selectedProjectId 
    ? trends.filter(t => t.projectId === selectedProjectId) 
    : trends;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6">
        {/* رسم بياني للاتجاهات التاريخية */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">اتجاهات نمو المشاريع عبر الزمن</CardTitle>
            <CardDescription>
              تحليل لأداء المشاريع واتجاهاتها على مدار الوقت
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChartRecharts
                  data={prepareTrendsChartData(filteredTrends)}
                  margin={{ top: 20, right: 30, left: 20, bottom: 30 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                  <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                  <Tooltip contentStyle={{ direction: 'rtl' }} />
                  <Legend />
                  <Line 
                    yAxisId="left" 
                    type="monotone" 
                    dataKey="onTimeDeliveryRate" 
                    name="معدل التسليم في الموعد" 
                    stroke="#8884d8" 
                    activeDot={{ r: 8 }} 
                  />
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="budgetAdherence" 
                    name="الالتزام بالميزانية (%)" 
                    stroke="#82ca9d" 
                  />
                  <Line 
                    yAxisId="right" 
                    type="monotone" 
                    dataKey="qualityScore" 
                    name="درجة الجودة" 
                    stroke="#ffc658" 
                  />
                </LineChartRecharts>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* بطاقات الاتجاهات الرئيسية */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">التحليل الاتجاهي الرئيسي</CardTitle>
            <CardDescription>
              تحليل الأنماط والاتجاهات الرئيسية في أداء المشاريع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <TrendAnalysis 
                title="الالتزام بالمواعيد"
                value="76%"
                change="+8%"
                direction="up"
                description="تحسن مستمر في الالتزام بالمواعيد على مدار الستة أشهر الماضية، مع اتجاه تصاعدي مستقر."
              />
              
              <Separator />
              
              <TrendAnalysis 
                title="الالتزام بالميزانية"
                value="92%"
                change="+4%"
                direction="up"
                description="تظهر البيانات تحسناً مستمراً في الالتزام بالميزانية، مع انخفاض حالات تجاوز الميزانية بنسبة 12%."
              />
              
              <Separator />
              
              <TrendAnalysis 
                title="مؤشر الجودة"
                value="85/100"
                change="-3%"
                direction="down"
                description="انخفاض طفيف في مؤشرات الجودة خلال الربع الأخير. يوصى بمراجعة إجراءات ضبط الجودة."
              />
            </div>
          </CardContent>
        </Card>

        {/* بطاقة نصائح تحسين الاتجاهات */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">توقعات المستقبل</CardTitle>
            <CardDescription>
              تنبؤات مستقبلية بناءً على تحليل الاتجاهات التاريخية
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-lg border p-3">
                <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4 text-green-500" />
                  <span>نمو الأداء المتوقع</span>
                </h4>
                <p className="text-sm text-muted-foreground">
                  بناءً على الاتجاهات الحالية، يتوقع تحسن أداء المشاريع بنسبة 15% خلال الأشهر الستة القادمة.
                </p>
              </div>
              
              <div className="rounded-lg border p-3">
                <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  <span>مخاطر محتملة</span>
                </h4>
                <p className="text-sm text-muted-foreground">
                  هناك احتمالية لتباطؤ في تسليم المشاريع خلال موسم الصيف. يُنصح بالتخطيط المسبق لهذه الفترة.
                </p>
              </div>
              
              <div className="rounded-lg border p-3">
                <h4 className="font-medium text-sm mb-2 flex items-center gap-1">
                  <Zap className="h-4 w-4 text-primary" />
                  <span>فرص التحسين</span>
                </h4>
                <p className="text-sm text-muted-foreground">
                  يمكن تحقيق مكاسب كبيرة من خلال تحسين عمليات إدارة المشتريات، والتي تظهر البيانات أنها تؤثر بشكل كبير على المواعيد النهائية.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// تاب العلاقات والتأثيرات
const CorrelationsTab = ({ correlations, selectedProjectId }: { 
  correlations: any[], 
  selectedProjectId?: number 
}) => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* بطاقة العوامل المؤثرة في التأخير */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">العوامل المؤثرة في تأخر المشاريع</CardTitle>
            <CardDescription>
              تحليل العلاقات بين مختلف العوامل وتأثيرها على مواعيد تسليم المشاريع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <CorrelationFactor 
                factor="تغييرات نطاق العمل"
                impact={85}
                description="تغييرات نطاق العمل المتكررة لها تأثير قوي جداً على تأخر المشاريع. كل تغيير إضافي يزيد من احتمالية التأخير بنسبة 12%."
              />
              
              <CorrelationFactor 
                factor="تأخر الموردين"
                impact={72}
                description="يؤدي تأخر توريد المواد إلى تأخيرات متتالية في جدول المشروع، مع تأثير عالٍ على المراحل الحرجة."
              />
              
              <CorrelationFactor 
                factor="أحوال الطقس"
                impact={45}
                description="في مشاريع البنية التحتية، تؤثر الظروف الجوية السيئة بشكل متوسط على جداول العمل، خاصة في المواقع الخارجية."
              />
              
              <CorrelationFactor 
                factor="نقص العمالة الماهرة"
                impact={68}
                description="وجود نقص في العمالة المتخصصة يؤثر بشكل كبير على الجدول الزمني، خاصة في المراحل التقنية من المشروع."
              />
            </div>
          </CardContent>
        </Card>

        {/* بطاقة العوامل المؤثرة في تجاوز الميزانية */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">العوامل المؤثرة في تجاوز الميزانية</CardTitle>
            <CardDescription>
              تحليل العلاقات بين مختلف العوامل وتأثيرها على ميزانيات المشاريع
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <CorrelationFactor 
                factor="التقدير غير الدقيق للتكاليف"
                impact={92}
                description="التقديرات غير الدقيقة في مرحلة التخطيط هي السبب الرئيسي في تجاوز الميزانية، مع نسبة تأثير عالية جداً."
              />
              
              <CorrelationFactor 
                factor="تغيير أسعار المواد"
                impact={78}
                description="تقلبات أسعار المواد وخاصة في المشاريع طويلة الأمد تؤثر بشكل كبير على الميزانية الإجمالية."
              />
              
              <CorrelationFactor 
                factor="الأعمال الإضافية غير المخططة"
                impact={75}
                description="تظهر البيانات أن الأعمال الإضافية التي تظهر أثناء التنفيذ تزيد من تكاليف المشروع بنسبة تصل إلى 25%."
              />
              
              <CorrelationFactor 
                factor="تأخر المشروع"
                impact={65}
                description="كل شهر تأخير في المشروع يزيد من التكاليف الثابتة بنسبة 8% في المتوسط."
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">مصفوفة التأثير المتبادل</CardTitle>
          <CardDescription>
            تحليل كيفية تأثير مختلف عوامل المشروع على بعضها البعض
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px] border-collapse">
              <thead>
                <tr className="border-b">
                  <th className="py-2 px-3 text-right font-medium text-sm">العامل</th>
                  <th className="py-2 px-3 text-center font-medium text-sm">الوقت</th>
                  <th className="py-2 px-3 text-center font-medium text-sm">التكلفة</th>
                  <th className="py-2 px-3 text-center font-medium text-sm">الجودة</th>
                  <th className="py-2 px-3 text-center font-medium text-sm">المخاطر</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b">
                  <td className="py-2 px-3 font-medium">تغييرات النطاق</td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="neutral" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="negative" />
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-3 font-medium">تأخر الموردين</td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="low" direction="neutral" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-3 font-medium">زيادة العمالة</td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="positive" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="neutral" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="low" direction="neutral" />
                  </td>
                </tr>
                <tr className="border-b">
                  <td className="py-2 px-3 font-medium">تحسين الجودة</td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="positive" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="positive" />
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-medium">تقليل التكاليف</td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="low" direction="neutral" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="high" direction="positive" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                  <td className="py-2 px-3 text-center">
                    <ImpactIndicator level="medium" direction="negative" />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// مكونات إضافية للعرض

// مكون مؤشر المخاطر
const RiskIndicator = ({ title, value, icon }: { title: string, value: number, icon: React.ReactNode }) => {
  let color = "";
  if (value < 30) color = "bg-green-500";
  else if (value < 70) color = "bg-amber-500";
  else color = "bg-red-500";

  return (
    <div className="bg-muted/50 p-2 rounded-lg">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-1">
          {icon}
          <span className="text-xs font-medium">{title}</span>
        </div>
        <span className="text-xs font-bold">{value}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
};

// مكون اقتراح التحسين
const ImprovementSuggestion = ({ title, description, impact, effort, icon }: { 
  title: string, 
  description: string, 
  impact: string, 
  effort: string, 
  icon: React.ReactNode 
}) => {
  return (
    <div className="flex gap-3">
      <div className="mt-0.5">
        {icon}
      </div>
      <div>
        <h4 className="text-sm font-medium">{title}</h4>
        <p className="text-sm text-muted-foreground mt-1">{description}</p>
        <div className="flex items-center gap-3 mt-2">
          <Badge variant="outline" className="text-xs bg-primary/5">التأثير: {impact}</Badge>
          <Badge variant="outline" className="text-xs bg-primary/5">الجهد: {effort}</Badge>
        </div>
      </div>
    </div>
  );
};

// مكون تحليل الاتجاهات
const TrendAnalysis = ({ title, value, change, direction, description }: { 
  title: string, 
  value: string, 
  change: string, 
  direction: 'up' | 'down' | 'neutral',
  description: string 
}) => {
  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-medium">{title}</h4>
        <div className="flex items-center gap-2">
          <span className="font-bold">{value}</span>
          <Badge variant={direction === 'up' ? 'secondary' : direction === 'down' ? 'destructive' : 'outline'}>
            {change} {direction === 'up' ? '▲' : direction === 'down' ? '▼' : '►'}
          </Badge>
        </div>
      </div>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
};

// مكون عامل الارتباط
const CorrelationFactor = ({ factor, impact, description }: { 
  factor: string, 
  impact: number, 
  description: string 
}) => {
  let color = "";
  if (impact < 40) color = "bg-green-500";
  else if (impact < 70) color = "bg-amber-500";
  else color = "bg-red-500";

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-medium">{factor}</h4>
        <Badge variant="outline" className={impact > 70 ? 'text-red-500' : impact > 50 ? 'text-amber-500' : 'text-green-500'}>
          تأثير {impact}%
        </Badge>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
        <div className={`h-2 rounded-full ${color}`} style={{ width: `${impact}%` }} />
      </div>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
};

// مكون مؤشر التأثير
const ImpactIndicator = ({ level, direction }: { 
  level: 'high' | 'medium' | 'low', 
  direction: 'positive' | 'negative' | 'neutral' 
}) => {
  let color = "";
  let symbol = "";
  
  if (direction === 'positive') {
    color = "text-green-500";
    symbol = "▲";
  } else if (direction === 'negative') {
    color = "text-red-500";
    symbol = "▼";
  } else {
    color = "text-amber-500";
    symbol = "◆";
  }

  const size = level === 'high' ? 'text-lg' : level === 'medium' ? 'text-md' : 'text-sm';

  return (
    <span className={`${color} ${size} font-bold`}>{symbol}</span>
  );
};

// دوال مساعدة

// وظيفة مساعدة لتوليد بيانات مخطط الرادار للمخاطر
function generateRiskRadarData(predictions: ProjectPrediction[]) {
  const riskFactors = [
    { subject: 'مخاطر الجدول الزمني', average: 0, max: 0 },
    { subject: 'مخاطر الميزانية', average: 0, max: 0 },
    { subject: 'مخاطر الجودة', average: 0, max: 0 },
    { subject: 'المخاطر التشغيلية', average: 0, max: 0 },
    { subject: 'المخاطر الفنية', average: 0, max: 0 },
  ];

  // حساب المتوسط والقيمة القصوى
  predictions.forEach(prediction => {
    riskFactors[0].average += prediction.timelineRisk;
    riskFactors[1].average += prediction.budgetRisk;
    riskFactors[2].average += prediction.qualityRisk;
    riskFactors[3].average += Math.round((prediction.timelineRisk + prediction.budgetRisk) / 2);
    riskFactors[4].average += Math.round((prediction.qualityRisk + prediction.budgetRisk) / 2);
    
    riskFactors[0].max = Math.max(riskFactors[0].max, prediction.timelineRisk);
    riskFactors[1].max = Math.max(riskFactors[1].max, prediction.budgetRisk);
    riskFactors[2].max = Math.max(riskFactors[2].max, prediction.qualityRisk);
    riskFactors[3].max = Math.max(riskFactors[3].max, Math.round((prediction.timelineRisk + prediction.budgetRisk) / 2));
    riskFactors[4].max = Math.max(riskFactors[4].max, Math.round((prediction.qualityRisk + prediction.budgetRisk) / 2));
  });
  
  // حساب المتوسط
  if (predictions.length > 0) {
    riskFactors.forEach(factor => {
      factor.average = Math.round(factor.average / predictions.length);
    });
  }
  
  return riskFactors;
}

// وظيفة مساعدة لإعداد بيانات الاتجاهات للرسم البياني
function prepareTrendsChartData(trendsData: any[]) {
  const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  
  // تجميع البيانات حسب الشهر
  const aggregatedData: Record<string, { 
    onTimeDeliveryRate: number, 
    budgetAdherence: number, 
    qualityScore: number, 
    count: number 
  }> = {};
  
  trendsData.forEach(trend => {
    const monthName = months[new Date(trend.date).getMonth()];
    
    if (!aggregatedData[monthName]) {
      aggregatedData[monthName] = {
        onTimeDeliveryRate: 0,
        budgetAdherence: 0,
        qualityScore: 0,
        count: 0
      };
    }
    
    aggregatedData[monthName].onTimeDeliveryRate += trend.onTimeDeliveryRate;
    aggregatedData[monthName].budgetAdherence += trend.budgetAdherence;
    aggregatedData[monthName].qualityScore += trend.qualityScore;
    aggregatedData[monthName].count += 1;
  });
  
  // حساب المتوسط لكل شهر
  return Object.keys(aggregatedData).map(month => ({
    month,
    onTimeDeliveryRate: Math.round(aggregatedData[month].onTimeDeliveryRate / aggregatedData[month].count),
    budgetAdherence: Math.round(aggregatedData[month].budgetAdherence / aggregatedData[month].count),
    qualityScore: Math.round(aggregatedData[month].qualityScore / aggregatedData[month].count)
  }));
}

// وظيفة مساعدة للحصول على تقييم الجودة
function getQualityRating(yourIssues: number, avgIssues: number): string {
  const ratio = yourIssues / avgIssues;
  
  if (ratio < 0.7) return 'أعلى من المتوسط';
  if (ratio < 1.1) return 'في نطاق المتوسط';
  return 'أقل من المتوسط';
}

// وظيفة مساعدة للحصول على مؤشر الجودة
function getQualityIndicator(yourIssues: number, avgIssues: number): string {
  const ratio = yourIssues / avgIssues;
  
  if (ratio < 0.7) return '✓ جيد';
  if (ratio < 1.1) return '⚠ مقبول';
  return '✗ يحتاج تحسين';
}

// وظيفة مساعدة للحصول على مستوى المخاطر
function getRiskLevel(score: number): { label: string; variant: "default" | "destructive" | "outline" | "secondary" } {
  if (score < 30) return { label: 'منخفض', variant: 'secondary' };
  if (score < 70) return { label: 'متوسط', variant: 'outline' };
  return { label: 'مرتفع', variant: 'destructive' };
}

// وظيفة مساعدة للحصول على لون المخاطر (hex)
function getRiskColorHex(score: number): string {
  if (score < 30) return '#22c55e'; // أخضر
  if (score < 70) return '#f59e0b'; // برتقالي
  return '#ef4444'; // أحمر
}

// وظيفة مساعدة للحصول على مستوى الربحية
function getProfitabilityLevel(score: number): { label: string; variant: "default" | "destructive" | "outline" | "secondary" } {
  if (score > 70) return { label: 'مرتفع', variant: 'secondary' };
  if (score > 30) return { label: 'متوسط', variant: 'outline' };
  return { label: 'منخفض', variant: 'destructive' };
}

// دوال توليد بيانات تجريبية للمشاريع بناءً على بيانات المشاريع الفعلية

// توليد تنبؤات المشروع
function generateProjectPredictions(projects: any[]): ProjectPrediction[] {
  if (!projects || projects.length === 0) return [];

  return projects.map(project => {
    // حساب درجة المخاطر الإجمالية بناءً على خصائص المشروع
    const baseRiskScore = Math.min(100, Math.max(0, 
      project.budget > 500000 ? 70 : 40 + 
      (project.progress < 30 ? 20 : project.progress < 70 ? 10 : 0) +
      (project.category === 'water' ? 15 : project.category === 'roads' ? 10 : 5)
    ));
    
    // حساب مخاطر الجدول الزمني
    const timelineRisk = Math.min(100, Math.max(0, baseRiskScore + 
      (Math.random() * 30 - 15) // إضافة بعض العشوائية
    ));
    
    // حساب مخاطر الميزانية
    const budgetRisk = Math.min(100, Math.max(0, baseRiskScore + 
      (Math.random() * 30 - 15) // إضافة بعض العشوائية
    ));
    
    // حساب مخاطر الجودة
    const qualityRisk = Math.min(100, Math.max(0, baseRiskScore * 0.7 + 
      (Math.random() * 20 - 10) // إضافة بعض العشوائية
    ));
    
    // حساب درجة الربحية
    const profitabilityScore = Math.min(100, Math.max(0, 
      100 - baseRiskScore + (Math.random() * 20 - 10)
    ));
    
    // توليد اقتراحات بناءً على المخاطر
    const suggestedActions = generateSuggestedActions(project, timelineRisk, budgetRisk, qualityRisk);
    
    return {
      id: project.id,
      name: project.name,
      riskScore: Math.round(baseRiskScore),
      profitabilityScore: Math.round(profitabilityScore),
      timelineRisk: Math.round(timelineRisk),
      budgetRisk: Math.round(budgetRisk),
      qualityRisk: Math.round(qualityRisk),
      suggestedActions,
      potentialDelays: Math.round(timelineRisk / 10), // التأخير المحتمل بالأيام
      costOverrunPercentage: Math.round(budgetRisk / 5) // نسبة تجاوز التكلفة المتوقعة
    };
  });
}

// توليد الإجراءات المقترحة
function generateSuggestedActions(project: any, timeRisk: number, budgetRisk: number, qualityRisk: number): string[] {
  const suggestions: string[] = [];
  
  if (timeRisk > 60) {
    suggestions.push('مراجعة الجدول الزمني وإعادة ترتيب أولويات المهام لتقليل المخاطر');
  }
  
  if (budgetRisk > 60) {
    suggestions.push('مراجعة بنود الميزانية وتحديد مجالات التوفير المحتملة');
  }
  
  if (qualityRisk > 50) {
    suggestions.push('تعزيز إجراءات ضبط الجودة وزيادة عمليات التفتيش الدورية');
  }
  
  if (project.progress < 30 && timeRisk > 40) {
    suggestions.push('تقييم إمكانية إضافة موارد إضافية في مراحل مبكرة من المشروع');
  }
  
  if (project.progress > 60 && budgetRisk > 50) {
    suggestions.push('مراقبة النفقات بدقة في المراحل النهائية لتجنب تجاوز الميزانية');
  }
  
  // التأكد من وجود اقتراحات كافية
  if (suggestions.length < 2) {
    suggestions.push('تحسين التواصل بين فريق المشروع وأصحاب المصلحة لتحديد المشكلات مبكراً');
  }
  
  return suggestions;
}

// توليد مقارنات القطاع
function generateIndustryComparisons(projects: any[]): IndustryComparison[] {
  if (!projects || projects.length === 0) return [];
  
  // تجميع المشاريع حسب الفئة
  const categorizedProjects: Record<string, any[]> = {};
  projects.forEach(project => {
    if (!categorizedProjects[project.category]) {
      categorizedProjects[project.category] = [];
    }
    categorizedProjects[project.category].push(project);
  });
  
  // توليد بيانات المقارنة لكل فئة
  return Object.keys(categorizedProjects).map(category => {
    // متوسطات القطاع المفترضة
    const avgDelay = category === 'electricity' ? 12 : 
                     category === 'water' ? 18 : 
                     category === 'sewage' ? 15 : 
                     category === 'communications' ? 8 : 
                     category === 'roads' ? 20 : 15;
    
    const avgCostOverrun = category === 'electricity' ? 15 : 
                           category === 'water' ? 22 : 
                           category === 'sewage' ? 18 : 
                           category === 'communications' ? 12 : 
                           category === 'roads' ? 25 : 20;
    
    const avgQualityIssues = category === 'electricity' ? 6 : 
                             category === 'water' ? 8 : 
                             category === 'sewage' ? 7 : 
                             category === 'communications' ? 4 : 
                             category === 'roads' ? 9 : 7;
    
    // متوسطات المشاريع الخاصة بالشركة (مستندة إلى خصائص المشروع الفعلية مع بعض العشوائية)
    const yourDelay = Math.round(avgDelay * (0.8 + Math.random() * 0.4));
    const yourCostOverrun = Math.round(avgCostOverrun * (0.7 + Math.random() * 0.6));
    const yourQualityIssues = Math.round(avgQualityIssues * (0.6 + Math.random() * 0.8));
    
    return {
      category: category,
      averageDelay: avgDelay,
      yourAvgDelay: yourDelay,
      averageCostOverrun: avgCostOverrun,
      yourAvgCostOverrun: yourCostOverrun,
      averageQualityIssues: avgQualityIssues,
      yourAvgQualityIssues: yourQualityIssues
    };
  });
}

// توليد اتجاهات تاريخية
function generateHistoricalTrends(projects: any[]): {
  projectId: number;
  date: string;
  onTimeDeliveryRate: number;
  budgetAdherence: number;
  qualityScore: number;
}[] {
  if (!projects || projects.length === 0) return [];
  
  // إنشاء بيانات الاتجاهات للأشهر الستة الماضية
  const trends: {
    projectId: number;
    date: string;
    onTimeDeliveryRate: number;
    budgetAdherence: number;
    qualityScore: number;
  }[] = [];
  const currentDate = new Date();
  
  for (let i = 5; i >= 0; i--) {
    const month = new Date(currentDate);
    month.setMonth(currentDate.getMonth() - i);
    
    // بيانات متوسطة مع تحسن تدريجي
    const baseOnTimeRate = 60 + i * 3 + Math.random() * 10;
    const baseBudgetAdherence = 80 + i * 2 + Math.random() * 8;
    const baseQualityScore = 75 + i * 1.5 + Math.random() * 10;
    
    // إضافة اتجاه لكل مشروع
    projects.forEach(project => {
      // تعديل البيانات بناءً على خصائص المشروع
      const projectFactor = project.progress > 50 ? 1.1 : 0.9;
      
      trends.push({
        projectId: project.id,
        date: month.toISOString(),
        onTimeDeliveryRate: Math.min(100, Math.round(baseOnTimeRate * projectFactor)),
        budgetAdherence: Math.min(100, Math.round(baseBudgetAdherence * projectFactor)),
        qualityScore: Math.min(100, Math.round(baseQualityScore * (project.category === 'communications' ? 1.15 : projectFactor)))
      });
    });
  }
  
  return trends;
}

// توليد بيانات العلاقات
function generateCorrelationData(projects: any[]): any[] {
  if (!projects || projects.length === 0) return [];
  
  // استخدام بيانات المشاريع لإنشاء بيانات العلاقات
  return projects.map(project => {
    const delayFactors = {
      scopeChanges: Math.round(Math.random() * 40 + 55),
      supplierDelays: Math.round(Math.random() * 30 + 55),
      weather: Math.round(Math.random() * 30 + 25),
      laborShortage: Math.round(Math.random() * 30 + 45)
    };
    
    const budgetFactors = {
      inaccurateEstimation: Math.round(Math.random() * 20 + 75),
      materialPriceChanges: Math.round(Math.random() * 25 + 60),
      additionalWork: Math.round(Math.random() * 25 + 60),
      projectDelay: Math.round(Math.random() * 30 + 45)
    };
    
    return {
      projectId: project.id,
      delayFactors,
      budgetFactors
    };
  });
}

export default AIAnalytics;