import { useState } from "react";
import { PlusIcon, Filter, Search, Settings, Calendar, Map, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useProjects } from "@/lib/data";

const Equipment = () => {
  const { data: projects, isLoading } = useProjects();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewEquipmentDialog, setShowNewEquipmentDialog] = useState(false);

  // Sample equipment data
  const equipmentData = [
    {
      id: 1,
      name: "حفارة كبيرة",
      type: "heavy",
      status: "in-use",
      currentProjectId: 1,
      image: "https://images.unsplash.com/photo-1533131966730-1b937add69f1?auto=format&fit=crop&w=300&h=200",
      model: "CAT 336",
      serialNumber: "CAT336-2023-001",
      purchaseDate: new Date(2022, 5, 15),
      lastMaintenance: new Date(2023, 9, 20)
    },
    {
      id: 2,
      name: "شاحنة نقل",
      type: "transportation",
      status: "in-use",
      currentProjectId: 1,
      image: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&w=300&h=200",
      model: "Mercedes Actros",
      serialNumber: "MA-2023-102",
      purchaseDate: new Date(2021, 3, 10),
      lastMaintenance: new Date(2023, 10, 5)
    },
    {
      id: 3,
      name: "مولد كهرباء",
      type: "power",
      status: "in-use",
      currentProjectId: 2,
      image: "https://images.unsplash.com/photo-1589758443576-76e979209197?auto=format&fit=crop&w=300&h=200",
      model: "Caterpillar XQ175",
      serialNumber: "CAT-XQ175-119",
      purchaseDate: new Date(2023, 1, 22),
      lastMaintenance: new Date(2023, 8, 15)
    },
    {
      id: 4,
      name: "رافعة شوكية",
      type: "lifting",
      status: "available",
      currentProjectId: null,
      image: "https://images.unsplash.com/photo-1621631216534-222ace36876a?auto=format&fit=crop&w=300&h=200",
      model: "Toyota 8FG",
      serialNumber: "TOY-8FG-2023-56",
      purchaseDate: new Date(2022, 8, 5),
      lastMaintenance: new Date(2023, 7, 12)
    },
    {
      id: 5,
      name: "خلاطة خرسانة",
      type: "concrete",
      status: "maintenance",
      currentProjectId: null,
      image: "https://images.unsplash.com/photo-1597357664116-3129f5e9a4c4?auto=format&fit=crop&w=300&h=200",
      model: "SANY HBT",
      serialNumber: "SANY-HBT-2022-32",
      purchaseDate: new Date(2022, 4, 17),
      lastMaintenance: new Date(2023, 10, 25)
    }
  ];

  // Filter equipment based on search query
  const filteredEquipment = equipmentData.filter(equipment => 
    equipment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    equipment.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    equipment.model.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "in-use":
        return <Badge className="bg-primary">قيد الاستخدام</Badge>;
      case "available":
        return <Badge className="bg-green-500">متاح</Badge>;
      case "maintenance":
        return <Badge className="bg-yellow-500">صيانة</Badge>;
      default:
        return <Badge className="bg-gray-500">{status}</Badge>;
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case "heavy": return "معدات ثقيلة";
      case "transportation": return "نقل";
      case "power": return "طاقة";
      case "lifting": return "رفع";
      case "concrete": return "خرسانة";
      default: return type;
    }
  };

  const getProjectName = (projectId: number | null) => {
    if (projectId === null) return "غير مخصص";
    const project = projects?.find(p => p.id === projectId);
    return project ? project.name : "غير معروف";
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('ar-SA').format(date);
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <>
      <div className="flex flex-col space-y-6">
        {/* Header with title and actions */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold dark:text-white">المعدات</h1>
          <div className="flex space-x-2 space-x-reverse">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Filter size={16} />
              <span>تصفية</span>
            </Button>
            <Dialog open={showNewEquipmentDialog} onOpenChange={setShowNewEquipmentDialog}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-1">
                  <PlusIcon size={16} />
                  <span>معدة جديدة</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>إضافة معدة جديدة</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      اسم المعدة
                    </Label>
                    <Input id="name" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="type" className="text-right">
                      النوع
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر النوع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="heavy">معدات ثقيلة</SelectItem>
                        <SelectItem value="transportation">نقل</SelectItem>
                        <SelectItem value="power">طاقة</SelectItem>
                        <SelectItem value="lifting">رفع</SelectItem>
                        <SelectItem value="concrete">خرسانة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="model" className="text-right">
                      الموديل
                    </Label>
                    <Input id="model" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="serialNumber" className="text-right">
                      الرقم التسلسلي
                    </Label>
                    <Input id="serialNumber" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="purchaseDate" className="text-right">
                      تاريخ الشراء
                    </Label>
                    <Input id="purchaseDate" type="date" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project" className="text-right">
                      المشروع
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="unassigned">غير مخصص</SelectItem>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="status" className="text-right">
                      الحالة
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الحالة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">متاح</SelectItem>
                        <SelectItem value="in-use">قيد الاستخدام</SelectItem>
                        <SelectItem value="maintenance">صيانة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="image" className="text-right">
                      صورة
                    </Label>
                    <Input id="image" type="file" className="col-span-3" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewEquipmentDialog(false)}>إلغاء</Button>
                  <Button type="submit" onClick={() => setShowNewEquipmentDialog(false)}>حفظ</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="ابحث عن اسم المعدة أو الموديل..."
              className="pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Tabs defaultValue="all" className="w-full sm:w-auto">
            <TabsList>
              <TabsTrigger value="all">الكل</TabsTrigger>
              <TabsTrigger value="in-use">قيد الاستخدام</TabsTrigger>
              <TabsTrigger value="available">متاح</TabsTrigger>
              <TabsTrigger value="maintenance">صيانة</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Equipment Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEquipment.map(equipment => (
            <Card key={equipment.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <div className="relative h-40">
                <img 
                  src={equipment.image} 
                  alt={equipment.name}
                  className="w-full h-full object-cover" 
                />
                <div className="absolute top-2 right-2">
                  {getStatusBadge(equipment.status)}
                </div>
              </div>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex justify-between items-center">
                  <span>{equipment.name}</span>
                  <Badge variant="outline" className="font-normal">
                    {getTypeText(equipment.type)}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">الموديل:</span>
                    <span className="font-medium dark:text-gray-200">{equipment.model}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">الرقم التسلسلي:</span>
                    <span className="font-medium dark:text-gray-200">{equipment.serialNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">تاريخ الشراء:</span>
                    <span className="font-medium dark:text-gray-200">{formatDate(equipment.purchaseDate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 dark:text-gray-400">آخر صيانة:</span>
                    <span className="font-medium dark:text-gray-200">{formatDate(equipment.lastMaintenance)}</span>
                  </div>
                  <div className="flex justify-between pt-1">
                    <span className="text-gray-500 dark:text-gray-400">المشروع:</span>
                    <span className="font-medium dark:text-gray-200">{getProjectName(equipment.currentProjectId)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button size="sm" variant="ghost" className="text-primary">
                  <History className="h-4 w-4 ml-1" />
                  <span>السجل</span>
                </Button>
                <div className="space-x-1 space-x-reverse">
                  <Button size="sm" variant="ghost">
                    <Map className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Calendar className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <Settings className="h-4 w-4" />
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Empty state */}
        {filteredEquipment.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium text-gray-600 dark:text-gray-300">لا توجد معدات مطابقة للبحث</h3>
            <p className="text-gray-500 mt-2">حاول تغيير معايير البحث أو إضافة معدة جديدة</p>
          </div>
        )}
      </div>
    </>
  );
};

export default Equipment;
