import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { 
  PlusCircle, 
  Info, 
  Download, 
  Printer, 
  Loader2,
  Filter,
  XCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Import project components
import ProjectDashboard from '@/components/projects/ProjectDashboard';
import ProjectFilters, { ProjectFiltersState } from '@/components/projects/ProjectFilters';
import ProjectCard from '@/components/projects/ProjectCard';
import ProjectListView from '@/components/projects/ProjectListView';
import ProjectViewSelector from '@/components/projects/ProjectViewSelector';
import ProjectForm from '@/components/projects/ProjectForm';
import ProjectKanbanView from '@/components/projects/ProjectKanbanView';
import ProjectMap from '@/components/projects/ProjectMap';
import ProjectStats from '@/components/projects/ProjectStats';
import ProjectDetails from '@/components/projects/ProjectDetails';

// Import API hooks
import { 
  useProjects, 
  useCreateProject, 
  useUpdateProject, 
  useDeleteProject 
} from '@/lib/data';

// Import types
import type { Project } from '@shared/schema';

// View types
type ViewType = 'dashboard' | 'grid' | 'list' | 'kanban' | 'map' | 'analytics';

const Projects: React.FC = () => {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // State for view, filters and modals
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [projectToEdit, setProjectToEdit] = useState<Project | null>(null);
  const [projectToDelete, setProjectToDelete] = useState<number | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(null);
  const [filters, setFilters] = useState<ProjectFiltersState>({
    search: '',
    status: [],
    category: [],
    date: 'all',
    budget: 'all',
    sortBy: 'newest'
  });

  // Fetch projects data
  const { data: projects, isLoading, error, refetch } = useProjects();
  
  // Mutation hooks
  const createProjectMutation = useCreateProject();
  const updateProjectMutation = useUpdateProject();
  const deleteProjectMutation = useDeleteProject();
  
  // State for seed loading
  const [isSeedingProjects, setIsSeedingProjects] = useState(false);

  // Handle errors
  useEffect(() => {
    if (error) {
      toast({
        title: "خطأ في تحميل المشاريع",
        description: error.message,
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Apply filters to projects
  const filteredProjects = React.useMemo(() => {
    if (!projects) return [];
    
    return projects.filter(project => {
      // Search filter
      if (filters.search && !project.name.toLowerCase().includes(filters.search.toLowerCase()) &&
          !project.description?.toLowerCase().includes(filters.search.toLowerCase()) &&
          !project.location.toLowerCase().includes(filters.search.toLowerCase()) &&
          !project.clientName?.toLowerCase().includes(filters.search.toLowerCase())) {
        return false;
      }
      
      // Status filter
      if (filters.status.length > 0 && !filters.status.includes(project.status)) {
        return false;
      }
      
      // Category filter
      if (filters.category.length > 0 && !filters.category.includes(project.category)) {
        return false;
      }
      
      // Date filter
      if (filters.date !== 'all') {
        const startDate = new Date(project.startDate);
        const now = new Date();
        const thisMonth = now.getMonth();
        const thisYear = now.getFullYear();
        
        if (filters.date === 'thisMonth' && 
            (startDate.getMonth() !== thisMonth || startDate.getFullYear() !== thisYear)) {
          return false;
        }
        
        if (filters.date === 'lastMonth') {
          const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1;
          const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear;
          if (startDate.getMonth() !== lastMonth || startDate.getFullYear() !== lastMonthYear) {
            return false;
          }
        }
        
        if (filters.date === 'thisYear' && startDate.getFullYear() !== thisYear) {
          return false;
        }
        
        if (filters.date === 'custom' && filters.startDate && filters.endDate) {
          const filterStartDate = new Date(filters.startDate);
          const filterEndDate = new Date(filters.endDate);
          if (startDate < filterStartDate || startDate > filterEndDate) {
            return false;
          }
        }
      }
      
      // Budget filter
      if (filters.budget !== 'all') {
        if (filters.budget === 'under100k' && project.budget >= 100000) {
          return false;
        }
        if (filters.budget === 'under500k' && (project.budget < 100000 || project.budget >= 500000)) {
          return false;
        }
        if (filters.budget === 'under1m' && (project.budget < 500000 || project.budget >= 1000000)) {
          return false;
        }
        if (filters.budget === 'over1m' && project.budget < 1000000) {
          return false;
        }
        if (filters.budget === 'custom') {
          if (filters.minBudget !== undefined && project.budget < filters.minBudget) {
            return false;
          }
          if (filters.maxBudget !== undefined && project.budget > filters.maxBudget) {
            return false;
          }
        }
      }
      
      return true;
    }).sort((a, b) => {
      // Apply sorting
      switch (filters.sortBy) {
        case 'newest':
          return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
        case 'oldest':
          return new Date(a.startDate).getTime() - new Date(b.startDate).getTime();
        case 'nameAsc':
          return a.name.localeCompare(b.name);
        case 'nameDesc':
          return b.name.localeCompare(a.name);
        case 'budgetAsc':
          return a.budget - b.budget;
        case 'budgetDesc':
          return b.budget - a.budget;
        case 'progressAsc':
          return a.progress - b.progress;
        case 'progressDesc':
          return b.progress - a.progress;
        default:
          return 0;
      }
    });
  }, [projects, filters]);

  // Check if any filters are active
  const filtersActive = Boolean(
    filters.search || 
    filters.status.length > 0 || 
    filters.category.length > 0 || 
    filters.date !== 'all' || 
    filters.budget !== 'all'
  );

  // Handler functions
  const handleCreateProject = (data: any) => {
    createProjectMutation.mutate(data, {
      onSuccess: () => {
        setIsCreateModalOpen(false);
        toast({
          title: "تم إنشاء المشروع",
          description: "تم إنشاء المشروع بنجاح",
        });
        refetch();
      },
      onError: (error) => {
        toast({
          title: "خطأ في إنشاء المشروع",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleUpdateProject = (data: any) => {
    if (!projectToEdit) return;
    
    updateProjectMutation.mutate({ id: projectToEdit.id, data }, {
      onSuccess: () => {
        setIsEditModalOpen(false);
        setProjectToEdit(null);
        toast({
          title: "تم تحديث المشروع",
          description: "تم تحديث المشروع بنجاح",
        });
        refetch();
      },
      onError: (error) => {
        toast({
          title: "خطأ في تحديث المشروع",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleDeleteProject = () => {
    if (!projectToDelete) return;
    
    deleteProjectMutation.mutate(projectToDelete, {
      onSuccess: () => {
        setIsDeleteModalOpen(false);
        setProjectToDelete(null);
        toast({
          title: "تم حذف المشروع",
          description: "تم حذف المشروع بنجاح",
        });
        refetch();
      },
      onError: (error) => {
        toast({
          title: "خطأ في حذف المشروع",
          description: error.message,
          variant: "destructive",
        });
      }
    });
  };

  const handleViewDetails = (projectId: number) => {
    setLocation(`/projects/${projectId}`);
  };

  const handleNavigateToTab = (projectId: number, tab: string) => {
    setLocation(`/projects/${projectId}?tab=${tab}`);
  };

  const handleEditProject = (project: Project) => {
    setProjectToEdit(project);
    setIsEditModalOpen(true);
  };

  const handleDeleteProjectConfirm = (projectId: number) => {
    setProjectToDelete(projectId);
    setIsDeleteModalOpen(true);
  };

  const resetFilters = () => {
    setFilters({
      search: '',
      status: [],
      category: [],
      date: 'all',
      budget: 'all',
      sortBy: 'newest'
    });
  };
  
  // إنشاء بيانات مشاريع تجريبية
  const handleSeedProjects = async () => {
    try {
      setIsSeedingProjects(true);
      const response = await fetch('/api/seed/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });
      
      if (!response.ok) {
        throw new Error('فشل في إنشاء بيانات المشاريع');
      }
      
      const data = await response.json();
      
      toast({
        title: "تم بنجاح",
        description: `تم إنشاء ${data.count} مشاريع للعرض التجريبي`,
      });
      
      refetch();
    } catch (error) {
      toast({
        title: "خطأ",
        description: error instanceof Error ? error.message : "حدث خطأ أثناء إنشاء بيانات المشاريع",
        variant: "destructive",
      });
    } finally {
      setIsSeedingProjects(false);
    }
  };

  // Pick recent projects for dashboard
  const recentProjects = React.useMemo(() => {
    if (!projects) return [];
    
    return [...projects]
      .sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - 
                      new Date(a.updatedAt || a.createdAt).getTime())
      .slice(0, 5);
  }, [projects]);

  // Remove the url-based navigation and use the component directly
  const handleViewDetails = (projectId: number) => {
    setSelectedProjectId(projectId);
    console.log("Viewing project details for ID:", projectId);
  };

  const handleBackToList = () => {
    setSelectedProjectId(null);
  };

  // Render loading state
  if (isLoading) {
    return (
      <div className="h-[50vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">جاري تحميل المشاريع...</p>
        </div>
      </div>
    );
  }

  // Render project details if a project is selected
  if (selectedProjectId) {
    return (
      <ProjectDetails
        projectId={selectedProjectId}
        onBack={handleBackToList}
        onEdit={handleEditProject}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">إدارة المشاريع</h1>
          <p className="text-muted-foreground">
            إدارة وتتبع جميع مشاريع البنية التحتية
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="gap-1"
            onClick={() => window.print()}
          >
            <Printer className="h-4 w-4" />
            <span className="hidden sm:inline">طباعة</span>
          </Button>
          
          <Button
            variant="outline"
            className="gap-1"
            onClick={() => {
              toast({
                title: "تصدير البيانات",
                description: "جاري تصدير بيانات المشاريع، سيتم تنزيلها قريبًا",
              });
            }}
          >
            <Download className="h-4 w-4" />
            <span className="hidden sm:inline">تصدير</span>
          </Button>
          
          <Button
            variant="outline"
            className="gap-1"
            onClick={handleSeedProjects}
            disabled={isSeedingProjects}
          >
            {isSeedingProjects ? (
              <Loader2 className="h-4 w-4 animate-spin ml-1" />
            ) : null}
            <span>إنشاء بيانات تجريبية</span>
          </Button>
          
          <Button 
            className="gap-1" 
            onClick={() => setIsCreateModalOpen(true)}
          >
            <PlusCircle className="h-4 w-4" />
            <span>مشروع جديد</span>
          </Button>
        </div>
      </div>

      {/* Filters and view selector */}
      <div className="flex flex-col gap-4">
        <ProjectFilters 
          filters={filters}
          onFilterChange={setFilters}
          onReset={resetFilters}
          filtersActive={filtersActive}
        />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-sm text-muted-foreground">
            {filteredProjects.length === 0 ? (
              <span>لا توجد مشاريع مطابقة</span>
            ) : (
              <span>عرض {filteredProjects.length} {filteredProjects.length === 1 ? 'مشروع' : 'مشاريع'} {filtersActive && 'مع تطبيق الفلاتر'}</span>
            )}
          </div>
          
          <ProjectViewSelector
            activeView={activeView}
            onViewChange={setActiveView}
          />
        </div>
      </div>
      
      {/* Filter active notification */}
      {filtersActive && (
        <div className="bg-muted/50 p-3 rounded-md flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">تم تطبيق فلاتر على المشاريع. بعض المشاريع قد تكون مخفية.</span>
          </div>
          <Button variant="ghost" size="sm" onClick={resetFilters} className="h-7 px-2 text-xs">
            <XCircle className="h-3.5 w-3.5 ml-1" />
            إزالة الفلاتر
          </Button>
        </div>
      )}

      {/* Main content based on active view */}
      {activeView === 'dashboard' && (
        <ProjectDashboard
          projects={filteredProjects}
          recentProjects={recentProjects}
          onCreateProject={() => setIsCreateModalOpen(true)}
          onViewProject={handleViewDetails}
          onViewAllProjects={() => setActiveView('grid')}
        />
      )}
      
      {activeView === 'grid' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProjects.map(project => (
            <ProjectCard
              key={project.id}
              project={project}
              onEdit={handleEditProject}
              onDelete={handleDeleteProjectConfirm}
              onViewDetails={handleViewDetails}
            />
          ))}
          
          {/* Empty state */}
          {filteredProjects.length === 0 && (
            <div className="col-span-full flex flex-col items-center justify-center p-8 bg-muted/30 rounded-lg">
              <Info className="h-10 w-10 text-muted mb-2" />
              <h3 className="text-lg font-semibold">لا توجد مشاريع</h3>
              <p className="text-muted-foreground text-center max-w-md mt-1 mb-4">
                {filtersActive 
                  ? 'لا توجد مشاريع مطابقة للفلاتر المحددة. حاول تعديل الفلاتر أو إزالتها.'
                  : 'لم يتم إضافة أي مشاريع بعد. أضف مشروعًا جديدًا للبدء.'}
              </p>
              
              {filtersActive ? (
                <Button variant="outline" onClick={resetFilters}>
                  إزالة الفلاتر
                </Button>
              ) : (
                <div className="flex flex-col gap-2">
                  <Button onClick={() => setIsCreateModalOpen(true)}>
                    إضافة مشروع جديد
                  </Button>
                  <Button 
                    variant="secondary" 
                    onClick={handleSeedProjects} 
                    disabled={isSeedingProjects}
                    className="mt-2"
                  >
                    {isSeedingProjects ? (
                      <>
                        <Loader2 className="h-4 w-4 ml-1 animate-spin" />
                        جاري إنشاء بيانات تجريبية...
                      </>
                    ) : (
                      <>إنشاء بيانات مشاريع للاختبار</>
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
      
      {activeView === 'list' && (
        <ProjectListView
          projects={filteredProjects}
          onEdit={handleEditProject}
          onDelete={handleDeleteProjectConfirm}
          onViewDetails={handleViewDetails}
          onNavigateToTab={handleNavigateToTab}
        />
      )}
      
      {activeView === 'kanban' && (
        <ProjectKanbanView
          projects={filteredProjects}
          onEditProject={handleEditProject}
          onViewProject={handleViewDetails}
        />
      )}
      
      {activeView === 'map' && (
        <ProjectMap
          projects={filteredProjects}
          onViewProject={handleViewDetails}
        />
      )}
      
      {activeView === 'analytics' && (
        <ProjectStats projects={filteredProjects} />
      )}

      {/* Create project modal */}
      <ProjectForm
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreateProject}
        isSubmitting={createProjectMutation.isPending}
      />

      {/* Edit project modal */}
      <ProjectForm
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setProjectToEdit(null);
        }}
        onSubmit={handleUpdateProject}
        initialData={projectToEdit || undefined}
        isSubmitting={updateProjectMutation.isPending}
      />

      {/* Delete confirmation dialog */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تأكيد حذف المشروع</DialogTitle>
            <DialogDescription>
              هل أنت متأكد من حذف هذا المشروع؟ هذا الإجراء لا يمكن التراجع عنه.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsDeleteModalOpen(false);
                setProjectToDelete(null);
              }}
            >
              إلغاء
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteProject}
              disabled={deleteProjectMutation.isPending}
            >
              {deleteProjectMutation.isPending ? "جاري الحذف..." : "حذف"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Projects;