import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useTheme } from "@/components/ui/theme-provider";
import { useRtl } from "@/components/ui/rtl-provider";
import { Shield, User as UserIcon, Bell, Globe, Moon, Sun, Palette, Key, Lock, Save } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const Settings = () => {
  const { theme, setTheme } = useTheme();
  const { lang, setLanguage } = useRtl();
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [whatsappNotifications, setWhatsappNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [desktopNotifications, setDesktopNotifications] = useState(true);
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold dark:text-white">الإعدادات</h1>
        <Button>
          <Save className="ml-2 h-4 w-4" />
          حفظ التغييرات
        </Button>
      </div>
      
      <Tabs defaultValue="account" className="space-y-6">
        <TabsList className="grid grid-cols-4 md:w-[600px]">
          <TabsTrigger value="account" className="flex items-center gap-2">
            <UserIcon className="h-4 w-4" />
            <span className="hidden sm:inline">الحساب</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">الإشعارات</span>
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center gap-2">
            <Palette className="h-4 w-4" />
            <span className="hidden sm:inline">المظهر</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">الأمان</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Account Settings */}
        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>المعلومات الشخصية</CardTitle>
              <CardDescription>
                قم بتحديث معلومات ملفك الشخصي وبيانات الاتصال
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex flex-col items-center gap-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=120&h=120&fit=crop&crop=faces" alt="عبدالله العتيبي" />
                    <AvatarFallback>عع</AvatarFallback>
                  </Avatar>
                  <Button variant="outline" size="sm">تغيير الصورة</Button>
                </div>
                <div className="flex-1 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">الاسم الكامل</Label>
                      <Input id="fullName" defaultValue="عبدالله العتيبي" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="username">اسم المستخدم</Label>
                      <Input id="username" defaultValue="admin" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">البريد الإلكتروني</Label>
                      <Input id="email" type="email" defaultValue="abdullah@stb.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">رقم الهاتف</Label>
                      <Input id="phone" defaultValue="+966 50 123 4567" />
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="position">المنصب</Label>
                  <Input id="position" defaultValue="مدير النظام" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bio">نبذة تعريفية</Label>
                  <Textarea
                    id="bio"
                    placeholder="اكتب نبذة تعريفية قصيرة عن نفسك..."
                    rows={4}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>معلومات الشركة</CardTitle>
              <CardDescription>
                قم بتحديث معلومات الشركة والمؤسسة
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">اسم الشركة</Label>
                  <Input id="companyName" defaultValue="شركة STB للبنية التحتية" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyRole">دورك في الشركة</Label>
                  <Select defaultValue="admin">
                    <SelectTrigger id="companyRole">
                      <SelectValue placeholder="اختر الدور" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">مدير</SelectItem>
                      <SelectItem value="project_manager">مدير مشروع</SelectItem>
                      <SelectItem value="engineer">مهندس</SelectItem>
                      <SelectItem value="supervisor">مشرف</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="companyAddress">عنوان الشركة</Label>
                <Textarea
                  id="companyAddress"
                  defaultValue="الرياض، المملكة العربية السعودية"
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تفضيلات الإشعارات</CardTitle>
              <CardDescription>
                اختر كيف ومتى تتلقى الإشعارات
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">البريد الإلكتروني</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      تلقي الإشعارات عبر البريد الإلكتروني
                    </p>
                  </div>
                  <Switch
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">واتساب</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      تلقي الإشعارات عبر واتساب
                    </p>
                  </div>
                  <Switch
                    checked={whatsappNotifications}
                    onCheckedChange={setWhatsappNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">الرسائل النصية</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      تلقي الإشعارات عبر الرسائل النصية القصيرة
                    </p>
                  </div>
                  <Switch
                    checked={smsNotifications}
                    onCheckedChange={setSmsNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">إشعارات سطح المكتب</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      تلقي الإشعارات على سطح المكتب
                    </p>
                  </div>
                  <Switch
                    checked={desktopNotifications}
                    onCheckedChange={setDesktopNotifications}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>أنواع الإشعارات</CardTitle>
              <CardDescription>
                اختر أنواع الإشعارات التي ترغب في تلقيها
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">تحديثات المشاريع</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      إشعارات عند تحديث حالة المشاريع
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">المواعيد النهائية</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      تذكير بالمواعيد النهائية القادمة
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">المعاملات المالية</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      إشعارات بالفواتير والمصروفات الجديدة
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">رسائل الدردشة</Label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      إشعارات عند استلام رسائل دردشة جديدة
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>الوضع</CardTitle>
              <CardDescription>
                اختر بين الوضع الفاتح والداكن
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <Button
                  variant={theme === "light" ? "default" : "outline"}
                  size="lg"
                  className="flex-1 justify-center gap-2"
                  onClick={() => setTheme("light")}
                >
                  <Sun className="h-5 w-5" />
                  <span>فاتح</span>
                </Button>
                <Button
                  variant={theme === "dark" ? "default" : "outline"}
                  size="lg"
                  className="flex-1 justify-center gap-2"
                  onClick={() => setTheme("dark")}
                >
                  <Moon className="h-5 w-5" />
                  <span>داكن</span>
                </Button>
                <Button
                  variant={theme === "system" ? "default" : "outline"}
                  size="lg"
                  className="flex-1 justify-center gap-2"
                  onClick={() => setTheme("system")}
                >
                  <span>تلقائي</span>
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>اللغة</CardTitle>
              <CardDescription>
                اختر لغة واجهة المستخدم
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2 space-x-reverse">
                <Button
                  variant={lang === "ar" ? "default" : "outline"}
                  size="lg"
                  className="flex-1 justify-center gap-2"
                  onClick={() => setLanguage("ar")}
                >
                  <Globe className="h-5 w-5" />
                  <span>العربية</span>
                </Button>
                <Button
                  variant={lang === "en" ? "default" : "outline"}
                  size="lg"
                  className="flex-1 justify-center gap-2"
                  onClick={() => setLanguage("en")}
                >
                  <Globe className="h-5 w-5" />
                  <span>English</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>تغيير كلمة المرور</CardTitle>
              <CardDescription>
                قم بتحديث كلمة المرور الخاصة بك بشكل دوري للحفاظ على أمان حسابك
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">كلمة المرور الحالية</Label>
                  <Input id="currentPassword" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newPassword">كلمة المرور الجديدة</Label>
                  <Input id="newPassword" type="password" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">تأكيد كلمة المرور الجديدة</Label>
                  <Input id="confirmPassword" type="password" />
                </div>
                <Button className="w-full sm:w-auto">
                  <Key className="ml-2 h-4 w-4" />
                  تغيير كلمة المرور
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>الجلسات النشطة</CardTitle>
              <CardDescription>
                إدارة الجلسات النشطة على حسابك
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-base font-medium dark:text-white">هذا الجهاز (متصل حالياً)</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Chrome على Windows • الرياض، المملكة العربية السعودية • آخر نشاط: الآن
                    </p>
                  </div>
                  <Button variant="outline" size="sm" className="text-primary">
                    <Lock className="ml-2 h-4 w-4" />
                    الجلسة الحالية
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-base font-medium dark:text-white">iPhone 13 Pro</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Safari على iOS • جدة، المملكة العربية السعودية • آخر نشاط: منذ 3 ساعات
                    </p>
                  </div>
                  <Button variant="outline" size="sm" className="text-red-600">
                    تسجيل الخروج
                  </Button>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <p className="text-base font-medium dark:text-white">MacBook Pro</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Chrome على macOS • الرياض، المملكة العربية السعودية • آخر نشاط: أمس
                    </p>
                  </div>
                  <Button variant="outline" size="sm" className="text-red-600">
                    تسجيل الخروج
                  </Button>
                </div>
              </div>
              
              <Button variant="outline" className="mt-4 w-full sm:w-auto">
                تسجيل الخروج من جميع الأجهزة الأخرى
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
