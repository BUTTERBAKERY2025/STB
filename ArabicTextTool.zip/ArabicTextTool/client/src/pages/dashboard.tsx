import { useState, useEffect } from 'react';
import { useProjects, useRecentActivities, useUpcomingDeadlines } from '@/lib/data';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Project } from '@shared/schema';
import { formatDate, formatCurrency } from '@/lib/utils';
import { Link } from 'wouter';

// UI Components
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Icons
import { 
  AlertTriangle, 
  BarChart2, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  Construction, 
  Hourglass, 
  Layers, 
  LayoutDashboard, 
  LineChart as LineChartIcon, 
  ListTodo, 
  LucideProps, 
  PieChart as PieChartIcon, 
  Plus, 
  RefreshCw, 
  Settings, 
  TrendingUp, 
  Users, 
  Wallet 
} from 'lucide-react';

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];
const STATUS_COLORS = {
  inProgress: '#0088FE',
  delayed: '#FF8042',
  completed: '#00C49F',
  planned: '#8884d8',
};

const Dashboard = () => {
  const [timeRange, setTimeRange] = useState('month');
  const [selectedTab, setSelectedTab] = useState('overview');
  
  const { data: projects = [], isLoading: isLoadingProjects } = useProjects();
  const { data: activities = [], isLoading: isLoadingActivities } = useRecentActivities(10);
  const { data: deadlines = [], isLoading: isLoadingDeadlines } = useUpcomingDeadlines();
  
  // مؤشرات الأداء الرئيسية
  const calculateKPIs = () => {
    if (!projects.length) return {
      totalProjects: 0,
      activeProjects: 0,
      completedProjects: 0,
      delayedProjects: 0,
      totalBudget: 0,
      spentBudget: 0,
      plannedProjects: 0,
    };
    
    const activeProjects = projects.filter(p => p.status === 'inProgress').length;
    const completedProjects = projects.filter(p => p.status === 'completed').length;
    const delayedProjects = projects.filter(p => p.status === 'delayed').length;
    const plannedProjects = projects.filter(p => p.status === 'planned').length;
    
    const totalBudget = projects.reduce((sum, project) => sum + (project.budget || 0), 0);
    // هذا مجرد تقدير للميزانية المنفقة - في التطبيق الحقيقي سيتم حسابها من المصروفات
    const spentBudget = projects.reduce((sum, project) => {
      if (project.status === 'completed') return sum + (project.budget || 0);
      if (project.status === 'inProgress') {
        return sum + ((project.budget || 0) * (project.progress || 0) / 100);
      }
      return sum;
    }, 0);
    
    return {
      totalProjects: projects.length,
      activeProjects,
      completedProjects,
      delayedProjects,
      plannedProjects,
      totalBudget,
      spentBudget,
    };
  };
  
  const kpis = calculateKPIs();
  
  // تحويل البيانات لاستخدامها في الرسوم البيانية
  const getProjectsByStatusData = () => {
    const statusCounts = {
      inProgress: kpis.activeProjects,
      completed: kpis.completedProjects,
      delayed: kpis.delayedProjects,
      planned: kpis.plannedProjects,
    };
    
    return Object.entries(statusCounts).map(([status, count]) => ({
      name: getStatusText(status),
      value: count,
      color: STATUS_COLORS[status as keyof typeof STATUS_COLORS],
    }));
  };
  
  const getStatusText = (status: string) => {
    switch (status) {
      case 'inProgress': return 'قيد التنفيذ';
      case 'delayed': return 'متأخر';
      case 'completed': return 'مكتمل';
      case 'planned': return 'مخطط';
      default: return status;
    }
  };
  
  const getProjectsByCategoryData = () => {
    const categoryGroups: Record<string, number> = {};
    
    projects.forEach(project => {
      const category = project.category || 'other';
      categoryGroups[category] = (categoryGroups[category] || 0) + 1;
    });
    
    return Object.entries(categoryGroups).map(([category, count], index) => ({
      name: getCategoryText(category),
      value: count,
      color: COLORS[index % COLORS.length],
    }));
  };
  
  const getCategoryText = (category: string) => {
    switch (category) {
      case 'electricity': return 'كهرباء';
      case 'water': return 'مياه';
      case 'communications': return 'اتصالات';
      case 'construction': return 'إنشاءات';
      case 'maintenance': return 'صيانة';
      default: return category;
    }
  };
  
  const getBudgetVsProgressData = () => {
    return projects
      .filter(p => p.status === 'inProgress' || p.status === 'completed')
      .map(project => ({
        name: project.name,
        ميزانية: project.budget || 0,
        إنجاز: project.progress || 0,
      }));
  };
  
  const getProjectTimelineData = () => {
    // يعطي آخر 6 مشاريع تم إنشاؤها
    return projects
      .slice(0, 6)
      .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
      .map(project => ({
        name: project.name,
        'تاريخ البداية': new Date(project.startDate).getTime(),
        'تاريخ النهاية': new Date(project.endDate).getTime(),
        status: project.status,
      }));
  };
  
  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    
    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
        {`${name} (${(percent * 100).toFixed(0)}%)`}
      </text>
    );
  };
  
  return (
    <div className="flex-1 space-y-4 p-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">لوحة التحكم</h2>
          <p className="text-muted-foreground">نظرة عامة على أداء المشاريع والمؤشرات الرئيسية</p>
        </div>
        <div className="flex items-center space-x-2 space-x-reverse">
          <Select
            value={timeRange}
            onValueChange={setTimeRange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="الفترة الزمنية" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">أسبوع</SelectItem>
              <SelectItem value="month">شهر</SelectItem>
              <SelectItem value="quarter">ربع سنوي</SelectItem>
              <SelectItem value="year">سنة</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" size="sm" className="ml-2">
            <RefreshCw className="h-4 w-4 ml-1" />
            تحديث
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="overview" value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList>
          <TabsTrigger value="overview">
            <LayoutDashboard className="h-4 w-4 ml-1" />
            نظرة عامة
          </TabsTrigger>
          <TabsTrigger value="financial">
            <Wallet className="h-4 w-4 ml-1" />
            المؤشرات المالية
          </TabsTrigger>
          <TabsTrigger value="progress">
            <TrendingUp className="h-4 w-4 ml-1" />
            تقدم المشاريع
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          {/* مؤشرات الأداء الرئيسية */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">إجمالي المشاريع</CardTitle>
                <Layers className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.totalProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.activeProjects} مشاريع نشطة
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">إجمالي الميزانية</CardTitle>
                <Wallet className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(kpis.totalBudget)}</div>
                <p className="text-xs text-muted-foreground">
                  {formatCurrency(kpis.spentBudget)} تم إنفاقه
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع المكتملة</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.completedProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.completedProjects > 0 
                    ? `${Math.round((kpis.completedProjects / kpis.totalProjects) * 100)}% من إجمالي المشاريع`
                    : 'لا توجد مشاريع مكتملة'
                  }
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع المتأخرة</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.delayedProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.delayedProjects > 0 
                    ? `${Math.round((kpis.delayedProjects / kpis.totalProjects) * 100)}% من إجمالي المشاريع`
                    : 'لا توجد مشاريع متأخرة'
                  }
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* الرسوم البيانية */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>توزيع المشاريع حسب الحالة</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                {isLoadingProjects ? (
                  <div className="h-80 w-full flex items-center justify-center">
                    <Skeleton className="h-80 w-80 rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={getProjectsByStatusData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={renderCustomizedLabel}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {getProjectsByStatusData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>توزيع المشاريع حسب الفئة</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                {isLoadingProjects ? (
                  <div className="h-80 w-full flex items-center justify-center">
                    <Skeleton className="h-80 w-80 rounded-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={getProjectsByCategoryData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={renderCustomizedLabel}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {getProjectsByCategoryData().map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* المواعيد النهائية القادمة */}
          <Card>
            <CardHeader>
              <CardTitle>المواعيد النهائية القادمة</CardTitle>
              <CardDescription>
                المواعيد النهائية للمشاريع خلال الأسبوعين القادمين
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingDeadlines ? (
                <div className="space-y-2">
                  {Array(3).fill(0).map((_, i) => (
                    <Skeleton key={i} className="w-full h-12" />
                  ))}
                </div>
              ) : deadlines.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">
                  لا توجد مواعيد نهائية قادمة
                </div>
              ) : (
                <div className="space-y-4">
                  {deadlines.map((deadline, index) => (
                    <div key={index} className="flex items-center justify-between border-b pb-2">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 ml-2 text-primary" />
                        <div>
                          <p className="font-medium">{deadline.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {deadline.projectId ? 
                              projects.find(p => p.id === deadline.projectId)?.name : 'غير مرتبط بمشروع'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Badge variant={
                          new Date(deadline.dueDate).getTime() - new Date().getTime() < 86400000 * 2 
                            ? "destructive" 
                            : "outline"
                        }>
                          {formatDate(new Date(deadline.dueDate))}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Link to="/projects">
                <Button variant="outline" size="sm">
                  عرض كافة المشاريع
                </Button>
              </Link>
            </CardFooter>
          </Card>
          
          {/* آخر النشاطات */}
          <Card>
            <CardHeader>
              <CardTitle>آخر النشاطات</CardTitle>
              <CardDescription>
                آخر التحديثات والنشاطات في المشاريع
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingActivities ? (
                <div className="space-y-2">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="w-full h-12" />
                  ))}
                </div>
              ) : activities.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">
                  لا توجد نشاطات حديثة
                </div>
              ) : (
                <div className="space-y-4">
                  {activities.map((activity, index) => (
                    <div key={index} className="flex items-start border-b pb-2">
                      <div className="mt-0.5 ml-2">
                        {activity.type === 'update' && <RefreshCw className="h-4 w-4 text-blue-500" />}
                        {activity.type === 'create' && <Plus className="h-4 w-4 text-green-500" />}
                        {activity.type === 'complete' && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                        {activity.type === 'delay' && <Clock className="h-4 w-4 text-amber-500" />}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.userName}</span>
                          <span className="text-muted-foreground"> {activity.description}</span>
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(new Date(activity.createdAt))}
                          {activity.projectId && projects.find(p => p.id === activity.projectId) && (
                            <> - {projects.find(p => p.id === activity.projectId)?.name}</>
                          )}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="financial" className="space-y-4">
          {/* مؤشرات مالية */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">إجمالي الميزانية</CardTitle>
                <Wallet className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(kpis.totalBudget)}</div>
                <p className="text-xs text-muted-foreground">
                  لجميع المشاريع
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">الميزانية المستهلكة</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(kpis.spentBudget)}</div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((kpis.spentBudget / kpis.totalBudget) * 100)}% من إجمالي الميزانية
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">متوسط ميزانية المشروع</CardTitle>
                <BarChart2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(kpis.totalProjects ? kpis.totalBudget / kpis.totalProjects : 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  لكل مشروع
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع ضمن الميزانية</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {projects.filter(p => (p.progress || 0) <= (p.budget || 0)).length}
                </div>
                <p className="text-xs text-muted-foreground">
                  {projects.length ? Math.round((projects.filter(p => (p.progress || 0) <= (p.budget || 0)).length / projects.length) * 100) : 0}% من المشاريع
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* رسوم بيانية للميزانية */}
          <Card>
            <CardHeader>
              <CardTitle>الميزانية مقابل الإنجاز</CardTitle>
              <CardDescription>
                مقارنة بين ميزانية المشاريع ونسبة الإنجاز
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingProjects ? (
                <Skeleton className="w-full h-80" />
              ) : (
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={getBudgetVsProgressData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="ميزانية" fill="#8884d8" />
                    <Bar yAxisId="right" dataKey="إنجاز" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="progress" className="space-y-4">
          {/* مؤشرات التقدم */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع النشطة</CardTitle>
                <Construction className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.activeProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.totalProjects ? Math.round((kpis.activeProjects / kpis.totalProjects) * 100) : 0}% من إجمالي المشاريع
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع المكتملة</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.completedProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.totalProjects ? Math.round((kpis.completedProjects / kpis.totalProjects) * 100) : 0}% من إجمالي المشاريع
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع المتأخرة</CardTitle>
                <Hourglass className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.delayedProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.totalProjects ? Math.round((kpis.delayedProjects / kpis.totalProjects) * 100) : 0}% من إجمالي المشاريع
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">المشاريع المخططة</CardTitle>
                <ListTodo className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{kpis.plannedProjects}</div>
                <p className="text-xs text-muted-foreground">
                  {kpis.totalProjects ? Math.round((kpis.plannedProjects / kpis.totalProjects) * 100) : 0}% من إجمالي المشاريع
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* الجدول الزمني للمشاريع */}
          <Card>
            <CardHeader>
              <CardTitle>الإطار الزمني للمشاريع</CardTitle>
              <CardDescription>
                تواريخ بداية ونهاية آخر المشاريع
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingProjects ? (
                <Skeleton className="w-full h-80" />
              ) : (
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart
                    layout="vertical"
                    data={getProjectTimelineData()}
                    margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" dataKey="تاريخ البداية" domain={['dataMin', 'dataMax']} />
                    <YAxis type="category" dataKey="name" width={150} />
                    <Tooltip labelFormatter={(value) => `المشروع: ${value}`} />
                    <Legend />
                    <Bar dataKey="تاريخ البداية" stackId="a" fill="#8884d8" />
                    <Bar dataKey="تاريخ النهاية" stackId="a" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;