import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { 
  FileText, Download, PlusIcon, Filter, ArrowUp, ArrowDown, Calculator, Printer,
  Calendar, DollarSign, BarChart2, PieChart, TrendingUp, TrendingDown, 
  Layers, FileSpreadsheet, ChevronRight, ClipboardList, CreditCard, Banknote
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/utils";
import { 
  useProjects, 
  useExpensesByProject, 
  useInvoicesByProject, 
  useCreateExpense, 
  useCreateInvoice,
  useCreateActivity,
  useUpdateExpense,
  useUpdateInvoice
} from "@/lib/data";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

const Finances = () => {
  const { toast } = useToast();
  
  // State
  const [activeTab, setActiveTab] = useState<string>("expenses");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("all");
  const [showNewFinanceDialog, setShowNewFinanceDialog] = useState(false);
  
  // Refs for print and export
  const statementRef = useRef<HTMLDivElement>(null);
  
  // Form states
  const [formProjectId, setFormProjectId] = useState<string>("");
  const [formAmount, setFormAmount] = useState<string>("");
  const [formDescription, setFormDescription] = useState<string>("");
  const [formDate, setFormDate] = useState<string>("");
  const [formDueDate, setFormDueDate] = useState<string>("");
  const [formCategory, setFormCategory] = useState<string>("");
  const [formInvoiceNumber, setFormInvoiceNumber] = useState<string>("");
  const [formClientName, setFormClientName] = useState<string>("");
  
  // Calculator states
  const [formCalcRevenue, setFormCalcRevenue] = useState<string>("1000000");
  const [formCalcCosts, setFormCalcCosts] = useState<string>("750000");
  const [formCalcTaxRate, setFormCalcTaxRate] = useState<string>("15");
  const [calculatedProfit, setCalculatedProfit] = useState<number>(212500);
  const [calculatedProfitMargin, setCalculatedProfitMargin] = useState<number>(21.25);
  
  // Queries and Mutations
  const { data: projects, isLoading: isLoadingProjects } = useProjects();
  const { data: expenses, isLoading: isLoadingExpenses } = 
    useExpensesByProject(selectedProjectId !== "all" ? parseInt(selectedProjectId) : 0);
  const { data: invoices, isLoading: isLoadingInvoices } = 
    useInvoicesByProject(selectedProjectId !== "all" ? parseInt(selectedProjectId) : 0);
  
  const { mutate: createExpense, isPending: isCreatingExpense } = useCreateExpense();
  const { mutate: createInvoice, isPending: isCreatingInvoice } = useCreateInvoice();
  const { mutate: createActivity } = useCreateActivity();
  const { mutate: updateExpense } = useUpdateExpense();
  const { mutate: updateInvoice } = useUpdateInvoice();

  // Process data
  const filteredExpenses = expenses?.filter(expense => 
    selectedProjectId === "all" || expense.projectId.toString() === selectedProjectId
  ) || [];

  const filteredInvoices = invoices?.filter(invoice => 
    selectedProjectId === "all" || invoice.projectId.toString() === selectedProjectId
  ) || [];

  // Calculate totals
  const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalInvoices = filteredInvoices.reduce((sum, invoice) => sum + invoice.amount, 0);
  const balance = totalInvoices - totalExpenses;
  
  // Log tab changes for debugging
  // تحميل البيانات ومعالجة URL عند بدء التشغيل
  useEffect(() => {
    // لتجنب مشاكل التنقل، استخدم التأثير لتتبع التغييرات في علامة التبويب
    console.log("Tab state changed to:", activeTab);
    
    // تحليل URL لاستخراج معلمات tab و project
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    const projectParam = urlParams.get('project');
    
    // إذا وجدت معلمات في URL، استخدمها
    if (tabParam) {
      setActiveTab(tabParam);
      console.log("Loading tab from URL:", tabParam);
    }
    
    if (projectParam) {
      setSelectedProjectId(projectParam);
      console.log("Loading project from URL:", projectParam);
      
      if (projectParam !== "all") {
        const projectId = parseInt(projectParam);
        setExpenseFilter((prev) => ({ ...prev, projectId }));
        setInvoiceFilter((prev) => ({ ...prev, projectId }));
      }
    }
  }, []);
  
  // وظيفة طباعة كشف الحساب
  const handlePrint = () => {
    if (selectedProjectId === "all") return;
    
    const projectName = getProjectName(parseInt(selectedProjectId));
    const currentDate = new Date().toLocaleDateString('ar-SA');
    
    // تحضير نافذة الطباعة
    const printWindow = window.open('', 'PRINT', 'height=800,width=1200');
    
    if (!printWindow || !statementRef.current) return;
    
    // إنشاء نسخة من محتوى العنصر
    const contentElement = statementRef.current.cloneNode(true) as HTMLElement;
    
    // إزالة الأزرار من النسخة المطبوعة
    const buttonsToRemove = contentElement.querySelectorAll('button');
    buttonsToRemove.forEach(button => button.remove());
    
    // إزالة أي عناصر إضافية لا نريد طباعتها
    const chartsToHide = contentElement.querySelectorAll('.recharts-wrapper');
    chartsToHide.forEach(chart => {
      if (chart.parentElement) {
        const parentNode = chart.parentElement;
        const imgPlaceholder = document.createElement('div');
        imgPlaceholder.classList.add('chart-placeholder');
        imgPlaceholder.textContent = '[مخطط بياني]';
        imgPlaceholder.style.textAlign = 'center';
        imgPlaceholder.style.padding = '10px';
        imgPlaceholder.style.border = '1px dashed #ccc';
        parentNode.replaceChild(imgPlaceholder, chart);
      }
    });
    
    // الحصول على محتوى النسخة المعدلة
    const statementContent = contentElement.innerHTML;
    
    // إضافة CSS محسن للطباعة
    const printCSS = `
      <style>
        @font-face {
          font-family: 'Tajawal';
          src: url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');
          font-weight: normal;
          font-style: normal;
        }
        
        @media print {
          @page { 
            size: A4; 
            margin: 15mm; 
          }
          
          * {
            box-sizing: border-box;
            font-family: 'Tajawal', 'Arial', 'Tahoma', sans-serif;
          }
          
          body {
            direction: rtl;
            text-align: right;
            color: #333;
            line-height: 1.6;
            font-size: 12pt;
            background-color: white;
          }
          
          h1, h2, h3, h4, h5 { 
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 10px;
          }
          
          /* تحسين ظهور الجداول */
          table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 1.5rem;
            page-break-inside: auto;
            border: 1px solid #ddd;
          }
          
          tr { 
            page-break-inside: avoid; 
            page-break-after: auto;
          }
          
          table th, table td { 
            padding: 8px; 
            border: 1px solid #ddd; 
            text-align: right; 
            font-size: 11pt;
          }
          
          table th { 
            background-color: #f2f2f2 !important; 
            font-weight: bold;
            color: #333 !important;
          }
          
          /* تنسيق البطاقات والعناصر */
          .card, .grid > div { 
            border: 1px solid #ddd !important; 
            padding: 15px !important; 
            margin-bottom: 15px !important; 
            border-radius: 5px !important; 
            page-break-inside: avoid;
            background-color: white !important;
          }
          
          /* تنسيق العنوان والتذييل */
          .header { 
            border-bottom: 2px solid #444;
            margin-bottom: 25px;
            padding-bottom: 15px;
            text-align: center !important;
            display: block !important;
          }
          
          .header div {
            display: block;
            text-align: center;
          }
          
          .footer { 
            margin-top: 40px; 
            padding-top: 10px;
            border-top: 1px solid #ddd;
            text-align: center; 
            font-size: 10pt; 
            color: #666; 
          }
          
          /* ألوان النص */
          .text-green-600, .text-green { color: #16a34a !important; }
          .text-red-600, .text-red { color: #dc2626 !important; }
          .text-yellow-600 { color: #ca8a04 !important; }
          .text-blue-600 { color: #2563eb !important; }
          
          /* تنسيق العناصر المختلفة */
          .font-bold { font-weight: bold !important; }
          .text-center { text-align: center !important; }
          .text-right { text-align: right !important; }
          
          /* تنسيق الشبكة */
          .grid {
            display: grid !important;
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 15px !important;
            page-break-inside: avoid;
          }
          
          .grid-cols-4, .md\\:grid-cols-4 {
            grid-template-columns: repeat(2, 1fr) !important;
          }
          
          .grid-cols-2, .md\\:grid-cols-2 {
            grid-template-columns: repeat(2, 1fr) !important;
          }
          
          /* إخفاء ما لا نريد طباعته */
          button, 
          .recharts-wrapper, 
          .no-print,
          .chart-react,
          [data-no-print="true"] { 
            display: none !important; 
          }
          
          /* تحسين أي عناصر أخرى */
          a { 
            text-decoration: none;
            color: inherit;
          }
          
          /* تحسين عناصر شادكن */
          .rounded-lg, .rounded-md {
            border-radius: 5px !important;
          }
          
          .p-4, .p-6 {
            padding: 15px !important;
          }
          
          .chart-placeholder {
            text-align: center;
            padding: 20px;
            border: 1px dashed #ccc;
            margin: 10px 0;
            background-color: #f9f9f9;
          }
        }
      </style>
    `;
    
    // إنشاء هيكل المستند للطباعة
    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>كشف حساب - ${projectName}</title>
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
        ${printCSS}
      </head>
      <body>
        <div class="header">
          <h1>نظام إدارة مشاريع البنية التحتية</h1>
          <h2>كشف حساب: ${projectName}</h2>
          <p>تاريخ التقرير: ${currentDate}</p>
        </div>
        
        <div id="print-content">
          ${statementContent}
        </div>
        
        <div class="footer">
          <p>نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}</p>
        </div>
      </body>
      </html>
    `);
    
    // إغلاق دفق الكتابة والتحضير للطباعة
    printWindow.document.close();
    printWindow.focus();
    
    // تأخير الطباعة قليلاً لضمان تحميل المحتوى والخطوط
    setTimeout(() => {
      printWindow.print();
      // نترك النافذة مفتوحة بعد الطباعة لإتاحة الفرصة للمستخدم لمعاينة الصفحة
    }, 1500);
    
    // تسجيل نشاط الطباعة
    if (selectedProjectId !== "all") {
      createActivity({
        projectId: parseInt(selectedProjectId),
        userId: 1,
        action: "طباعة تقرير",
        description: `تمت طباعة كشف حساب للمشروع: ${projectName}`,
        category: "financial"
      });
    }
  };
  
  // وظيفة تصدير ملف PDF
  const handleExportPDF = async () => {
    if (selectedProjectId === "all" || !statementRef.current) return;
    
    try {
      const projectName = getProjectName(parseInt(selectedProjectId));
      const filename = `كشف_حساب_${projectName}_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // عرض مؤشر التحميل 
      toast({
        title: "جاري التصدير",
        description: "يتم الآن تصدير البيانات إلى ملف PDF...",
      });
      
      // إنشاء نسخة من محتوى كشف الحساب
      const contentClone = statementRef.current.cloneNode(true) as HTMLElement;
      
      // إزالة الأزرار والعناصر التي لا نريد تصديرها
      const elementsToRemove = contentClone.querySelectorAll('button, .recharts-wrapper');
      elementsToRemove.forEach(el => el.remove());
      
      // استبدال عناصر الرسوم البيانية بنص وصفي
      const chartsContainers = contentClone.querySelectorAll('.chart');
      chartsContainers.forEach(container => {
        const captionElement = document.createElement('div');
        captionElement.textContent = 'مخطط بياني';
        captionElement.style.textAlign = 'center';
        captionElement.style.padding = '10px';
        captionElement.style.border = '1px dashed #ccc';
        captionElement.style.margin = '10px 0';
        container.innerHTML = '';
        container.appendChild(captionElement);
      });
      
      // إنشاء عنصر div مؤقت لتخزين المحتوى المعدل مع أنماط الطباعة
      const tempDiv = document.createElement('div');
      tempDiv.setAttribute('dir', 'rtl');
      tempDiv.style.padding = '20px';
      tempDiv.style.backgroundColor = 'white';
      tempDiv.style.width = '210mm'; // عرض A4
      tempDiv.style.margin = '0 auto';
      tempDiv.style.fontFamily = "'Tajawal', 'Arial', sans-serif";
      
      // إضافة ترويسة
      const header = document.createElement('div');
      header.style.textAlign = 'center';
      header.style.marginBottom = '20px';
      header.style.paddingBottom = '10px';
      header.style.borderBottom = '2px solid #444';
      
      const title = document.createElement('h1');
      title.textContent = 'نظام إدارة مشاريع البنية التحتية';
      title.style.fontSize = '24px';
      title.style.fontWeight = 'bold';
      title.style.margin = '5px 0';
      
      const subtitle = document.createElement('h2');
      subtitle.textContent = `كشف حساب: ${projectName}`;
      subtitle.style.fontSize = '20px';
      subtitle.style.margin = '5px 0';
      
      const dateText = document.createElement('p');
      dateText.textContent = `تاريخ التقرير: ${new Date().toLocaleDateString('ar-SA')}`;
      dateText.style.fontSize = '14px';
      dateText.style.margin = '5px 0';
      
      header.appendChild(title);
      header.appendChild(subtitle);
      header.appendChild(dateText);
      tempDiv.appendChild(header);
      
      // إضافة المحتوى الرئيسي
      tempDiv.appendChild(contentClone);
      
      // إضافة تذييل
      const footer = document.createElement('div');
      footer.style.textAlign = 'center';
      footer.style.marginTop = '30px';
      footer.style.paddingTop = '10px';
      footer.style.borderTop = '1px solid #ddd';
      footer.style.fontSize = '12px';
      footer.style.color = '#666';
      
      const footerText = document.createElement('p');
      footerText.textContent = `نظام إدارة مشاريع البنية التحتية - تم إنشاء هذا التقرير بتاريخ ${new Date().toLocaleString('ar-SA')}`;
      footer.appendChild(footerText);
      tempDiv.appendChild(footer);
      
      // إضافة Div مؤقت إلى المستند
      document.body.appendChild(tempDiv);
      
      // انتظار تمام تحميل الخطوط والمحتوى
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // تحويل العنصر إلى صورة باستخدام html2canvas مع تحسين الجودة
      const canvas = await html2canvas(tempDiv, {
        scale: 2, // زيادة جودة الصورة
        useCORS: true,
        logging: false,
        allowTaint: true,
        backgroundColor: '#ffffff',
        onclone: (document) => {
          // أي تعديلات إضافية على المستند المستنسخ إذا لزم الأمر
        }
      });
      
      // إزالة العنصر المؤقت من المستند
      document.body.removeChild(tempDiv);
      
      // إنشاء إعدادات PDF
      const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
        compress: true,
        hotfixes: ['px_scaling']
      });
      
      // إعداد الصفحة بدعم اللغة العربية
      pdf.setR2L(true);
      
      // إضافة الصورة إلى ملف PDF
      const imgData = canvas.toDataURL('image/jpeg', 1.0);
      const imgWidth = 210; // عرض A4 بالملم
      const pageHeight = 297; // ارتفاع A4 بالملم
      const imgHeight = canvas.height * imgWidth / canvas.width;
      
      // التعامل مع الصور الكبيرة التي تتجاوز حجم الصفحة
      let heightLeft = imgHeight;
      let position = 0;
      
      // إضافة الصفحة الأولى
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      // إضافة صفحات إضافية إذا كان المحتوى يتجاوز صفحة واحدة
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      // حفظ الملف
      pdf.save(filename);
      
      // عرض رسالة نجاح
      toast({
        title: "تم التصدير بنجاح",
        description: "تم تصدير كشف الحساب إلى ملف PDF بنجاح",
        duration: 3000,
      });
      
      // تسجيل نشاط التصدير
      if (selectedProjectId !== "all") {
        createActivity({
          projectId: parseInt(selectedProjectId),
          userId: 1,
          action: "تصدير تقرير",
          description: `تم تصدير كشف حساب للمشروع: ${projectName} بصيغة PDF`,
          category: "financial"
        });
      }
    } catch (error) {
      console.error("خطأ في تصدير ملف PDF:", error);
      
      // عرض رسالة خطأ للمستخدم
      toast({
        title: "خطأ في التصدير",
        description: "حدث خطأ أثناء محاولة تصدير الملف. يرجى المحاولة مرة أخرى.",
        variant: "destructive",
        duration: 5000,
      });
    }
  };

  // Helper functions
  const resetForm = () => {
    setFormProjectId("");
    setFormAmount("");
    setFormDescription("");
    setFormDate("");
    setFormDueDate("");
    setFormCategory("");
    setFormInvoiceNumber("");
    setFormClientName("");
  };
  
  const handleSubmit = () => {
    if (!formProjectId || !formAmount || !formDescription || !formDate) {
      return; // Validate required fields
    }
    
    const projectId = parseInt(formProjectId);
    const amount = parseFloat(formAmount);
    
    if (activeTab === "expenses") {
      if (!formCategory) return;
      
      createExpense({
        projectId,
        title: formDescription, // استخدام الوصف كعنوان أيضاً
        description: formDescription,
        date: formDate,
        amount,
        category: formCategory,
        status: "pending",
        receiptUrl: null,
        approvedBy: null
      }, {
        onSuccess: () => {
          // Reset form and close dialog
          resetForm();
          setShowNewFinanceDialog(false);
        }
      });
    } else {
      if (!formDueDate || !formInvoiceNumber || !formClientName) return;
      
      createInvoice({
        projectId,
        amount,
        description: formDescription,
        issueDate: formDate,
        dueDate: formDueDate,
        invoiceNumber: formInvoiceNumber,
        clientName: formClientName,
        status: "pending",
        paymentDate: null,
        attachmentUrl: null
      }, {
        onSuccess: () => {
          // Reset form and close dialog
          resetForm();
          setShowNewFinanceDialog(false);
        }
      });
    }
  };
  
  const calculateProfit = () => {
    try {
      const revenue = parseFloat(formCalcRevenue);
      const costs = parseFloat(formCalcCosts);
      const taxRate = parseFloat(formCalcTaxRate);
      
      if (isNaN(revenue) || isNaN(costs) || isNaN(taxRate)) {
        return;
      }
      
      // حساب الربح الإجمالي (الإيرادات - التكاليف)
      const grossProfit = revenue - costs;
      
      // حساب الضريبة
      const taxAmount = (grossProfit * taxRate) / 100;
      
      // حساب صافي الربح بعد الضريبة
      const netProfit = grossProfit - taxAmount;
      
      // حساب هامش الربح كنسبة مئوية
      const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
      
      // تحديث حالة الواجهة بالقيم المحسوبة
      setCalculatedProfit(netProfit);
      setCalculatedProfitMargin(parseFloat(profitMargin.toFixed(2)));
      
      // إضافة سجل نشاط عند حساب الربح لمشروع محدد
      if (selectedProjectId !== "all") {
        const projectId = parseInt(selectedProjectId);
        
        // تسجيل النشاط المالي في سجل الأنشطة
        createActivity({
          projectId,
          userId: 1, // المستخدم الحالي
          action: "حساب أرباح",
          description: `تم حساب أرباح المشروع باستخدام حاسبة الربح. صافي الربح: ${formatCurrency(netProfit)}`,
          category: "financial"
        }, {
          onError: (error) => {
            console.error("خطأ في تسجيل نشاط حساب الأرباح", error);
          }
        });
      }
    } catch (e) {
      console.error("خطأ في حساب الربح", e);
    }
  };

  const getProjectName = (projectId: number) => {
    const project = projects?.find(p => p.id === projectId);
    return project ? project.name : "مشروع غير معروف";
  };

  const getCategoryText = (category: string) => {
    switch (category) {
      case "material": return "مواد";
      case "equipment": return "معدات";
      case "labor": return "عمالة";
      case "subcontractor": return "مقاول من الباطن";
      case "transportation": return "نقل";
      case "utilities": return "مرافق";
      case "permits": return "تصاريح";
      case "insurance": return "تأمين";
      case "maintenance": return "صيانة";
      case "other": return "أخرى";
      default: return category;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved": return "معتمد";
      case "pending": return "قيد المراجعة";
      case "rejected": return "مرفوض";
      case "paid": return "مدفوع";
      case "overdue": return "متأخر";
      default: return status;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
      case "paid":
        return <Badge className="bg-green-500">معتمد</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500">قيد المراجعة</Badge>;
      case "rejected":
      case "overdue":
        return <Badge className="bg-red-500">مرفوض</Badge>;
      default:
        return <Badge className="bg-gray-500">{status}</Badge>;
    }
  };

  // Loading state
  if (isLoadingProjects || (selectedProjectId !== "all" && (isLoadingExpenses || isLoadingInvoices))) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <div className="flex flex-col space-y-6">
      {/* Header with title and actions */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold dark:text-white">الإدارة المالية</h1>
        <div className="flex space-x-2 space-x-reverse">
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Filter size={16} />
            <span>تصفية</span>
          </Button>
          <Dialog open={showNewFinanceDialog} onOpenChange={setShowNewFinanceDialog}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-1">
                <PlusIcon size={16} />
                <span>{activeTab === "expenses" ? "مصروف جديد" : "فاتورة جديدة"}</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>
                  {activeTab === "expenses" ? "إضافة مصروف جديد" : "إضافة فاتورة جديدة"}
                </DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="financeProject" className="text-right">
                    المشروع
                  </Label>
                  <Select
                    value={formProjectId}
                    onValueChange={setFormProjectId}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="اختر المشروع" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects?.map(project => (
                        <SelectItem key={project.id} value={project.id.toString()}>
                          {project.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="amount" className="text-right">
                    المبلغ
                  </Label>
                  <Input 
                    id="amount" 
                    type="number" 
                    className="col-span-3"
                    value={formAmount}
                    onChange={(e) => setFormAmount(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    الوصف
                  </Label>
                  <Input 
                    id="description" 
                    className="col-span-3"
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="date" className="text-right">
                    {activeTab === "expenses" ? "التاريخ" : "تاريخ الإصدار"}
                  </Label>
                  <Input 
                    id="date" 
                    type="date" 
                    className="col-span-3"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                  />
                </div>
                {activeTab === "expenses" && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="category" className="text-right">
                      الفئة
                    </Label>
                    <Select
                      value={formCategory}
                      onValueChange={setFormCategory}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="material">مواد</SelectItem>
                        <SelectItem value="equipment">معدات</SelectItem>
                        <SelectItem value="labor">عمالة</SelectItem>
                        <SelectItem value="subcontractor">مقاول من الباطن</SelectItem>
                        <SelectItem value="transportation">نقل</SelectItem>
                        <SelectItem value="utilities">مرافق</SelectItem>
                        <SelectItem value="permits">تصاريح</SelectItem>
                        <SelectItem value="insurance">تأمين</SelectItem>
                        <SelectItem value="maintenance">صيانة</SelectItem>
                        <SelectItem value="other">أخرى</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
                {activeTab === "invoices" && (
                  <>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="dueDate" className="text-right">
                        تاريخ الاستحقاق
                      </Label>
                      <Input 
                        id="dueDate" 
                        type="date" 
                        className="col-span-3"
                        value={formDueDate}
                        onChange={(e) => setFormDueDate(e.target.value)}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="invoiceNumber" className="text-right">
                        رقم الفاتورة
                      </Label>
                      <Input 
                        id="invoiceNumber"
                        className="col-span-3"
                        value={formInvoiceNumber}
                        onChange={(e) => setFormInvoiceNumber(e.target.value)}
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="clientName" className="text-right">
                        اسم العميل
                      </Label>
                      <Input 
                        id="clientName"
                        className="col-span-3"
                        value={formClientName}
                        onChange={(e) => setFormClientName(e.target.value)}
                      />
                    </div>
                  </>
                )}
              </div>
              <div className="flex justify-end gap-2">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    resetForm();
                    setShowNewFinanceDialog(false);
                  }}
                >
                  إلغاء
                </Button>
                <Button 
                  type="submit" 
                  onClick={handleSubmit}
                  disabled={isCreatingExpense || isCreatingInvoice}
                >
                  {isCreatingExpense || isCreatingInvoice ? "جاري الحفظ..." : "حفظ"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex justify-between">
              <span>الإيرادات</span>
              <ArrowUp className="h-5 w-5 text-green-500" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold dark:text-white">{formatCurrency(totalInvoices)}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {filteredInvoices.length} فواتير
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex justify-between">
              <span>المصروفات</span>
              <ArrowDown className="h-5 w-5 text-red-500" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold dark:text-white">{formatCurrency(totalExpenses)}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {filteredExpenses.length} مصروفات
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex justify-between">
              <span>الرصيد</span>
              <Calculator className="h-5 w-5 text-primary" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {formatCurrency(balance)}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {balance >= 0 ? 'ربح' : 'خسارة'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Project Filter */}
      <div className="flex items-center gap-2">
        <Label htmlFor="projectFilter" className="whitespace-nowrap">المشروع:</Label>
        <Select
          value={selectedProjectId}
          onValueChange={setSelectedProjectId}
        >
          <SelectTrigger id="projectFilter" className="w-[240px]">
            <SelectValue placeholder="جميع المشاريع" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">جميع المشاريع</SelectItem>
            {projects?.map(project => (
              <SelectItem key={project.id} value={project.id.toString()}>
                {project.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex-1"></div>
        <Button variant="outline" className="flex items-center gap-1">
          <Download size={16} />
          <span>تصدير</span>
        </Button>
      </div>

      {/* Custom Tab Navigation */}
      <div className="border-b border-gray-200 dark:border-gray-700">
        <div className="grid w-full grid-cols-4">
          <button
            onClick={() => {
              const newTab = "expenses";
              // تحديث عنوان URL
              window.history.pushState({}, "", `/finances?tab=${newTab}`);
              // أرسل حدث تنقل مخصص 
              const navigationEvent = new CustomEvent('navigation', { detail: { path: `/finances?tab=${newTab}` } });
              window.dispatchEvent(navigationEvent);
              // تعيين قيمة التبويب الحالي
              setActiveTab(newTab);
              console.log("Tab changed to:", newTab);
            }}
            className={`px-4 py-2 text-center font-medium ${
              activeTab === "expenses" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            }`}
          >
            المصروفات
          </button>
          <button
            onClick={() => {
              const newTab = "invoices";
              // تحديث عنوان URL
              window.history.pushState({}, "", `/finances?tab=${newTab}`);
              // أرسل حدث تنقل مخصص 
              const navigationEvent = new CustomEvent('navigation', { detail: { path: `/finances?tab=${newTab}` } });
              window.dispatchEvent(navigationEvent);
              // تعيين قيمة التبويب الحالي
              setActiveTab(newTab);
              console.log("Tab changed to:", newTab);
            }}
            className={`px-4 py-2 text-center font-medium ${
              activeTab === "invoices" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            }`}
          >
            الفواتير
          </button>
          <button
            onClick={() => {
              const newTab = "statements";
              // تحديث عنوان URL
              window.history.pushState({}, "", `/finances?tab=${newTab}`);
              // أرسل حدث تنقل مخصص 
              const navigationEvent = new CustomEvent('navigation', { detail: { path: `/finances?tab=${newTab}` } });
              window.dispatchEvent(navigationEvent);
              // تعيين قيمة التبويب الحالي
              setActiveTab(newTab);
              console.log("Tab changed to:", newTab);
            }}
            className={`px-4 py-2 text-center font-medium ${
              activeTab === "statements" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            }`}
          >
            كشف الحساب
          </button>
          <button
            onClick={() => {
              const newTab = "calculator";
              // تحديث عنوان URL
              window.history.pushState({}, "", `/finances?tab=${newTab}`);
              // أرسل حدث تنقل مخصص 
              const navigationEvent = new CustomEvent('navigation', { detail: { path: `/finances?tab=${newTab}` } });
              window.dispatchEvent(navigationEvent);
              // تعيين قيمة التبويب الحالي
              setActiveTab(newTab);
              console.log("Tab changed to:", newTab);
            }}
            className={`px-4 py-2 text-center font-medium ${
              activeTab === "calculator" ? "border-b-2 border-primary text-primary" : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
            }`}
          >
            حاسبة الربح
          </button>
        </div>
      </div>
      
      {/* Tab Content Container */}
      <div>
        {/* Expenses Tab */}
        {activeTab === "expenses" && (
          <div className="mt-6">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المشروع</TableHead>
                      <TableHead>الوصف</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>الفئة</TableHead>
                      <TableHead>التاريخ</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-left">إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenses.map(expense => (
                      <TableRow key={expense.id}>
                        <TableCell className="font-medium">{getProjectName(expense.projectId)}</TableCell>
                        <TableCell>{expense.description}</TableCell>
                        <TableCell>{formatCurrency(expense.amount)}</TableCell>
                        <TableCell>{getCategoryText(expense.category)}</TableCell>
                        <TableCell>{expense.date}</TableCell>
                        <TableCell>{getStatusBadge(expense.status)}</TableCell>
                        <TableCell className="text-left">
                          <div className="flex space-x-1 space-x-reverse">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              title="عرض التفاصيل"
                            >
                              <FileText className="h-4 w-4" />
                            </Button>
                            {expense.status === "pending" && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0 text-green-500"
                                title="الموافقة"
                                onClick={() => {
                                  updateExpense({
                                    id: expense.id, 
                                    expense: {
                                      ...expense,
                                      status: "approved",
                                      approvedBy: 1 // المستخدم الحالي
                                    }
                                  }, {
                                    onSuccess: () => {
                                      // تسجيل النشاط
                                      createActivity({
                                        projectId: expense.projectId,
                                        userId: 1,
                                        action: "تحديث المصروفات",
                                        description: `تمت الموافقة على مصروف: ${expense.description}`,
                                        category: "financial"
                                      });
                                    }
                                  });
                                }}
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M20 6L9 17l-5-5"></path>
                                </svg>
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Invoices Tab */}
        {activeTab === "invoices" && (
          <div className="mt-6">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>المشروع</TableHead>
                      <TableHead>الوصف</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>تاريخ الإصدار</TableHead>
                      <TableHead>تاريخ الاستحقاق</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-left">إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredInvoices.map(invoice => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-medium">{getProjectName(invoice.projectId)}</TableCell>
                        <TableCell>{invoice.description}</TableCell>
                        <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                        <TableCell>{invoice.issueDate}</TableCell>
                        <TableCell>{invoice.dueDate}</TableCell>
                        <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                        <TableCell className="text-left">
                          <div className="flex space-x-1 space-x-reverse">
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" title="عرض التفاصيل">
                              <FileText className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" title="تحميل الفاتورة">
                              <Download className="h-4 w-4" />
                            </Button>
                            {invoice.status === "pending" && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-8 w-8 p-0 text-green-500"
                                title="تسجيل كمدفوع"
                                onClick={() => {
                                  const today = new Date().toISOString().split('T')[0];
                                  updateInvoice({
                                    id: invoice.id, 
                                    invoice: {
                                      ...invoice,
                                      status: "paid",
                                      paymentDate: today
                                    }
                                  }, {
                                    onSuccess: () => {
                                      // تسجيل النشاط
                                      createActivity({
                                        projectId: invoice.projectId,
                                        userId: 1,
                                        action: "تحديث الفواتير",
                                        description: `تم تسجيل الفاتورة كمدفوعة: ${invoice.invoiceNumber}`,
                                        category: "financial"
                                      });
                                    }
                                  });
                                }}
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                  <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                </svg>
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Statements Tab */}
        {activeTab === "statements" && (
          <div className="mt-6">
            <Card>
              <CardContent className="py-4">
                {selectedProjectId === "all" ? (
                  <div className="text-center py-8">
                    <h3 className="text-xl font-medium mb-4">كشف حساب المشروع</h3>
                    <p className="text-gray-500 mb-8">اختر مشروع لعرض كشف الحساب التفصيلي</p>
                  </div>
                ) : (
                  <div ref={statementRef} className="statement-content">
                    <div className="flex items-center justify-between mb-6">
                      <div>
                        <h3 className="text-xl font-medium">كشف حساب: {getProjectName(parseInt(selectedProjectId))}</h3>
                        <p className="text-sm text-gray-500 mt-1">تقرير مالي شامل للفترة الحالية</p>
                      </div>
                      <div className="flex space-x-2 space-x-reverse">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex items-center gap-1"
                          onClick={handlePrint}
                        >
                          <Printer className="h-4 w-4" />
                          <span>طباعة</span>
                        </Button>
                        <Button 
                          size="sm" 
                          className="flex items-center gap-2"
                          onClick={handleExportPDF}
                        >
                          <FileText className="h-4 w-4" />
                          <span>تصدير PDF</span>
                        </Button>
                      </div>
                    </div>
                    
                    {/* بطاقات الملخص المالي */}
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">إجمالي الإيرادات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold text-green-600">
                            {formatCurrency(filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0))}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {filteredInvoices.length} فاتورة
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">إجمالي المصروفات</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold text-red-600">
                            {formatCurrency(filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0))}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {filteredExpenses.length} مصروف
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">صافي الربح</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className={`text-2xl font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(balance)}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            نسبة الربح: {totalInvoices > 0 ? ((balance / totalInvoices) * 100).toFixed(1) : '0'}%
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">فواتير قيد الانتظار</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-2xl font-bold text-yellow-600">
                            {formatCurrency(
                              filteredInvoices
                                .filter(i => i.status === 'pending')
                                .reduce((sum, i) => sum + i.amount, 0)
                            )}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {filteredInvoices.filter(i => i.status === 'pending').length} فاتورة
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                    
                    {/* عرض مرئي لتوزيع المصروفات */}
                    <div className="mb-8">
                      <h4 className="font-medium text-lg mb-4">توزيع المصروفات حسب الفئة</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <div className="flex flex-col space-y-3">
                            {['materials', 'equipment', 'labor', 'other'].map(category => {
                              const categoryExpenses = filteredExpenses.filter(e => e.category === category);
                              const categoryTotal = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);
                              const percentage = totalExpenses > 0 
                                ? ((categoryTotal / totalExpenses) * 100) 
                                : 0;
                              
                              return (
                                <div key={category} className="grid grid-cols-6 items-center">
                                  <span className="col-span-1">{getCategoryText(category)}</span>
                                  <div className="col-span-4 h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${
                                        category === 'materials' ? 'bg-blue-500' :
                                        category === 'equipment' ? 'bg-purple-500' :
                                        category === 'labor' ? 'bg-orange-500' : 'bg-gray-500'
                                      }`}
                                      style={{ width: `${percentage}%` }}
                                    />
                                  </div>
                                  <span className="col-span-1 text-left">{percentage.toFixed(1)}%</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>الفئة</TableHead>
                              <TableHead>العدد</TableHead>
                              <TableHead>الإجمالي</TableHead>
                              <TableHead>النسبة</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {['materials', 'equipment', 'labor', 'other'].map(category => {
                              const categoryExpenses = filteredExpenses.filter(e => e.category === category);
                              const categoryTotal = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);
                              const percentage = totalExpenses > 0 
                                ? ((categoryTotal / totalExpenses) * 100).toFixed(1) 
                                : '0';
                              
                              return (
                                <TableRow key={category}>
                                  <TableCell>{getCategoryText(category)}</TableCell>
                                  <TableCell>{categoryExpenses.length}</TableCell>
                                  <TableCell>{formatCurrency(categoryTotal)}</TableCell>
                                  <TableCell>{percentage}%</TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* جدول المقارنة المالية */}
                    <div className="mb-8">
                      <h4 className="font-medium text-lg mb-4">المقارنة المالية الشهرية</h4>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>الشهر</TableHead>
                              <TableHead>الإيرادات</TableHead>
                              <TableHead>المصروفات</TableHead>
                              <TableHead>صافي الربح</TableHead>
                              <TableHead>التغير</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {(() => {
                              // تجميع البيانات حسب الشهر
                              const months: Record<string, { invoices: number, expenses: number }> = {};
                              
                              // تحليل تواريخ الفواتير
                              filteredInvoices.forEach(invoice => {
                                const date = new Date(invoice.issueDate);
                                const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`;
                                
                                if (!months[monthKey]) {
                                  months[monthKey] = { invoices: 0, expenses: 0 };
                                }
                                
                                months[monthKey].invoices += invoice.amount;
                              });
                              
                              // تحليل تواريخ المصروفات
                              filteredExpenses.forEach(expense => {
                                const date = new Date(expense.date);
                                const monthKey = `${date.getFullYear()}-${date.getMonth() + 1}`;
                                
                                if (!months[monthKey]) {
                                  months[monthKey] = { invoices: 0, expenses: 0 };
                                }
                                
                                months[monthKey].expenses += expense.amount;
                              });
                              
                              // تحويل البيانات إلى مصفوفة للعرض
                              const monthNames = [
                                'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
                                'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
                              ];
                              
                              return Object.entries(months)
                                .sort((a, b) => a[0].localeCompare(b[0]))
                                .map(([key, data], index) => {
                                  const [year, month] = key.split('-').map(Number);
                                  const profit = data.invoices - data.expenses;
                                  
                                  // حساب التغير بالنسبة للشهر السابق
                                  let change = 0;
                                  let changeText = '';
                                  
                                  if (index > 0) {
                                    const prevMonth = Object.values(months)[index - 1];
                                    const prevProfit = prevMonth.invoices - prevMonth.expenses;
                                    
                                    if (prevProfit !== 0) {
                                      change = ((profit - prevProfit) / Math.abs(prevProfit)) * 100;
                                      changeText = change > 0 
                                        ? `+${change.toFixed(1)}%`
                                        : `${change.toFixed(1)}%`;
                                    } else if (profit !== 0) {
                                      changeText = 'جديد';
                                    }
                                  } else {
                                    changeText = '-';
                                  }
                                  
                                  return (
                                    <TableRow key={key}>
                                      <TableCell>
                                        {monthNames[month - 1]} {year}
                                      </TableCell>
                                      <TableCell>{formatCurrency(data.invoices)}</TableCell>
                                      <TableCell>{formatCurrency(data.expenses)}</TableCell>
                                      <TableCell className={profit >= 0 ? 'text-green-600' : 'text-red-600'}>
                                        {formatCurrency(profit)}
                                      </TableCell>
                                      <TableCell className={change > 0 ? 'text-green-600' : change < 0 ? 'text-red-600' : ''}>
                                        {changeText}
                                      </TableCell>
                                    </TableRow>
                                  );
                                });
                            })()}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* حالة الفواتير */}
                    <div>
                      <h4 className="font-medium text-lg mb-4">حالة الفواتير</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <div className="space-y-4">
                            {['paid', 'pending', 'overdue'].map(status => {
                              const statusInvoices = filteredInvoices.filter(i => i.status === status);
                              const statusTotal = statusInvoices.reduce((sum, i) => sum + i.amount, 0);
                              const percentage = totalInvoices > 0 
                                ? ((statusTotal / totalInvoices) * 100) 
                                : 0;
                              
                              const statusColor = 
                                status === 'paid' ? 'bg-green-500' :
                                status === 'pending' ? 'bg-yellow-500' : 'bg-red-500';
                              
                              return (
                                <div key={status} className="bg-muted/30 rounded-md p-4">
                                  <div className="flex justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                      <div className={`h-3 w-3 rounded-full ${statusColor}`}></div>
                                      <span className="font-medium">{getStatusText(status)}</span>
                                    </div>
                                    <span className="font-medium">{formatCurrency(statusTotal)}</span>
                                  </div>
                                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                                    <div 
                                      className={statusColor}
                                      style={{ width: `${percentage}%` }}
                                    />
                                  </div>
                                  <div className="flex justify-between mt-1 text-sm text-gray-500">
                                    <span>{statusInvoices.length} فاتورة</span>
                                    <span>{percentage.toFixed(1)}%</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                        
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>الحالة</TableHead>
                              <TableHead>العدد</TableHead>
                              <TableHead>الإجمالي</TableHead>
                              <TableHead>النسبة</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {['paid', 'pending', 'overdue'].map(status => {
                              const statusInvoices = filteredInvoices.filter(i => i.status === status);
                              const statusTotal = statusInvoices.reduce((sum, i) => sum + i.amount, 0);
                              const percentage = totalInvoices > 0 
                                ? ((statusTotal / totalInvoices) * 100).toFixed(1) 
                                : '0';
                              
                              return (
                                <TableRow key={status}>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      {getStatusBadge(status)}
                                    </div>
                                  </TableCell>
                                  <TableCell>{statusInvoices.length}</TableCell>
                                  <TableCell>{formatCurrency(statusTotal)}</TableCell>
                                  <TableCell>{percentage}%</TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                    
                    {/* الفواتير المتأخرة - إذا وجدت */}
                    {filteredInvoices.some(invoice => invoice.status === 'overdue') && (
                      <div className="mt-8">
                        <h4 className="font-medium text-lg mb-4 text-red-600">الفواتير المتأخرة - تتطلب متابعة</h4>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>رقم الفاتورة</TableHead>
                              <TableHead>العميل</TableHead>
                              <TableHead>المبلغ</TableHead>
                              <TableHead>تاريخ الاستحقاق</TableHead>
                              <TableHead>التأخير (أيام)</TableHead>
                              <TableHead>الإجراء</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredInvoices
                              .filter(invoice => invoice.status === 'overdue')
                              .map(invoice => {
                                const dueDate = new Date(invoice.dueDate);
                                const today = new Date();
                                const diffTime = Math.abs(today.getTime() - dueDate.getTime());
                                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                                
                                return (
                                  <TableRow key={invoice.id}>
                                    <TableCell>{invoice.invoiceNumber}</TableCell>
                                    <TableCell>{invoice.clientName}</TableCell>
                                    <TableCell>{formatCurrency(invoice.amount)}</TableCell>
                                    <TableCell>{invoice.dueDate}</TableCell>
                                    <TableCell className="text-red-600 font-medium">{diffDays}</TableCell>
                                    <TableCell>
                                      <Button size="sm" variant="outline">متابعة</Button>
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
        
        {/* Profit Calculator Tab */}
        {activeTab === "calculator" && (
          <div className="mt-6">
            <Card>
              <CardContent className="py-6">
                <div className="max-w-md mx-auto space-y-6">
                  <h3 className="text-xl font-medium text-center mb-6">حاسبة هامش الربح</h3>
                  
                  {selectedProjectId !== "all" ? (
                    <div className="space-y-4">
                      {/* Project-specific calculator */}
                      <div className="bg-muted/50 p-4 rounded-md mb-4">
                        <p className="text-center font-medium mb-2">{getProjectName(parseInt(selectedProjectId))}</p>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="text-right font-medium">إجمالي الإيرادات:</div>
                          <div>{formatCurrency(
                            filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0)
                          )}</div>
                          
                          <div className="text-right font-medium">إجمالي المصروفات:</div>
                          <div>{formatCurrency(
                            filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0)
                          )}</div>
                          
                          <div className="text-right font-medium border-t pt-1 mt-1">الربح الإجمالي:</div>
                          <div className="border-t pt-1 mt-1 font-bold">{formatCurrency(
                            filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0) -
                            filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0)
                          )}</div>
                        </div>
                      </div>
                    </div>
                  ) : null}
                  
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 items-center gap-4">
                      <Label htmlFor="calcRevenue" className="text-right">
                        إجمالي الإيرادات
                      </Label>
                      <Input 
                        id="calcRevenue" 
                        type="number" 
                        value={formCalcRevenue}
                        onChange={(e) => setFormCalcRevenue(e.target.value)}
                        className="col-span-2" 
                      />
                    </div>
                    
                    <div className="grid grid-cols-3 items-center gap-4">
                      <Label htmlFor="calcCosts" className="text-right">
                        إجمالي التكاليف
                      </Label>
                      <Input 
                        id="calcCosts" 
                        type="number" 
                        value={formCalcCosts}
                        onChange={(e) => setFormCalcCosts(e.target.value)}
                        className="col-span-2" 
                      />
                    </div>
                    
                    <div className="grid grid-cols-3 items-center gap-4">
                      <Label htmlFor="calcTaxRate" className="text-right">
                        معدل الضريبة (%)
                      </Label>
                      <Input 
                        id="calcTaxRate" 
                        type="number" 
                        value={formCalcTaxRate}
                        onChange={(e) => setFormCalcTaxRate(e.target.value)}
                        className="col-span-2" 
                      />
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div className="grid grid-cols-3 items-center gap-4">
                        <Label className="text-right font-medium">
                          صافي الربح
                        </Label>
                        <div className={`col-span-2 text-xl font-bold ${calculatedProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(calculatedProfit)}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 items-center gap-4 mt-2">
                        <Label className="text-right font-medium">
                          هامش الربح
                        </Label>
                        <div className="col-span-2 text-xl font-bold text-primary">
                          {calculatedProfitMargin}%
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-center pt-4">
                      <Button onClick={calculateProfit}>حساب</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default Finances;