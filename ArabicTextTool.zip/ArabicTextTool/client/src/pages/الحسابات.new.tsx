import React from "react";
import AccountManager from "@/components/financial/AccountManager";

/**
 * صفحة الحسابات المالية
 * 
 * توفر واجهة موحدة لإدارة:
 * 1. شجرة الحسابات المحاسبية
 * 2. إنشاء وإدارة القيود المحاسبية
 * 3. كشوفات الحسابات
 * 4. خيارات الترحيل والتصدير للتقارير
 */
const AccountsPage = () => {
  return (
    <div className="container mx-auto p-4 space-y-6">
      <AccountManager />
    </div>
  );
};

export default AccountsPage;