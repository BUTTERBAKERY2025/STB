import { useState } from "react";
import { PlusIcon, Filter, Search, FileText, Download, Trash2, UploadCloud, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useProjects } from "@/lib/data";
import { formatDate } from "@/lib/utils";

const Documents = () => {
  const { data: projects, isLoading } = useProjects();
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewDocumentDialog, setShowNewDocumentDialog] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");

  // Sample documents data
  const documents = [
    {
      id: 1,
      projectId: 1,
      name: "مخططات الكهرباء النهائية.pdf",
      fileUrl: "/documents/electrical-plans.pdf",
      fileType: "pdf",
      uploadedBy: 1,
      uploadedAt: new Date(2023, 10, 15),
      category: "contract",
      size: "3.5 MB"
    },
    {
      id: 2,
      projectId: 1,
      name: "جدول الكميات.xlsx",
      fileUrl: "/documents/bill-of-quantities.xlsx",
      fileType: "excel",
      uploadedBy: 2,
      uploadedAt: new Date(2023, 10, 20),
      category: "report",
      size: "1.2 MB"
    },
    {
      id: 3,
      projectId: 2,
      name: "عقد توريد المعدات.pdf",
      fileUrl: "/documents/equipment-contract.pdf",
      fileType: "pdf",
      uploadedBy: 1,
      uploadedAt: new Date(2023, 10, 25),
      category: "contract",
      size: "2.7 MB"
    },
    {
      id: 4,
      projectId: 3,
      name: "تقرير سير العمل - نوفمبر.docx",
      fileUrl: "/documents/progress-report-nov.docx",
      fileType: "word",
      uploadedBy: 3,
      uploadedAt: new Date(2023, 11, 5),
      category: "report",
      size: "1.8 MB"
    },
    {
      id: 5,
      projectId: 1,
      name: "فاتورة الدفعة الأولى.pdf",
      fileUrl: "/documents/first-payment-invoice.pdf",
      fileType: "pdf",
      uploadedBy: 2,
      uploadedAt: new Date(2023, 11, 10),
      category: "invoice",
      size: "0.9 MB"
    }
  ];

  // Filter documents based on search query and selected project
  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                        doc.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedProjectId === "all") return matchesSearch;
    return matchesSearch && doc.projectId.toString() === selectedProjectId;
  });

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case "pdf":
        return "📄";
      case "excel":
        return "📊";
      case "word":
        return "📝";
      case "image":
        return "🖼️";
      default:
        return "📎";
    }
  };

  const getCategoryText = (category: string) => {
    switch (category) {
      case "contract": return "عقد";
      case "invoice": return "فاتورة";
      case "report": return "تقرير";
      case "other": return "أخرى";
      default: return category;
    }
  };

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case "contract":
        return <Badge className="bg-blue-500">عقد</Badge>;
      case "invoice":
        return <Badge className="bg-green-500">فاتورة</Badge>;
      case "report":
        return <Badge className="bg-purple-500">تقرير</Badge>;
      default:
        return <Badge className="bg-gray-500">{getCategoryText(category)}</Badge>;
    }
  };

  const getUploaderName = (uploaderId: number) => {
    switch (uploaderId) {
      case 1: return "عبدالله العتيبي";
      case 2: return "أحمد محمد";
      case 3: return "سارة العلي";
      default: return "غير معروف";
    }
  };

  const getProjectName = (projectId: number) => {
    const project = projects?.find(p => p.id === projectId);
    return project ? project.name : "مشروع غير معروف";
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <>
      <div className="flex flex-col space-y-6">
        {/* Header with title and actions */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold dark:text-white">المستندات</h1>
          <div className="flex space-x-2 space-x-reverse">
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <Filter size={16} />
              <span>تصفية</span>
            </Button>
            <Dialog open={showNewDocumentDialog} onOpenChange={setShowNewDocumentDialog}>
              <DialogTrigger asChild>
                <Button className="flex items-center gap-1">
                  <PlusIcon size={16} />
                  <span>مستند جديد</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>إضافة مستند جديد</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="docName" className="text-right">
                      اسم المستند
                    </Label>
                    <Input id="docName" className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project" className="text-right">
                      المشروع
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="category" className="text-right">
                      الفئة
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر الفئة" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contract">عقد</SelectItem>
                        <SelectItem value="invoice">فاتورة</SelectItem>
                        <SelectItem value="report">تقرير</SelectItem>
                        <SelectItem value="other">أخرى</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="file" className="text-right">
                      الملف
                    </Label>
                    <Input id="file" type="file" className="col-span-3" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowNewDocumentDialog(false)}>إلغاء</Button>
                  <Button type="submit" onClick={() => setShowNewDocumentDialog(false)}>رفع المستند</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-2.5 h-4 w-4 text-gray-400" />
            <Input 
              placeholder="البحث عن اسم المستند أو الفئة..."
              className="pr-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select
            value={selectedProjectId}
            onValueChange={setSelectedProjectId}
          >
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="جميع المشاريع" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">جميع المشاريع</SelectItem>
              {projects?.map(project => (
                <SelectItem key={project.id} value={project.id.toString()}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Tabs 
            value={viewMode} 
            onValueChange={(value) => setViewMode(value as "grid" | "table")}
            className="w-full sm:w-auto"
          >
            <TabsList>
              <TabsTrigger value="grid">شبكة</TabsTrigger>
              <TabsTrigger value="table">قائمة</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Documents Display */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDocuments.map(doc => (
              <Card key={doc.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="text-4xl ml-4">{getFileIcon(doc.fileType)}</div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-medium text-lg dark:text-white truncate" title={doc.name}>
                        {doc.name}
                      </h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {doc.size} • {formatDate(doc.uploadedAt)}
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">المشروع:</span>
                      <span className="font-medium dark:text-gray-200">{getProjectName(doc.projectId)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">الفئة:</span>
                      <span>{getCategoryBadge(doc.category)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">تم الرفع بواسطة:</span>
                      <span className="font-medium dark:text-gray-200">{getUploaderName(doc.uploadedBy)}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="bg-gray-50 dark:bg-gray-800 px-6 py-3 flex justify-between">
                  <Button variant="ghost" size="sm" className="text-green-600 dark:text-green-500">
                    <Download className="h-4 w-4 ml-1" />
                    <span>تنزيل</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="text-red-600 dark:text-red-500">
                    <Trash2 className="h-4 w-4 ml-1" />
                    <span>حذف</span>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>اسم المستند</TableHead>
                  <TableHead>المشروع</TableHead>
                  <TableHead>الفئة</TableHead>
                  <TableHead>الحجم</TableHead>
                  <TableHead>تاريخ الرفع</TableHead>
                  <TableHead>تم الرفع بواسطة</TableHead>
                  <TableHead className="text-left">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocuments.map(doc => (
                  <TableRow key={doc.id}>
                    <TableCell className="font-medium flex items-center">
                      <span className="ml-2">{getFileIcon(doc.fileType)}</span>
                      {doc.name}
                    </TableCell>
                    <TableCell>{getProjectName(doc.projectId)}</TableCell>
                    <TableCell>{getCategoryBadge(doc.category)}</TableCell>
                    <TableCell>{doc.size}</TableCell>
                    <TableCell>{formatDate(doc.uploadedAt)}</TableCell>
                    <TableCell>{getUploaderName(doc.uploadedBy)}</TableCell>
                    <TableCell className="text-left">
                      <div className="flex space-x-1 space-x-reverse">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-green-600">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-red-600">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Empty state */}
        {filteredDocuments.length === 0 && (
          <div className="text-center py-16 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                <FolderOpen className="h-8 w-8 text-gray-400 dark:text-gray-500" />
              </div>
            </div>
            <h3 className="text-xl font-medium text-gray-600 dark:text-gray-300 mb-2">لا توجد مستندات</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4">لم يتم العثور على أي مستندات مطابقة لمعايير البحث</p>
            <div className="flex justify-center">
              <Button
                onClick={() => setShowNewDocumentDialog(true)}
                className="flex items-center gap-2"
              >
                <UploadCloud className="h-4 w-4" />
                <span>رفع مستند جديد</span>
              </Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Documents;
