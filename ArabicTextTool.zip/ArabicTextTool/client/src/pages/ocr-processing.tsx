import { useState } from "react";
import { 
  Filter, 
  PlusIcon, 
  FileText, 
  Upload, 
  Check, 
  Loader2,
  Pencil,
  Save,
  Image,
  RotateCcw,
  ZoomIn,
  Download
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { formatCurrency } from "@/lib/utils";
import { useProjects } from "@/lib/data";

const OcrProcessing = () => {
  const { data: projects, isLoading } = useProjects();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [activeTab, setActiveTab] = useState("upload");
  const [showInvoiceDialog, setShowInvoiceDialog] = useState(false);

  // Sample OCR results
  const extractedData = {
    invoiceNumber: "INV-20230518-001",
    date: "18/05/2023",
    dueDate: "17/06/2023",
    vendorName: "شركة الإنشاءات المتكاملة",
    vendorTaxId: "300984675200003",
    customerName: "شركة STB للبنية التحتية",
    customerTaxId: "310459871600002",
    currency: "ريال سعودي",
    subtotal: 85000,
    taxAmount: 12750,
    total: 97750,
    lineItems: [
      {
        id: 1,
        description: "توريد كابلات كهربائية",
        quantity: 500,
        unit: "متر",
        unitPrice: 120,
        subtotal: 60000,
        tax: 9000,
        total: 69000
      },
      {
        id: 2,
        description: "تركيب محولات كهربائية",
        quantity: 5,
        unit: "قطعة",
        unitPrice: 5000,
        subtotal: 25000,
        tax: 3750,
        total: 28750
      }
    ],
    notes: "يرجى السداد خلال 30 يوم من تاريخ الإصدار",
    confidence: 92
  };

  // التعامل مع تحميل الملف
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  // معالجة الفاتورة
  const handleProcessInvoice = () => {
    if (!selectedFile) return;
    
    setIsProcessing(true);
    setProcessingProgress(0);
    
    // محاكاة لعملية المعالجة
    const interval = setInterval(() => {
      setProcessingProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          setShowResults(true);
          setActiveTab("results");
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  // إعادة تعيين الحالة
  const handleReset = () => {
    setSelectedFile(null);
    setIsProcessing(false);
    setProcessingProgress(0);
    setShowResults(false);
    setActiveTab("upload");
  };

  // نسخ البيانات المستخرجة إلى فاتورة جديدة
  const handleCreateInvoice = () => {
    setShowInvoiceDialog(true);
  };

  if (isLoading) {
    return <div className="p-8 text-center">جاري التحميل...</div>;
  }

  return (
    <>
      <div className="flex flex-col space-y-6">
        {/* Header with title and actions */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold dark:text-white">معالجة الفواتير بتقنية OCR</h1>
          <div className="flex space-x-2 space-x-reverse">
            <Dialog open={showInvoiceDialog} onOpenChange={setShowInvoiceDialog}>
              <DialogTrigger asChild>
                <Button
                  className="flex items-center gap-1"
                  disabled={!showResults}
                >
                  <PlusIcon size={16} />
                  <span>فاتورة جديدة</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>إنشاء فاتورة من البيانات المستخرجة</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="project" className="text-right">
                      المشروع
                    </Label>
                    <Select>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="اختر المشروع" />
                      </SelectTrigger>
                      <SelectContent>
                        {projects?.map(project => (
                          <SelectItem key={project.id} value={project.id.toString()}>
                            {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="invoiceNumber" className="text-right">
                      رقم الفاتورة
                    </Label>
                    <Input id="invoiceNumber" defaultValue={extractedData.invoiceNumber} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="vendorName" className="text-right">
                      اسم المورد
                    </Label>
                    <Input id="vendorName" defaultValue={extractedData.vendorName} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="date" className="text-right">
                      تاريخ الفاتورة
                    </Label>
                    <Input id="date" defaultValue={extractedData.date} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="dueDate" className="text-right">
                      تاريخ الاستحقاق
                    </Label>
                    <Input id="dueDate" defaultValue={extractedData.dueDate} className="col-span-3" />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="total" className="text-right">
                      إجمالي المبلغ
                    </Label>
                    <Input id="total" defaultValue={extractedData.total.toString()} className="col-span-3" />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowInvoiceDialog(false)}>إلغاء</Button>
                  <Button type="submit" onClick={() => setShowInvoiceDialog(false)}>إنشاء الفاتورة</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Processing Area */}
        <Tabs
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload">تحميل المستند</TabsTrigger>
            <TabsTrigger value="results" disabled={!showResults}>النتائج</TabsTrigger>
            <TabsTrigger value="history">سجل المعالجة</TabsTrigger>
          </TabsList>
          
          {/* Upload Tab */}
          <TabsContent value="upload" className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>تحميل فاتورة</CardTitle>
                  <CardDescription>
                    قم بتحميل صورة أو مستند PDF للفاتورة لاستخراج البيانات منها تلقائياً
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!selectedFile ? (
                    <div 
                      className="border-2 border-dashed rounded-lg p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800/50"
                      onClick={() => document.getElementById('file-upload')?.click()}
                    >
                      <Upload className="h-10 w-10 text-gray-400 dark:text-gray-500 mb-4" />
                      <h3 className="text-lg font-medium mb-2">اسحب وأفلت أو انقر للتحميل</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                        JPG, PNG أو PDF بحد أقصى 10 ميجابايت
                      </p>
                      <Button size="sm" className="gap-1">
                        <FileText className="h-4 w-4" />
                        <span>اختر ملف</span>
                      </Button>
                      <input 
                        id="file-upload" 
                        type="file" 
                        accept=".jpg,.jpeg,.png,.pdf" 
                        className="hidden" 
                        onChange={handleFileChange}
                      />
                    </div>
                  ) : (
                    <div className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <FileText className="h-8 w-8 text-primary ml-2" />
                          <div>
                            <p className="font-medium">{selectedFile.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {(selectedFile.size / 1024 / 1024).toFixed(2)} MB • {selectedFile.type}
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={handleReset}
                          className="h-7 w-7 p-0"
                        >
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      </div>
                      
                      {isProcessing && (
                        <div className="space-y-2">
                          <Progress value={processingProgress} className="h-2" />
                          <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                            <span>جاري معالجة الفاتورة...</span>
                            <span>{processingProgress}%</span>
                          </div>
                        </div>
                      )}
                      
                      <div className="mt-4">
                        <Button 
                          onClick={handleProcessInvoice} 
                          disabled={isProcessing} 
                          className="w-full"
                        >
                          {isProcessing ? (
                            <>
                              <Loader2 className="h-4 w-4 ml-2 animate-spin" />
                              جاري المعالجة...
                            </>
                          ) : (
                            <>
                              <Image className="h-4 w-4 ml-2" />
                              معالجة الفاتورة
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="text-sm text-gray-500 dark:text-gray-400 pt-0">
                  <p>
                    نستخدم تقنية OCR للتعرف على النصوص واستخراج البيانات من الفواتير تلقائياً
                  </p>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>إرشادات المعالجة</CardTitle>
                  <CardDescription>
                    نصائح للحصول على أفضل نتائج من معالجة الفواتير
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">1</div>
                      <div>
                        <h4 className="font-medium">جودة عالية</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          تأكد من أن صورة الفاتورة واضحة وذات دقة عالية للحصول على نتائج أفضل
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">2</div>
                      <div>
                        <h4 className="font-medium">إضاءة مناسبة</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          تجنب الظلال والتباين العالي حتى تكون النصوص في الفاتورة مقروءة
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">3</div>
                      <div>
                        <h4 className="font-medium">التنسيق الصحيح</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          تأكد من أن الفاتورة منظمة وتحتوي على جميع البيانات المطلوبة بوضوح
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center text-xs">4</div>
                      <div>
                        <h4 className="font-medium">مراجعة النتائج</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          دائماً قم بمراجعة وتصحيح أي بيانات قبل استخدامها في النظام
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Results Tab */}
          <TabsContent value="results" className="pt-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
              <div className="md:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                      <span>معاينة المستند</span>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <ZoomIn className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>تكبير المستند</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-2">
                    <div className="bg-gray-100 dark:bg-gray-800 rounded-md min-h-[600px] flex items-center justify-center">
                      <div className="text-center text-gray-500 dark:text-gray-400">
                        <FileText className="h-12 w-12 mx-auto mb-2" />
                        <p>معاينة المستند</p>
                        <p className="text-xs">سيتم عرض الفاتورة هنا</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="md:col-span-3 space-y-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>البيانات المستخرجة</CardTitle>
                    <CardDescription>
                      تم استخراج هذه البيانات من الفاتورة بدقة {extractedData.confidence}%
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">رقم الفاتورة</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.invoiceNumber}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">تاريخ الفاتورة</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.date}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">تاريخ الاستحقاق</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.dueDate}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">المورد</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.vendorName}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">الرقم الضريبي للمورد</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.vendorTaxId}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-muted-foreground">العميل</Label>
                          <div className="flex items-center">
                            <span className="font-medium text-base">{extractedData.customerName}</span>
                            <Button variant="ghost" size="icon" className="h-6 w-6 mr-1">
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-medium mb-2">بنود الفاتورة</h4>
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>الوصف</TableHead>
                                <TableHead className="text-left">الكمية</TableHead>
                                <TableHead className="text-left">سعر الوحدة</TableHead>
                                <TableHead className="text-left">الإجمالي</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {extractedData.lineItems.map(item => (
                                <TableRow key={item.id}>
                                  <TableCell className="font-medium">{item.description}</TableCell>
                                  <TableCell>{item.quantity} {item.unit}</TableCell>
                                  <TableCell>{formatCurrency(item.unitPrice)}</TableCell>
                                  <TableCell>{formatCurrency(item.total)}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t">
                        <div className="flex justify-between items-center">
                          <span className="text-muted-foreground">المجموع الفرعي</span>
                          <span className="font-medium">{formatCurrency(extractedData.subtotal)}</span>
                        </div>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-muted-foreground">ضريبة القيمة المضافة (15%)</span>
                          <span className="font-medium">{formatCurrency(extractedData.taxAmount)}</span>
                        </div>
                        <div className="flex justify-between items-center mt-2 text-lg font-bold">
                          <span>الإجمالي</span>
                          <span>{formatCurrency(extractedData.total)}</span>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t">
                        <h4 className="font-medium mb-2">ملاحظات</h4>
                        <p className="text-gray-600 dark:text-gray-300 text-sm">{extractedData.notes}</p>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between border-t pt-4">
                    <Button variant="outline" className="gap-1" onClick={handleReset}>
                      <RotateCcw className="h-4 w-4" />
                      <span>معالجة فاتورة أخرى</span>
                    </Button>
                    <div className="flex gap-2">
                      <Button variant="outline" className="gap-1">
                        <Download className="h-4 w-4" />
                        <span>تصدير البيانات</span>
                      </Button>
                      <Button className="gap-1" onClick={handleCreateInvoice}>
                        <Save className="h-4 w-4" />
                        <span>إنشاء فاتورة</span>
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          {/* History Tab */}
          <TabsContent value="history" className="pt-4">
            <Card>
              <CardHeader>
                <CardTitle>سجل معالجة الفواتير</CardTitle>
                <CardDescription>
                  آخر 10 فواتير تمت معالجتها
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>رقم الفاتورة</TableHead>
                      <TableHead>المورد</TableHead>
                      <TableHead>تاريخ المعالجة</TableHead>
                      <TableHead>المبلغ</TableHead>
                      <TableHead>نسبة الدقة</TableHead>
                      <TableHead>الحالة</TableHead>
                      <TableHead className="text-left">إجراءات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="font-medium">INV-20230518-001</TableCell>
                      <TableCell>شركة الإنشاءات المتكاملة</TableCell>
                      <TableCell>2023/05/20</TableCell>
                      <TableCell>{formatCurrency(97750)}</TableCell>
                      <TableCell>92%</TableCell>
                      <TableCell><Badge className="bg-green-500">مكتمل</Badge></TableCell>
                      <TableCell>
                        <div className="flex space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">INV-20230412-023</TableCell>
                      <TableCell>مؤسسة التقنية للكهرباء</TableCell>
                      <TableCell>2023/04/15</TableCell>
                      <TableCell>{formatCurrency(43500)}</TableCell>
                      <TableCell>88%</TableCell>
                      <TableCell><Badge className="bg-green-500">مكتمل</Badge></TableCell>
                      <TableCell>
                        <div className="flex space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">INV-20230325-105</TableCell>
                      <TableCell>شركة الخليج للتوريدات</TableCell>
                      <TableCell>2023/03/27</TableCell>
                      <TableCell>{formatCurrency(128600)}</TableCell>
                      <TableCell>95%</TableCell>
                      <TableCell><Badge className="bg-green-500">مكتمل</Badge></TableCell>
                      <TableCell>
                        <div className="flex space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default OcrProcessing;