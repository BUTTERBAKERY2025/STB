import { createRoot } from "react-dom/client";
import App from "./App";
import { RtlProvider } from "./components/ui/rtl-provider";
import { ThemeProvider } from "./components/ui/theme-provider";
import { HelmetProvider } from "react-helmet-async";
import { Router } from "wouter";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <HelmetProvider>
    <RtlProvider>
      <ThemeProvider defaultTheme="light" storageKey="stb-theme">
        {/* إضافة المسار الأساسي إلى wouter */}
        <Router base="">
          <App />
        </Router>
      </ThemeProvider>
    </RtlProvider>
  </HelmetProvider>
);
