import { ReactNode, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect } from "wouter";
import MainLayout from "@/layouts/MainLayout";

/**
 * مكون حماية المسارات - يستخدم للتحقق من صلاحية المستخدم 
 * ووضع المكونات في التخطيط الرئيسي
 * 
 * يستخدم Redirect بدلاً من navigate للتوجيه الفوري
 */
export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();

  // إظهار شاشة التحميل أثناء التحقق
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجلاً
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // عرض المحتوى داخل التخطيط الرئيسي في حالة وجود مستخدم مسجل
  return <MainLayout>{children}</MainLayout>;
}