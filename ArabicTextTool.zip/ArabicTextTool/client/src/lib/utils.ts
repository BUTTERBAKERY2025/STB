import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(number: number): string {
  return new Intl.NumberFormat('en-US').format(number);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', { 
    style: 'currency', 
    currency: 'SAR',
    maximumFractionDigits: 0 
  }).format(amount);
}

export function formatDate(date: string | Date): string {
  try {
    // إذا كان التاريخ من نوع سلسلة نصية، نقوم بتحويله إلى كائن Date
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // التحقق من صحة التاريخ
    if (isNaN(dateObj.getTime())) {
      return 'تاريخ غير صالح';
    }
    
    return new Intl.DateTimeFormat('ar-SA', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(dateObj);
  } catch (error) {
    console.error('Error formatting date:', error);
    return 'تاريخ غير صالح';
  }
}

export function formatTime(date: Date | string): string {
  try {
    // إذا كان التاريخ من نوع سلسلة نصية، نقوم بتحويله إلى كائن Date
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // التحقق من صحة التاريخ
    if (isNaN(dateObj.getTime())) {
      return 'وقت غير صالح';
    }
    
    return new Intl.DateTimeFormat('ar-SA', {
      hour: 'numeric',
      minute: 'numeric',
      hour12: true
    }).format(dateObj);
  } catch (error) {
    console.error('Error formatting time:', error);
    return 'وقت غير صالح';
  }
}

export function formatDateTime(date: Date | string): string {
  try {
    // إذا كان التاريخ من نوع سلسلة نصية، نقوم بتحويله إلى كائن Date
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    // التحقق من صحة التاريخ
    if (isNaN(dateObj.getTime())) {
      return 'تاريخ ووقت غير صالح';
    }
    
    return `${formatDate(dateObj)}، ${formatTime(dateObj)}`;
  } catch (error) {
    console.error('Error formatting datetime:', error);
    return 'تاريخ ووقت غير صالح';
  }
}

export function getDaysUntil(date: Date | string): number {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // إذا كان التاريخ من نوع سلسلة نصية، نقوم بتحويله إلى كائن Date
    const targetDate = typeof date === 'string' ? new Date(date) : new Date(date);
    
    // التحقق من صحة التاريخ
    if (isNaN(targetDate.getTime())) {
      return 0;
    }
    
    targetDate.setHours(0, 0, 0, 0);
    
    const diffTime = targetDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  } catch (error) {
    console.error('Error calculating days until:', error);
    return 0;
  }
}

export function calculateDaysLeft(endDate: string | Date): number {
  const end = new Date(endDate);
  const now = new Date();
  const diffTime = end.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays : 0;
}

export function getRelativeDays(days: number): string {
  if (days === 0) return "اليوم";
  if (days === 1) return "غداً";
  if (days < 7) return `بعد ${days} أيام`;
  if (days < 14) return "بعد أسبوع";
  if (days < 30) return "بعد أسبوعين";
  return `بعد ${Math.floor(days / 30)} أشهر`;
}

// دالة لحساب عدد الأيام المتبقية حتى تاريخ معين (يمكن أن تكون قيمة سالبة إذا كان التاريخ في الماضي)
export function getRemainingDays(date: Date | string): number {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // إذا كان التاريخ من نوع سلسلة نصية، نقوم بتحويله إلى كائن Date
    const targetDate = typeof date === 'string' ? new Date(date) : new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    // التحقق من صحة التاريخ
    if (isNaN(targetDate.getTime())) {
      return 0;
    }
    
    const diffTime = targetDate.getTime() - today.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  } catch (error) {
    console.error('Error calculating remaining days:', error);
    return 0;
  }
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "inProgress":
      return "text-primary";
    case "completed":
      return "text-success";
    case "delayed":
      return "text-warning";
    case "cancelled":
      return "text-error";
    case "planned":
      return "text-purple-500";
    default:
      return "text-gray-500";
  }
}

export function getStatusBadgeColor(status: string): string {
  switch (status) {
    case "inProgress":
      return "bg-primary";
    case "completed":
      return "bg-success";
    case "delayed":
      return "bg-warning";
    case "cancelled":
      return "bg-error";
    case "planned":
      return "bg-purple-500";
    default:
      return "bg-gray-500";
  }
}

export function getStatusText(status: string): string {
  switch (status) {
    case "inProgress":
      return "قيد التنفيذ";
    case "completed":
      return "مكتمل";
    case "delayed":
      return "متأخر";
    case "cancelled":
      return "ملغي";
    case "planned":
      return "مخطط";
    case "pending":
      return "قيد الانتظار";
    case "approved":
      return "تمت الموافقة";
    case "paid":
      return "مدفوع";
    case "rejected":
      return "مرفوض";
    default:
      return "غير معروف";
  }
}

export function getCategoryIcon(category: string): string {
  switch (category) {
    case "electricity":
      return "⚡";
    case "water":
      return "💧";
    case "communications":
      return "📡";
    case "construction":
      return "🏗️";
    case "maintenance":
      return "🔧";
    default:
      return "🏗️";
  }
}

export function getCategoryText(category: string): string {
  switch (category) {
    case "electricity":
      return "كهرباء";
    case "water":
      return "مياه";
    case "communications":
      return "اتصالات";
    case "construction":
      return "إنشاءات";
    case "maintenance":
      return "صيانة";
    default:
      return category;
  }
}

// دالة لتحويل النص إلى نص آمن للاستخدام في URLs
export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')     // استبدال المسافات بـ "-"
    .replace(/&/g, '-and-')   // استبدال & بـ "and"
    .replace(/[^\w\u0621-\u064A\u0660-\u0669-]+/g, '') // إزالة جميع الأحرف غير المسموح بها
    .replace(/--+/g, '-');    // استبدال متعدد من "-" بواحد فقط
}

// دالة لحساب نسبة التقدم بين تاريخين
export function calculateProgressPercentage(startDate: Date, endDate: Date, currentDate: Date = new Date()): number {
  const start = startDate.getTime();
  const end = endDate.getTime();
  const current = currentDate.getTime();
  
  // إذا لم يبدأ المشروع بعد
  if (current < start) return 0;
  // إذا انتهى المشروع
  if (current > end) return 100;
  
  // الوقت المنقضي
  const elapsed = current - start;
  // إجمالي وقت المشروع
  const total = end - start;
  // نسبة التقدم
  const progress = Math.floor((elapsed / total) * 100);
  
  return progress;
}
