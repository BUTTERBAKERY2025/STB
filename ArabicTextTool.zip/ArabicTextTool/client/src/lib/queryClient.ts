import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const [endpoint, ...restParams] = queryKey;
    
    // إنشاء عنوان URL مع معلمات الاستعلام إذا كانت موجودة
    let url = endpoint as string;
    if (restParams.length > 0) {
      // تصفية معلمات undefined أو null
      const queryParams = restParams.filter(param => param !== undefined && param !== null);
      
      // إضافة معلمات الاستعلام إلى عنوان URL
      if (queryParams.length > 0 && typeof queryParams[0] === 'string') {
        // إذا كانت المعلمة الأولى هي معرف المشروع أو تصفية
        if (queryParams[0] !== 'all') {
          url += `?${new URLSearchParams({ 
            ...(queryParams[0] ? { filter: queryParams[0] } : {})
          })}`;
        }
      }
      
      // إضافة معلمة الإطار الزمني إذا وجدت (المعلمة الثانية عادة)
      if (queryParams.length > 1 && typeof queryParams[1] === 'string') {
        const separator = url.includes('?') ? '&' : '?';
        url += `${separator}timeframe=${queryParams[1]}`;
      }
      
      // إضافة أي معلمات أخرى...
      if (queryParams.length > 2 && typeof queryParams[2] === 'string') {
        const separator = url.includes('?') ? '&' : '?';
        url += `${separator}statusFilter=${queryParams[2]}`;
      }
    }
    
    const res = await fetch(url, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
