import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import type { 
  User, InsertUser, 
  Project, InsertProject, 
  ChartOfAccount, InsertChartOfAccount,
  JournalEntry, InsertJournalEntry,
  JournalEntryItem, InsertJournalEntryItem,
  AccountBalance,
  GeoLocation, InsertGeoLocation
} from '@shared/schema';

// Users
export const useUsers = () => {
  return useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/users');
        return await res.json();
      } catch (error) {
        console.log('Error fetching users:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Projects
export const useProjects = () => {
  return useQuery({
    queryKey: ['/api/projects'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/projects');
        return await res.json();
      } catch (error) {
        console.log('Error fetching projects:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProject = (id: number) => {
  return useQuery({
    queryKey: ['/api/projects', id],
    enabled: id !== undefined && id !== null && id > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${id}`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching project:', error);
        return null;
      }
    },
    throwOnError: true,
  });
};

export const useCreateProject = () => {
  return useMutation({
    mutationFn: async (project: InsertProject) => {
      const res = await apiRequest('POST', '/api/projects', project);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    },
  });
};

export const useUpdateProject = () => {
  return useMutation({
    mutationFn: async ({ id, project }: { id: number, project: Partial<InsertProject> }) => {
      const res = await apiRequest('PATCH', `/api/projects/${id}`, project);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects', data.id] });
    },
  });
};

export const useDeleteProject = () => {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/projects/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    },
  });
};

// Chart of Accounts
export const useAccounts = () => {
  return useQuery({
    queryKey: ['/api/accounts'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/accounts');
        return await res.json();
      } catch (error) {
        console.log('Error fetching accounts:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useAccount = (id: number) => {
  return useQuery({
    queryKey: ['/api/accounts', id],
    enabled: id !== undefined && id !== null && id > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/accounts/${id}`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching account:', error);
        return null;
      }
    },
    throwOnError: true,
  });
};

export const useCreateAccount = () => {
  return useMutation({
    mutationFn: async (account: InsertChartOfAccount) => {
      const res = await apiRequest('POST', '/api/accounts', account);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
    },
  });
};

export const useUpdateAccount = () => {
  return useMutation({
    mutationFn: async ({ id, account }: { id: number, account: Partial<InsertChartOfAccount> }) => {
      const res = await apiRequest('PATCH', `/api/accounts/${id}`, account);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/accounts', data.id] });
    },
  });
};

export const useDeleteAccount = () => {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/accounts/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/accounts'] });
    },
  });
};

// Geo Locations
export const useGeoLocations = (activeProjectId?: number) => {
  return useQuery({
    queryKey: ['/api/geo-locations', { projectId: activeProjectId }],
    queryFn: async () => {
      try {
        let url = '/api/geo-locations';
        if (activeProjectId) {
          url += `?projectId=${activeProjectId}`;
        }
        const res = await apiRequest('GET', url);
        return await res.json();
      } catch (error) {
        console.log('Error fetching geo locations:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectGeoLocations = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'geo-locations'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/geo-locations`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching project geo locations:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useCreateGeoLocation = () => {
  return useMutation({
    mutationFn: async (location: InsertGeoLocation) => {
      const res = await apiRequest('POST', '/api/geo-locations', location);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/geo-locations'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'geo-locations'] });
      }
    },
  });
};

export const useUpdateGeoLocation = () => {
  return useMutation({
    mutationFn: async ({ id, location }: { id: number, location: Partial<InsertGeoLocation> }) => {
      const res = await apiRequest('PATCH', `/api/geo-locations/${id}`, location);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/geo-locations'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'geo-locations'] });
      }
    },
  });
};

export const useDeleteGeoLocation = () => {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/geo-locations/${id}`);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/geo-locations'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'geo-locations'] });
      }
    },
  });
};

// Journal Entries
export const useJournalEntries = () => {
  return useQuery({
    queryKey: ['/api/journal-entries'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/journal-entries');
        return await res.json();
      } catch (error) {
        console.log('Error fetching journal entries:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useCreateJournalEntry = () => {
  return useMutation({
    mutationFn: async (entry: InsertJournalEntry) => {
      const res = await apiRequest('POST', '/api/journal-entries', entry);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/journal-entries'] });
      queryClient.invalidateQueries({ queryKey: ['/api/account-balances'] });
    },
  });
};

export const useCreateJournalEntryItem = () => {
  return useMutation({
    mutationFn: async ({ entryId, item }: { entryId: number, item: InsertJournalEntryItem }) => {
      const res = await apiRequest('POST', `/api/journal-entries/${entryId}/items`, item);
      return await res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/journal-entries'] });
      queryClient.invalidateQueries({ queryKey: ['/api/journal-entries', variables.entryId] });
      queryClient.invalidateQueries({ queryKey: ['/api/account-balances'] });
    },
  });
};

// Account Balances and Statements
export const useAccountBalances = (params: { projectId?: number, fiscalYear?: number, fiscalMonth?: number } = {}) => {
  return useQuery({
    queryKey: ['/api/account-balances', params],
    queryFn: async () => {
      try {
        let url = '/api/account-balances';
        const queryParams = new URLSearchParams();
        if (params.projectId) queryParams.set('projectId', params.projectId.toString());
        if (params.fiscalYear) queryParams.set('fiscalYear', params.fiscalYear.toString());
        if (params.fiscalMonth) queryParams.set('fiscalMonth', params.fiscalMonth.toString());
        
        if (queryParams.toString()) {
          url += `?${queryParams.toString()}`;
        }
        
        const res = await apiRequest('GET', url);
        return await res.json();
      } catch (error) {
        console.log('Error fetching account balances:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useAccountStatement = (accountId: number, params: { projectId?: number, fromDate?: Date, toDate?: Date } = {}) => {
  return useQuery({
    queryKey: ['/api/account-statement', accountId, params],
    enabled: accountId !== undefined && accountId !== null && accountId > 0,
    queryFn: async () => {
      try {
        let url = `/api/account-statement/${accountId}`;
        const queryParams = new URLSearchParams();
        if (params.projectId) queryParams.set('projectId', params.projectId.toString());
        if (params.fromDate) queryParams.set('fromDate', params.fromDate.toISOString());
        if (params.toDate) queryParams.set('toDate', params.toDate.toISOString());
        
        if (queryParams.toString()) {
          url += `?${queryParams.toString()}`;
        }
        
        const res = await apiRequest('GET', url);
        return await res.json();
      } catch (error) {
        console.log('Error fetching account statement:', error);
        return { account: null, transactions: [] };
      }
    },
    throwOnError: true,
  });
};

// Analytics Queries
export const useProjectPerformance = () => {
  return useQuery({
    queryKey: ['/api/project-performance'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-performance');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project performance:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectTimeline = () => {
  return useQuery({
    queryKey: ['/api/project-timeline'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-timeline');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project timeline:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectCosts = () => {
  return useQuery({
    queryKey: ['/api/project-costs'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-costs');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project costs:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useResourceUsage = () => {
  return useQuery({
    queryKey: ['/api/resource-usage'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/resource-usage');
        return await res.json();
      } catch (error) {
        console.log('Error fetching resource usage:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useResourceTimeUsage = () => {
  return useQuery({
    queryKey: ['/api/resource-time-usage'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/resource-time-usage');
        return await res.json();
      } catch (error) {
        console.log('Error fetching resource time usage:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useResourceProjectUsage = () => {
  return useQuery({
    queryKey: ['/api/resource-project-usage'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/resource-project-usage');
        return await res.json();
      } catch (error) {
        console.log('Error fetching resource project usage:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useResourceEfficiency = () => {
  return useQuery({
    queryKey: ['/api/resource-efficiency'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/resource-efficiency');
        return await res.json();
      } catch (error) {
        console.log('Error fetching resource efficiency:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectsStatus = () => {
  return useQuery({
    queryKey: ['/api/projects-status'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/projects-status');
        return await res.json();
      } catch (error) {
        console.log('Error fetching projects status:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectStatistics = () => {
  return useQuery({
    queryKey: ['/api/project-statistics'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-statistics');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project statistics:', error);
        return {};
      }
    },
    throwOnError: true,
  });
};

export const useProjectRisks = () => {
  return useQuery({
    queryKey: ['/api/project-risks'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/project-risks');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project risks:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useTaskProgress = () => {
  return useQuery({
    queryKey: ['/api/task-progress'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/task-progress');
        return await res.json();
      } catch (error) {
        console.log('Error fetching task progress:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Financial Analytics
export const useBudgetTimeline = () => {
  return useQuery({
    queryKey: ['/api/budget-timeline'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/budget-timeline');
        return await res.json();
      } catch (error) {
        console.log('Error fetching budget timeline:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useRevenueExpenses = () => {
  return useQuery({
    queryKey: ['/api/financial/revenue-expenses'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/financial/revenue-expenses');
        return await res.json();
      } catch (error) {
        console.log('Error fetching revenue and expenses:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useExpenseCategories = () => {
  return useQuery({
    queryKey: ['/api/financial/expense-categories'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/financial/expense-categories');
        return await res.json();
      } catch (error) {
        console.log('Error fetching expense categories:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useProjectFinancials = () => {
  return useQuery({
    queryKey: ['/api/financial/project-financials'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/financial/project-financials');
        return await res.json();
      } catch (error) {
        console.log('Error fetching project financials:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useCashFlow = () => {
  return useQuery({
    queryKey: ['/api/financial/cash-flow'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/financial/cash-flow');
        return await res.json();
      } catch (error) {
        console.log('Error fetching cash flow:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Activities & Deadlines
export const useRecentActivities = (limit = 5) => {
  return useQuery({
    queryKey: ['/api/activities', { limit }],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/activities?limit=${limit}`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching recent activities:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useActivitiesByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'activities'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/activities`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching project activities:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useUpcomingDeadlines = () => {
  return useQuery({
    queryKey: ['/api/deadlines'],
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', '/api/deadlines');
        return await res.json();
      } catch (error) {
        console.log('Error fetching upcoming deadlines:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useDeadlinesByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'deadlines'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/deadlines`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching project deadlines:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Daily Reports
export const useDailyReportsByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'daily-reports'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/daily-reports`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching daily reports:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useCreateDailyReport = () => {
  return useMutation({
    mutationFn: async (reportData: any) => {
      const res = await apiRequest('POST', '/api/daily-reports', reportData);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'daily-reports'] });
    },
  });
};

export const useCreateActivity = () => {
  return useMutation({
    mutationFn: async (activityData: any) => {
      const res = await apiRequest('POST', '/api/activities', activityData);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'activities'] });
      }
    },
  });
};

// Team Management
export const useTeamByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'team'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/team`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching team:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

export const useCreateTeamAssignment = () => {
  return useMutation({
    mutationFn: async (assignment: any) => {
      const res = await apiRequest('POST', '/api/team-assignments', assignment);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/team-assignments'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'team'] });
      }
    },
  });
};

export const useDeleteTeamAssignment = () => {
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/team-assignments/${id}`);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/team-assignments'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'team'] });
      }
    },
  });
};

// Invoices
export const useCreateInvoice = () => {
  return useMutation({
    mutationFn: async (invoice: any) => {
      const res = await apiRequest('POST', '/api/invoices', invoice);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'invoices'] });
      }
    },
  });
};

export const useUpdateInvoice = () => {
  return useMutation({
    mutationFn: async ({ id, invoice }: { id: number, invoice: any }) => {
      const res = await apiRequest('PATCH', `/api/invoices/${id}`, invoice);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/invoices'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'invoices'] });
      }
    },
  });
};

export const useInvoicesByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'invoices'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/invoices`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching invoices:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Expenses
export const useCreateExpense = () => {
  return useMutation({
    mutationFn: async (expense: any) => {
      const res = await apiRequest('POST', '/api/expenses', expense);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'expenses'] });
      }
    },
  });
};

export const useUpdateExpense = () => {
  return useMutation({
    mutationFn: async ({ id, expense }: { id: number, expense: any }) => {
      const res = await apiRequest('PATCH', `/api/expenses/${id}`, expense);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      if (data.projectId) {
        queryClient.invalidateQueries({ queryKey: ['/api/projects', data.projectId, 'expenses'] });
      }
    },
  });
};

export const useExpensesByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'expenses'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/expenses`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching expenses:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Equipment
export const useEquipmentByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'equipment'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/equipment`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching equipment:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};

// Documents
export const useDocumentsByProject = (projectId: number) => {
  return useQuery({
    queryKey: ['/api/projects', projectId, 'documents'],
    enabled: projectId !== undefined && projectId !== null && projectId > 0,
    queryFn: async () => {
      try {
        const res = await apiRequest('GET', `/api/projects/${projectId}/documents`);
        return await res.json();
      } catch (error) {
        console.log('Error fetching documents:', error);
        return [];
      }
    },
    throwOnError: true,
  });
};