import { sql } from "drizzle-orm";
import { text, integer, pgTable, serial, real, boolean, date, timestamp, pgEnum, unique } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// =====================================
// المستخدمين (موجود بالفعل في المشروع)
// =====================================
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// =====================================
// الحسابات - هيكل شجرة الحسابات
// =====================================
export const accountTypeEnum = pgEnum("account_type", [
  "asset",        // أصول
  "liability",    // خصوم
  "equity",       // حقوق ملكية
  "revenue",      // إيرادات
  "expense",      // مصروفات
]);

export const accountClassEnum = pgEnum("account_class", [
  "current_asset",        // أصول متداولة
  "fixed_asset",          // أصول ثابتة
  "current_liability",    // خصوم متداولة
  "long_term_liability",  // خصوم طويلة الأجل
  "equity",               // حقوق ملكية
  "revenue",              // إيرادات
  "direct_expense",       // مصروفات مباشرة
  "indirect_expense",     // مصروفات غير مباشرة
  "other_income",         // إيرادات أخرى
  "other_expense",        // مصروفات أخرى
]);

// جدول الحسابات (شجرة الحسابات)
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  type: accountTypeEnum("type").notNull(),
  class: accountClassEnum("class").notNull(),
  parentId: integer("parent_id").references(() => chartOfAccounts.id),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;

// =====================================
// المعاملات المالية
// =====================================
export const transactionTypeEnum = pgEnum("transaction_type", [
  "income",     // إيراد
  "expense",    // مصروف
  "transfer",   // تحويل
  "adjustment", // تسوية
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending",    // معلق
  "completed",  // مكتمل
  "cancelled",  // ملغي
  "reconciled", // مسوى
]);

export const financialTransactions = pgTable("financial_transactions", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  type: transactionTypeEnum("type").notNull(),
  category: text("category"),
  status: transactionStatusEnum("status").default("pending"),
  projectId: integer("project_id").references(() => projects.id),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  createdBy: integer("created_by").references(() => users.id),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancialTransactionSchema = createInsertSchema(financialTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;
export type FinancialTransaction = typeof financialTransactions.$inferSelect;

// =====================================
// دفتر الأستاذ (القيود المحاسبية)
// =====================================
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  projectId: integer("project_id").references(() => projects.id),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  createdBy: integer("created_by").references(() => users.id),
  status: text("status").default("posted"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;

// =====================================
// تفاصيل القيود المحاسبية (دفتر الأستاذ)
// =====================================
export const journalEntryItems = pgTable("journal_entry_items", {
  id: serial("id").primaryKey(),
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  description: text("description"),
  debit: real("debit").default(0),
  credit: real("credit").default(0),
  projectId: integer("project_id").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntryItemSchema = createInsertSchema(journalEntryItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntryItem = z.infer<typeof insertJournalEntryItemSchema>;
export type JournalEntryItem = typeof journalEntryItems.$inferSelect;

// =====================================
// أرصدة الحسابات
// =====================================
export const accountBalances = pgTable("account_balances", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  projectId: integer("project_id").references(() => projects.id),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  openingBalance: real("opening_balance").default(0),
  debitTotal: real("debit_total").default(0),
  creditTotal: real("credit_total").default(0),
  closingBalance: real("closing_balance").default(0),
  lastTransactionDate: date("last_transaction_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    // Ensure each account has one balance per project per month
    uniqueAccountBalance: unique().on(table.accountId, table.projectId, table.fiscalYear, table.fiscalMonth),
  };
});

export const insertAccountBalanceSchema = createInsertSchema(accountBalances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAccountBalance = z.infer<typeof insertAccountBalanceSchema>;
export type AccountBalance = typeof accountBalances.$inferSelect;

// =====================================
// المراكز المالية للمشاريع
// =====================================
export const projectFinancialCenters = pgTable("project_financial_centers", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  totalAssets: real("total_assets").default(0),
  totalLiabilities: real("total_liabilities").default(0),
  totalEquity: real("total_equity").default(0),
  totalRevenue: real("total_revenue").default(0),
  totalExpenses: real("total_expenses").default(0),
  netIncome: real("net_income").default(0),
  cashBalance: real("cash_balance").default(0),
  accountsReceivable: real("accounts_receivable").default(0),
  accountsPayable: real("accounts_payable").default(0),
  date: date("date").notNull(),
  isAdjusted: boolean("is_adjusted").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProjectFinancialCenterSchema = createInsertSchema(projectFinancialCenters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectFinancialCenter = z.infer<typeof insertProjectFinancialCenterSchema>;
export type ProjectFinancialCenter = typeof projectFinancialCenters.$inferSelect;

// =====================================
// المراكز المالية للشركة (المجمعة)
// =====================================
export const companyFinancialStatements = pgTable("company_financial_statements", {
  id: serial("id").primaryKey(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  statementType: text("statement_type").notNull(), // balance-sheet, income-statement, cash-flow
  content: text("content").notNull(), // JSON format
  date: date("date").notNull(),
  isAudited: boolean("is_audited").default(false),
  auditedBy: integer("audited_by").references(() => users.id),
  auditDate: date("audit_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCompanyFinancialStatementSchema = createInsertSchema(companyFinancialStatements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCompanyFinancialStatement = z.infer<typeof insertCompanyFinancialStatementSchema>;
export type CompanyFinancialStatement = typeof companyFinancialStatements.$inferSelect;

// =====================================
// المشاريع
// =====================================
export const projectStatusEnum = pgEnum("project_status", [
  "active",
  "completed",
  "on_hold",
  "cancelled",
  "planning",
]);

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  clientName: text("client_name"),
  location: text("location"),
  status: projectStatusEnum("status").default("planning"),
  budget: real("budget"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  managerId: integer("manager_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  completionPercentage: real("completion_percentage").default(0),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;