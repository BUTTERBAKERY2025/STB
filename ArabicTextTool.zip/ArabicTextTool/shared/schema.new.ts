import { sql } from "drizzle-orm";
import { text, integer, pgTable, serial, real, boolean, date, timestamp, pgEnum, unique } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// =====================================
// المستخدمين
// =====================================
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true, updatedAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// =====================================
// المشاريع
// =====================================
export const projectStatusEnum = pgEnum("project_status", [
  "active",
  "completed",
  "on_hold",
  "cancelled",
  "planning",
]);

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  clientName: text("client_name"),
  location: text("location"),
  status: projectStatusEnum("status").default("planning"),
  budget: real("budget"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  managerId: integer("manager_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  completionPercentage: real("completion_percentage").default(0),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// =====================================
// الحسابات - هيكل شجرة الحسابات
// =====================================
export const accountTypeEnum = pgEnum("account_type", [
  "asset",        // أصول
  "liability",    // خصوم
  "equity",       // حقوق ملكية
  "revenue",      // إيرادات
  "expense",      // مصروفات
]);

export const accountClassEnum = pgEnum("account_class", [
  "current_asset",        // أصول متداولة
  "fixed_asset",          // أصول ثابتة
  "current_liability",    // خصوم متداولة
  "long_term_liability",  // خصوم طويلة الأجل
  "equity",               // حقوق ملكية
  "revenue",              // إيرادات
  "direct_expense",       // مصروفات مباشرة
  "indirect_expense",     // مصروفات غير مباشرة
  "other_income",         // إيرادات أخرى
  "other_expense",        // مصروفات أخرى
]);

// جدول الحسابات (شجرة الحسابات)
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  type: accountTypeEnum("type").notNull(),
  class: accountClassEnum("class").notNull(),
  parentId: integer("parent_id").references(() => chartOfAccounts.id),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;

// =====================================
// المعاملات المالية
// =====================================
export const transactionTypeEnum = pgEnum("transaction_type", [
  "income",     // إيراد
  "expense",    // مصروف
  "transfer",   // تحويل
  "adjustment", // تسوية
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending",    // معلق
  "completed",  // مكتمل
  "cancelled",  // ملغي
  "reconciled", // مسوى
]);

export const financialTransactions = pgTable("financial_transactions", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  type: transactionTypeEnum("type").notNull(),
  category: text("category"),
  status: transactionStatusEnum("status").default("pending"),
  projectId: integer("project_id").references(() => projects.id),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  createdBy: integer("created_by").references(() => users.id),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancialTransactionSchema = createInsertSchema(financialTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;
export type FinancialTransaction = typeof financialTransactions.$inferSelect;

// =====================================
// دفتر الأستاذ (القيود المحاسبية)
// =====================================
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  projectId: integer("project_id").references(() => projects.id),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  createdBy: integer("created_by").references(() => users.id),
  status: text("status").default("posted"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;

// =====================================
// تفاصيل القيود المحاسبية (دفتر الأستاذ)
// =====================================
export const journalEntryItems = pgTable("journal_entry_items", {
  id: serial("id").primaryKey(),
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  description: text("description"),
  debit: real("debit").default(0),
  credit: real("credit").default(0),
  projectId: integer("project_id").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntryItemSchema = createInsertSchema(journalEntryItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntryItem = z.infer<typeof insertJournalEntryItemSchema>;
export type JournalEntryItem = typeof journalEntryItems.$inferSelect;

// =====================================
// الميزانيات
// =====================================
export const budgetStatusEnum = pgEnum("budget_status", [
  "proposed", // مقترح
  "approved", // معتمد
  "expired",  // منتهي
  "rejected", // مرفوض
]);

export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  category: text("category").notNull(),
  subcategory: text("subcategory"),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  plannedAmount: real("planned_amount").notNull(),
  status: budgetStatusEnum("status").default("proposed"),
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBudgetSchema = createInsertSchema(budgets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBudget = z.infer<typeof insertBudgetSchema>;
export type Budget = typeof budgets.$inferSelect;

// =====================================
// التدفقات النقدية
// =====================================
export const cashFlowStatusEnum = pgEnum("cashflow_status", [
  "planned",   // مخطط
  "actual",    // فعلي
  "projected", // متوقع
]);

export const cashFlowItems = pgTable("cash_flow_items", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  date: date("date").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  isInflow: boolean("is_inflow").notNull(),
  status: cashFlowStatusEnum("status").default("planned"),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  notes: text("notes"),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCashFlowItemSchema = createInsertSchema(cashFlowItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCashFlowItem = z.infer<typeof insertCashFlowItemSchema>;
export type CashFlowItem = typeof cashFlowItems.$inferSelect;

// =====================================
// التقارير المالية
// =====================================
export const financialReportStatusEnum = pgEnum("financial_report_status", [
  "draft",    // مسودة
  "final",    // نهائي
  "approved", // معتمد
  "audited",  // مدقق
]);

export const financialReports = pgTable("financial_reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  reportType: text("report_type").notNull(), // balance-sheet, income-statement, cash-flow
  projectId: integer("project_id").references(() => projects.id),
  fromDate: date("from_date").notNull(),
  toDate: date("to_date").notNull(),
  status: financialReportStatusEnum("status").default("draft"),
  content: text("content").notNull(), // JSON
  generatedBy: integer("generated_by").references(() => users.id),
  approvedBy: integer("approved_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancialReportSchema = createInsertSchema(financialReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancialReport = z.infer<typeof insertFinancialReportSchema>;
export type FinancialReport = typeof financialReports.$inferSelect;

// =====================================
// الفواتير
// =====================================
export const invoiceStatusEnum = pgEnum("invoice_status", [
  "draft",     // مسودة
  "issued",    // صادرة
  "paid",      // مدفوعة
  "partial",   // مدفوعة جزئياً
  "overdue",   // متأخرة
  "cancelled", // ملغاة
]);

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  clientId: integer("client_id").references(() => users.id),
  issueDate: date("issue_date").notNull(),
  dueDate: date("due_date").notNull(),
  totalAmount: real("total_amount").notNull(),
  paidAmount: real("paid_amount").default(0),
  status: invoiceStatusEnum("status").default("draft"),
  paymentTerms: text("payment_terms"),
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

// =====================================
// طلبات الدفع (المستخلصات)
// =====================================
export const paymentRequestStatusEnum = pgEnum("payment_request_status", [
  "draft",       // مسودة
  "submitted",   // مقدم
  "in_review",   // قيد المراجعة
  "approved",    // معتمد
  "partial",     // مدفوع جزئياً
  "paid",        // مدفوع بالكامل
  "rejected",    // مرفوض
]);

export const paymentRequests = pgTable("payment_requests", {
  id: serial("id").primaryKey(),
  requestNumber: text("request_number").notNull().unique(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  clientId: integer("client_id").references(() => users.id),
  issueDate: date("issue_date").notNull(),
  fromDate: date("from_date").notNull(),
  toDate: date("to_date").notNull(),
  totalAmount: real("total_amount").notNull(),
  previousAmount: real("previous_amount").default(0),
  currentAmount: real("current_amount").notNull(),
  taxAmount: real("tax_amount").default(0),
  retainedAmount: real("retained_amount").default(0),
  netAmount: real("net_amount").notNull(),
  status: paymentRequestStatusEnum("status").default("draft"),
  paymentDate: date("payment_date"),
  notes: text("notes"),
  approvedBy: integer("approved_by").references(() => users.id),
  approvalDate: date("approval_date"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPaymentRequestSchema = createInsertSchema(paymentRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentRequest = z.infer<typeof insertPaymentRequestSchema>;
export type PaymentRequest = typeof paymentRequests.$inferSelect;

// =====================================
// بنود طلبات الدفع (المستخلصات)
// =====================================
export const paymentRequestItems = pgTable("payment_request_items", {
  id: serial("id").primaryKey(),
  paymentRequestId: integer("payment_request_id").references(() => paymentRequests.id).notNull(),
  description: text("description").notNull(),
  unit: text("unit"),
  quantity: real("quantity").notNull(),
  unitPrice: real("unit_price").notNull(),
  totalPrice: real("total_price").notNull(),
  previousQuantity: real("previous_quantity").default(0),
  currentQuantity: real("current_quantity").notNull(),
  completionPercentage: real("completion_percentage"),
  projectId: integer("project_id").references(() => projects.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    uniqueItemPerRequest: unique().on(table.paymentRequestId, table.description),
  };
});

export const insertPaymentRequestItemSchema = createInsertSchema(paymentRequestItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentRequestItem = z.infer<typeof insertPaymentRequestItemSchema>;
export type PaymentRequestItem = typeof paymentRequestItems.$inferSelect;

// =====================================
// المراكز المالية للمشاريع
// =====================================
export const projectFinancialCenters = pgTable("project_financial_centers", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  totalAssets: real("total_assets").default(0),
  totalLiabilities: real("total_liabilities").default(0),
  totalEquity: real("total_equity").default(0),
  totalRevenue: real("total_revenue").default(0),
  totalExpenses: real("total_expenses").default(0),
  netIncome: real("net_income").default(0),
  cashBalance: real("cash_balance").default(0),
  accountsReceivable: real("accounts_receivable").default(0),
  accountsPayable: real("accounts_payable").default(0),
  date: date("date").notNull(),
  isAdjusted: boolean("is_adjusted").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    uniquePerMonth: unique().on(table.projectId, table.fiscalYear, table.fiscalMonth),
  };
});

export const insertProjectFinancialCenterSchema = createInsertSchema(projectFinancialCenters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectFinancialCenter = z.infer<typeof insertProjectFinancialCenterSchema>;
export type ProjectFinancialCenter = typeof projectFinancialCenters.$inferSelect;

// =====================================
// القوائم المالية للشركة
// =====================================
export const companyFinancialStatements = pgTable("company_financial_statements", {
  id: serial("id").primaryKey(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  statementType: text("statement_type").notNull(), // balance-sheet, income-statement, cash-flow
  content: text("content").notNull(), // JSON format
  date: date("date").notNull(),
  isAudited: boolean("is_audited").default(false),
  auditedBy: integer("audited_by").references(() => users.id),
  auditDate: date("audit_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    uniqueStatement: unique().on(table.fiscalYear, table.fiscalMonth, table.statementType),
  };
});

export const insertCompanyFinancialStatementSchema = createInsertSchema(companyFinancialStatements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCompanyFinancialStatement = z.infer<typeof insertCompanyFinancialStatementSchema>;
export type CompanyFinancialStatement = typeof companyFinancialStatements.$inferSelect;

// =====================================
// أرصدة الحسابات
// =====================================
export const accountBalances = pgTable("account_balances", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  projectId: integer("project_id").references(() => projects.id),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  openingBalance: real("opening_balance").default(0),
  debitTotal: real("debit_total").default(0),
  creditTotal: real("credit_total").default(0),
  closingBalance: real("closing_balance").default(0),
  lastTransactionDate: date("last_transaction_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    // Ensure each account has one balance per project per month
    uniqueAccountBalance: unique().on(table.accountId, table.projectId, table.fiscalYear, table.fiscalMonth),
  };
});

export const insertAccountBalanceSchema = createInsertSchema(accountBalances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAccountBalance = z.infer<typeof insertAccountBalanceSchema>;
export type AccountBalance = typeof accountBalances.$inferSelect;

export const accountStatementsView = sql`
  SELECT 
    ab.id, 
    ab.account_id AS "accountId",
    coa.code AS "accountCode", 
    coa.name AS "accountName",
    ab.project_id AS "projectId",
    p.name AS "projectName",
    ab.fiscal_year AS "fiscalYear",
    ab.fiscal_month AS "fiscalMonth",
    ab.opening_balance AS "openingBalance",
    ab.debit_total AS "debitTotal",
    ab.credit_total AS "creditTotal",
    ab.closing_balance AS "closingBalance",
    ab.last_transaction_date AS "lastTransactionDate"
  FROM 
    account_balances ab
  LEFT JOIN 
    chart_of_accounts coa ON ab.account_id = coa.id
  LEFT JOIN 
    projects p ON ab.project_id = p.id
`;

// =====================================
// العمال والمقاولين
// =====================================
export const workers = pgTable("workers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  idNumber: text("id_number").notNull().unique(),
  phone: text("phone"),
  address: text("address"),
  specialization: text("specialization"),
  dailyRate: real("daily_rate"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertWorkerSchema = createInsertSchema(workers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertWorker = z.infer<typeof insertWorkerSchema>;
export type Worker = typeof workers.$inferSelect;

// =====================================
// سجل حضور العمال
// =====================================
export const workerAttendance = pgTable("worker_attendance", {
  id: serial("id").primaryKey(),
  workerId: integer("worker_id").references(() => workers.id).notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  date: date("date").notNull(),
  status: text("status").default("present"), // present, absent, late, halfday
  hoursWorked: real("hours_worked").default(8),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    uniqueAttendance: unique().on(table.workerId, table.projectId, table.date),
  };
});

export const insertWorkerAttendanceSchema = createInsertSchema(workerAttendance).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertWorkerAttendance = z.infer<typeof insertWorkerAttendanceSchema>;
export type WorkerAttendance = typeof workerAttendance.$inferSelect;