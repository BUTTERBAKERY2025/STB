import { sql } from "drizzle-orm";
import { text, integer, pgTable, serial, real, boolean, date, timestamp, pgEnum, unique, primaryKey, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// =====================================
// المستخدمين
// =====================================
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  email: text("email"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true, updatedAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// =====================================
// المشاريع
// =====================================
export const projectStatusEnum = pgEnum("project_status", [
  "planned",
  "inProgress",
  "delayed",
  "completed",
  "cancelled",
]);

export const projectCategoryEnum = pgEnum("project_category", [
  "electricity",
  "water",
  "communications",
  "roads",
  "buildings",
]);

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  clientName: text("client_name"),
  contractNumber: text("contract_number"),
  location: text("location"),
  status: projectStatusEnum("status").default("planned"),
  category: projectCategoryEnum("category").default("buildings"),
  budget: real("budget").default(0),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  duration: integer("duration").default(1), // Duration in months
  progress: real("progress").default(0), // Progress percentage (0-100)
  imageUrl: text("image_url"),
  managerId: integer("manager_id").references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// =====================================
// الحسابات - هيكل شجرة الحسابات
// =====================================
export const accountTypeEnum = pgEnum("account_type", [
  "asset",        // أصول
  "liability",    // خصوم
  "equity",       // حقوق ملكية
  "revenue",      // إيرادات
  "expense",      // مصروفات
]);

export const accountClassEnum = pgEnum("account_class", [
  "current_asset",        // أصول متداولة
  "fixed_asset",          // أصول ثابتة
  "current_liability",    // خصوم متداولة
  "long_term_liability",  // خصوم طويلة الأجل
  "equity",               // حقوق ملكية
  "revenue",              // إيرادات
  "direct_expense",       // مصروفات مباشرة
  "indirect_expense",     // مصروفات غير مباشرة
  "other_income",         // إيرادات أخرى
  "other_expense",        // مصروفات أخرى
]);

// جدول الحسابات (شجرة الحسابات)
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  type: accountTypeEnum("type").notNull(),
  class: accountClassEnum("class").notNull(),
  parentId: integer("parent_id").references(() => chartOfAccounts.id),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;
export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;

// =====================================
// المعاملات المالية
// =====================================
export const transactionTypeEnum = pgEnum("transaction_type", [
  "income",     // إيراد
  "expense",    // مصروف
  "transfer",   // تحويل
  "adjustment", // تسوية
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending",    // معلق
  "completed",  // مكتمل
  "cancelled",  // ملغي
  "reconciled", // مسوى
]);

export const financialTransactions = pgTable("financial_transactions", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  type: transactionTypeEnum("type").notNull(),
  category: text("category"),
  status: transactionStatusEnum("status").default("pending"),
  projectId: integer("project_id").references(() => projects.id),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  createdBy: integer("created_by").references(() => users.id),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancialTransactionSchema = createInsertSchema(financialTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancialTransaction = z.infer<typeof insertFinancialTransactionSchema>;
export type FinancialTransaction = typeof financialTransactions.$inferSelect;

// =====================================
// دفتر الأستاذ (القيود المحاسبية)
// =====================================
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  reference: text("reference"),
  date: date("date").notNull(),
  description: text("description").notNull(),
  projectId: integer("project_id").references(() => projects.id),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  createdBy: integer("created_by").references(() => users.id),
  status: text("status").default("posted"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;

// =====================================
// تفاصيل القيود المحاسبية (دفتر الأستاذ)
// =====================================
export const journalEntryItems = pgTable("journal_entry_items", {
  id: serial("id").primaryKey(),
  journalEntryId: integer("journal_entry_id").references(() => journalEntries.id).notNull(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  description: text("description"),
  debit: real("debit").default(0),
  credit: real("credit").default(0),
  projectId: integer("project_id").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertJournalEntryItemSchema = createInsertSchema(journalEntryItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertJournalEntryItem = z.infer<typeof insertJournalEntryItemSchema>;
export type JournalEntryItem = typeof journalEntryItems.$inferSelect;

// =====================================
// الميزانيات
// =====================================
export const budgetStatusEnum = pgEnum("budget_status", [
  "proposed",  // مقترحة
  "approved",  // معتمدة
  "expired",   // منتهية
  "rejected",  // مرفوضة
]);

export const budgets = pgTable("budgets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  category: text("category").notNull(),
  subcategory: text("subcategory"),
  accountId: integer("account_id").references(() => chartOfAccounts.id),
  plannedAmount: real("planned_amount").notNull(),
  status: budgetStatusEnum("status").default("proposed"),
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBudgetSchema = createInsertSchema(budgets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBudget = z.infer<typeof insertBudgetSchema>;
export type Budget = typeof budgets.$inferSelect;

// =====================================
// التدفق النقدي
// =====================================
export const cashFlowStatusEnum = pgEnum("cashflow_status", [
  "expected",  // متوقع
  "realized",  // محقق
  "cancelled", // ملغي
]);

export const cashFlowItems = pgTable("cash_flow_items", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id),
  category: text("category").notNull(),
  description: text("description").notNull(),
  expectedDate: date("expected_date").notNull(),
  expectedAmount: real("expected_amount").notNull(),
  actualDate: date("actual_date"),
  actualAmount: real("actual_amount"),
  type: transactionTypeEnum("type").notNull(),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  status: cashFlowStatusEnum("status").default("expected"),
  probability: integer("probability").default(100),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCashFlowItemSchema = createInsertSchema(cashFlowItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCashFlowItem = z.infer<typeof insertCashFlowItemSchema>;
export type CashFlowItem = typeof cashFlowItems.$inferSelect;

// =====================================
// التقارير المالية
// =====================================
export const financialReportStatusEnum = pgEnum("financial_report_status", [
  "draft",     // مسودة
  "final",     // نهائي
  "approved",  // معتمد
  "archived",  // مؤرشف
]);

export const financialReports = pgTable("financial_reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(), // profit-loss, balance-sheet, cash-flow, etc.
  projectId: integer("project_id").references(() => projects.id),
  dateFrom: date("date_from").notNull(),
  dateTo: date("date_to").notNull(),
  parameters: text("parameters").default("{}"), // JSON format
  status: financialReportStatusEnum("status").default("draft"),
  fileUrl: text("file_url"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancialReportSchema = createInsertSchema(financialReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancialReport = z.infer<typeof insertFinancialReportSchema>;
export type FinancialReport = typeof financialReports.$inferSelect;

// =====================================
// الفواتير
// =====================================
export const invoiceStatusEnum = pgEnum("invoice_status", [
  "draft",     // مسودة
  "pending",   // قيد الانتظار
  "paid",      // مدفوعة
  "overdue",   // متأخرة
  "cancelled", // ملغاة
]);

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull(),
  projectId: integer("project_id").references(() => projects.id),
  clientName: text("client_name").notNull(),
  issueDate: date("issue_date").notNull(),
  dueDate: date("due_date").notNull(),
  amount: real("amount").notNull(),
  description: text("description").notNull(),
  status: invoiceStatusEnum("status").default("draft"),
  paymentDate: date("payment_date"),
  paymentMethod: text("payment_method"),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  attachmentUrl: text("attachment_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;

// =====================================
// مستخلصات الدفع
// =====================================
export const paymentRequestStatusEnum = pgEnum("payment_request_status", [
  "draft",     // مسودة
  "pending",   // قيد المراجعة
  "approved",  // معتمد
  "rejected",  // مرفوض
  "paid",      // مدفوع
]);

export const paymentRequests = pgTable("payment_requests", {
  id: serial("id").primaryKey(),
  requestNumber: text("request_number").notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull(), // initial, partial, final
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  totalCompletionPercentage: real("total_completion_percentage").notNull(),
  previousPaymentAmount: real("previous_payment_amount").default(0),
  currentPaymentAmount: real("current_payment_amount").notNull(),
  status: paymentRequestStatusEnum("status").default("draft"),
  approvedBy: integer("approved_by").references(() => users.id),
  approvalDate: date("approval_date"),
  paymentDate: date("payment_date"),
  invoiceId: integer("invoice_id").references(() => invoices.id),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPaymentRequestSchema = createInsertSchema(paymentRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentRequest = z.infer<typeof insertPaymentRequestSchema>;
export type PaymentRequest = typeof paymentRequests.$inferSelect;

// =====================================
// بنود مستخلصات الدفع
// =====================================
export const paymentRequestItems = pgTable("payment_request_items", {
  id: serial("id").primaryKey(),
  paymentRequestId: integer("payment_request_id").references(() => paymentRequests.id).notNull(),
  itemName: text("item_name").notNull(),
  description: text("description"),
  unit: text("unit"),
  quantity: real("quantity").notNull(),
  unitPrice: real("unit_price").notNull(),
  previousCompletionPercentage: real("previous_completion_percentage").default(0),
  currentCompletionPercentage: real("current_completion_percentage").notNull(),
  previousAmount: real("previous_amount").default(0),
  currentAmount: real("current_amount").notNull(),
  totalAmount: real("total_amount").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPaymentRequestItemSchema = createInsertSchema(paymentRequestItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPaymentRequestItem = z.infer<typeof insertPaymentRequestItemSchema>;
export type PaymentRequestItem = typeof paymentRequestItems.$inferSelect;

// =====================================
// المواقع الجغرافية (Geo-Locations)
// =====================================
export const geoLocations = pgTable("geo_locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  entityType: text("entity_type").notNull().default("site"), // site, equipment, worker
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertGeoLocationSchema = createInsertSchema(geoLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertGeoLocation = z.infer<typeof insertGeoLocationSchema>;
export type GeoLocation = typeof geoLocations.$inferSelect;

// =====================================
// المعدات (Equipment)
// =====================================
export const equipmentStatusEnum = pgEnum("equipment_status", [
  "available", // متاح
  "inUse",     // قيد الاستخدام
  "maintenance", // صيانة
  "outOfService", // خارج الخدمة
]);

export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  serialNumber: text("serial_number"),
  manufacturer: text("manufacturer"),
  model: text("model"),
  purchaseDate: date("purchase_date"),
  purchaseCost: real("purchase_cost"),
  status: equipmentStatusEnum("status").default("available"),
  notes: text("notes"),
  currentProjectId: integer("current_project_id").references(() => projects.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertEquipmentSchema = createInsertSchema(equipment).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;
export type Equipment = typeof equipment.$inferSelect;

// =====================================
// فريق العمل (Team Members)
// =====================================
export const teamMemberRoleEnum = pgEnum("team_member_role", [
  "projectManager", // مدير مشروع
  "siteEngineer",   // مهندس موقع
  "foreman",        // مشرف
  "worker",         // عامل
  "consultant",     // استشاري
  "qualityController", // مراقب جودة
  "safetyOfficer",  // مسؤول سلامة
  "other",          // أخرى
]);

export const teamMembers = pgTable("team_members", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  specialization: text("specialization"),
  position: text("position"),
  nationalId: text("national_id"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// =====================================
// تخصيص فريق العمل للمشاريع
// =====================================
export const teamAssignments = pgTable("team_assignments", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  teamMemberId: integer("team_member_id").references(() => teamMembers.id).notNull(),
  role: teamMemberRoleEnum("role").default("worker"),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
},
(table) => {
  return {
    projectTeamUnique: unique().on(table.projectId, table.teamMemberId),
  };
});

export const insertTeamAssignmentSchema = createInsertSchema(teamAssignments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTeamAssignment = z.infer<typeof insertTeamAssignmentSchema>;
export type TeamAssignment = typeof teamAssignments.$inferSelect;

// =====================================
// المستندات (Documents)
// =====================================
export const documentCategoryEnum = pgEnum("document_category", [
  "contract",      // عقد
  "blueprint",     // مخطط
  "permit",        // تصريح
  "specification", // مواصفات
  "invoice",       // فاتورة
  "report",        // تقرير
  "certificate",   // شهادة
  "other",         // أخرى
]);

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  category: documentCategoryEnum("category").default("other"),
  fileUrl: text("file_url"),
  filename: text("filename"),
  fileSize: integer("file_size"),
  fileType: text("file_type"),
  projectId: integer("project_id").references(() => projects.id),
  uploadedBy: integer("uploaded_by").references(() => users.id),
  isPublic: boolean("is_public").default(false),
  tags: text("tags"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// =====================================
// التقارير اليومية (Daily Reports)
// =====================================
export const weatherConditionEnum = pgEnum("weather_condition", [
  "sunny",     // مشمس
  "partlyCloudy", // غائم جزئيًا
  "cloudy",    // غائم
  "rainy",     // ممطر
  "stormy",    // عاصف
  "windy",     // رياح
  "hot",       // حار
  "cold",      // بارد
]);

export const dailyReports = pgTable("daily_reports", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  date: date("date").notNull(),
  reporterId: integer("reporter_id").references(() => users.id),
  weather: weatherConditionEnum("weather"),
  temperature: real("temperature"),
  workCompleted: text("work_completed").notNull(),
  materialsDelivered: text("materials_delivered"),
  equipmentUsed: text("equipment_used"),
  delaysEncountered: text("delays_encountered"),
  visitorsOnSite: text("visitors_on_site"),
  safetyIncidents: text("safety_incidents"),
  qualityIssues: text("quality_issues"),
  workHours: real("work_hours"),
  workerCount: integer("worker_count"),
  notes: text("notes"),
  imageUrls: text("image_urls").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;
export type DailyReport = typeof dailyReports.$inferSelect;

// =====================================
// مخاطر المشروع (Project Risks)
// =====================================
export const riskSeverityEnum = pgEnum("risk_severity", [
  "low",      // منخفض
  "medium",   // متوسط
  "high",     // عالي
  "critical", // حرج
]);

export const riskStatusEnum = pgEnum("risk_status", [
  "identified",  // محدد
  "assessed",    // مقيم
  "mitigated",   // مخفف
  "accepted",    // مقبول
  "resolved",    // محلول
  "closed",      // مغلق
]);

export const projectRisks = pgTable("project_risks", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  severity: riskSeverityEnum("severity").default("medium"),
  probability: real("probability").default(50),
  impact: real("impact").default(50),
  detectability: real("detectability").default(50),
  riskScore: real("risk_score"),
  status: riskStatusEnum("status").default("identified"),
  identifiedDate: date("identified_date").notNull(),
  identifiedBy: integer("identified_by").references(() => users.id),
  mitigationPlan: text("mitigation_plan"),
  contingencyPlan: text("contingency_plan"),
  owner: text("owner"),
  reviewDate: date("review_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProjectRiskSchema = createInsertSchema(projectRisks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectRisk = z.infer<typeof insertProjectRiskSchema>;
export type ProjectRisk = typeof projectRisks.$inferSelect;

// =====================================
// المواعيد النهائية (Deadlines)
// =====================================
export const deadlineStatusEnum = pgEnum("deadline_status", [
  "pending",   // قيد الانتظار
  "completed", // مكتمل
  "delayed",   // متأخر
  "cancelled", // ملغي
]);

export const deadlines = pgTable("deadlines", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date").notNull(),
  completionDate: date("completion_date"),
  status: deadlineStatusEnum("status").default("pending"),
  priority: integer("priority").default(1),
  assignedTo: integer("assigned_to").references(() => users.id),
  notifyBefore: integer("notify_before").default(7), // Days to notify before deadline
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDeadlineSchema = createInsertSchema(deadlines).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertDeadline = z.infer<typeof insertDeadlineSchema>;
export type Deadline = typeof deadlines.$inferSelect;

// =====================================
// المصروفات (Expenses)
// =====================================
export const expenseCategoryEnum = pgEnum("expense_category", [
  "material",     // مواد
  "labor",        // عمالة
  "equipment",    // معدات
  "subcontractor", // مقاول من الباطن
  "transportation", // نقل
  "utilities",    // مرافق
  "permits",      // تصاريح
  "insurance",    // تأمين
  "maintenance",  // صيانة
  "other",        // أخرى
]);

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  date: date("date").notNull(),
  amount: real("amount").notNull(),
  category: expenseCategoryEnum("category").default("other"),
  vendor: text("vendor"),
  referenceNumber: text("reference_number"),
  receiptUrl: text("receipt_url"),
  approvedBy: integer("approved_by").references(() => users.id),
  status: text("status").default("pending"),
  paymentMethod: text("payment_method"),
  transactionId: integer("transaction_id").references(() => financialTransactions.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

// =====================================
// المراكز المالية للمشاريع
// =====================================
export const projectFinancialCenters = pgTable("project_financial_centers", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  totalAssets: real("total_assets").default(0),
  totalLiabilities: real("total_liabilities").default(0),
  totalEquity: real("total_equity").default(0),
  totalRevenue: real("total_revenue").default(0),
  totalExpenses: real("total_expenses").default(0),
  netIncome: real("net_income").default(0),
  cashBalance: real("cash_balance").default(0),
  accountsReceivable: real("accounts_receivable").default(0),
  accountsPayable: real("accounts_payable").default(0),
  date: date("date").notNull(),
  isAdjusted: boolean("is_adjusted").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProjectFinancialCenterSchema = createInsertSchema(projectFinancialCenters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectFinancialCenter = z.infer<typeof insertProjectFinancialCenterSchema>;
export type ProjectFinancialCenter = typeof projectFinancialCenters.$inferSelect;

// =====================================
// المراكز المالية للشركة (المجمعة)
// =====================================
export const companyFinancialStatements = pgTable("company_financial_statements", {
  id: serial("id").primaryKey(),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  statementType: text("statement_type").notNull(), // balance-sheet, income-statement, cash-flow
  content: text("content").notNull(), // JSON format
  date: date("date").notNull(),
  isAudited: boolean("is_audited").default(false),
  auditedBy: integer("audited_by").references(() => users.id),
  auditDate: date("audit_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertCompanyFinancialStatementSchema = createInsertSchema(companyFinancialStatements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCompanyFinancialStatement = z.infer<typeof insertCompanyFinancialStatementSchema>;
export type CompanyFinancialStatement = typeof companyFinancialStatements.$inferSelect;

// =====================================
// أرصدة الحسابات
// =====================================
export const accountBalances = pgTable("account_balances", {
  id: serial("id").primaryKey(),
  accountId: integer("account_id").references(() => chartOfAccounts.id).notNull(),
  projectId: integer("project_id").references(() => projects.id),
  fiscalYear: integer("fiscal_year").notNull(),
  fiscalMonth: integer("fiscal_month").notNull(),
  openingBalance: real("opening_balance").default(0),
  debitTotal: real("debit_total").default(0),
  creditTotal: real("credit_total").default(0),
  closingBalance: real("closing_balance").default(0),
  lastTransactionDate: date("last_transaction_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => {
  return {
    // Ensure each account has one balance per project per month
    uniqueAccountBalance: unique().on(table.accountId, table.projectId, table.fiscalYear, table.fiscalMonth),
  };
});

export const insertAccountBalanceSchema = createInsertSchema(accountBalances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAccountBalance = z.infer<typeof insertAccountBalanceSchema>;
export type AccountBalance = typeof accountBalances.$inferSelect;

// =====================================
// كشوفات الحسابات
// =====================================
export const accountStatementsView = sql`
  CREATE OR REPLACE VIEW account_statements_view AS
  SELECT 
    a.id,
    a.code,
    a.name,
    a.type,
    a.class,
    p.id as project_id,
    p.name as project_name,
    ab.fiscal_year,
    ab.fiscal_month,
    ab.opening_balance,
    ab.debit_total,
    ab.credit_total,
    ab.closing_balance,
    ab.last_transaction_date
  FROM 
    chart_of_accounts a
  LEFT JOIN 
    account_balances ab ON a.id = ab.account_id
  LEFT JOIN 
    projects p ON ab.project_id = p.id
  WHERE 
    a.is_active = true
  ORDER BY 
    a.code, p.name, ab.fiscal_year, ab.fiscal_month
`;

// =====================================
// العلاقات (Relationships)
// =====================================

/* تم تعليق جميع تعريفات العلاقات لأنها تسبب مشاكل في النسخة الحالية من drizzle
   سيتم تنفيذ العلاقات برمجياً بدلاً من استخدام هذه الآلية
*/