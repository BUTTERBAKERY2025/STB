import {
  users, projects, invoices, chartOfAccounts, journalEntries, journalEntryItems, accountBalances, geoLocations,
  projectRisks, teamMembers, teamAssignments, equipment, documents, dailyReports, deadlines, expenses,
  type User, type InsertUser, type Project, type InsertProject,
  type Invoice, type InsertInvoice, type ChartOfAccount, type InsertChartOfAccount,
  type JournalEntry, type InsertJournalEntry, type JournalEntryItem, type InsertJournalEntryItem,
  type AccountBalance, type InsertAccountBalance, type GeoLocation, type InsertGeoLocation,
  type ProjectRisk, type InsertProjectRisk, type TeamMember, type InsertTeamMember,
  type TeamAssignment, type InsertTeamAssignment, type Equipment, type InsertEquipment,
  type Document, type InsertDocument, type DailyReport, type InsertDailyReport,
  type Deadline, type InsertDeadline, type Expense, type InsertExpense
} from "@shared/schema";

import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  sessionStore: session.Store;
  
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  listUsers(): Promise<User[]>;
  
  // Projects
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  listProjects(): Promise<Project[]>;
  deleteProject(id: number): Promise<boolean>;
  
  // Chart of Accounts
  getAccount(id: number): Promise<ChartOfAccount | undefined>;
  createAccount(account: InsertChartOfAccount): Promise<ChartOfAccount>;
  updateAccount(id: number, account: Partial<InsertChartOfAccount>): Promise<ChartOfAccount | undefined>;
  listAccounts(): Promise<ChartOfAccount[]>;
  deleteAccount(id: number): Promise<boolean>;

  // Journal Entries
  getJournalEntry(id: number): Promise<JournalEntry | undefined>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  listJournalEntries(): Promise<JournalEntry[]>;
  
  // Journal Entry Items
  createJournalEntryItem(item: InsertJournalEntryItem): Promise<JournalEntryItem>;
  listJournalEntryItems(journalEntryId: number): Promise<JournalEntryItem[]>;
  
  // Account Balances and Statements
  getAccountBalances(projectId?: number, fiscalYear?: number, fiscalMonth?: number): Promise<AccountBalance[]>;
  getAccountStatement(accountId: number, projectId?: number, fromDate?: Date, toDate?: Date): Promise<any>;
  
  // Geo Locations
  getGeoLocation(id: number): Promise<GeoLocation | undefined>;
  getGeoLocationsByProject(projectId: number, entityType?: string): Promise<GeoLocation[]>;
  createGeoLocation(location: InsertGeoLocation): Promise<GeoLocation>;
  updateGeoLocation(id: number, location: Partial<InsertGeoLocation>): Promise<GeoLocation | undefined>;
  deleteGeoLocation(id: number): Promise<boolean>;
  
  // Project Risks
  getProjectRisk(id: number): Promise<ProjectRisk | undefined>;
  getProjectRisksByProject(projectId: number): Promise<ProjectRisk[]>;
  createProjectRisk(risk: InsertProjectRisk): Promise<ProjectRisk>;
  updateProjectRisk(id: number, risk: Partial<InsertProjectRisk>): Promise<ProjectRisk | undefined>;
  deleteProjectRisk(id: number): Promise<boolean>;
  
  // Team Members & Assignments
  getTeamMember(id: number): Promise<TeamMember | undefined>;
  listTeamMembers(): Promise<TeamMember[]>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: number, member: Partial<InsertTeamMember>): Promise<TeamMember | undefined>;
  deleteTeamMember(id: number): Promise<boolean>;
  
  getTeamAssignment(id: number): Promise<TeamAssignment | undefined>;
  getTeamAssignmentsByProject(projectId: number): Promise<TeamAssignment[]>;
  createTeamAssignment(assignment: InsertTeamAssignment): Promise<TeamAssignment>;
  updateTeamAssignment(id: number, assignment: Partial<InsertTeamAssignment>): Promise<TeamAssignment | undefined>;
  deleteTeamAssignment(id: number): Promise<boolean>;
  
  // Equipment
  getEquipment(id: number): Promise<Equipment | undefined>;
  listEquipment(): Promise<Equipment[]>;
  getEquipmentByProject(projectId: number): Promise<Equipment[]>;
  createEquipment(equipment: InsertEquipment): Promise<Equipment>;
  updateEquipment(id: number, equipment: Partial<InsertEquipment>): Promise<Equipment | undefined>;
  deleteEquipment(id: number): Promise<boolean>;
  
  // Documents
  getDocument(id: number): Promise<Document | undefined>;
  getDocumentsByProject(projectId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: number, document: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<boolean>;
  
  // Daily Reports
  getDailyReport(id: number): Promise<DailyReport | undefined>;
  getDailyReportsByProject(projectId: number): Promise<DailyReport[]>;
  createDailyReport(report: InsertDailyReport): Promise<DailyReport>;
  updateDailyReport(id: number, report: Partial<InsertDailyReport>): Promise<DailyReport | undefined>;
  deleteDailyReport(id: number): Promise<boolean>;
  
  // Deadlines
  getDeadline(id: number): Promise<Deadline | undefined>;
  getDeadlinesByProject(projectId: number): Promise<Deadline[]>;
  createDeadline(deadline: InsertDeadline): Promise<Deadline>;
  updateDeadline(id: number, deadline: Partial<InsertDeadline>): Promise<Deadline | undefined>;
  deleteDeadline(id: number): Promise<boolean>;
  
  // Expenses
  getExpense(id: number): Promise<Expense | undefined>;
  getExpensesByProject(projectId: number): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  sessionStore: session.Store;
  
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private invoices: Map<number, Invoice>;
  private accounts: Map<number, ChartOfAccount>;
  private journalEntries: Map<number, JournalEntry>;
  private journalEntryItems: Map<number, JournalEntryItem>;
  private accountBalances: Map<number, AccountBalance>;
  private geoLocations: Map<number, GeoLocation>;
  private teamMembers: Map<number, TeamMember>;
  private teamAssignments: Map<number, TeamAssignment>;
  private equipment: Map<number, Equipment>;
  private documents: Map<number, Document>;
  private dailyReports: Map<number, DailyReport>;
  private deadlines: Map<number, Deadline>;
  private projectRisks: Map<number, ProjectRisk>;
  private expenses: Map<number, Expense>;
  
  private userCurrentId: number;
  private projectCurrentId: number;
  private invoiceCurrentId: number;
  private accountCurrentId: number;
  private journalEntryCurrentId: number;
  private journalEntryItemCurrentId: number;
  private accountBalanceCurrentId: number;
  private geoLocationCurrentId: number;
  private teamMemberCurrentId: number;
  private teamAssignmentCurrentId: number;
  private equipmentCurrentId: number;
  private documentCurrentId: number;
  private dailyReportCurrentId: number;
  private deadlineCurrentId: number;
  private projectRiskCurrentId: number;
  private expenseCurrentId: number;
  
  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    this.users = new Map();
    this.projects = new Map();
    this.invoices = new Map();
    this.accounts = new Map();
    this.journalEntries = new Map();
    this.journalEntryItems = new Map();
    this.accountBalances = new Map();
    this.geoLocations = new Map();
    this.teamMembers = new Map();
    this.teamAssignments = new Map();
    this.equipment = new Map();
    this.documents = new Map();
    this.dailyReports = new Map();
    this.deadlines = new Map();
    this.projectRisks = new Map();
    this.expenses = new Map();
    
    this.userCurrentId = 1;
    this.projectCurrentId = 1;
    this.invoiceCurrentId = 1;
    this.accountCurrentId = 1;
    this.journalEntryCurrentId = 1;
    this.journalEntryItemCurrentId = 1;
    this.accountBalanceCurrentId = 1;
    this.geoLocationCurrentId = 1;
    this.teamMemberCurrentId = 1;
    this.teamAssignmentCurrentId = 1;
    this.equipmentCurrentId = 1;
    this.documentCurrentId = 1;
    this.dailyReportCurrentId = 1;
    this.deadlineCurrentId = 1;
    this.projectRiskCurrentId = 1;
    this.expenseCurrentId = 1;
    
    // Add default admin user
    const adminUser: User = {
      id: this.userCurrentId++,
      username: "admin",
      password: "admin123", // In a real app, this would be hashed
      fullName: "مدير النظام",
      email: "admin@example.com",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(adminUser.id, adminUser);
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.userCurrentId++,
      username: insertUser.username,
      password: insertUser.password,
      fullName: insertUser.fullName || null,
      email: insertUser.email || null,
      role: insertUser.role || "user",
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.users.set(user.id, user);
    return user;
  }
  
  async listUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  // Project methods
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async createProject(insertProject: InsertProject): Promise<Project> {
    const project: Project = {
      id: this.projectCurrentId++,
      name: insertProject.name,
      status: insertProject.status || "planned",
      category: insertProject.category as "electricity" | "water" | "communications" | "roads" | "buildings" || "buildings",
      description: insertProject.description || null,
      clientName: insertProject.clientName || null,
      contractNumber: insertProject.contractNumber || null,
      location: insertProject.location || null,
      startDate: insertProject.startDate || new Date(),
      endDate: insertProject.endDate || new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // +90 days default
      duration: insertProject.duration || 3, // 3 months default
      budget: insertProject.budget || 0,
      progress: insertProject.progress || 0,
      imageUrl: insertProject.imageUrl || null,
      notes: insertProject.notes || null,
      managerId: insertProject.managerId || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.projects.set(project.id, project);
    return project;
  }
  
  async updateProject(id: number, projectUpdate: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject: Project = {
      ...project,
      ...projectUpdate,
      updatedAt: new Date()
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
  
  async listProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }
  
  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  // Chart of Accounts methods
  async getAccount(id: number): Promise<ChartOfAccount | undefined> {
    return this.accounts.get(id);
  }
  
  async createAccount(account: InsertChartOfAccount): Promise<ChartOfAccount> {
    const newAccount: ChartOfAccount = {
      id: this.accountCurrentId++,
      code: account.code,
      name: account.name,
      type: account.type,
      class: account.class,
      parentId: account.parentId || null,
      description: account.description || null,
      isActive: account.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.accounts.set(newAccount.id, newAccount);
    return newAccount;
  }
  
  async updateAccount(id: number, accountUpdate: Partial<InsertChartOfAccount>): Promise<ChartOfAccount | undefined> {
    const account = this.accounts.get(id);
    if (!account) return undefined;
    
    const updatedAccount: ChartOfAccount = {
      ...account,
      ...accountUpdate,
      updatedAt: new Date()
    };
    
    this.accounts.set(id, updatedAccount);
    return updatedAccount;
  }
  
  async listAccounts(): Promise<ChartOfAccount[]> {
    return Array.from(this.accounts.values());
  }
  
  async deleteAccount(id: number): Promise<boolean> {
    // قبل الحذف، نتحقق من عدم وجود حسابات أخرى مرتبطة به كأب
    const hasChildren = Array.from(this.accounts.values()).some(
      account => account.parentId === id
    );
    
    if (hasChildren) {
      throw new Error('لا يمكن حذف الحساب لأنه يحتوي على حسابات فرعية');
    }
    
    // نتحقق من عدم وجود قيود محاسبية مرتبطة بهذا الحساب
    const hasJournalEntries = Array.from(this.journalEntryItems.values()).some(
      item => item.accountId === id
    );
    
    if (hasJournalEntries) {
      throw new Error('لا يمكن حذف الحساب لوجود قيود محاسبية مرتبطة به');
    }
    
    return this.accounts.delete(id);
  }
  
  // Journal Entries methods
  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    return this.journalEntries.get(id);
  }
  
  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const newEntry: JournalEntry = {
      id: this.journalEntryCurrentId++,
      date: entry.date || new Date(),
      reference: entry.reference || null,
      description: entry.description || null,
      projectId: entry.projectId || null,
      status: entry.status || "draft",
      type: entry.type || "standard",
      createdAt: new Date(),
      updatedAt: new Date(),
      createdById: entry.createdById || 1, // Default to admin
    };
    
    this.journalEntries.set(newEntry.id, newEntry);
    return newEntry;
  }
  
  async listJournalEntries(): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values());
  }
  
  // Journal Entry Items methods
  async createJournalEntryItem(item: InsertJournalEntryItem): Promise<JournalEntryItem> {
    const newItem: JournalEntryItem = {
      id: this.journalEntryItemCurrentId++,
      journalEntryId: item.journalEntryId,
      accountId: item.accountId,
      description: item.description || null,
      debit: item.debit || 0,
      credit: item.credit || 0,
      projectId: item.projectId || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.journalEntryItems.set(newItem.id, newItem);
    
    // تحديث أرصدة الحسابات
    this.updateAccountBalance(newItem);
    
    return newItem;
  }
  
  async listJournalEntryItems(journalEntryId: number): Promise<JournalEntryItem[]> {
    return Array.from(this.journalEntryItems.values())
      .filter(item => item.journalEntryId === journalEntryId);
  }
  
  // Account Balances and Statements methods
  async getAccountBalances(projectId?: number, fiscalYear?: number, fiscalMonth?: number): Promise<AccountBalance[]> {
    let balances = Array.from(this.accountBalances.values());
    
    // تطبيق فلاتر البحث
    if (projectId !== undefined) {
      balances = balances.filter(balance => balance.projectId === projectId);
    }
    
    if (fiscalYear !== undefined) {
      balances = balances.filter(balance => {
        const date = new Date(balance.periodEnd);
        return date.getFullYear() === fiscalYear;
      });
    }
    
    if (fiscalMonth !== undefined) {
      balances = balances.filter(balance => {
        const date = new Date(balance.periodEnd);
        return date.getMonth() + 1 === fiscalMonth; // getMonth() يبدأ من 0
      });
    }
    
    return balances;
  }
  
  async getAccountStatement(accountId: number, projectId?: number, fromDate?: Date, toDate?: Date): Promise<any> {
    // الحصول على الحساب
    const account = await this.getAccount(accountId);
    if (!account) {
      throw new Error('الحساب غير موجود');
    }
    
    // الحصول على كل قيود اليومية المرتبطة بهذا الحساب
    let items = Array.from(this.journalEntryItems.values())
      .filter(item => item.accountId === accountId);
    
    // تطبيق فلتر المشروع إذا وجد
    if (projectId !== undefined) {
      items = items.filter(item => item.projectId === projectId);
    }
    
    // الحصول على تفاصيل قيود اليومية
    const itemDetails = await Promise.all(items.map(async item => {
      const entry = await this.getJournalEntry(item.journalEntryId);
      
      // تطبيق فلتر التاريخ
      if (fromDate && entry && new Date(entry.date) < fromDate) {
        return null;
      }
      
      if (toDate && entry && new Date(entry.date) > toDate) {
        return null;
      }
      
      return {
        ...item,
        entryDate: entry?.date,
        entryReference: entry?.reference,
        entryDescription: entry?.description
      };
    }));
    
    // إزالة العناصر التي تم تصفيتها
    const filteredItems = itemDetails.filter(item => item !== null);
    
    // حساب الرصيد
    let balance = 0;
    const statementItems = filteredItems.map(item => {
      if (!item) return null;
      
      if (account.type === 'asset' || account.type === 'expense') {
        balance += item.debit - item.credit;
      } else {
        balance += item.credit - item.debit;
      }
      
      return {
        ...item,
        balance
      };
    }).filter(Boolean);
    
    // تنظيم البيانات للعرض
    return {
      account,
      statement: statementItems,
      summary: {
        totalDebit: statementItems.reduce((sum, item) => sum + (item?.debit || 0), 0),
        totalCredit: statementItems.reduce((sum, item) => sum + (item?.credit || 0), 0),
        balance
      }
    };
  }
  
  // طريقة خاصة لتحديث أرصدة الحسابات
  private async updateAccountBalance(item: JournalEntryItem): Promise<void> {
    const entry = await this.getJournalEntry(item.journalEntryId);
    if (!entry) return;
    
    const account = await this.getAccount(item.accountId);
    if (!account) return;
    
    // تحديد الفترة المالية بناءً على تاريخ القيد
    const entryDate = new Date(entry.date);
    const year = entryDate.getFullYear();
    const month = entryDate.getMonth() + 1; // +1 لأن getMonth يبدأ من 0
    
    // إنشاء مفتاح فريد للرصيد استنادًا إلى الحساب والمشروع والفترة
    const balanceKey = `${item.accountId}_${item.projectId || 0}_${year}_${month}`;
    
    // البحث عن رصيد موجود
    const existingBalance = Array.from(this.accountBalances.values()).find(balance => 
      balance.accountId === item.accountId &&
      balance.projectId === (item.projectId || null) &&
      new Date(balance.periodStart).getFullYear() === year &&
      new Date(balance.periodStart).getMonth() + 1 === month
    );
    
    if (existingBalance) {
      // تحديث الرصيد الموجود
      const isDebitAccount = account.type === 'asset' || account.type === 'expense';
      
      if (isDebitAccount) {
        existingBalance.debitTotal += item.debit;
        existingBalance.creditTotal += item.credit;
        existingBalance.balance = existingBalance.debitTotal - existingBalance.creditTotal;
      } else {
        existingBalance.debitTotal += item.debit;
        existingBalance.creditTotal += item.credit;
        existingBalance.balance = existingBalance.creditTotal - existingBalance.debitTotal;
      }
      
      existingBalance.updatedAt = new Date();
      this.accountBalances.set(existingBalance.id, existingBalance);
    } else {
      // إنشاء رصيد جديد
      const periodStart = new Date(year, month - 1, 1); // الشهر يبدأ من 0
      const periodEnd = new Date(year, month, 0); // آخر يوم في الشهر
      
      const isDebitAccount = account.type === 'asset' || account.type === 'expense';
      const balance = isDebitAccount 
        ? item.debit - item.credit 
        : item.credit - item.debit;
      
      const newBalance: AccountBalance = {
        id: this.accountBalanceCurrentId++,
        accountId: item.accountId,
        projectId: item.projectId,
        periodStart,
        periodEnd,
        debitTotal: item.debit,
        creditTotal: item.credit,
        balance,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      this.accountBalances.set(newBalance.id, newBalance);
    }
  }
  
  // Geo Locations methods
  async getGeoLocation(id: number): Promise<GeoLocation | undefined> {
    return this.geoLocations.get(id);
  }

  async getGeoLocationsByProject(projectId: number, entityType?: string): Promise<GeoLocation[]> {
    let locations = Array.from(this.geoLocations.values())
      .filter(location => location.projectId === projectId);
    
    if (entityType) {
      locations = locations.filter(location => location.entityType === entityType);
    }
    
    return locations;
  }

  async createGeoLocation(location: InsertGeoLocation): Promise<GeoLocation> {
    const newLocation: GeoLocation = {
      id: this.geoLocationCurrentId++,
      name: location.name,
      description: location.description || null,
      latitude: location.latitude,
      longitude: location.longitude,
      projectId: location.projectId,
      entityType: location.entityType || 'site',
      entityId: location.entityId || null,
      status: location.status || 'active',
      radius: location.radius || 100,
      lastUpdateTime: new Date(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.geoLocations.set(newLocation.id, newLocation);
    return newLocation;
  }

  async updateGeoLocation(id: number, locationUpdate: Partial<InsertGeoLocation>): Promise<GeoLocation | undefined> {
    const location = this.geoLocations.get(id);
    if (!location) return undefined;
    
    const updatedLocation: GeoLocation = {
      ...location,
      ...locationUpdate,
      lastUpdateTime: new Date(),
      updatedAt: new Date()
    };
    
    this.geoLocations.set(id, updatedLocation);
    return updatedLocation;
  }

  async deleteGeoLocation(id: number): Promise<boolean> {
    return this.geoLocations.delete(id);
  }
  
  // Project Risks methods
  async getProjectRisk(id: number): Promise<ProjectRisk | undefined> {
    return this.projectRisks.get(id);
  }
  
  async getProjectRisksByProject(projectId: number): Promise<ProjectRisk[]> {
    return Array.from(this.projectRisks.values())
      .filter(risk => risk.projectId === projectId);
  }
  
  async createProjectRisk(risk: InsertProjectRisk): Promise<ProjectRisk> {
    const newRisk: ProjectRisk = {
      id: this.projectRiskCurrentId++,
      title: risk.title,
      description: risk.description,
      projectId: risk.projectId,
      category: risk.category || "operational",
      severity: risk.severity || "medium",
      impact: risk.impact || 3,
      probability: risk.probability || 3,
      status: risk.status || "identified",
      identifiedBy: risk.identifiedBy || 1,
      identifiedDate: risk.identifiedDate || new Date(),
      assignedTo: risk.assignedTo || null,
      reviewDate: risk.reviewDate || null,
      mitigationStrategy: risk.mitigationStrategy || null,
      contingencyPlan: risk.contingencyPlan || null,
      resolution: risk.resolution || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.projectRisks.set(newRisk.id, newRisk);
    return newRisk;
  }
  
  async updateProjectRisk(id: number, riskUpdate: Partial<InsertProjectRisk>): Promise<ProjectRisk | undefined> {
    const risk = this.projectRisks.get(id);
    if (!risk) return undefined;
    
    const updatedRisk: ProjectRisk = {
      ...risk,
      ...riskUpdate,
      updatedAt: new Date()
    };
    
    this.projectRisks.set(id, updatedRisk);
    return updatedRisk;
  }
  
  async deleteProjectRisk(id: number): Promise<boolean> {
    return this.projectRisks.delete(id);
  }
  
  // Team Members methods
  async getTeamMember(id: number): Promise<TeamMember | undefined> {
    return this.teamMembers.get(id);
  }
  
  async listTeamMembers(): Promise<TeamMember[]> {
    return Array.from(this.teamMembers.values());
  }
  
  async createTeamMember(member: InsertTeamMember): Promise<TeamMember> {
    const newMember: TeamMember = {
      id: this.teamMemberCurrentId++,
      name: member.name,
      role: member.role || "worker",
      specialization: member.specialization || null,
      contactInfo: member.contactInfo || null,
      email: member.email || null,
      phone: member.phone || null,
      status: member.status || "active",
      notes: member.notes || null,
      imageUrl: member.imageUrl || null,
      userId: member.userId || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.teamMembers.set(newMember.id, newMember);
    return newMember;
  }
  
  async updateTeamMember(id: number, memberUpdate: Partial<InsertTeamMember>): Promise<TeamMember | undefined> {
    const member = this.teamMembers.get(id);
    if (!member) return undefined;
    
    const updatedMember: TeamMember = {
      ...member,
      ...memberUpdate,
      updatedAt: new Date()
    };
    
    this.teamMembers.set(id, updatedMember);
    return updatedMember;
  }
  
  async deleteTeamMember(id: number): Promise<boolean> {
    // Check if member is assigned to any project
    const hasAssignments = Array.from(this.teamAssignments.values()).some(
      assignment => assignment.teamMemberId === id
    );
    
    if (hasAssignments) {
      throw new Error('لا يمكن حذف عضو الفريق لأنه مرتبط بمشاريع');
    }
    
    return this.teamMembers.delete(id);
  }
  
  // Team Assignments methods
  async getTeamAssignment(id: number): Promise<TeamAssignment | undefined> {
    return this.teamAssignments.get(id);
  }
  
  async getTeamAssignmentsByProject(projectId: number): Promise<TeamAssignment[]> {
    return Array.from(this.teamAssignments.values())
      .filter(assignment => assignment.projectId === projectId);
  }
  
  async createTeamAssignment(assignment: InsertTeamAssignment): Promise<TeamAssignment> {
    const newAssignment: TeamAssignment = {
      id: this.teamAssignmentCurrentId++,
      projectId: assignment.projectId,
      teamMemberId: assignment.teamMemberId,
      role: assignment.role || null,
      startDate: assignment.startDate || new Date(),
      endDate: assignment.endDate || null,
      responsibilities: assignment.responsibilities || null,
      status: assignment.status || "active",
      notes: assignment.notes || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.teamAssignments.set(newAssignment.id, newAssignment);
    return newAssignment;
  }
  
  async updateTeamAssignment(id: number, assignmentUpdate: Partial<InsertTeamAssignment>): Promise<TeamAssignment | undefined> {
    const assignment = this.teamAssignments.get(id);
    if (!assignment) return undefined;
    
    const updatedAssignment: TeamAssignment = {
      ...assignment,
      ...assignmentUpdate,
      updatedAt: new Date()
    };
    
    this.teamAssignments.set(id, updatedAssignment);
    return updatedAssignment;
  }
  
  async deleteTeamAssignment(id: number): Promise<boolean> {
    return this.teamAssignments.delete(id);
  }
  
  // Equipment methods
  async getEquipment(id: number): Promise<Equipment | undefined> {
    return this.equipment.get(id);
  }
  
  async listEquipment(): Promise<Equipment[]> {
    return Array.from(this.equipment.values());
  }
  
  async getEquipmentByProject(projectId: number): Promise<Equipment[]> {
    return Array.from(this.equipment.values())
      .filter(equipment => equipment.currentProjectId === projectId);
  }
  
  async createEquipment(equipment: InsertEquipment): Promise<Equipment> {
    const newEquipment: Equipment = {
      id: this.equipmentCurrentId++,
      name: equipment.name,
      type: equipment.type,
      serialNumber: equipment.serialNumber || null,
      manufacturer: equipment.manufacturer || null,
      model: equipment.model || null,
      purchaseDate: equipment.purchaseDate || null,
      purchaseCost: equipment.purchaseCost || null,
      status: equipment.status || "available",
      currentProjectId: equipment.currentProjectId || null,
      notes: equipment.notes || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.equipment.set(newEquipment.id, newEquipment);
    return newEquipment;
  }
  
  async updateEquipment(id: number, equipmentUpdate: Partial<InsertEquipment>): Promise<Equipment | undefined> {
    const existingEquipment = this.equipment.get(id);
    if (!existingEquipment) return undefined;
    
    const updatedEquipment: Equipment = {
      ...existingEquipment,
      ...equipmentUpdate,
      updatedAt: new Date()
    };
    
    this.equipment.set(id, updatedEquipment);
    return updatedEquipment;
  }
  
  async deleteEquipment(id: number): Promise<boolean> {
    return this.equipment.delete(id);
  }
  
  // Documents methods
  async getDocument(id: number): Promise<Document | undefined> {
    return this.documents.get(id);
  }
  
  async getDocumentsByProject(projectId: number): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter(document => document.projectId === projectId);
  }
  
  async createDocument(document: InsertDocument): Promise<Document> {
    const newDocument: Document = {
      id: this.documentCurrentId++,
      title: document.title || `Document-${this.documentCurrentId}`,
      description: document.description || null,
      projectId: document.projectId,
      category: document.category || "other",
      fileUrl: document.fileUrl || null,
      fileType: document.fileType || null,
      fileSize: document.fileSize || null,
      version: document.version || "1.0",
      uploadedBy: document.uploadedBy || null,
      status: document.status || "active",
      approvedBy: document.approvedBy || null,
      approvalDate: document.approvalDate || null,
      tags: document.tags || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.documents.set(newDocument.id, newDocument);
    return newDocument;
  }
  
  async updateDocument(id: number, documentUpdate: Partial<InsertDocument>): Promise<Document | undefined> {
    const document = this.documents.get(id);
    if (!document) return undefined;
    
    const updatedDocument: Document = {
      ...document,
      ...documentUpdate,
      updatedAt: new Date()
    };
    
    this.documents.set(id, updatedDocument);
    return updatedDocument;
  }
  
  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }
  
  // Daily Reports methods
  async getDailyReport(id: number): Promise<DailyReport | undefined> {
    return this.dailyReports.get(id);
  }
  
  async getDailyReportsByProject(projectId: number): Promise<DailyReport[]> {
    return Array.from(this.dailyReports.values())
      .filter(report => report.projectId === projectId);
  }
  
  async createDailyReport(report: InsertDailyReport): Promise<DailyReport> {
    const newReport: DailyReport = {
      id: this.dailyReportCurrentId++,
      date: report.date || new Date().toISOString().split('T')[0],
      projectId: report.projectId,
      reporterId: report.reporterId || null,
      weather: report.weather || null,
      temperature: report.temperature || null,
      workCompleted: report.workCompleted || null,
      materialsUsed: report.materialsUsed || null,
      equipmentUsed: report.equipmentUsed || null,
      workerCount: report.workerCount || null,
      delayReasons: report.delayReasons || null,
      qualityIssues: report.qualityIssues || null,
      safetyIncidents: report.safetyIncidents || null,
      visitorsOnSite: report.visitorsOnSite || null,
      nextDayPlan: report.nextDayPlan || null,
      notes: report.notes || null,
      imageUrls: report.imageUrls || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.dailyReports.set(newReport.id, newReport);
    return newReport;
  }
  
  async updateDailyReport(id: number, reportUpdate: Partial<InsertDailyReport>): Promise<DailyReport | undefined> {
    const report = this.dailyReports.get(id);
    if (!report) return undefined;
    
    const updatedReport: DailyReport = {
      ...report,
      ...reportUpdate,
      updatedAt: new Date()
    };
    
    this.dailyReports.set(id, updatedReport);
    return updatedReport;
  }
  
  async deleteDailyReport(id: number): Promise<boolean> {
    return this.dailyReports.delete(id);
  }
  
  // Deadlines methods
  async getDeadline(id: number): Promise<Deadline | undefined> {
    return this.deadlines.get(id);
  }
  
  async getDeadlinesByProject(projectId: number): Promise<Deadline[]> {
    return Array.from(this.deadlines.values())
      .filter(deadline => deadline.projectId === projectId);
  }
  
  async createDeadline(deadline: InsertDeadline): Promise<Deadline> {
    const newDeadline: Deadline = {
      id: this.deadlineCurrentId++,
      title: deadline.title,
      description: deadline.description || null,
      projectId: deadline.projectId,
      dueDate: deadline.dueDate,
      priority: deadline.priority || "medium",
      status: deadline.status || "pending",
      assignedTo: deadline.assignedTo || null,
      parentId: deadline.parentId || null,
      dependsOn: deadline.dependsOn || null,
      completionPercent: deadline.completionPercent || 0,
      notifyBefore: deadline.notifyBefore || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.deadlines.set(newDeadline.id, newDeadline);
    return newDeadline;
  }
  
  async updateDeadline(id: number, deadlineUpdate: Partial<InsertDeadline>): Promise<Deadline | undefined> {
    const deadline = this.deadlines.get(id);
    if (!deadline) return undefined;
    
    const updatedDeadline: Deadline = {
      ...deadline,
      ...deadlineUpdate,
      updatedAt: new Date()
    };
    
    this.deadlines.set(id, updatedDeadline);
    return updatedDeadline;
  }
  
  async deleteDeadline(id: number): Promise<boolean> {
    // Check if there are dependent deadlines
    const hasDependents = Array.from(this.deadlines.values()).some(
      d => d.dependsOn === id || d.parentId === id
    );
    
    if (hasDependents) {
      throw new Error('لا يمكن حذف الموعد النهائي لأنه مرتبط بمواعيد أخرى');
    }
    
    return this.deadlines.delete(id);
  }
  
  // Expenses methods
  async getExpense(id: number): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }
  
  async getExpensesByProject(projectId: number): Promise<Expense[]> {
    return Array.from(this.expenses.values())
      .filter(expense => expense.projectId === projectId);
  }
  
  async createExpense(expense: InsertExpense): Promise<Expense> {
    const newExpense: Expense = {
      id: this.expenseCurrentId++,
      projectId: expense.projectId,
      date: expense.date || new Date().toISOString().split('T')[0],
      amount: expense.amount,
      category: expense.category || "materials",
      description: expense.description || null,
      vendor: expense.vendor || null,
      receiptUrl: expense.receiptUrl || null,
      approvedBy: expense.approvedBy || null,
      approvalDate: expense.approvalDate || null,
      status: expense.status || "pending",
      paymentMethod: expense.paymentMethod || null,
      paymentReference: expense.paymentReference || null,
      notes: expense.notes || null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    this.expenses.set(newExpense.id, newExpense);
    return newExpense;
  }
  
  async updateExpense(id: number, expenseUpdate: Partial<InsertExpense>): Promise<Expense | undefined> {
    const expense = this.expenses.get(id);
    if (!expense) return undefined;
    
    const updatedExpense: Expense = {
      ...expense,
      ...expenseUpdate,
      updatedAt: new Date()
    };
    
    this.expenses.set(id, updatedExpense);
    return updatedExpense;
  }
  
  async deleteExpense(id: number): Promise<boolean> {
    return this.expenses.delete(id);
  }
}

export const storage = new MemStorage();