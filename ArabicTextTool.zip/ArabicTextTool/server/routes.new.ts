import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes will go here
  app.get("/api/health", (req: Request, res: Response) => {
    res.status(200).json({ status: "up" });
  });
  
  // Create HTTP server
  const httpServer = createServer(app);
  
  return httpServer;
}