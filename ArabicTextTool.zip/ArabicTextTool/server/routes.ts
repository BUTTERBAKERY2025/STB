import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertProjectSchema, 
  insertChartOfAccountSchema,
  insertJournalEntrySchema,
  insertJournalEntryItemSchema,
  insertGeoLocationSchema,
  insertTeamMemberSchema,
  insertTeamAssignmentSchema,
  insertEquipmentSchema,
  insertDocumentSchema,
  insertProjectRiskSchema,
  insertDailyReportSchema,
  insertDeadlineSchema,
  insertExpenseSchema
} from "@shared/schema";
import { z } from "zod";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Authentication
  setupAuth(app);
  
  // API Health Check
  app.get("/api/health", (req: Request, res: Response) => {
    res.status(200).json({ status: "up" });
  });
  
  // إنشاء بيانات مشاريع للاختبار
  app.post("/api/seed/projects", async (req: Request, res: Response) => {
    try {
      // حذف المشاريع الحالية إذا كان هناك أي
      const projects = await storage.listProjects();
      for (const project of projects) {
        await storage.deleteProject(project.id);
      }
      
      // إنشاء مشاريع جديدة للاختبار
      const sampleProjects = [
        {
          name: "إنشاء برج القصر السكني",
          description: "مشروع إنشاء برج سكني فاخر يتكون من 25 طابقاً بمواصفات عالمية",
          clientName: "شركة الخليج للاستثمار العقاري",
          contractNumber: "CON-2023-1001",
          location: "جدة - حي الشاطئ",
          status: "inProgress" as const,
          category: "buildings" as const,
          budget: 75000000,
          startDate: "2023-06-01",
          endDate: "2025-12-31",
          duration: 30,
          progress: 35,
          imageUrl: "https://images.unsplash.com/photo-1576941089067-2de3c901e126?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8Y29uc3RydWN0aW9ufGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
          notes: "يتم تنفيذ المشروع وفق أعلى معايير الجودة والسلامة العالمية"
        },
        {
          name: "تطوير شبكة الطرق الداخلية",
          description: "مشروع تطوير وتحسين شبكة الطرق الداخلية بالمنطقة الصناعية",
          clientName: "أمانة المدينة المنورة",
          contractNumber: "CON-2023-458",
          location: "المدينة المنورة - المنطقة الصناعية",
          status: "planned" as const,
          category: "roads" as const,
          budget: 25000000,
          startDate: "2023-09-15",
          endDate: "2024-04-30",
          duration: 7,
          progress: 0,
          imageUrl: "https://images.unsplash.com/photo-1573027589492-33ddcc5d017b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aGlnaHdheXxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
          notes: "الخطة الزمنية معتمدة من الجهة المختصة"
        },
        {
          name: "إنشاء خزانات المياه المعالجة",
          description: "إنشاء خزانات المياه المعالجة بسعة 50,000 متر مكعب بالمنطقة الشرقية",
          clientName: "وزارة المياه",
          contractNumber: "CON-2023-745",
          location: "الدمام - المنطقة الصناعية الثانية",
          status: "delayed" as const,
          category: "water" as const,
          budget: 45000000,
          startDate: "2023-01-10",
          endDate: "2024-05-01",
          duration: 16,
          progress: 45,
          imageUrl: "https://images.unsplash.com/photo-1625248742113-745e7805b49d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8d2F0ZXIlMjB0cmVhdG1lbnR8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=800&q=60",
          notes: "تأخير المشروع بسبب صعوبات في توريد بعض المعدات"
        },
        {
          name: "تركيب شبكة الألياف الضوئية",
          description: "مشروع تركيب وتشغيل شبكة ألياف ضوئية بسرعات عالية",
          clientName: "شركة الاتصالات السعودية",
          contractNumber: "CON-2022-932",
          location: "الرياض - مناطق متفرقة",
          status: "completed" as const,
          category: "communications" as const,
          budget: 35000000,
          startDate: "2022-05-20",
          endDate: "2023-07-01",
          duration: 14,
          progress: 100,
          imageUrl: "https://images.unsplash.com/photo-1494783367193-149034c05e8f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8bmV0d29yayUyMGNhYmxlfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
          notes: "تم إنجاز المشروع قبل الموعد المحدد وبجودة عالية"
        },
        {
          name: "محطة توليد الطاقة الشمسية",
          description: "إنشاء محطة توليد طاقة شمسية بقدرة 50 ميجاوات",
          clientName: "وزارة الطاقة",
          contractNumber: "CON-2023-512",
          location: "تبوك - منطقة نيوم",
          status: "inProgress" as const,
          category: "electricity" as const,
          budget: 120000000,
          startDate: "2023-04-01",
          endDate: "2025-05-01",
          duration: 25,
          progress: 25,
          imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c29sYXIlMjBwYW5lbHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
          notes: "المرحلة الأولى من المشروع بدأت بنجاح"
        },
        {
          name: "تطوير مركز البيانات الرئيسي",
          description: "تطوير وتحديث مركز البيانات الرئيسي وفق أحدث التقنيات",
          clientName: "مدينة الملك عبدالعزيز للعلوم والتقنية",
          contractNumber: "CON-2023-128",
          location: "الرياض - مدينة الملك عبدالعزيز",
          status: "inProgress" as const,
          category: "communications" as const,
          budget: 85000000,
          startDate: "2023-02-15",
          endDate: "2024-08-30",
          duration: 18,
          progress: 60,
          imageUrl: "https://images.unsplash.com/photo-1588508065123-287b28e013da?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8ZGF0YSUyMGNlbnRlcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
          notes: "المشروع يتقدم وفق الخطة المعتمدة"
        }
      ];
      
      // إضافة المشاريع إلى قاعدة البيانات
      const createdProjects = [];
      for (const projectData of sampleProjects) {
        const project = await storage.createProject(projectData);
        createdProjects.push(project);
      }
      
      res.status(201).json({
        message: "تم إنشاء بيانات المشاريع بنجاح",
        count: createdProjects.length,
        projects: createdProjects
      });
    } catch (err) {
      console.error("Error seeding projects:", err);
      res.status(500).json({ error: "حدثت مشكلة أثناء إنشاء بيانات المشاريع" });
    }
  });

  // جلب كافة المشاريع
  app.get("/api/projects", async (req: Request, res: Response) => {
    try {
      const projects = await storage.listProjects();
      res.json(projects);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب المشاريع' });
    }
  });
  
  // إنشاء مشروع جديد
  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating project:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء المشروع' });
      }
    }
  });
  
  // تحديث مشروع
  app.patch("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedProject = await storage.updateProject(id, req.body);
      if (!updatedProject) {
        return res.status(404).json({ error: 'المشروع غير موجود' });
      }
      res.json(updatedProject);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء تحديث المشروع' });
    }
  });
  
  // حذف مشروع
  app.delete("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteProject(id);
      if (!success) {
        return res.status(404).json({ error: 'المشروع غير موجود' });
      }
      res.status(200).json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء حذف المشروع' });
    }
  });

  // ========================
  // نظام الحسابات المالي
  // ========================

  // الحصول على شجرة الحسابات
  app.get("/api/accounts", async (req: Request, res: Response) => {
    try {
      const accounts = await storage.listAccounts();
      res.json(accounts);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب الحسابات' });
    }
  });

  // إنشاء حساب جديد
  app.post("/api/accounts", async (req: Request, res: Response) => {
    try {
      const validatedData = insertChartOfAccountSchema.parse(req.body);
      const account = await storage.createAccount(validatedData);
      res.status(201).json(account);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating account:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء الحساب' });
      }
    }
  });

  // تحديث حساب
  app.patch("/api/accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedAccount = await storage.updateAccount(id, req.body);
      if (!updatedAccount) {
        return res.status(404).json({ error: 'الحساب غير موجود' });
      }
      res.json(updatedAccount);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء تحديث الحساب' });
    }
  });

  // حذف حساب
  app.delete("/api/accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteAccount(id);
      if (!success) {
        return res.status(404).json({ error: 'الحساب غير موجود' });
      }
      res.status(200).json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء حذف الحساب' });
    }
  });

  // الحصول على قيود اليومية
  app.get("/api/journal-entries", async (req: Request, res: Response) => {
    try {
      const journalEntries = await storage.listJournalEntries();
      res.json(journalEntries);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب قيود اليومية' });
    }
  });

  // إنشاء قيد يومية جديد
  app.post("/api/journal-entries", async (req: Request, res: Response) => {
    try {
      const validatedData = insertJournalEntrySchema.parse(req.body);
      const journalEntry = await storage.createJournalEntry(validatedData);
      res.status(201).json(journalEntry);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating journal entry:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء قيد اليومية' });
      }
    }
  });

  // إضافة بند قيد يومية
  app.post("/api/journal-entries/:id/items", async (req: Request, res: Response) => {
    try {
      const journalEntryId = parseInt(req.params.id);
      
      // تحقق من وجود قيد اليومية
      const journalEntry = await storage.getJournalEntry(journalEntryId);
      if (!journalEntry) {
        return res.status(404).json({ error: 'قيد اليومية غير موجود' });
      }

      const itemData = { ...req.body, journalEntryId };
      const validatedData = insertJournalEntryItemSchema.parse(itemData);
      const journalEntryItem = await storage.createJournalEntryItem(validatedData);
      
      res.status(201).json(journalEntryItem);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating journal entry item:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إضافة بند قيد اليومية' });
      }
    }
  });

  // الحصول على أرصدة الحسابات
  app.get("/api/account-balances", async (req: Request, res: Response) => {
    try {
      // استخراج معايير التصفية من الاستعلام
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const fiscalYear = req.query.fiscalYear ? parseInt(req.query.fiscalYear as string) : undefined;
      const fiscalMonth = req.query.fiscalMonth ? parseInt(req.query.fiscalMonth as string) : undefined;
      
      const accountBalances = await storage.getAccountBalances(projectId, fiscalYear, fiscalMonth);
      res.json(accountBalances);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب أرصدة الحسابات' });
    }
  });

  // الحصول على تفاصيل حركة حساب معين
  app.get("/api/account-statement/:id", async (req: Request, res: Response) => {
    try {
      const accountId = parseInt(req.params.id);
      const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
      const fromDate = req.query.fromDate ? new Date(req.query.fromDate as string) : undefined;
      const toDate = req.query.toDate ? new Date(req.query.toDate as string) : undefined;
      
      const accountStatement = await storage.getAccountStatement(accountId, projectId, fromDate, toDate);
      res.json(accountStatement);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب كشف الحساب' });
    }
  });

  // ========================
  // المواقع الجغرافية
  // ========================

  // الحصول على المواقع الجغرافية لمشروع معين
  app.get("/api/projects/:projectId/geo-locations", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const entityType = req.query.entityType as string | undefined;
      
      const locations = await storage.getGeoLocationsByProject(projectId, entityType);
      res.json(locations);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب المواقع الجغرافية' });
    }
  });

  // إنشاء موقع جغرافي جديد
  app.post("/api/geo-locations", async (req: Request, res: Response) => {
    try {
      const validatedData = insertGeoLocationSchema.parse(req.body);
      const location = await storage.createGeoLocation(validatedData);
      res.status(201).json(location);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating geo location:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء الموقع الجغرافي' });
      }
    }
  });

  // تحديث موقع جغرافي
  app.patch("/api/geo-locations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedLocation = await storage.updateGeoLocation(id, req.body);
      if (!updatedLocation) {
        return res.status(404).json({ error: 'الموقع الجغرافي غير موجود' });
      }
      res.json(updatedLocation);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء تحديث الموقع الجغرافي' });
    }
  });

  // حذف موقع جغرافي
  app.delete("/api/geo-locations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteGeoLocation(id);
      if (!success) {
        return res.status(404).json({ error: 'الموقع الجغرافي غير موجود' });
      }
      res.status(200).json({ success: true });
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء حذف الموقع الجغرافي' });
    }
  });

  // API نقاط نهاية وهمية للتقارير والتحليلات
  
  // نقطة نهاية وهمية لبيانات أداء المشروع
  app.get("/api/project-performance", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const timeframe = req.query.timeframe as string || 'month';
    
    // بيانات وهمية للتطوير - سيتم استبدالها بمصدر بيانات حقيقي لاحقاً
    let performanceData = [];
    
    if (projectId) {
      // بيانات مشروع محدد
      performanceData = [{
        projectId,
        projectName: "مشروع نموذجي",
        plannedCompletion: 75,
        actualCompletion: 65,
        plannedCost: 1200000,
        actualCost: 1350000,
        variance: 10,
        lastUpdated: new Date().toLocaleDateString('ar-SA'),
      }];
    } else {
      // بيانات لجميع المشاريع
      performanceData = [
        {
          projectId: 1,
          projectName: "مشروع 1",
          plannedCompletion: 80,
          actualCompletion: 70,
          plannedCost: 1500000,
          actualCost: 1400000,
          variance: -5,
          lastUpdated: new Date().toLocaleDateString('ar-SA'),
        },
        {
          projectId: 2,
          projectName: "مشروع 2",
          plannedCompletion: 60,
          actualCompletion: 45,
          plannedCost: 800000,
          actualCost: 950000,
          variance: 18,
          lastUpdated: new Date().toLocaleDateString('ar-SA'),
        },
        {
          projectId: 3,
          projectName: "مشروع 3",
          plannedCompletion: 30,
          actualCompletion: 35,
          plannedCost: 2000000,
          actualCost: 1800000,
          variance: -10,
          lastUpdated: new Date().toLocaleDateString('ar-SA'),
        }
      ];
    }
    
    res.status(200).json(performanceData);
  });

  // نقطة نهاية وهمية لبيانات الجدول الزمني
  app.get("/api/project-timeline", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const timeframe = req.query.timeframe as string || 'month';
    
    if (!projectId) {
      return res.status(400).json({ message: "يجب تحديد المشروع" });
    }
    
    // بيانات وهمية للتطوير
    const timelineData = [];
    const days = timeframe === 'week' ? 7 : timeframe === 'month' ? 30 : timeframe === 'quarter' ? 90 : 365;
    const dataPoints = timeframe === 'week' ? days : 12;
    const step = Math.max(1, Math.floor(days / dataPoints));
    
    const today = new Date();
    
    for (let i = 0; i < dataPoints; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - (dataPoints - i - 1) * step);
      
      const planned = Math.min(100, Math.floor((i + 1) * (100 / dataPoints) + Math.random() * 5));
      const actual = Math.min(100, Math.max(0, planned - Math.floor(Math.random() * 20)));
      
      timelineData.push({
        date: date.toLocaleDateString('ar-SA'),
        plannedCompletion: planned,
        actualCompletion: actual,
      });
    }
    
    res.status(200).json(timelineData);
  });

  // نقطة نهاية وهمية لبيانات تكاليف المشروع
  app.get("/api/project-costs", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    
    if (!projectId) {
      return res.status(400).json({ message: "يجب تحديد المشروع" });
    }
    
    // بيانات وهمية للتطوير
    const costData = [
      { category: 'مواد', planned: 500000, actual: 530000 },
      { category: 'عمالة', planned: 300000, actual: 350000 },
      { category: 'معدات', planned: 200000, actual: 220000 },
      { category: 'إدارة', planned: 150000, actual: 180000 },
      { category: 'أخرى', planned: 50000, actual: 70000 },
    ];
    
    res.status(200).json(costData);
  });
  
  // نقاط نهاية لتقارير استخدام الموارد
  
  // بيانات استخدام الموارد
  app.get("/api/resource-usage", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const timeframe = req.query.timeframe as string || 'month';
    const resourceType = req.query.resourceType as string || 'all';
    
    let resourceData;
    
    if (resourceType === 'all') {
      resourceData = [
        { resourceType: 'معدات', allocation: 500000, usage: 450000, efficiency: 90, cost: 450000 },
        { resourceType: 'عمالة', allocation: 300000, usage: 280000, efficiency: 85, cost: 280000 },
        { resourceType: 'مواد', allocation: 400000, usage: 380000, efficiency: 95, cost: 380000 },
        { resourceType: 'نقل', allocation: 100000, usage: 90000, efficiency: 80, cost: 90000 },
        { resourceType: 'تشغيل', allocation: 150000, usage: 130000, efficiency: 85, cost: 130000 },
      ];
    } else if (resourceType === 'equipment') {
      resourceData = [
        { resourceType: 'حفارات', allocation: 150000, usage: 135000, efficiency: 90, cost: 135000 },
        { resourceType: 'رافعات', allocation: 120000, usage: 114000, efficiency: 95, cost: 114000 },
        { resourceType: 'شاحنات', allocation: 100000, usage: 85000, efficiency: 85, cost: 85000 },
        { resourceType: 'معدات خرسانة', allocation: 80000, usage: 72000, efficiency: 90, cost: 72000 },
        { resourceType: 'أخرى', allocation: 50000, usage: 44000, efficiency: 88, cost: 44000 },
      ];
    } else if (resourceType === 'labor') {
      resourceData = [
        { resourceType: 'مهندسين', allocation: 100000, usage: 95000, efficiency: 95, cost: 95000 },
        { resourceType: 'فنيين', allocation: 80000, usage: 76000, efficiency: 90, cost: 76000 },
        { resourceType: 'عمال', allocation: 60000, usage: 54000, efficiency: 85, cost: 54000 },
        { resourceType: 'سائقين', allocation: 40000, usage: 36000, efficiency: 90, cost: 36000 },
        { resourceType: 'أخرى', allocation: 20000, usage: 19000, efficiency: 80, cost: 19000 },
      ];
    } else if (resourceType === 'materials') {
      resourceData = [
        { resourceType: 'خرسانة', allocation: 150000, usage: 147000, efficiency: 98, cost: 147000 },
        { resourceType: 'حديد', allocation: 120000, usage: 114000, efficiency: 95, cost: 114000 },
        { resourceType: 'أخشاب', allocation: 50000, usage: 45000, efficiency: 90, cost: 45000 },
        { resourceType: 'طوب', allocation: 40000, usage: 38000, efficiency: 95, cost: 38000 },
        { resourceType: 'أخرى', allocation: 40000, usage: 36000, efficiency: 90, cost: 36000 },
      ];
    }
    
    res.status(200).json(resourceData);
  });
  
  // بيانات استخدام الموارد عبر الزمن
  app.get("/api/resource-time-usage", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const timeframe = req.query.timeframe as string || 'month';
    
    const data = [];
    let days = 0;
    
    switch (timeframe) {
      case 'week':
        days = 7;
        break;
      case 'month':
        days = 30;
        break;
      case 'quarter':
        days = 90;
        break;
      case 'year':
        days = 365;
        break;
      default:
        days = 30;
    }
    
    const dataPoints = timeframe === 'week' ? days : 12;
    const step = Math.max(1, Math.floor(days / dataPoints));
    
    const today = new Date();
    
    for (let i = 0; i < dataPoints; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - (dataPoints - i - 1) * step);
      
      const equipmentUsage = Math.floor(Math.random() * 100000) + 50000;
      const laborUsage = Math.floor(Math.random() * 50000) + 30000;
      const materialsUsage = Math.floor(Math.random() * 80000) + 40000;
      
      data.push({
        date: date.toLocaleDateString('ar-SA'),
        equipment: equipmentUsage,
        labor: laborUsage,
        materials: materialsUsage,
      });
    }
    
    res.status(200).json(data);
  });
  
  // بيانات استخدام الموارد حسب المشروع
  app.get("/api/resource-project-usage", async (req: Request, res: Response) => {
    const timeframe = req.query.timeframe as string || 'month';
    
    // الحصول على المشاريع من قاعدة البيانات
    const projects = await storage.listProjects();
    
    const data = projects.map(project => ({
      projectName: project.name,
      equipment: Math.floor(Math.random() * 200000) + 50000,
      labor: Math.floor(Math.random() * 150000) + 50000,
      materials: Math.floor(Math.random() * 250000) + 100000,
    }));
    
    if (!data.length) {
      // إذا لم تكن هناك مشاريع، قم بإرجاع بيانات افتراضية
      res.status(200).json([
        { projectName: 'مشروع 1', equipment: 200000, labor: 150000, materials: 250000 },
        { projectName: 'مشروع 2', equipment: 150000, labor: 120000, materials: 180000 },
        { projectName: 'مشروع 3', equipment: 100000, labor: 80000, materials: 120000 },
      ]);
    } else {
      res.status(200).json(data);
    }
  });
  
  // بيانات كفاءة استخدام الموارد
  app.get("/api/resource-efficiency", (req: Request, res: Response) => {
    const projectId = req.query.projectId ? parseInt(req.query.projectId as string) : undefined;
    const timeframe = req.query.timeframe as string || 'month';
    
    const efficiencyData = [
      { resource: 'معدات', efficiency: 90, ideal: 100 },
      { resource: 'عمالة', efficiency: 85, ideal: 100 },
      { resource: 'مواد', efficiency: 95, ideal: 100 },
      { resource: 'نقل', efficiency: 80, ideal: 100 },
      { resource: 'تشغيل', efficiency: 85, ideal: 100 },
    ];
    
    res.status(200).json(efficiencyData);
  });

  // واجهات API لتقارير حالة المشاريع
  app.get("/api/projects-status", (req: Request, res: Response) => {
    // سيتم استبدال هذه البيانات بتكامل حقيقي مع قاعدة البيانات
    const data = [
      {
        projectName: 'مشروع إنشاء مبنى سكني',
        status: 'inProgress' as const,
        progress: 65,
        startDate: '2024-01-15',
        endDate: '2024-08-30',
        daysLeft: 152,
        budget: 1500000,
        spent: 950000,
        budgetVariance: 550000,
        tasks: {
          completed: 48,
          inProgress: 15,
          notStarted: 22,
          total: 85
        },
        team: {
          assigned: 24,
          active: 18
        },
        risk: 'medium'
      },
      {
        projectName: 'تطوير البنية التحتية للطرق',
        status: 'inProgress' as const,
        progress: 35,
        startDate: '2024-02-01',
        endDate: '2024-10-15',
        daysLeft: 198,
        budget: 3500000,
        spent: 1200000,
        budgetVariance: 2300000,
        tasks: {
          completed: 22,
          inProgress: 18,
          notStarted: 45,
          total: 85
        },
        team: {
          assigned: 35,
          active: 30
        },
        risk: 'low'
      },
      {
        projectName: 'إنشاء محطة توليد كهرباء',
        status: 'delayed' as const,
        progress: 40,
        startDate: '2023-11-01',
        endDate: '2024-09-30',
        daysLeft: 182,
        budget: 8500000,
        spent: 4600000,
        budgetVariance: 3900000,
        tasks: {
          completed: 38,
          inProgress: 22,
          notStarted: 30,
          total: 90
        },
        team: {
          assigned: 45,
          active: 38
        },
        risk: 'high'
      }
    ];

    // تصفية حسب حالة المشروع إذا تم تحديدها
    const statusFilter = req.query.statusFilter as string;
    if (statusFilter && statusFilter !== 'all') {
      return res.json(data.filter(project => project.status === statusFilter));
    }
    
    res.json(data);
  });

  app.get("/api/project-statistics", (req: Request, res: Response) => {
    const data = [
      { category: 'نشط', value: 2 },
      { category: 'متأخر', value: 2 },
      { category: 'مكتمل', value: 1 },
      { category: 'متوقف', value: 1 },
      { category: 'تخطيط', value: 1 },
    ];
    
    res.json(data);
  });

  app.get("/api/project-risks", (req: Request, res: Response) => {
    // الحصول على معلمة المشروع من الاستعلام
    const projectId = req.query.selectedProject as string;
    
    // إذا تم تحديد مشروع معين، قم بتخصيص بيانات المخاطر له
    if (projectId && projectId !== 'all') {
      // استخدام معرف المشروع لتوليد قيم مختلفة لكل مشروع
      const id = parseInt(projectId);
      const riskOffset = (id % 3) * 10; // 0, 10 أو 20 اعتمادًا على معرف المشروع
      const riskMultiplier = (id % 2) === 0 ? 1.1 : 0.9; // زيادة أو تقليل المخاطر بنسبة 10%
      
      const data = [
        { category: 'مخاطر مالية', value: Math.min(100, Math.round((65 + riskOffset) * riskMultiplier)), fullMark: 100 },
        { category: 'مخاطر فنية', value: Math.min(100, Math.round((45 + riskOffset) * riskMultiplier)), fullMark: 100 },
        { category: 'مخاطر الجدول الزمني', value: Math.min(100, Math.round((70 + riskOffset) * riskMultiplier)), fullMark: 100 },
        { category: 'مخاطر الموارد', value: Math.min(100, Math.round((55 + riskOffset) * riskMultiplier)), fullMark: 100 },
        { category: 'مخاطر أصحاب المصلحة', value: Math.min(100, Math.round((40 + riskOffset) * riskMultiplier)), fullMark: 100 },
        { category: 'مخاطر قانونية', value: Math.min(100, Math.round((30 + riskOffset) * riskMultiplier)), fullMark: 100 },
      ];
      
      res.json(data);
    } else {
      // البيانات الافتراضية لجميع المشاريع
      const data = [
        { category: 'مخاطر مالية', value: 65, fullMark: 100 },
        { category: 'مخاطر فنية', value: 45, fullMark: 100 },
        { category: 'مخاطر الجدول الزمني', value: 70, fullMark: 100 },
        { category: 'مخاطر الموارد', value: 55, fullMark: 100 },
        { category: 'مخاطر أصحاب المصلحة', value: 40, fullMark: 100 },
        { category: 'مخاطر قانونية', value: 30, fullMark: 100 },
      ];
      
      res.json(data);
    }
  });

  app.get("/api/task-progress", (req: Request, res: Response) => {
    // الحصول على معلمة الإطار الزمني
    const timeframe = req.query.timeframe as string || 'month';
    
    // الحصول على المشاريع الحالية
    const projects = storage.listProjects();
    
    // توليد بيانات مخصصة لتقدم المهام بناءً على المشاريع الحقيقية
    const generateTaskData = async () => {
      const result = [];
      const projectList = await projects;
      
      // اختر أقرب خمسة مشاريع إذا كانت هناك مشاريع كافية
      const selectedProjects = projectList.slice(0, 5);
      
      for (const project of selectedProjects) {
        // تطبيق عامل تغيير بناءً على الإطار الزمني
        let timeFactor = 1;
        switch (timeframe) {
          case 'week':
            timeFactor = 0.6; // تقدم أقل في الأسبوع
            break;
          case 'month':
            timeFactor = 1;
            break;
          case 'quarter':
            timeFactor = 1.5; // تقدم أكبر في الربع السنوي
            break;
          case 'year':
            timeFactor = 2.2; // تقدم أكبر في السنة
            break;
        }
        
        // حساب التقدم بناءً على معرف المشروع
        const baseCompleted = 15 + (project.id % 5) * 8;
        const baseInProgress = 8 + (project.id % 3) * 5;
        const baseNotStarted = 20 + (project.id % 4) * 10;
        
        // تطبيق عامل الوقت وضمان أن الأرقام صحيحة
        const completed = Math.round(baseCompleted * timeFactor);
        const inProgress = Math.round(baseInProgress);
        const notStarted = Math.max(5, Math.round(baseNotStarted / timeFactor));
        
        result.push({
          projectName: project.name,
          completed,
          inProgress,
          notStarted
        });
      }
      
      // إذا لم تكن هناك مشاريع كافية، أضف بيانات إضافية
      if (result.length < 5) {
        const defaultProjects = [
          { projectName: 'مشروع إنشاء مبنى سكني', completed: 48, inProgress: 15, notStarted: 22 },
          { projectName: 'تطوير البنية التحتية للطرق', completed: 22, inProgress: 18, notStarted: 45 },
          { projectName: 'إنشاء محطة توليد كهرباء', completed: 38, inProgress: 22, notStarted: 30 },
          { projectName: 'تطوير نظام مياه', completed: 25, inProgress: 10, notStarted: 15 },
          { projectName: 'إنشاء مركز تسوق', completed: 8, inProgress: 15, notStarted: 82 },
        ];
        
        for (let i = result.length; i < 5; i++) {
          result.push(defaultProjects[i]);
        }
      }
      
      return result;
    };
    
    // استدعاء وظيفة توليد البيانات وإرسالها
    generateTaskData()
      .then(data => res.json(data))
      .catch(error => {
        console.error("Error generating task progress data:", error);
        res.status(500).json({ error: "Failed to generate task progress data" });
      });
  });
  
  app.get("/api/budget-timeline", (req: Request, res: Response) => {
    // الحصول على معلمات الاستعلام
    const projectId = req.query.selectedProject as string;
    const timeframe = req.query.timeframe as string || 'month';
    
    // قم بتحديد عدد الأشهر بناءً على الإطار الزمني
    let monthCount = 6;
    switch (timeframe) {
      case 'week':
        monthCount = 1;
        break;
      case 'month':
        monthCount = 3;
        break;
      case 'quarter':
        monthCount = 6;
        break;
      case 'year':
        monthCount = 12;
        break;
    }
    
    // إنشاء بيانات مخصصة بناءً على المعلمات
    const data = [];
    const currentDate = new Date();
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    
    const multiplier = projectId && projectId !== 'all' ? parseInt(projectId) % 5 + 1 : 1;
    
    for (let i = 0; i < monthCount; i++) {
      const monthIndex = (currentDate.getMonth() - monthCount + i + 12) % 12;
      const baseAmount = 500000 + (monthIndex * 50000);
      const plannedAmount = baseAmount * multiplier;
      const actualAmount = plannedAmount * (0.9 + Math.random() * 0.2); // 90% to 110% of planned
      
      data.push({
        month: months[monthIndex],
        planned: Math.round(plannedAmount),
        actual: Math.round(actualAmount)
      });
    }
    
    res.json(data);
  });

  // واجهات API للتقارير المالية
  app.get("/api/financial/revenue-expenses", (req: Request, res: Response) => {
    const timeframe = req.query.timeframe as string || 'year';
    let months = 12;
    
    if (timeframe === 'quarter') {
      months = 3;
    } else if (timeframe === 'all') {
      months = 24;
    }
    
    const today = new Date();
    const monthNames = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    const data = [];
    
    for (let i = months - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setMonth(today.getMonth() - i);
      
      const monthName = monthNames[date.getMonth()];
      
      // توليد بيانات عشوائية
      const revenue = Math.floor(Math.random() * 500000) + 1000000;
      const expenses = Math.floor(Math.random() * 400000) + 800000;
      const profit = revenue - expenses;
      
      data.push({
        month: monthName,
        revenue,
        expenses,
        profit,
      });
    }
    
    res.json(data);
  });

  app.get("/api/financial/expense-categories", (req: Request, res: Response) => {
    const data = [
      { category: 'المواد والخامات', value: 625000 },
      { category: 'رواتب ومكافآت', value: 950000 },
      { category: 'معدات وآلات', value: 350000 },
      { category: 'مصاريف إدارية', value: 220000 },
      { category: 'نقل ومواصلات', value: 180000 },
      { category: 'تشغيل وصيانة', value: 140000 },
      { category: 'أخرى', value: 85000 },
    ];
    
    res.json(data);
  });

  app.get("/api/financial/project-financials", (req: Request, res: Response) => {
    const data = [
      { projectName: 'مشروع إنشاء مبنى سكني', budget: 1500000, spent: 950000, revenue: 1800000, profit: 850000 },
      { projectName: 'تطوير البنية التحتية للطرق', budget: 3500000, spent: 1200000, revenue: 4200000, profit: 3000000 },
      { projectName: 'إنشاء محطة توليد كهرباء', budget: 8500000, spent: 4600000, revenue: 9500000, profit: 4900000 },
      { projectName: 'تجديد مبنى إداري', budget: 750000, spent: 720000, revenue: 900000, profit: 180000 },
      { projectName: 'تطوير نظام مياه', budget: 2200000, spent: 980000, revenue: 2500000, profit: 1520000 },
    ];
    
    res.json(data);
  });

  app.get("/api/financial/cash-flow", (req: Request, res: Response) => {
    const timeframe = req.query.timeframe as string || 'year';
    let months = 12;
    
    if (timeframe === 'quarter') {
      months = 3;
    } else if (timeframe === 'all') {
      months = 24;
    }
    
    const today = new Date();
    const monthNames = [
      'يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    const data = [];
    let balance = 1000000; // رصيد افتتاحي
    
    for (let i = months - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setMonth(today.getMonth() - i);
      
      const monthName = monthNames[date.getMonth()];
      
      // توليد بيانات عشوائية
      const inflow = Math.floor(Math.random() * 500000) + 800000;
      const outflow = Math.floor(Math.random() * 400000) + 700000;
      
      // تحديث الرصيد
      balance = balance + inflow - outflow;
      
      data.push({
        month: monthName,
        inflow,
        outflow,
        balance,
      });
    }
    
    res.json(data);
  });

  // إنشاء الخادم HTTP
  // ========================
  // مخاطر المشروع
  // ========================
  
  // جلب المخاطر لمشروع محدد
  app.get("/api/projects/:projectId/risks", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const risks = await storage.getProjectRisksByProject(projectId);
      res.json(risks);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب مخاطر المشروع' });
    }
  });
  
  // إنشاء مخاطرة جديدة
  app.post("/api/project-risks", async (req: Request, res: Response) => {
    try {
      const validatedData = insertProjectRiskSchema.parse(req.body);
      const risk = await storage.createProjectRisk(validatedData);
      res.status(201).json(risk);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating project risk:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء المخاطرة' });
      }
    }
  });
  
  // تحديث مخاطرة
  app.patch("/api/project-risks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedRisk = await storage.updateProjectRisk(id, req.body);
      if (!updatedRisk) {
        return res.status(404).json({ error: 'المخاطرة غير موجودة' });
      }
      res.json(updatedRisk);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء تحديث المخاطرة' });
    }
  });
  
  // ========================
  // فريق العمل
  // ========================
  
  // جلب أعضاء فريق العمل
  app.get("/api/team-members", async (req: Request, res: Response) => {
    try {
      const teamMembers = await storage.listTeamMembers();
      res.json(teamMembers);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب أعضاء فريق العمل' });
    }
  });
  
  // جلب تعيينات فريق العمل لمشروع محدد
  app.get("/api/projects/:projectId/team-assignments", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const assignments = await storage.getTeamAssignmentsByProject(projectId);
      res.json(assignments);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب تعيينات فريق العمل' });
    }
  });
  
  // إنشاء عضو فريق جديد
  app.post("/api/team-members", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTeamMemberSchema.parse(req.body);
      const member = await storage.createTeamMember(validatedData);
      res.status(201).json(member);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating team member:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء عضو فريق العمل' });
      }
    }
  });
  
  // إنشاء تعيين فريق جديد
  app.post("/api/team-assignments", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTeamAssignmentSchema.parse(req.body);
      const assignment = await storage.createTeamAssignment(validatedData);
      res.status(201).json(assignment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating team assignment:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء تعيين فريق العمل' });
      }
    }
  });
  
  // ========================
  // المعدات والآلات
  // ========================
  
  // جلب المعدات
  app.get("/api/equipment", async (req: Request, res: Response) => {
    try {
      const equipment = await storage.listEquipment();
      res.json(equipment);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب المعدات' });
    }
  });
  
  // جلب المعدات لمشروع محدد
  app.get("/api/projects/:projectId/equipment", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const equipment = await storage.getEquipmentByProject(projectId);
      res.json(equipment);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب معدات المشروع' });
    }
  });
  
  // إنشاء معدة جديدة
  app.post("/api/equipment", async (req: Request, res: Response) => {
    try {
      // تعديل اسم الحقل من projectId إلى currentProjectId إذا وجد
      let data = req.body;
      if (data.projectId !== undefined) {
        data.currentProjectId = data.projectId;
        delete data.projectId;
      }
      
      const validatedData = insertEquipmentSchema.parse(data);
      const equipment = await storage.createEquipment(validatedData);
      res.status(201).json(equipment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating equipment:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إضافة معدة جديدة' });
      }
    }
  });

  // تحديث معدة
  app.put("/api/equipment/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const equipment = await storage.getEquipment(id);
      
      if (!equipment) {
        return res.status(404).json({ error: 'لم يتم العثور على المعدة' });
      }
      
      // تعديل اسم الحقل من projectId إلى currentProjectId إذا وجد
      let validatedData = req.body;
      if (validatedData.projectId !== undefined) {
        validatedData.currentProjectId = validatedData.projectId;
        delete validatedData.projectId;
      }
      
      validatedData = insertEquipmentSchema.partial().parse(validatedData);
      const updatedEquipment = await storage.updateEquipment(id, validatedData);
      
      res.json(updatedEquipment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error updating equipment:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء تحديث المعدة' });
      }
    }
  });
  
  // ========================
  // المستندات
  // ========================
  
  // جلب مستندات مشروع محدد
  app.get("/api/projects/:projectId/documents", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const documents = await storage.getDocumentsByProject(projectId);
      res.json(documents);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب مستندات المشروع' });
    }
  });
  
  // إنشاء مستند جديد
  app.post("/api/documents", async (req: Request, res: Response) => {
    try {
      const validatedData = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(validatedData);
      res.status(201).json(document);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating document:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إضافة مستند جديد' });
      }
    }
  });
  
  // ========================
  // التقارير اليومية
  // ========================
  
  // جلب التقارير اليومية لمشروع محدد
  app.get("/api/projects/:projectId/daily-reports", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const reports = await storage.getDailyReportsByProject(projectId);
      res.json(reports);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب التقارير اليومية' });
    }
  });
  
  // إنشاء تقرير يومي جديد
  app.post("/api/daily-reports", async (req: Request, res: Response) => {
    try {
      const validatedData = insertDailyReportSchema.parse(req.body);
      const report = await storage.createDailyReport(validatedData);
      res.status(201).json(report);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating daily report:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء تقرير يومي جديد' });
      }
    }
  });
  
  // ========================
  // المواعيد النهائية
  // ========================
  
  // جلب المواعيد النهائية لمشروع محدد
  app.get("/api/projects/:projectId/deadlines", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const deadlines = await storage.getDeadlinesByProject(projectId);
      res.json(deadlines);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب المواعيد النهائية' });
    }
  });
  
  // إنشاء موعد نهائي جديد
  app.post("/api/deadlines", async (req: Request, res: Response) => {
    try {
      const validatedData = insertDeadlineSchema.parse(req.body);
      const deadline = await storage.createDeadline(validatedData);
      res.status(201).json(deadline);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating deadline:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء موعد نهائي جديد' });
      }
    }
  });
  
  // ========================
  // المصروفات
  // ========================
  
  // جلب مصروفات مشروع محدد
  app.get("/api/projects/:projectId/expenses", async (req: Request, res: Response) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const expenses = await storage.getExpensesByProject(projectId);
      res.json(expenses);
    } catch (err) {
      res.status(500).json({ error: 'حدثت مشكلة أثناء جلب مصروفات المشروع' });
    }
  });
  
  // إنشاء مصروف جديد
  app.post("/api/expenses", async (req: Request, res: Response) => {
    try {
      const validatedData = insertExpenseSchema.parse(req.body);
      const expense = await storage.createExpense(validatedData);
      res.status(201).json(expense);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ error: 'البيانات المرسلة غير صحيحة', details: err.errors });
      } else {
        console.error('Error creating expense:', err);
        res.status(500).json({ error: 'حدثت مشكلة أثناء إنشاء مصروف جديد' });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}